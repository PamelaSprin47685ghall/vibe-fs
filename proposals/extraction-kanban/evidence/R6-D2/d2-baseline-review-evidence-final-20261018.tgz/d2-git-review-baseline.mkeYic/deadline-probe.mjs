import assert from 'node:assert/strict'
import { execFile } from 'node:child_process'
import { existsSync, mkdtempSync, rmSync } from 'node:fs'
import { join } from 'node:path'

const scratch = mkdtempSync('/private/tmp/d2-exec-deadline.')
const observe = ignore => new Promise(resolve => {
  const start = performance.now()
  const marker = join(scratch, ignore ? 'ignored-completed' : 'normal-completed')
  const source = `import { writeFileSync } from 'node:fs'; ${ignore ? "process.on('SIGTERM', () => {});" : ''} writeFileSync(1, 'ready\\n'); setTimeout(() => { writeFileSync(${JSON.stringify(marker)}, 'late-completion'); process.exit(0) }, 1200);`
  let ready = false
  const child = execFile(process.execPath, ['--input-type=module', '-e', source], { encoding: 'buffer', timeout: 400, killSignal: 'SIGTERM' }, (error, stdout, stderr) => resolve({
    ignore,
    elapsedMs: performance.now() - start,
    ready,
    error: error ? { code: error.code, signal: error.signal, killed: error.killed, message: error.message } : null,
    stdout: Buffer.from(stdout).toString(),
    stderr: Buffer.from(stderr).toString(),
    lateCompletionFile: existsSync(marker),
  }))
  child.stdout.on('data', bytes => { if (bytes.includes(Buffer.from('ready'))) ready = true })
})

try {
  const normal = await observe(false)
  const ignored = await observe(true)
  assert.equal(normal.ready, true)
  assert.equal(ignored.ready, true)
  assert.equal(normal.error.signal, 'SIGTERM')
  assert.equal(normal.lateCompletionFile, false)
  assert.equal(ignored.lateCompletionFile, true)
  assert.ok(ignored.elapsedMs > 1000)
  console.log(JSON.stringify({ runtime: process.versions.bun ?? process.version, normal, ignored }, null, 2))
} finally {
  rmSync(scratch, { recursive: true, force: true })
}
