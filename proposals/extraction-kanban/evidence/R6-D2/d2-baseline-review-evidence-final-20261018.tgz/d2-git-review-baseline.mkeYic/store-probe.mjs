import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { spawnSync } from 'node:child_process'
import { chmodSync, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'

const packageRoot = '/private/tmp/d2-git-review-baseline.mkeYic/package'
const load = relative => import(pathToFileURL(join(packageRoot, relative)).href)
const rawModule = await load('dist/Persistence/EventStore/ProcessGitRawStore.js')
const database = await load('dist/Persistence/EventStore/GitObjectDatabase.js')
const gitTypes = await load('dist/Persistence/EventStore/GitTypes.js')
const { ofArray } = await load('dist/fable_modules/fable-library-js.5.13.0/List.js')
const watched = ['dist/Persistence/EventStore/ProcessGitRawStore.js', 'dist/Persistence/EventStore/GitObjectDatabase.js']
const digest = file => createHash('sha256').update(readFileSync(join(packageRoot, file))).digest('hex')
const before = watched.map(file => [file, digest(file)])
const scratch = mkdtempSync('/private/tmp/d2-store-probe.')
const observations = []
const git = (args, input) => {
  const result = spawnSync('git', ['-C', scratch, ...args], { input, encoding: null, timeout: 5000 })
  assert.equal(result.error, undefined)
  assert.equal(result.signal, null)
  return result
}
const oid = value => gitTypes.GitObjectIdModule_create(value)
const value = gitTypes.GitObjectIdModule_value

try {
  assert.equal(git(['init', '--quiet']).status, 0)
  const raw = rawModule.ProcessGitRawStoreModule_create(scratch)
  const bytes = Buffer.from([0xff, 0x00, 0x80, 0xfe, 0x41])
  const written = await raw.WriteBlob(bytes)
  const nativeOid = git(['hash-object', '--stdin'], bytes).stdout.toString().trim()
  assert.equal(value(written), nativeOid)
  assert.deepEqual(Buffer.from(await raw.ReadObject(written)), bytes)
  observations.push({ kind: 'loose-binary-blob-positive', oid: nativeOid, bytes: bytes.toString('hex') })

  const name = '汉字-é.bin'
  const tree = await raw.WriteTree(ofArray([new gitTypes.TreeEntry('100644', name, written)]))
  const nativeTree = git(['mktree'], Buffer.from(`100644 blob ${nativeOid}\t${name}\n`))
  assert.equal(nativeTree.status, 0)
  const expected = nativeTree.stdout.toString().trim()
  assert.notEqual(value(tree), expected)
  const actualTree = git(['ls-tree', '-z', value(tree)])
  assert.equal(actualTree.status, 0)
  const actualTreeBytes = actualTree.stdout
  const actualNameBytes = actualTreeBytes.subarray(actualTreeBytes.indexOf(9) + 1, -1)
  assert.notEqual(actualNameBytes.toString('hex'), Buffer.from(name).toString('hex'))
  observations.push({ kind: 'unicode-tree-name-uses-latin1', expectedName: name, expectedNameHex: Buffer.from(name).toString('hex'), actualNameHex: actualNameBytes.toString('hex'), expectedTree: expected, actualTree: value(tree) })

  const refParent = join(scratch, '.git', 'refs', 'wanxiang')
  mkdirSync(refParent, { recursive: true })
  const missingRef = await raw.ReadRef('refs/wanxiang/store')
  const nativeMissingRef = git(['rev-parse', '--verify', '--quiet', 'refs/wanxiang/store'])
  assert.equal(missingRef, undefined)
  assert.equal(nativeMissingRef.status, 1)
  observations.push({ kind: 'valid-missing-ref-positive', productResult: null, nativeCode: nativeMissingRef.status })
  writeFileSync(join(refParent, 'store'), 'malformed-existing-ref\n')
  const malformed = await raw.ReadRef('refs/wanxiang/store')
  const nativeRef = git(['show-ref', '--verify', 'refs/wanxiang/store'])
  assert.equal(malformed, undefined)
  assert.notEqual(nativeRef.status, 0)
  observations.push({ kind: 'malformed-existing-ref-becomes-missing', productResult: null, nativeCode: nativeRef.status, nativeStderr: nativeRef.stderr.toString() })

  const objectPrefix = join(scratch, '.git', 'objects', nativeOid.slice(0, 2))
  chmodSync(objectPrefix, 0)
  try {
    assert.throws(() => readFileSync(join(objectPrefix, nativeOid.slice(2))), error => error.code === 'EACCES')
    const coldRaw = rawModule.ProcessGitRawStoreModule_create(scratch)
    const inaccessible = await coldRaw.ReadObject(written)
    assert.equal(inaccessible, undefined)
    observations.push({ kind: 'inaccessible-existing-object-becomes-missing', productResult: null, permissionFailureConfirmed: 'EACCES' })
  } finally {
    chmodSync(objectPrefix, 0o755)
  }

  rmSync(join(refParent, 'store'))
  chmodSync(refParent, 0o500)
  try {
    assert.throws(() => writeFileSync(join(refParent, 'permission-positive'), ''), error => error.code === 'EACCES')
    const swapped = await database.compareAndSwapRef(join(scratch, '.git'), 'refs/wanxiang/store', undefined, nativeOid)
    assert.equal(swapped, false)
    assert.equal(existsSync(join(refParent, 'store')), false)
    observations.push({ kind: 'ref-lock-permission-failure-becomes-cas-false', productResult: swapped, permissionFailureConfirmed: 'EACCES' })
  } finally {
    chmodSync(refParent, 0o755)
  }

  for (const method of ['ReadObject', 'ReadTree', 'ReadRef', 'WriteBlob']) {
    const calls = []
    const runner = async ([args, stdin]) => {
      const argv = [...args]
      calls.push({ argv, stdin: stdin ? Buffer.from(stdin).toString('hex') : null })
      if (argv[0] === 'hash-object') return [0, Buffer.from(`${'a'.repeat(40)}\n`), '']
      return [143, Buffer.alloc(0), 'controlled execution receipt missing']
    }
    const controlled = rawModule.ProcessGitRawStoreModule_createWithRunner(join(scratch, method), runner)
    const result = method === 'WriteBlob' ? await controlled.WriteBlob(bytes) : method === 'ReadRef' ? await controlled.ReadRef('refs/wanxiang/store') : await controlled[method](oid('b'.repeat(40)))
    if (method === 'WriteBlob') {
      assert.equal(value(result), 'a'.repeat(40))
      assert.equal(calls.at(-1).argv[0], 'hash-object')
    } else assert.equal(result, undefined)
    observations.push({ kind: 'controlled-failure-propagation-old-result', method, result: method === 'WriteBlob' ? value(result) : null, calls })
  }

  assert.deepEqual(watched.map(file => [file, digest(file)]), before)
  console.log(JSON.stringify({ runtime: process.versions.bun ? `Bun ${process.versions.bun}` : `Node ${process.version}`, observations, unchangedProduct: before }, null, 2))
} finally {
  rmSync(scratch, { recursive: true, force: true })
}
