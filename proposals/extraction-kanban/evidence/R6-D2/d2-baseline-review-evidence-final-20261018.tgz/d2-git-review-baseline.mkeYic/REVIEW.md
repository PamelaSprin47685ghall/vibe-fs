# D2 baseline and boundary review

Read AGENTS.md, UPSTREAM-DELIVERY-CHECKLIST.md and CARDS.md before this review. The baseline is frozen main candidate 652, archive SHA-256 `003bc8818969597f9afd6a1c0767c7aae271dd53e5f0392b146367d156ec3887`, and wanxiangli `df14f48 / 0.6.8`. This is investigation and prototype evidence, not D2 delivery or a replacement for the four delivery evidence classes. No shared production source was edited.

## Actual consumer chains

1. `resources/git/wanxiang-hook.mjs` -> `Git/Hook/Sync.fs` (`runPrePush` / committed `runReferenceTransaction`) -> `ProcessGitRawStore.create` and `GitGateway.converge`. Gateway uses `ReadRef` only for the non-authoritative tracking-ref optimization, then calls WriterStreamSync for object reads/materialization, and D1's text runner for transport.
2. `WriterStreamSync.materializeLocalAt` -> changed writer-segment `WriteBlob` -> writer-tree `WriteTree` -> manifest `WriteBlob` -> root `WriteTree` -> materialization cache. A failed operation must stop later writes and publication. Existing permitted retention deletion/segment reorganization may already have happened; a subsequent Git error must not claim that nothing changed locally.
3. `WriterStreamSync.readRemoteStreamsAt` / `syncWriterStreamsAt` -> root/writer `ReadTree`, manifest/writer `ReadObject` -> strict manifest/canonical/union validation -> local writer import under the existing store lock -> materialization. Unknown reads must not become missing/legacy/empty remote input. Valid local imports before a later materialization failure remain valid local writer truth.
4. `RetentionSurface.syncAt` / segment-cap wrapper uses the same concrete raw store for requirement verification. `writerSyncAdapterScenario` supplies an in-memory physical port; it is not a separate production store algorithm.
5. `WorkspaceEventStore` -> `EventStore.createLocal` -> ProcessEventLog is the product append/replay path. It never constructs GitRawStore. The current sources and durable-events-017 require zero Git capability/I/O on append; durable-events-011 requires no loose Git objects from runtime append. Journal's WriteBlob is local inline payload handling and is unrelated to GitRawRunner.

No production caller invokes `IGitRawStore.CompareAndSwapRef`. Its only other implementations are RetentionSurface's controlled port and process-execution-012's compiler fixture. Remote CAS remains owned by Gateway's real `push --force-with-lease`, not this unused direct-ref operation. A ref receipt is not the local NDJSON COMMIT witness.

## Minimal contract / responsibility direction

Reuse ProgramEnd, EndEvidence, StopRequest and NoExecution from the bounded pure process vocabulary. Binary input/output must remain bytes; do not wrap the text runner or reconstruct bytes from strings. Preserve known target end independently from stop requests, capture faults and missing receipts. An error object without a numeric status is not exit 1, callback success alone is not proof that no deadline request occurred, and supervisor exit must not substitute for target exit.

Make IGitRawStore results explicit: writes return `Result<oid, failure>`; reads return `Result<option<value>, failure>`. None means an explicitly observed valid missing result. Put the result/failure capability in the physical Git contract, and retain the business EventStore.Port/Model/EventVocabulary closure without physical Git/runtime dependencies. All production result migrations are contained in WriterStreamSync and Gateway, plus Hook/Retention wiring and the compiler fixtures.

Delete GitObjectDatabase and its project inputs, the unused CAS capability/implementations, layout-answer global cache, failed-layout fallbacks, optional row-skipping parser and scalar status default. Let real Git own loose/packed formats, hashes, ref validation and locks. Keep the existing changed-file stat/OID cache and instance immutable caches; do not cache failures or convert malformed output into absence. Use binary stdin with NUL-delimited tree plumbing and explicit missing-object responses. A normal nonzero process result is still command-specific; do not classify every cat-file exit 128 as absence.

The direct ODB performance fence is historical: its 24-spawn append measurement describes a retired path. No current WHAT promises direct ODB writes. durable-convergence-010 instead requires clean no-op zero transport and changed-file work; those obligations survive this simplification. Compare the final actual pre-push process for clean, one changed segment, and multiple writers against the same private bare remote, recording Git launches, wall time and exact retained facts. Do not infer final Hook cost from a library-only median.

## Baseline defects and attribution

Both ProcessGitRawStore.fs and GitObjectDatabase.fs are byte-identical between D1 input `25651051f` and this review. Their SHA-256 values are respectively `6cc71cd902ab9a250833c229e0bc523d6a2fb394999297d978efc5a1971f8066` and `7f433f7f6895b76b3b3c94211b95856df4bd82782a17a23c7a6f9a5b75aa6b47`. The following are pre-D1 defects, not D1 regressions:

- Native error.code 128/7 becomes 1 because the callback adapter reads error.status.
- Failed binary stdout is dropped because it reads error.stdout instead of callback stdout; successful stderr is always discarded.
- Async execFile options.input does not supply stdin. A real Git hash-object stalls until timeout; explicit child.stdin.end with the same bytes succeeds.
- Layout query failure falls back to more commands, including writes. Read errors become None; malformed existing refs and inaccessible existing objects also become None. Ref-lock EACCES becomes CAS false.
- Loose tree names use Latin-1 while the CLI and reader use UTF-8. `汉字-é.bin` becomes bytes `49572de92e62696e` rather than `e6b189e5ad972dc3a92e62696e`, with a different real Git tree OID.
- Native execFile timeout only requests SIGTERM. A target ignoring TERM wrote its private completion marker after the deadline and returned callback error=null about 1.24 seconds after a 400ms timeout. The product's 120s path was not allowed to hang during this review; this is a bounded native API counterexample.

`native-probe.mjs` has four groups and seven actual Git executions per runtime, three through the fixed package's default runner and four native controls. `store-probe.mjs` has ten groups, mixing actual Git/filesystem evidence with four controlled old-tuple failure cases; its injected cases are not real physical failures. `deadline-probe.mjs` has two actual targets per runtime. These are bounded review observations, not formal requirement counts or a complete delivery acceptance.

The initial emoji tree probe did not check ls-tree's exit code; its empty stdout is not evidence of an empty filename. It is preserved separately. The final non-ASCII example checks successful ls-tree before comparing exact bytes. The first deadline probe incorrectly expected stdout to remain writable after execFile had destroyed its pipe; the final probe uses a private file witness. Those harness mistakes are not product failures.

## Supervised binary prototype: one unresolved prerequisite

Exact 0.6.8 SupervisedProcess can preserve binary channels and write multiple chunks without changing the text protocol. The final Node prototype sent 33,554,449 bytes as 16MiB/16MiB/17, read them back exactly, and completed 15 owned supervisor sessions. Twelve ordinary Git pairs measured median 10.79ms native vs 52.84ms supervised in this local sample. A 500ms deadline returned at about 511ms with the truthful `Unconfirmed / UNKNOWN_TARGET_EXIT` after group KILL, while supervisor handles closed. The owned target PID was absent at the final read-only cleanup check; this does not supply the lost target exit receipt or prove every process tree ended. Original earlier samples remain in node.log; use node-final.log for the final frozen prototype source.

Bun 1.3.14 fails this proposed path on 0.6.8: a fresh 16MiB write returned Unknown for a short FileSink count, and a separate fresh 64KiB scheme eventually returned Unknown for a zero count. Neither failed write was resent. The source count guard was introduced by the earlier repair `ca238c0` (0.6.6), not by the original split or this D1 change. It must be recorded as a previous-repair issue.

The direct native FileSink control sends the complete 33,554,449 bytes after write + awaited flush + end in four combinations (16MiB/64KiB, fast Git/200ms delayed reader), despite write counts smaller than requested. Actual target hashes agree; adding write/flush counts does not reconstruct byte length. The library rejects before awaiting flush. Bun's official [FileSink reference](https://bun.com/reference/bun/FileSink) documents buffering and flush completion. Fix this shared native input interpretation and retain broken-pipe/unknown negative controls before claiming Bun D2 feasible. Do not hide it with smaller chunks or reopen deferred R12 natural Unknown.
