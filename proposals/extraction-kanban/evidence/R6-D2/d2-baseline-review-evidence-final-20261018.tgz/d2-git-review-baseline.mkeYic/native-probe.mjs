import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { execFile, spawnSync } from 'node:child_process'
import { mkdtempSync, readFileSync, rmSync } from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'

const packageRoot = '/private/tmp/d2-git-review-baseline.mkeYic/package'
const load = relative => import(pathToFileURL(join(packageRoot, relative)).href)
const { ProcessGitRawStoreModule_createDefaultRunner } = await load('dist/Persistence/EventStore/ProcessGitRawStore.js')
const { ofArray } = await load('dist/fable_modules/fable-library-js.5.13.0/List.js')
const watched = ['dist/Persistence/EventStore/ProcessGitRawStore.js', 'dist/Persistence/EventStore/GitObjectDatabase.js']
const sha = bytes => createHash('sha256').update(bytes).digest('hex')
const before = watched.map(file => [file, sha(readFileSync(join(packageRoot, file)))])
const scratch = mkdtempSync('/private/tmp/d2-native-probe.')
const binary = Buffer.from([0xff, 0x00, 0x41, 0xfe, 0x80, 0x0a])
const observations = []

const call = (file, args, options, stdin) => new Promise(resolve => {
  const child = execFile(file, args, { encoding: 'buffer', timeout: 500, killSignal: 'SIGTERM', ...options }, (error, stdout, stderr) => resolve({
    error: error ? { code: error.code, status: error.status, signal: error.signal, killed: error.killed, hasStdout: error.stdout != null, hasStderr: error.stderr != null, message: error.message } : null,
    stdoutHex: Buffer.from(stdout ?? '').toString('hex'),
    stderrHex: Buffer.from(stderr ?? '').toString('hex'),
  }))
  if (stdin) child.stdin.end(stdin)
})

try {
  assert.equal(spawnSync('git', ['init', '--quiet', scratch]).status, 0)
  const raw = ProcessGitRawStoreModule_createDefaultRunner(scratch)

  const ignoredInput = await call('git', ['-C', scratch, 'hash-object', '--stdin'], { input: binary })
  const explicitInput = await call('git', ['-C', scratch, 'hash-object', '--stdin'], {}, binary)
  assert.equal(explicitInput.error, null)
  assert.equal(Buffer.from(explicitInput.stdoutHex, 'hex').toString().trim().length, 40)
  assert.equal(ignoredInput.error?.killed, true)
  assert.equal(ignoredInput.stdoutHex, '')
  observations.push({ kind: 'async-execFile-options-input-is-not-stdin', ignoredInput, explicitInput })

  const alias = "!printf '\\377\\000A\\376\\200\\n'; printf 'native-stderr' >&2; exit 7"
  const args = ['-c', `alias.d2-probe=${alias}`, 'd2-probe']
  const native = await call('git', ['-C', scratch, ...args], {})
  const product = await raw([ofArray(args), undefined])
  assert.equal(native.error.code, 7)
  assert.equal(native.stdoutHex, binary.toString('hex'))
  assert.equal(Buffer.from(native.stderrHex, 'hex').toString(), 'native-stderr')
  assert.equal(product[0], 1)
  assert.equal(Buffer.from(product[1]).length, 0)
  observations.push({ kind: 'failed-git-native-code-and-bytes-are-lost', native, product: { code: product[0], stdoutHex: Buffer.from(product[1]).toString('hex'), stderr: product[2] } })

  const successfulAlias = ['-c', "alias.d2-warning=!printf 'ok'; printf 'successful-stderr' >&2", 'd2-warning']
  const successful = await raw([ofArray(successfulAlias), undefined])
  assert.equal(successful[0], 0)
  assert.equal(Buffer.from(successful[1]).toString(), 'ok')
  assert.equal(successful[2], '')
  observations.push({ kind: 'successful-stderr-is-dropped', actual: { code: successful[0], stdout: Buffer.from(successful[1]).toString(), stderr: successful[2] }, expectedStderr: 'successful-stderr' })

  const missingHeadArgs = ['rev-parse', '--verify', 'HEAD']
  const missingNative = await call('git', ['-C', scratch, ...missingHeadArgs], {})
  const missingProduct = await raw([ofArray(missingHeadArgs), undefined])
  assert.equal(missingNative.error.code, 128)
  assert.equal(missingProduct[0], 1)
  observations.push({ kind: 'native-128-becomes-one', native: missingNative, productCode: missingProduct[0] })

  assert.deepEqual(watched.map(file => [file, sha(readFileSync(join(packageRoot, file)))]), before)
  console.log(JSON.stringify({ runtime: process.versions.bun ? `Bun ${process.versions.bun}` : `Node ${process.version}`, observations, unchangedProduct: before }, null, 2))
} finally {
  rmSync(scratch, { recursive: true, force: true })
}
