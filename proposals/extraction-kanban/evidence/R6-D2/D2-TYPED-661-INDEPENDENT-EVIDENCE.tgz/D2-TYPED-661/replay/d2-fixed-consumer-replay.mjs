import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { createHash } from 'node:crypto'
import { spawn } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const [repository, product, archive, expected, prior] = process.argv.slice(2).map((value, index) => index === 3 ? value : path.resolve(value))
const evidence = fs.mkdtempSync('/private/tmp/d2-fixed-consumer-replay-evidence-')
const scratch = fs.mkdtempSync('/private/tmp/d2-fixed-consumer-replay-case-')
const digest = file => createHash('sha256').update(fs.readFileSync(file)).digest('hex')
const save = (name, value) => fs.writeFileSync(path.join(evidence, name), JSON.stringify(value, null, 2))
const files = root => {
  const result = {}
  const visit = directory => {
    for (const name of fs.readdirSync(directory).sort()) {
      const file = path.join(directory, name)
      const stat = fs.lstatSync(file)
      assert.equal(stat.isSymbolicLink(), false)
      if (stat.isDirectory()) visit(file)
      else result[path.relative(root, file)] = digest(file)
    }
  }
  visit(root)
  return result
}
const execute = async (name, executable, args, cwd) => {
  const environment = { PATH: process.env.PATH, HOME: path.join(cwd, 'home'), USERPROFILE: path.join(cwd, 'home'), TMPDIR: path.join(cwd, 'tmp'), GIT_CONFIG_NOSYSTEM: '1', GIT_CONFIG_GLOBAL: '/dev/null' }
  fs.mkdirSync(environment.HOME, { recursive: true })
  fs.mkdirSync(environment.TMPDIR, { recursive: true })
  save(`${name}.command.json`, { executable, args, cwd, env: environment })
  const stdout = fs.openSync(path.join(evidence, `${name}.stdout`), 'w')
  const stderr = fs.openSync(path.join(evidence, `${name}.stderr`), 'w')
  const child = spawn(executable, args, { cwd, env: environment, detached: true, stdio: ['ignore', stdout, stderr] })
  let timedOut = false
  const timer = setTimeout(() => { timedOut = true; try { process.kill(-child.pid, 'SIGKILL') } catch (error) { if (error.code !== 'ESRCH') throw error } }, 60000)
  const result = await new Promise((resolve, reject) => {
    child.once('error', reject)
    child.once('close', (code, signal) => resolve({ code, signal, timedOut, pid: child.pid }))
  })
  clearTimeout(timer)
  fs.closeSync(stdout)
  fs.closeSync(stderr)
  save(`${name}.status.json`, result)
  return result
}

console.log(JSON.stringify({ evidence, scratch, product, archive, expected }))
try {
  assert.equal(digest(archive), expected)
  const previous = JSON.parse(fs.readFileSync(path.join(prior, 'products-before.json'), 'utf8'))
  const before = files(product)
  assert.deepEqual(Object.keys(before).sort(), Object.keys(previous).sort())
  const changed = Object.keys(before).filter(file => before[file] !== previous[file])
  assert.deepEqual(changed, ['dist/Persistence/EventStore/ProcessGitRawStore.js'])
  save('products-before.json', before)
  save('product-diff-from-660.json', { previousFiles: Object.keys(previous).length, files: Object.keys(before).length, changed })
  const sourceInputs = JSON.parse(fs.readFileSync(path.join(prior, 'real-source-inputs.json'), 'utf8'))
  const signatures = Object.fromEntries(Object.entries(sourceInputs).filter(([name]) => name.endsWith('.fsi')))
  for (const [name, expectedDigest] of Object.entries(signatures)) assert.equal(digest(path.join(repository, 'src/Wanxiangshu', name)), expectedDigest, name)
  save('unchanged-real-fsi.json', signatures)
  const runtimeRoot = path.join(scratch, 'runtime')
  const runtime = path.join(runtimeRoot, 'program')
  fs.mkdirSync(runtime, { recursive: true })
  fs.writeFileSync(path.join(runtimeRoot, 'package.json'), JSON.stringify({ name: 'd2-fixed-consumer-replay', type: 'module', private: true }))
  const consumer = path.join(runtime, 'D2TypedConsumer.js')
  fs.copyFileSync(path.join(prior, 'D2TypedConsumer.js'), consumer)
  assert.equal(digest(consumer), 'baa22ffb40cf00ad92b9b85fa4c42037568b468b1116796390239991c46e2c81')
  fs.copyFileSync(path.join(prior, 'driver.mjs'), path.join(runtime, 'driver.mjs'))
  for (const [from, to] of [[path.join(runtime, 'Persistence'), path.join(product, 'dist/Persistence')], [path.join(runtime, 'Process'), path.join(product, 'dist/Process')], [path.join(runtimeRoot, 'fable_modules'), path.join(product, 'dist/fable_modules')]]) fs.symlinkSync(to, from)
  fs.copyFileSync(consumer, path.join(evidence, 'D2TypedConsumer.js'))
  fs.copyFileSync(path.join(prior, 'D2TypedConsumer.fs'), path.join(evidence, 'D2TypedConsumer.fs'))
  fs.copyFileSync(path.join(runtime, 'driver.mjs'), path.join(evidence, 'driver.mjs'))
  const treeProbe = path.join(path.dirname(fileURLToPath(import.meta.url)), 'd2-tree-parser-counterexamples.mjs')
  fs.copyFileSync(treeProbe, path.join(evidence, 'd2-tree-parser-counterexamples.mjs'))
  const results = await Promise.all([{ name: 'node', executable: process.env.D2_NODE ?? process.execPath }, { name: 'bun', executable: process.env.D2_BUN ?? 'bun' }].flatMap(host => [
    execute(`${host.name}-typed`, host.executable, [path.join(runtime, 'driver.mjs')], path.join(scratch, `${host.name}-typed`)).then(result => ({ name: `${host.name}-typed`, ...result })),
    execute(`${host.name}-tree`, host.executable, [treeProbe, product], path.join(scratch, `${host.name}-tree`)).then(result => ({ name: `${host.name}-tree`, ...result })),
  ]))
  assert.deepEqual(files(product), before)
  for (const [name, expectedDigest] of Object.entries(signatures)) assert.equal(digest(path.join(repository, 'src/Wanxiangshu', name)), expectedDigest, name)
  assert.equal(digest(archive), expected)
  assert.equal(digest(consumer), digest(path.join(prior, 'D2TypedConsumer.js')))
  save('products-after.json', files(product))
  save('summary.json', { fixedArchive: expected, results, priorTypeEvidence: prior, priorTypeEvidenceArchiveSHA256: 'a34ae068c3fb656e73bc2b53f8d0edfd604aef6d4fc10816e2fdf0926a1cc8f6', reusedUnchangedRealFsi: signatures, noRecompileRequired: true, sameEmittedConsumerJS: true, noGeneratedProductionImplementationPresent: true, noSourceRuntimeFallback: true, productChangedOnlyRawStore: true, installationUnchanged: true, libraryUnchanged: true })
  for (const result of results) {
    assert.equal(result.timedOut, false)
    assert.equal(result.code, 0, fs.readFileSync(path.join(evidence, `${result.name}.stderr`), 'utf8'))
  }
} catch (error) {
  save('harness-error.json', { message: error.message, stack: error.stack })
  process.exitCode = 1
} finally {
  fs.copyFileSync(fileURLToPath(import.meta.url), path.join(evidence, 'd2-fixed-consumer-replay.mjs'))
  fs.rmSync(scratch, { recursive: true, force: true })
  save('cleanup.json', { scratchRemoved: !fs.existsSync(scratch), installationPreserved: fs.existsSync(product), scope: 'Typed Git programs use natural production scope/capture completion. Supplemental tree negatives use controlled runner replies; no independent per-PID sampling is claimed.' })
}
