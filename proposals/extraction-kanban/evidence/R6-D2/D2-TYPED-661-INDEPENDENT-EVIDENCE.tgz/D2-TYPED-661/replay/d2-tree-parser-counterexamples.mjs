import assert from 'node:assert/strict'
import path from 'node:path'
import { pathToFileURL } from 'node:url'

const product = path.resolve(process.argv[2])
const { createWithRunner } = await import(pathToFileURL(path.join(product, 'dist/Persistence/EventStore/GitRawSurface.js')).href)
const oid = 'a'.repeat(40)
const valid = `100644 blob ${oid}\tleaf\0`
const cases = [
  ['missing delimiter', Buffer.from(valid.slice(0, -1))],
  ['wrong object type', Buffer.from(`100644 tree ${oid}\tleaf\0`)],
  ['invalid name', Buffer.from(`100644 blob ${oid}\ta/b\0`)],
  ['duplicate rows', Buffer.from(valid + valid)],
  ['invalid UTF-8', Buffer.concat([Buffer.from(`100644 blob ${oid}\t`), Buffer.from([255, 0])])],
  ['empty nonempty tree', Buffer.alloc(0)],
  ['missing tab', Buffer.from(`100644 blob ${oid} leaf\0`)],
  ['wrong fields', Buffer.from(`100644 ${oid}\tleaf\0`)],
  ['invalid oid', Buffer.from('100644 blob invalid\tleaf\0')],
  ['empty name', Buffer.from(`100644 blob ${oid}\t\0`)],
]
const records = []
for (const [name, bytes] of cases) {
  let calls = 0
  const store = createWithRunner('/unused', async request => {
    calls++
    return {
      kind: 'Observed', ending: { kind: 'Exited', exitCode: 0 }, stopRequested: null,
      output: { stdout: request.arguments.includes('--batch-check') ? Buffer.from(`${oid} tree 32\n`) : bytes, stderr: Buffer.from('parser-diagnostic'), complete: true },
      fault: null,
    }
  })
  const failures = []
  for (let attempt = 0; attempt < 2; attempt++) {
    const result = await store.readTree(oid)
    assert.equal(result.ok, false, name)
    assert.equal(result.error.result.ending.exitCode, 0)
    assert.deepEqual(Buffer.from(result.error.result.output.stdout), bytes)
    assert.equal(Buffer.from(result.error.result.output.stderr).toString(), 'parser-diagnostic')
    failures.push(result.error.reason)
  }
  assert.equal(calls, 4, `${name}: a rejected result must not enter the cache`)
  records.push({ name, attempts: 2, calls, failures })
}
console.log(JSON.stringify({ accepted: true, cases: records.length, records }))
