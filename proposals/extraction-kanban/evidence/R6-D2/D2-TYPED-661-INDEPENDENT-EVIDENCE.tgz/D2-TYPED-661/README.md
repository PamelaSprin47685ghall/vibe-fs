# Candidate 661 independent fixed-consumer replay

Fixed candidate `wanxiangshu-0.9.0.tgz`, SHA256
`34393e1d4b8fcb4b7e3ddbaa9769a681c728fb12ed072a0785c0bb82483f009f`.
Actually clean-installed product:
`/private/tmp/d2-clean-install-661/node_modules/wanxiangshu`.

Node 26.6.0 and Bun 1.3.14 on macOS arm64 each pass the unchanged D2 F# consumer
JavaScript. This is an explicit replay after a pure tree-parser helper
reorganization, not a newly claimed interface compilation or extra run of the
five unchanged type-negative programs.

Independent installed-byte comparison finds the same 2,904 files as candidate
660, with exactly one changed file:
`dist/Persistence/EventStore/ProcessGitRawStore.js`. This includes the nested
installed dependencies; every wanxiangli 0.6.10 byte and the Fable runtime
modules remain unchanged. All 15 real .fsi files in the prior compile closure
match their candidate-660 source digests before and after this replay.

The positive real-interface compilation and five valid negative compiles are
therefore reused from `D2-TYPED-660-INDEPENDENT-EVIDENCE.tgz`, SHA256
`a34ae068c3fb656e73bc2b53f8d0edfd604aef6d4fc10816e2fdf0926a1cc8f6`.
That archive also retains the compiler's complete 30-input closure, actual
diagnostics and deletion of all generated production implementations. The
minimal original files needed for this replay are included under `prior660/`.

The original consumer JavaScript SHA256 remains
`baa22ffb40cf00ad92b9b85fa4c42037568b468b1116796390239991c46e2c81`.
It is the same bytes used by candidate 659's diagnosed Bun red and candidate
660's green. No input, limit, byte comparison, expected result, import or
consumer code is changed. Runtime stages contain that JavaScript, its original
driver and links only to the fixed installed `dist/Persistence`, `dist/Process`
and `dist/fable_modules`. No compiler output or F# implementation source is a
runtime fallback.

Both hosts return accepted:true across every original phase: real exit7/128
and exact 2 MiB+17 binary stdout/nine-byte stderr; Error.Result preservation;
combined OutputLimit and rejection; actual cold blob and UTF-8 tree reads;
object/tree missing as Error; exact missing ref as None; real ref permission
failure as Error; Unconfirmed as Error; and actual GitRawSurface.run.

Focused supplemental tree negatives exercise all reorganized helper boundaries:
missing final delimiter, wrong object type, invalid name, duplicate rows,
invalid UTF-8, empty output for nonempty metadata, missing tab, wrong field
count, invalid object id and empty name. All 10 pass on each host. Each rejected
tree is read twice and must invoke the runner four times, proving the rejected
result was not cached; the original exit0 and raw stdout/stderr remain in the
failure result. These are controlled-parser replies, not claims of real Git
returning malformed bytes. The unchanged typed program supplies the actual Git
positive tree/Unicode/tab/LF control.

The installed product and tarball are unchanged after replay. Temporary runtime
repositories and staging directories are removed; normal production scope and
capture completion supply the typed processes' close evidence. No independent
per-PID sampling is claimed for every Git process. Internal F# protocol evidence
does not claim a new npm .d.ts or new public Git export, and does not replace
Hook/WriterStreamSync/Gateway or full D2 integration evidence. R12-U1 stays out
of scope. Candidate 660 and earlier red archives remain independent records.

## Replay

Use the same fixed tarball and clean-installed package. The source checkout is
read only to verify unchanged real .fsi bytes, and is not used at runtime:

```sh
node replay/d2-fixed-consumer-replay.mjs MATCHING_CHECKOUT CLEAN_INSTALLED_PRODUCT candidate/wanxiangshu-0.9.0.tgz 34393e1d4b8fcb4b7e3ddbaa9769a681c728fb12ed072a0785c0bb82483f009f prior660
```

The runner locates `d2-tree-parser-counterexamples.mjs` next to itself. It
checks the exact consumer digest, the one-file installed-product diff and all
15 interface digests, runs Node/Bun with isolated HOME/TMPDIR and no source
imports, then checks all product bytes again. Raw commands, environments,
stdout/stderr, statuses, interface digests, before/after product maps and cleanup
receipt are included under `replay/`. Verify `MANIFEST.sha256` before replay.
