# Candidate 661 last-17-byte investigation: unresolved

The original formal Bun log reports expected
`73cd9847570c1a6413a50a7063f8f698b62c46cf` but product WriteBlob returned
`284160124c6f2e4694b0fee82bfb1fe73746b962`. The source test used 33,554,449
bytes, each byte index modulo 251. The original test's cleanup deleted its
repository, so this archive does not pretend to retain that actual object.

Independent Node 26.6.0 crypto computes the Git SHA1 over the explicit
`blob <length>\0` header and exact bytes:

| Bytes | Git blob OID |
| ---: | --- |
| 16,777,216 | b479a54098314bf47eae103ca368603202375ac2 |
| 16,777,233 | fddaacbea2390be498e58d620f60515815955402 |
| 33,554,432 | 284160124c6f2e4694b0fee82bfb1fe73746b962 |
| 33,554,449 | 73cd9847570c1a6413a50a7063f8f698b62c46cf |

The full input SHA256 is
`dff5b2f0725ee66b6c1fec1e6118b91622d727cda303e120c46c6e53d2deae96`.
Thus the formal comparison's expected OID is independently correct; the Bun
execFileSync comparator is not the cause of that particular discrepancy. The
reported actual OID exactly matches the known 32 MiB prefix's OID. This is
strong evidence for loss of the final 17 bytes, not a physical cold-read proof
of the now-deleted original object.

## Bounded new retained replays

All replays use the unchanged fixed 661 clean-installed package, archive SHA256
`34393e1d4b8fcb4b7e3ddbaa9769a681c728fb12ed072a0785c0bb82483f009f`,
including wanxiangli 0.6.10. Each sends the command exactly once. No input is
retried after Unknown and no source or installed product is modified.

One Node CLI control, three Bun CLI cases and one Bun test/node:test entry-mode
case each returned the full expected OID. Their repositories, input.bin and
actual.bin are retained separately. For every one, a separate native Node
process invoked Git cat-file with stdout written directly to a file descriptor,
then compared every byte, Git blob SHA1, SHA256, first difference and 1 MiB
block hashes. It also fed the input file descriptor directly to native Git
hash-object as a third independent expected-value check. All five new cases
are complete byte matches.

These targeted green replays do not erase, explain or supersede the formal
failure. They show the discrepancy is not yet reproducible in these limited
isolated contexts. The investigation remains unresolved and cannot close D2's
whole-input guarantee. Earlier 660/661 typed and narrow physical positives
remain valid for their recorded cases, not proof against this counterexample.

No instrumentation run has been used as evidence of a fix. The requested
next-stage private-package trace points are parent BunProcess write/flush/end,
Worker source.iterator bytes/write callbacks/EOF, and Worker target FileSink.
At the time of this archive, the agreed prerequisite of a newly retained
uninstrumented red case had not been obtained, so this reviewer had not run an
instrumented package. A separate reviewer owns a FIFO replacement prototype;
that work is not claimed here.

## Replay

`d2-32m-retained-repro.mjs` needs the fixed clean-installed product path and a
fresh evidence directory. It intentionally keeps the repository and binary
files instead of removing the evidence on failure. Set D2_NODE on a different
host; the default is the recorded macOS absolute Node path.

```sh
D2_NODE="$(command -v node)" bun d2-32m-retained-repro.mjs CLEAN_INSTALLED_PRODUCT FRESH_EVIDENCE_DIRECTORY
```

Place the adjacent `d2-cold-object-compare.mjs` alongside it. A mismatch exits 1
after saving the actual object and byte/block analysis. A successful command
does not imply the intermittent original failure is fixed.

The entry-mode fixture is also retained with its original absolute paths; it
was one explicit node:test case under `bun test`, not a rerun of the full
requirement suite. No source fallback, dotnet build or automatic code mutation
was used. This archive retains only owned deterministic test data and private
repositories. R12-U1 remains out of scope.
