import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { closeSync, openSync, readFileSync, writeFileSync } from 'node:fs'
import { spawnSync } from 'node:child_process'

const [repository, oid, inputPath, actualPath, summaryPath] = process.argv.slice(2)
const input = readFileSync(inputPath)
const output = openSync(actualPath, 'w')
const stderr = openSync(`${actualPath}.stderr`, 'w')
const child = spawnSync('/usr/bin/git', ['-C', repository, 'cat-file', 'blob', oid], { stdio: ['ignore', output, stderr], timeout: 30000 })
closeSync(output)
closeSync(stderr)
assert.ifError(child.error)
assert.equal(child.status, 0)
const actual = readFileSync(actualPath)
const hash = (algorithm, bytes) => createHash(algorithm).update(bytes).digest('hex')
const blob = bytes => createHash('sha1').update(Buffer.from(`blob ${bytes.length}\0`)).update(bytes).digest('hex')
let firstDifferent = -1
let differingBytes = 0
for (let index = 0; index < Math.max(input.length, actual.length); index++) {
  if (input[index] !== actual[index]) {
    if (firstDifferent === -1) firstDifferent = index
    differingBytes++
  }
}
const blocks = []
for (let offset = 0; offset < Math.max(input.length, actual.length); offset += 1048576) {
  const expected = input.subarray(offset, offset + 1048576)
  const received = actual.subarray(offset, offset + 1048576)
  blocks.push({ offset, expectedBytes: expected.length, actualBytes: received.length, expectedSha256: hash('sha256', expected), actualSha256: hash('sha256', received), equal: expected.equals(received) })
}
const inputFd = openSync(inputPath, 'r')
const native = spawnSync('/usr/bin/git', ['-C', repository, 'hash-object', '--stdin'], { stdio: [inputFd, 'pipe', 'pipe'], timeout: 30000 })
closeSync(inputFd)
assert.equal(native.status, 0)
const result = { node: process.version, oid, expectedBytes: input.length, actualBytes: actual.length, expectedSha256: hash('sha256', input), actualSha256: hash('sha256', actual), expectedBlobOid: blob(input), actualBlobOid: blob(actual), nativeNodeGitOid: native.stdout.toString().trim(), allBytesEqual: input.equals(actual), actualMatchesInputPrefix: actual.equals(input.subarray(0, actual.length)), firstDifferent, differingBytes, blocks }
assert.equal(result.actualBlobOid, oid)
assert.equal(result.nativeNodeGitOid, result.expectedBlobOid)
writeFileSync(summaryPath, JSON.stringify(result, null, 2))
console.log(JSON.stringify(result))
