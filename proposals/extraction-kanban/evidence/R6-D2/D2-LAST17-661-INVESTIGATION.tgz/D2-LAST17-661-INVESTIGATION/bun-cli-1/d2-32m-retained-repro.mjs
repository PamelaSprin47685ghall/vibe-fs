import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { execFileSync, spawnSync } from 'node:child_process'
import { copyFileSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import path from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const product = path.resolve(process.argv[2])
const evidence = path.resolve(process.argv[3])
mkdirSync(evidence, { recursive: true })
const repo = path.join(evidence, 'repository')
const temporary = path.join(evidence, 'tmp')
const home = path.join(evidence, 'home')
mkdirSync(repo)
mkdirSync(temporary)
mkdirSync(home)
process.env.HOME = home
process.env.TMPDIR = temporary
process.env.GIT_CONFIG_NOSYSTEM = '1'
process.env.GIT_CONFIG_GLOBAL = '/dev/null'
const { create } = await import(pathToFileURL(path.join(product, 'dist/Persistence/EventStore/GitRawSurface.js')).href)
const input = Buffer.alloc(33554449)
for (let index = 0; index < input.length; index++) input[index] = index % 251
const inputPath = path.join(evidence, 'input.bin')
writeFileSync(inputPath, input)
execFileSync('/usr/bin/git', ['init', '--bare', '--quiet', repo])
const started = Date.now()
const result = await create(repo).writeBlob(input)
const record = { host: process.versions.bun ? `Bun ${process.versions.bun}` : `Node ${process.version}`, product, repo, inputBytes: input.length, inputSha256: createHash('sha256').update(input).digest('hex'), expectedGitOid: createHash('sha1').update(Buffer.from(`blob ${input.length}\0`)).update(input).digest('hex'), writeCalls: 1, elapsedMs: Date.now() - started, result }
if (result.ok) {
  const compare = path.join(path.dirname(fileURLToPath(import.meta.url)), 'd2-cold-object-compare.mjs')
  const readback = spawnSync(process.env.D2_NODE ?? '/opt/homebrew/bin/node', [compare, repo, result.value, inputPath, path.join(evidence, 'actual.bin'), path.join(evidence, 'cold-read.json')], { encoding: 'utf8', timeout: 40000, maxBuffer: 1048576 })
  writeFileSync(path.join(evidence, 'cold-node.stdout'), readback.stdout ?? '')
  writeFileSync(path.join(evidence, 'cold-node.stderr'), readback.stderr ?? '')
  record.coldNodeStatus = { code: readback.status, signal: readback.signal, error: readback.error?.message ?? null }
  assert.equal(readback.status, 0, readback.stderr)
  record.cold = JSON.parse(readFileSync(path.join(evidence, 'cold-read.json'), 'utf8'))
  if (!record.cold.allBytesEqual) process.exitCode = 1
} else {
  process.exitCode = 1
}
writeFileSync(path.join(evidence, 'summary.json'), JSON.stringify(record, null, 2))
copyFileSync(fileURLToPath(import.meta.url), path.join(evidence, 'd2-32m-retained-repro.mjs'))
copyFileSync(path.join(path.dirname(fileURLToPath(import.meta.url)), 'd2-cold-object-compare.mjs'), path.join(evidence, 'd2-cold-object-compare.mjs'))
console.log(JSON.stringify(record, null, 2))
