import test from 'node:test'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { execFileSync, spawnSync } from 'node:child_process'
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import path from 'node:path'
import { create } from '/private/tmp/d2-clean-install-661/node_modules/wanxiangshu/dist/Persistence/EventStore/GitRawSurface.js'

test('retained exact 33554449-byte write in the original Bun test entry mode', async () => {
  const evidence = '/private/tmp/d2-32m-661-bun-testmode-retained'
  const repo = path.join(evidence, 'repository')
  mkdirSync(repo, { recursive: true })
  const bytes = Buffer.alloc(33554449)
  for (let index = 0; index < bytes.length; index++) bytes[index] = index % 251
  const inputPath = path.join(evidence, 'input.bin')
  writeFileSync(inputPath, bytes)
  execFileSync('/usr/bin/git', ['init', '--bare', '--quiet', repo])
  const result = await create(repo).writeBlob(bytes)
  const record = { entryMode: 'bun test with node:test', inputBytes: bytes.length, expectedGitOid: createHash('sha1').update(Buffer.from(`blob ${bytes.length}\0`)).update(bytes).digest('hex'), result }
  if (result.ok) {
    const compared = spawnSync('/opt/homebrew/bin/node', ['/private/tmp/d2-cold-object-compare.mjs', repo, result.value, inputPath, path.join(evidence, 'actual.bin'), path.join(evidence, 'cold-read.json')], { encoding: 'utf8', timeout: 40000, maxBuffer: 1048576 })
    writeFileSync(path.join(evidence, 'cold-node.stdout'), compared.stdout ?? '')
    writeFileSync(path.join(evidence, 'cold-node.stderr'), compared.stderr ?? '')
    assert.equal(compared.status, 0)
    record.cold = JSON.parse(readFileSync(path.join(evidence, 'cold-read.json'), 'utf8'))
  }
  writeFileSync(path.join(evidence, 'summary.json'), JSON.stringify(record, null, 2))
  assert.equal(result.ok, true)
  assert.equal(record.cold.allBytesEqual, true)
})
