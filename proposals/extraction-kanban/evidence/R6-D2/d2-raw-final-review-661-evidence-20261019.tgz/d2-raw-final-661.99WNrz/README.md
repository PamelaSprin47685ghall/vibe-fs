# Independent final 661 RawStore and tree-helper review

## Partial acceptance only

Fixed candidate 661 SHA-256: `34393e1d4b8fcb4b7e3ddbaa9769a681c728fb12ed072a0785c0bb82483f009f`.
Actual clean install: `/private/tmp/d2-clean-install-661/node_modules/wanxiangshu` with wanxiangli 0.6.10.
Installed RawStore module SHA-256: `919c7a270582912d61ff8dabf8c851b58eb7c46c7f5542d1c8d2c2afadec8e55`.

Node v26.6.0 and Bun 1.3.14 each pass the original 11 Raw/actual Hook groups plus 10 independent tree-protocol/cold-read groups. This is a receipt for these paths only. At this receipt's cut, the separate formal large-input Bun OID mismatch investigation remains open; these green local probes must not close overall D2 acceptance. Shared source was not edited.

## Original 11 groups rerun on actual 661

`probe.mjs` is unchanged from the 660 acceptance script; only its command arguments select 661. It imports the installed product and executes its installed standalone Hook, never source-checkout substitutes.

1. Real object/tree missing is Error preserving normal exit 0 and exact complete missing bytes; ref absence alone is normal null.
2. Controlled missing retains its original receipt in one call without fallback or write.
3. Short successful object body fails, repaired reads succeed, and returned bytes cannot mutate the immutable cache.
4. Empty blob/tree are present values.
5. Loose object-file EACCES fails and restores.
6. Loose parent-directory EACCES fails and restores.
7. Corrupt and truncated loose streams fail without retry and restore correctly.
8. Packed .pack EACCES fails object/tree despite silent native missing.
9. Packed .idx EACCES does the same.
10. The actual reference-transaction Hook stops on .pack EACCES before materialization/publication; restoring access permits the same cold entry.
11. The corresponding .idx actual Hook failure/recovery.

The Hook audit records repository discovery, common-dir discovery and batch-check only on the failure branch. No hash-object, mktree, fetch or push occurs; local event/cache files remain absent and local/remote refs stay unchanged. Raw logs: `node-661.log`, `bun-661.log`.

## New tree helper surface

The source helper split preserves the former protocol boundaries: first-tab delimiter, exactly three header fields, strict per-entry mode/type/OID/name validation, all-row count agreement, strict UTF-8 decoding and required final NUL. `List.choose` cannot silently discard an invalid row because parsed and original lengths are compared. Cache insertion happens only after the entire parse and metadata empty/nonempty agreement succeed. Remaining tabs belong to the filename; names are not Unicode-normalized.

`tree-protocol.mjs` independently rejects nine complete exit-0 receipts: invalid UTF-8, missing final NUL, duplicate names, mode/type mismatch, unsupported gitlink mode, extra header field, slash in a direct tree name, empty output with nonempty metadata, and nonempty output with empty metadata. Each case then repairs the same store's runner and reads successfully, proving the failure did not populate/poison its cache; caller mutations do not alter later cached results. The original normal exit 0 and exact bad bytes remain available in Error.

Its tenth group creates actual native Git objects through the installed product, then reads through a fresh store and compares against native ls-tree. It covers all four supported modes, U+E000 versus U+10000 byte ordering, a BOM-leading filename, a tab in a filename and directory ordering (`folder.` before `folder/`). Raw logs: `node-tree-661.log`, `bun-tree-661.log`.

## Separate native hypothesis and performance boundaries

The private native tree-header investigation is archived separately in `/private/tmp/d2-tree-header-review-evidence-20261019.tgz`. It does not confirm the proposed bug from merely changing a complete legal tree's declared size. It disproves reconstruction of raw size from normalized ls-tree modes. Its supplementary Git zero-padding and real short-blob comparison keep physical-container tolerance, unchanged logical content, old defects and review/probe mistakes separate.

No 661 performance sample was run. The actual 660 same-Trace2 comparison remains preserved in `/private/tmp/d2-raw-final-review-660-evidence-20261019.tgz`, SHA-256 `f4f4456363edd89f9dd34db8afc72994ac0cc5497c9f23efe25542e580ec867a`. That measured changed Hook calls around 0.97–1.15 s versus D1's 0.20–0.22 s; it is prior fixed-input architectural-cost evidence, not a newly measured 661 benchmark. No claim of zero performance regression is made.

The complete convergence matrix, formal requirement suite, pending Bun comparison, CUT-00-R1/R2/R3, and deferred R12-U1 remain separate. Apple Git here is 2.50.1, not a minimum-version platform test.

## Reproduce and cleanup

Install included `candidate-661.tgz` with declared dependencies. With an owned TMPDIR for each runtime:

```sh
TMPDIR=<node-tmp> node probe.mjs <installed-661-root> candidate-661.tgz
TMPDIR=<bun-tmp> bun probe.mjs <installed-661-root> candidate-661.tgz
TMPDIR=<node-tmp> node tree-protocol.mjs <installed-661-root> candidate-661.tgz
TMPDIR=<bun-tmp> bun tree-protocol.mjs <installed-661-root> candidate-661.tgz
```

Physical supervised processes require macOS process inspection. Every probe checks its archive/selected module digests unchanged before and after execution. All owned repository roots were removed, and the Node/Bun owned TMPDIRs were empty after the runs. Raw logs are unchanged; SHA256SUMS binds this receipt, scripts, logs and exact package.
