# D1 stopped capture regression

The baseline is the clean installation of frozen D1 generation 652, archive SHA-256 `003bc8818969597f9afd6a1c0767c7aae271dd53e5f0392b146367d156ec3887`. The product is `/private/tmp/d1-clean-install-652.MIf8Hg/node_modules/wanxiangshu`, with bundled wanxiangli 0.6.8. This is the D1 delivery candidate, not the moving D2 workspace.

The probe starts a real Node target. The target starts one same-group pipe writer and exits 23. The writer calls `fs.writeFileSync(1, payload)` for each 65,536-byte block, then records the completed byte count in its own file. The probe observes the real target exit receipt while the descendant holds stdout and no final extent exists. The normal production deadline requests KILL. It records the typed result and checks that the exact owned writer PID no longer executes. The probe removes its own spool and temporary directory after closure.

Run the included script with Node or Bun and the product installation path as its single argument. Node/Bun are the hosts; the target and writer use `/opt/homebrew/bin/node`.

The exact-count Bun run observed 21,168,128 sender-acknowledged bytes and 21,110,784 received bytes, a difference of 57,344. The D1 result still carried `fault:null` and `Some Spooled`, which claims complete captured output. Target exit 23 and the deadline request were correctly retained. This is a D1 result-protocol regression: the earlier timeout path discarded output, while D1 allowed complete output based only on scope close and no reported fault.

The exact-count Node run observed equal sender/receiver counts (179,240,960). It is a normal-data control for this observation, not evidence that Node lost bytes. Both hosts lack the final target extent in this forced-stop path; equality of one sample is not a general completeness proof.

The two earlier `*-node.log` and `*-bun.log` runs used a sender tally updated only every MiB. They show the same complete-output classification after a forced stop but do not prove missing bytes. The included source is the final per-write tally probe, not that earlier coarse variant. No earlier coarse outcome is counted as a lost-byte reproduction.

This evidence does not infer target failure from supervisor SIGKILL, does not clear any persistent Unknown, and does not diagnose R12-U1. The proposed correction preserves End/Stop/fault but delivers no complete text output after a requested stop; binary output retains received partial bytes with `Complete=false`.
