import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { chmodSync, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { spawnSync } from 'node:child_process'
import { pathToFileURL } from 'node:url'

const product = resolve(process.argv[2])
const hookPath = join(product, 'dist/Git/Hook/Sync.js')
const digest = path => createHash('sha256').update(readFileSync(path)).digest('hex')
const sourceBefore = digest(hookPath)
const hook = await import(pathToFileURL(hookPath))
const scratch = mkdtempSync('/private/tmp/d2-hook-diagnostic-')
const previousCwd = process.cwd()
const previousActive = process.env.WANXIANG_GIT_SYNC_ACTIVE
const objects = join(scratch, '.git/objects')
const line = JSON.stringify({ event_id: '1'.repeat(40), event_type: 'JobRequested', parents: [], payload: {}, payload_refs: [], stream_id: '2'.repeat(40) }) + '\n'
try {
  const initialized = spawnSync('git', ['init', '--quiet', scratch], { encoding: 'utf8' })
  assert.equal(initialized.status, 0, initialized.stderr)
  const events = join(scratch, '.git/wanxiangshu/events')
  mkdirSync(events, { recursive: true })
  const writer = join(events, 'writer-local.ndjson')
  writeFileSync(writer, line)
  chmodSync(objects, 0o500)
  const native = spawnSync('git', ['-C', scratch, 'hash-object', '-w', '--stdin'], { input: line, encoding: 'utf8' })
  assert.equal(native.status, 128)
  assert.match(native.stderr, /permission denied|insufficient permission|unable to create/i)
  process.chdir(scratch)
  const message = await hook.runPrePush('origin')
  assert.equal(typeof message, 'string')
  assert.match(message, /git hash-object/)
  assert.match(message, /128/)
  assert.ok(message.includes(native.stderr.trim()), 'The real Hook diagnostic must include the native Git stderr')
  assert.equal(readFileSync(writer, 'utf8'), line)
  assert.equal(digest(hookPath), sourceBefore)
  console.log(JSON.stringify({ passed: true, host: process.execPath, nativeStatus: native.status, nativeStderr: native.stderr, hookMessage: message, activeWriterUnchanged: true, productHookUnchanged: true, hookSha256: sourceBefore, scope: 'Actual fixed-package HookSync.runPrePush with a real worktree and native Git object-directory permission failure. No remote is configured. This proves native stderr reaches the user-facing Hook error; it does not prove the complete remote convergence matrix.' }))
} finally {
  process.chdir(previousCwd)
  if (previousActive === undefined) delete process.env.WANXIANG_GIT_SYNC_ACTIVE
  else process.env.WANXIANG_GIT_SYNC_ACTIVE = previousActive
  if (existsSync(objects)) chmodSync(objects, 0o700)
  rmSync(scratch, { recursive: true, force: true })
  console.log(JSON.stringify({ cleanup: true, scratchRemoved: !existsSync(scratch) }))
}
