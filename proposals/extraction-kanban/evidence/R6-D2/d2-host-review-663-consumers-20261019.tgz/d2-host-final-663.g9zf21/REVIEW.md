# Generation 663 actual-consumer acceptance

This is fixed-package acceptance and consumer verification by a reviewer who
participated in the private input-pump prototype. It is not counted as a
non-author algorithm review. The root and the other reviewers own that review
and the final D2 card decision.

The exact fixed main package SHA256 is
`3c0afec4f5aee947cff92a5a2e633a41d4e9728daa515f27295e634ed9b324e0`.
Runtime imports use the actual clean installation
`/private/tmp/d2-clean-install-663/node_modules/wanxiangshu`.
The three existing scripts were copied unchanged; only their product argument
was rebound. No source workspace production module is imported.

## Predeclared runs

- Node and Bun each ran the ten actual compiled WriterStreamSync/Gateway
  consumer branches once. Their raw-store and transport boundary receipts are
  controlled; the core consumers, active-writer files and cache behavior are
  real. Each error stops the later mutation/publication stage and preserves
  the original result/partial output. The positive missing-ref/cache path
  remains successful. These are twenty branch results, not twenty separate
  native Git runs.
- Node and Bun each ran shell-shim before/after once. All four reached the
  actual immutable-write cut. The unchanged real 1500 ms RawRunner deadline
  returned GitStorage failure, preserved the original receipt and incomplete
  output, made no retry or later mktree/transport/cache write, and left the
  active writer unchanged. Independent native Git proved the before object
  absent and the after object present with exactly the submitted bytes. The
  after shim actually ran one native hash-object -w, saved native exit 0 and
  channels, then hung to lose its terminal receipt. A signaled target and an
  Unconfirmed target end are both retained as observed, never turned into
  successful storage.
- Node ran the existing actual Hook permission-error case once. Native Git
  returned 128 and its real stderr reached HookSync.runPrePush unchanged.
  The active writer was unchanged and the owned permission changes were
  restored. No remote was configured. Bun Hook was not rerun in this step.

All five commands exited zero. Every actual shim writes spawn/EOF/cut/native
markers and preserves their UTC file timestamps in the complete raw log. Each
owned hanging target was independently confirmed no longer executing. No
timeout was extended and no case was repeated to obtain a green result.

## Exact byte mapping and inherited evidence

All 2076 package files match the installed 663 package. Generation 661 also has
2076 files. Only five paths differ: the nested library's ProcessSession.js,
SupervisedProcess.js, PROCESS.md and package.json, and the main package.json.
All main dist implementations and declarations, including the Plugin, Host,
Wait, Runner, RawStore, WriterStreamSync, Gateway and Hook, are byte-identical.
The complete mapping is retained in 663-vs-661-map.json.

All 22 nested library files are byte-identical to the independently installed
0.6.12 package exercised by this reviewer's twelve finite physical input cases.
That evidence is:
`d2-library-host-0612-acceptance-compact-20261019.tgz`, SHA256
`ec3bca7a5f0d7c0a4778d1280f0e1457793c8b8dbee5a31ef6101c1524109ce5`.

Per the declared final scope, stopped text capture, late Written after stop,
partial-input dual output, legacy manifest/v1 consumers and the npm public-root
Plugin canary are inherited from the earlier explicitly scoped evidence, using
unchanged main-module bytes plus the new fixed-library physical acceptance.
They were not rerun on 663. Their originating final-scope artifact is:
`d2-host-review-660-evidence-20261019.tgz`, SHA256
`16c4e038dd068612e0866f4d4b8e757e56102a13c7666090653ef3a592ca98a4`;
the 661 byte-mapping/cut supplement is
`d2-host-review-661-evidence-20261019.tgz`, SHA256
`e77c34695fbf2707b7063505b9572a2a807a2f0d2fa1f682d90842f34a089853`.
The 661 supplement states its own 660 inheritance instead of pretending those
older checks were rerun. The changed low-level library input is not described
as byte-identical; its new exact-package physical evidence is named above.

Earlier Node-wrapper attempts that expired in a preliminary query before the
write cut remain in the 660/661 artifacts. They remain invalid as positive cut
evidence and do not become an attributed implementation error or R12-U1 result.
No attempt was made to explain them or change the production deadline here.
R12-U1 remains deferred. Known old iterator truncation evidence is also kept
separately; this consumer acceptance does not erase any original red run.

## Replay and limits

The compact archive includes all logs, receipts, marker timestamps, script code,
command results, complete installation hashes and the exact package. There are
no large routine byte files in this consumer artifact and no omissions.

```sh
node d2-consumer-result-boundaries.mjs /private/tmp/d2-clean-install-663/node_modules/wanxiangshu
node d2-physical-shell-unknown-write.mjs /private/tmp/d2-clean-install-663/node_modules/wanxiangshu
bun d2-consumer-result-boundaries.mjs /private/tmp/d2-clean-install-663/node_modules/wanxiangshu
bun d2-physical-shell-unknown-write.mjs /private/tmp/d2-clean-install-663/node_modules/wanxiangshu
node d2-hook-native-diagnostic.mjs /private/tmp/d2-clean-install-663/node_modules/wanxiangshu
```

The CLI driver imposed a separate outer 25-second guard per command; none
expired. Each physical storage deadline stayed 1500 ms. These are D2 consumer
and fixed-package boundaries, not full-repository/complete-WHAT or deployment
proof. The final non-author review and other planned suites remain separate.
