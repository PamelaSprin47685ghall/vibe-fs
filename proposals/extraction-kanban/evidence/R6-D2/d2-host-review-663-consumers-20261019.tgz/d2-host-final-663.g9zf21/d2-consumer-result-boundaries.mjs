import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { mkdirSync, mkdtempSync, readFileSync, readdirSync, existsSync, writeFileSync, rmSync } from 'node:fs'
import { resolve, join } from 'node:path'
import { pathToFileURL } from 'node:url'

const product = resolve(process.argv[2])
const fromProduct = path => import(pathToFileURL(join(product, 'dist', path)))
const types = await fromProduct('Persistence/EventStore/GitTypes.js')
const processTypes = await fromProduct('Process/ProcessRequest.js')
const sync = await fromProduct('Persistence/EventStore/WriterStreamSync.js')
const gateway = await fromProduct('Git/Gateway.js')
const deadline = await fromProduct('Process/Deadline.js')
const { utcNow } = await fromProduct('fable_modules/fable-library-js.5.13.0/DateOffset.js')
const list = await fromProduct('fable_modules/fable-library-js.5.13.0/List.js')
const { FSharpResult$2: Result } = await fromProduct('fable_modules/fable-library-js.5.13.0/Result.js')
const ok = value => new Result(0, [value])
const error = value => new Result(1, [value])
const oid = digit => types.GitObjectIdModule_create(digit.repeat(40))
const oidText = value => types.GitObjectIdModule_value(value)
const rootSnapshot = new types.StoreSnapshot(types.RootOidModule_create(oid('a')))
const protectedFiles = [
  'Persistence/EventStore/WriterStreamSync.js',
  'Persistence/EventStore/GitTypes.js',
  'Git/Gateway.js',
  'Git/Hook/Sync.js',
]
const digest = path => createHash('sha256').update(readFileSync(path)).digest('hex')
const sourceDigests = () => Object.fromEntries(protectedFiles.map(path => [path, digest(join(product, 'dist', path))]))
const beforeProduct = sourceDigests()
const scratch = mkdtempSync('/private/tmp/d2-consumer-results-')
const outcomes = []
const emit = value => {
  outcomes.push(value)
  console.log(JSON.stringify(value))
}
const bytes = Buffer.from([0, 255, 10, 65, 128])
const nativeReceipt = new types.GitRawResult(1, [
  new types.GitRawObservation(
    new processTypes.EndEvidence(1, []),
    new processTypes.StopRequest(1, [100]),
    new types.GitRawOutput(bytes, Buffer.from([254, 13, 10]), false),
    'native receipt was lost',
  ),
])
const failure = operation => new types.GitStorageFailure(operation, 'No confirmed storage result', nativeReceipt)
const assertFailure = (result, expected) => {
  assert.equal(result.tag, 1)
  const issue = result.fields[0]
  assert.equal(issue.cases()[issue.tag], 'GitStorage')
  assert.equal(issue.fields[0], expected)
  assert.equal(issue.fields[0].Result, nativeReceipt)
  assert.deepEqual(Buffer.from(issue.fields[0].Result.fields[0].Output.Stdout), bytes)
}
const nowMs = Date.now()
const localLine = JSON.stringify({ event_id: '1'.repeat(40), event_type: 'JobRequested', parents: [], payload: {}, payload_refs: [], stream_id: '2'.repeat(40) }) + '\n'
const fixture = name => {
  const common = join(scratch, name, '.git')
  const events = join(common, 'wanxiangshu', 'events')
  mkdirSync(events, { recursive: true })
  const writer = join(events, 'writer-local.ndjson')
  writeFileSync(writer, localLine)
  return { common, events, writer }
}
const localState = scene => ({
  files: readdirSync(scene.events).sort(),
  writer: readFileSync(scene.writer).toString('base64'),
  cache: existsSync(join(scene.common, 'wanxiangshu', 'sync-materialization-cache')),
})
const failIfCalled = name => async () => assert.fail(`${name} must not be called after storage failure`)
const baseRaw = () => ({
  WriteBlob: failIfCalled('WriteBlob'),
  WriteTree: failIfCalled('WriteTree'),
  ReadObject: failIfCalled('ReadObject'),
  ReadTree: failIfCalled('ReadTree'),
  ReadRef: failIfCalled('ReadRef'),
})
const converge = (raw, scene, observed, transport, locked) => gateway.GitGateway_converge(
  raw,
  scene.common,
  transport,
  3,
  'origin',
  observed,
  async stage => {
    locked.count++
    return stage()
  },
  deadline.DeadlineModule_ofBudget(utcNow(), 60000),
  utcNow,
)

try {
  {
    const scene = fixture('read-ref-failure')
    const initial = localState(scene)
    const expected = failure('ReadRef')
    const calls = []
    const locked = { count: 0 }
    const raw = baseRaw()
    raw.ReadRef = async ref => {
      calls.push(ref)
      return error(expected)
    }
    const result = await converge(raw, scene, undefined, failIfCalled('transport'), locked)
    assertFailure(result, expected)
    assert.deepEqual(calls, ['refs/wanxiang/remotes/origin/store'])
    assert.equal(locked.count, 0)
    assert.deepEqual(localState(scene), initial)
    emit({ case: 'failed-tracking-read-stops-before-lock-and-transport', passed: true, rawCalls: calls, receiptIdentityPreserved: true })
  }

  for (const failAt of [1, 2, 3, 4]) {
    const scene = fixture(`write-failure-${failAt}`)
    const initial = localState(scene)
    const expected = failure(`write-${failAt}`)
    const calls = []
    const locked = { count: 0 }
    const raw = baseRaw()
    raw.ReadRef = async () => ok(undefined)
    const write = kind => async () => {
      calls.push(kind)
      if (calls.length === failAt) return error(expected)
      return ok(types.GitObjectIdModule_create(calls.length.toString(16).padStart(40, '0')))
    }
    raw.WriteBlob = write('WriteBlob')
    raw.WriteTree = write('WriteTree')
    const result = await converge(raw, scene, undefined, failIfCalled('push'), locked)
    assertFailure(result, expected)
    assert.equal(calls.length, failAt)
    assert.equal(locked.count, 1)
    assert.deepEqual(localState(scene), initial)
    emit({ case: 'materialization-failure-stops-next-write-cache-and-push', failAt, passed: true, rawCalls: calls, receiptIdentityPreserved: true })
  }

  for (const failAt of ['root', 'writers', 'manifest', 'writer']) {
    const scene = fixture(`read-failure-${failAt}`)
    const initial = localState(scene)
    const expected = failure(`read-${failAt}`)
    const calls = []
    const locked = { count: 0 }
    const raw = baseRaw()
    raw.ReadTree = async requested => {
      const step = oidText(requested) === oidText(oid('a')) ? 'root' : 'writers'
      calls.push(step)
      if (step === failAt) return error(expected)
      if (step === 'root') return ok(list.ofArray([
        new types.TreeEntry('40000', 'writers', oid('b')),
        new types.TreeEntry('100644', 'writer-manifest', oid('c')),
      ]))
      assert.equal(oidText(requested), oidText(oid('b')))
      return ok(list.ofArray([new types.TreeEntry('100644', 'writer-remote.ndjson', oid('d'))]))
    }
    raw.ReadObject = async requested => {
      const step = oidText(requested) === oidText(oid('c')) ? 'manifest' : 'writer'
      calls.push(step)
      if (step === failAt) return error(expected)
      assert.equal(step, 'manifest')
      const name = Buffer.from('writer-remote.ndjson').toString('base64url')
      return ok(Buffer.from(`v2\n${name}\t${oidText(oid('d'))}\t${nowMs}\n`))
    }
    const result = await converge(raw, scene, rootSnapshot, failIfCalled('transport'), locked)
    assertFailure(result, expected)
    assert.equal(calls.at(-1), failAt)
    assert.equal(locked.count, 0)
    assert.deepEqual(localState(scene), initial)
    emit({ case: 'remote-read-failure-stops-import-and-push', failAt, passed: true, rawCalls: calls, receiptIdentityPreserved: true })
  }

  {
    const scene = fixture('normal-and-clean-positive')
    const raw = baseRaw()
    const calls = []
    let published
    let writes = 0
    const locked = { count: 0 }
    raw.ReadRef = async () => ok(published)
    const write = kind => async () => {
      calls.push(kind)
      writes++
      return ok(types.GitObjectIdModule_create(writes.toString(16).padStart(40, '0')))
    }
    raw.WriteBlob = write('WriteBlob')
    raw.WriteTree = write('WriteTree')
    const transport = async args => {
      const argv = list.toArray(args)
      calls.push(argv[0])
      assert.equal(argv[0], 'push')
      return ok(new processTypes.TextProcessExit(0, '', ''))
    }
    const result = await converge(raw, scene, undefined, transport, locked)
    assert.equal(result.tag, 0)
    assert.deepEqual(calls, ['WriteBlob', 'WriteTree', 'WriteBlob', 'WriteTree', 'push'])
    published = types.RootOidModule_value(result.fields[0].RootOid)
    assert.equal(localState(scene).cache, true)
    calls.length = 0
    const repeat = await converge(raw, scene, undefined, failIfCalled('clean transport'), locked)
    assert.equal(repeat.tag, 0)
    assert.equal(oidText(types.RootOidModule_value(repeat.fields[0].RootOid)), oidText(published))
    assert.equal(calls.length, 0)
    emit({ case: 'known-absence-publishes-and-clean-positive-reuses', passed: true, writes, networkCommands: 1 })
  }
  assert.deepEqual(sourceDigests(), beforeProduct)
  emit({ success: true, host: process.execPath, cases: outcomes.length, protectedProductModulesUnchanged: true, sourceDigests: beforeProduct, scope: 'Actual compiled WriterStreamSync and GitGateway consumers with a controlled IGitRawStore and transport. Real local writer file bytes and cache presence are observed. No native Git writes or network operation is claimed.' })
} finally {
  rmSync(scratch, { recursive: true, force: true })
  emit({ cleanup: true, scratchRemoved: !existsSync(scratch) })
}
