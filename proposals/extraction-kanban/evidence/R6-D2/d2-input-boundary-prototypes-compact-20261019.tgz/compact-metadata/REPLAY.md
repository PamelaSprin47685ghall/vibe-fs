# Replay of the private boundary prototypes

The original full archive remains at
`/private/tmp/d2-input-boundary-prototypes-20261019.tgz`, SHA256
`d2b0ca9544877bd6bc5be63b1dbb71ae806949d847d7ebde6b71b62ef55bcec8`.
It is unchanged. This compact archive omits only the four successful native
FileSink target `.bytes` files; their complete size/hash, equality result,
parameters and xorshift32 seed remain in the per-case JSON and OMISSIONS.json.
All original FIFO failure/diagnostic logs, byte counts, receipts, traces and
source code remain included. No existing failure byte file is omitted.

These commands and arguments describe the original bounded runs:

```sh
bun /private/tmp/d2-native-filesink-reentry.3YC6ja/probe.mjs
node /private/tmp/d2-fifo-input-prototype.ZNCo2U/probe.mjs /private/tmp/d2-fifo-input-prototype.ZNCo2U/node-evidence
bun /private/tmp/d2-fifo-input-prototype.ZNCo2U/probe.mjs /private/tmp/d2-fifo-input-prototype.ZNCo2U/bun-evidence
bun /private/tmp/d2-fifo-input-prototype.ZNCo2U/probe.mjs /private/tmp/d2-fifo-input-prototype.ZNCo2U/bun-diagnostic-evidence
bun /private/tmp/d2-fifo-input-prototype.ZNCo2U/probe.mjs /private/tmp/d2-fifo-input-prototype.ZNCo2U/bun-trace-evidence
node /private/tmp/d2-fifo-input-prototype.ZNCo2U/direct-probe.mjs /private/tmp/d2-fifo-input-prototype.ZNCo2U/node-direct-evidence
bun /private/tmp/d2-fifo-input-prototype.ZNCo2U/direct-probe.mjs /private/tmp/d2-fifo-input-prototype.ZNCo2U/bun-direct-evidence
```

The initial two `probe.mjs` failures preceded the diagnostic source edits;
the source-evolution description in its README.md and their untouched logs are
retained. Those commands are not a claim that the final diagnostic source is
byte-identical to every initial fixture. The composed FIFO failure's temporary
target file was not preserved by the initial finally block; there is no missing
raw target file being reclassified as a compact omission.

The native diagnostic ran four cases once each and did not reproduce the
production truncation. The FIFO composed failure remains a failure; the separate
single-hop successes do not accept that pipeline. No FIFO code was wired into
production and no extra repeats were performed while creating this archive.
