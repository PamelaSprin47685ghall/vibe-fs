import assert from 'node:assert/strict'
import * as fs from 'node:fs'
import { join } from 'node:path'
import { spawn, spawnSync } from 'node:child_process'
import { once } from 'node:events'

export function createInput(directory) {
  const root = fs.mkdtempSync(join(directory, 'owned-stdin-fifo-'))
  const path = join(root, 'input')
  const descriptors = new Set()
  const trace = { calls: [], closed: [], pending: false, setupRemoved: false }
  let readFd
  let writeFd
  let sealed = false
  const close = descriptor => {
    if (!descriptors.has(descriptor)) return
    fs.closeSync(descriptor)
    descriptors.delete(descriptor)
    trace.closed.push(descriptor)
  }
  try {
    const created = spawnSync('/usr/bin/mkfifo', [path])
    assert.equal(created.status, 0, created.stderr.toString())
    const bootstrap = fs.openSync(path, fs.constants.O_RDONLY | fs.constants.O_NONBLOCK)
    descriptors.add(bootstrap)
    writeFd = fs.openSync(path, fs.constants.O_WRONLY)
    descriptors.add(writeFd)
    readFd = fs.openSync(path, fs.constants.O_RDONLY)
    descriptors.add(readFd)
    close(bootstrap)
    fs.unlinkSync(path)
    fs.rmdirSync(root)
    trace.setupRemoved = true
  } catch (error) {
    for (const descriptor of [...descriptors]) close(descriptor)
    fs.rmSync(root, { recursive: true, force: true })
    throw error
  }
  return {
    readFd,
    trace,
    releaseParentRead() { close(readFd) },
    async write(input) {
      assert.equal(trace.pending, false, 'One endpoint write is allowed at a time')
      assert.equal(sealed, false, 'The endpoint is already sealed')
      const bytes = Buffer.from(input)
      const call = { requested: bytes.length, pieces: [], written: 0, receipt: null }
      trace.calls.push(call)
      trace.pending = true
      try {
        while (call.written < bytes.length) {
          const size = await new Promise((resolve, reject) => {
            fs.write(writeFd, bytes, call.written, bytes.length - call.written, null, (error, written) => error ? reject(error) : resolve(written))
          })
          if (!Number.isSafeInteger(size) || size <= 0) throw new Error('The FIFO write did not make progress')
          call.pieces.push(size)
          call.written += size
        }
        call.receipt = { kind: 'Written', bytes: bytes.length }
      } catch (error) {
        sealed = true
        call.receipt = { kind: 'Unknown', acknowledgedPrefix: call.written, error: { code: error.code ?? null, message: error.message } }
      } finally {
        trace.pending = false
      }
      return call.receipt
    },
    end() {
      assert.equal(trace.pending, false, 'EOF must follow completion of the last write callback')
      sealed = true
      close(writeFd)
    },
    release() {
      assert.equal(trace.pending, false, 'Do not recycle an FD while an async write is in flight')
      sealed = true
      for (const descriptor of [...descriptors]) close(descriptor)
    },
    inspect() { return { openOwnedDescriptors: [...descriptors], pending: trace.pending, setupRemoved: trace.setupRemoved, sealed } },
  }
}

export function launch(executable, args, directory, input, env = { PATH: process.env.PATH }) {
  try {
    if (globalThis.Bun) {
      const child = Bun.spawn([executable, ...args], { cwd: directory, env, stdin: input.readFd, stdout: 'pipe', stderr: 'pipe' })
      input.releaseParentRead()
      return {
        pid: child.pid,
        stdout: new Response(child.stdout).arrayBuffer().then(bytes => Buffer.from(bytes)),
        stderr: new Response(child.stderr).arrayBuffer().then(bytes => Buffer.from(bytes)),
        ended: child.exited.then(code => ({ code, signal: child.signalCode ?? null })),
        kill: () => child.kill('SIGKILL'),
      }
    }
    const child = spawn(executable, args, { cwd: directory, env, stdio: [input.readFd, 'pipe', 'pipe'] })
    input.releaseParentRead()
    const stdout = []
    const stderr = []
    child.stdout.on('data', bytes => stdout.push(Buffer.from(bytes)))
    child.stderr.on('data', bytes => stderr.push(Buffer.from(bytes)))
    const ended = once(child, 'close').then(([code, signal]) => ({ code, signal }))
    return { pid: child.pid, stdout: ended.then(() => Buffer.concat(stdout)), stderr: ended.then(() => Buffer.concat(stderr)), ended, kill: () => child.kill('SIGKILL') }
  } catch (error) {
    input.release()
    throw error
  }
}
