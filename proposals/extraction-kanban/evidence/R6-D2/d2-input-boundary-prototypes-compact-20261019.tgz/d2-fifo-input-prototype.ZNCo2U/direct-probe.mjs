import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { setTimeout as delay } from 'node:timers/promises'
import { createInput, launch } from './fifo.mjs'

const evidence = process.argv[2]
mkdirSync(evidence, { recursive: true })
const scratch = mkdtempSync('/private/tmp/d2-fifo-input-run-')
const results = []
const owned = []
const sha = bytes => createHash('sha256').update(bytes).digest('hex')
const pattern = size => {
  const bytes = Buffer.alloc(size)
  let value = 0x81261ac3
  for (let index = 0; index < size; index++) {
    value ^= value << 13
    value ^= value >>> 17
    value ^= value << 5
    bytes[index] = value >>> 24
  }
  return bytes
}
const ready = async path => {
  const limit = performance.now() + 3000
  while (!existsSync(path) && performance.now() < limit) await delay(5)
  assert.equal(existsSync(path), true)
}

try {
  for (const size of [2097169, 33554449]) {
    const bytes = pattern(size)
    for (const hops of [1]) {
      const witness = join(scratch, `target-${size}-${hops}`)
      const tracePath = join(scratch, `bridge-${size}-${hops}.json`)
      const input = createInput(scratch)
      const child = hops === 1 ? launch('/usr/bin/tee', [witness], scratch, input) : launch('/opt/homebrew/bin/bun', ['/private/tmp/d2-fifo-input-prototype.ZNCo2U/bridge.mjs', witness, tracePath, scratch], scratch, input)
      owned.push({ input, child })
      const watchdog = setTimeout(() => child.kill(), 15000)
      try {
        for (let position = 0; position < bytes.length; position += 16777216) {
          const part = bytes.subarray(position, position + 16777216)
          const receipt = await input.write(part)
          if (receipt.kind !== 'Written') {
            const failed = { case: 'write-failed', size, hops, receipt, child: await child.ended, stdout: (await child.stdout).toString(), stderr: (await child.stderr).toString(), trace: existsSync(tracePath) ? readFileSync(tracePath, 'utf8') : null }
            writeFileSync(join(evidence, `write-failed-${size}-${hops}.json`), JSON.stringify(failed, null, 2) + '\n')
            console.log(JSON.stringify(failed))
          }
          assert.deepEqual(receipt, { kind: 'Written', bytes: part.length })
        }
        input.end()
        const ended = await child.ended
        assert.equal(ended.code, 0)
        const stdout = await child.stdout
        const stderr = await child.stderr
        const actual = readFileSync(witness)
        assert.deepEqual(actual, bytes)
        assert.deepEqual(stdout, bytes)
        assert.equal(stderr.length, 0)
        const bridge = hops === 2 ? JSON.parse(readFileSync(tracePath, 'utf8')) : null
        if (bridge) {
          assert.equal(bridge.sourceBytes, bytes.length)
          assert.equal(bridge.sourceEOF, true)
          assert.deepEqual(bridge.final.openOwnedDescriptors, [])
          writeFileSync(join(evidence, `bridge-${size}.json`), JSON.stringify(bridge, null, 2) + '\n')
        }
        const result = { passed: true, case: 'kernel-fifo-complete-write-and-EOF', host: process.execPath, size, hops, expectedSha256: sha(bytes), targetSha256: sha(actual), stdoutSha256: sha(stdout), byteEqualityChecked: true, ended, trace: input.trace, bridge }
        results.push(result)
        console.log(JSON.stringify(result))
      } finally {
        clearTimeout(watchdog)
        child.kill()
        await child.ended
        input.release()
        assert.deepEqual(input.inspect().openOwnedDescriptors, [])
      }
    }
  }

  {
    const marker = join(scratch, 'early-close-ready')
    const code = `require('node:fs').closeSync(0); require('node:fs').writeFileSync(${JSON.stringify(marker)},'ready'); setTimeout(()=>process.exit(23),100);`
    const input = createInput(scratch)
    const child = launch('/opt/homebrew/bin/node', ['-e', code], scratch, input)
    owned.push({ input, child })
    await ready(marker)
    const receipt = await input.write(pattern(1048576))
    assert.equal(receipt.kind, 'Unknown')
    assert.equal(receipt.error.code, 'EPIPE')
    input.end()
    const ended = await child.ended
    assert.equal(ended.code, 23)
    input.release()
    assert.deepEqual(input.inspect().openOwnedDescriptors, [])
    const result = { passed: true, case: 'target-closes-read-end', host: process.execPath, receipt, ended, calls: input.trace.calls.length, noRetry: input.trace.calls.length === 1, endpoint: input.inspect(), trace: input.trace }
    results.push(result)
    console.log(JSON.stringify(result))
  }

  {
    const marker = join(scratch, 'blocked-ready')
    const code = `require('node:fs').writeFileSync(${JSON.stringify(marker)},'ready'); setInterval(()=>{},1000);`
    const input = createInput(scratch)
    const child = launch('/opt/homebrew/bin/node', ['-e', code], scratch, input)
    owned.push({ input, child })
    await ready(marker)
    let settled = false
    const pending = input.write(pattern(16777216)).then(value => { settled = true; return value })
    await delay(100)
    assert.equal(settled, false)
    child.kill()
    const ended = await child.ended
    const receipt = await pending
    assert.equal(receipt.kind, 'Unknown')
    input.end()
    input.release()
    assert.deepEqual(input.inspect().openOwnedDescriptors, [])
    const result = { passed: true, case: 'kill-releases-one-pending-fifo-write', host: process.execPath, pendingEstablished: true, receipt, ended, calls: input.trace.calls.length, noRetry: input.trace.calls.length === 1, endpoint: input.inspect(), trace: input.trace, noSuccessfulTargetEndInferred: true }
    results.push(result)
    console.log(JSON.stringify(result))
  }
  writeFileSync(join(evidence, 'summary.json'), JSON.stringify({ passed: true, host: process.execPath, results, scope: 'Private physical prototype only. Real POSIX stdin FIFOs with inherited blocking read descriptors, parent asynchronous fs.write full-progress loop, EOF by descriptor close. One-hop native tee and composed Bun process.stdin.iterator→second FIFO→tee use actual OS input. EPIPE and pending-write kill have no retry and all owned FDs are closed. This is not current production or an acceptance of FileSink behavior.' }, null, 2) + '\n')
} finally {
  for (const { input, child } of owned) {
    child.kill()
    await child.ended
    if (!input.inspect().pending) input.release()
  }
  rmSync(scratch, { recursive: true, force: true })
  console.log(JSON.stringify({ cleanup: true, scratchRemoved: !existsSync(scratch), endpoints: owned.map(({ input }) => input.inspect()) }))
}
