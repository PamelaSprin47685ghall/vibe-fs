# Private FIFO input prototype

No shared production file was edited. `fifo.mjs` creates a real POSIX FIFO,
opens a blocking child read descriptor and an async parent write descriptor,
removes the setup path, closes the parent copy of the read descriptor after
spawn, and loops on exact positive `fs.write` progress. It never retries a
failed write. EOF follows the final write callback by closing the write FD.
It refuses to recycle an FD while a write remains in flight.

## Results

- Initial `probe.mjs` on Node and Bun: direct 2 MiB + 17 passed, but the
  composed Bun bridge did not finish within its 15-second owned watchdog.
  The watchdog killed the bridge; the upstream write then returned EPIPE.
  These original failed logs are retained as `node.log` and `bun.log`.
- `bun-diagnostic.log` retains a second bounded diagnostic with child stderr,
  which was empty and showed SIGKILL from that watchdog.
- `bun-trace.log` adds phase tracing. The bridge had forwarded 1,589,248 of
  2,097,169 bytes in 8 KiB pieces. The last recorded inner write was Written;
  its input was not pending, and the source had not reached EOF. No unique
  cause was established. The composed path is not accepted for production.
- Separate `direct-probe.mjs` deliberately runs only the one-hop endpoint.
  Node and Bun each passed 2 MiB + 17 and 32 MiB + 17 by comparing the real tee
  file and stdout byte for byte. The target closes fd 0 case retained exit 23
  and returned Unknown/EPIPE without retry. The stopped-reader case established
  one pending 16 MiB write for 100 ms, killed the actual target, returned
  Unknown/EPIPE without retry, and closed every owned FD.

The direct endpoint result is not a production replacement or a resolution of
the composed failure. It does not prove multi-endpoint worker-pool fairness or
bounded cancellation when a reader stays alive without reading. The bridge's
use of native output pipes also differs from production output FIFOs.

## Probe-only edits during diagnosis

Before the initial runs, bridge output was changed from `writeFileSync` to an
explicit full-progress `writeSync` loop to avoid relying on one output write.
After the initial failures, `probe.mjs` recorded child exit/stderr on a failed
input receipt. The third attempt additionally wrote bridge phase/count trace
files. These are diagnostic fixture changes, not production repairs. Original
failed logs remain unchanged. `direct-probe.mjs` is the instrumented probe with
only the hop list changed from `[1, 2]` to `[1]`.

The fixture finally blocks closed owned endpoints and awaited owned children.
An independent process inventory after the initial matrices showed no process
whose command contained either private probe directory prefix.
