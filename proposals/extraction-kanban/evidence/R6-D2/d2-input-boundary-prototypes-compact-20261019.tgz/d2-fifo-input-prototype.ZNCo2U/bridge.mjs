import { createInput, launch } from './fifo.mjs'
import { writeFileSync, writeSync } from 'node:fs'

function writeAll(descriptor, bytes) {
  let position = 0
  while (position < bytes.length) {
    const written = writeSync(descriptor, bytes, position, bytes.length - position)
    if (written <= 0) throw new Error('The output write did not make progress')
    position += written
  }
}

const [witness, tracePath, directory] = process.argv.slice(2)
writeFileSync(tracePath, JSON.stringify({ entered: true, pid: process.pid, inputFd: process.stdin.fd }) + '\n')
const input = createInput(directory)
const child = launch('/usr/bin/tee', [witness], directory, input)
const trace = { sourceChunks: [], sourceBytes: 0, sourceEOF: false, input: input.trace }
writeFileSync(tracePath, JSON.stringify({ ...trace, targetPid: child.pid, phase: 'before-iterator' }) + '\n')
try {
  for await (const bytes of process.stdin.iterator({ destroyOnReturn: false })) {
    trace.sourceChunks.push(bytes.length)
    trace.sourceBytes += bytes.length
    writeFileSync(tracePath, JSON.stringify({ ...trace, phase: 'write-start' }) + '\n')
    const written = await input.write(bytes)
    writeFileSync(tracePath, JSON.stringify({ ...trace, written, phase: 'write-complete' }) + '\n')
    if (written.kind !== 'Written') break
  }
  trace.sourceEOF = true
  input.end()
  const ended = await child.ended
  const stdout = await child.stdout
  const stderr = await child.stderr
  writeAll(1, stdout)
  writeAll(2, stderr)
  trace.child = ended
} finally {
  child.kill()
  await child.ended
  input.release()
  trace.final = input.inspect()
  writeFileSync(tracePath, JSON.stringify(trace, null, 2) + '\n')
}
