# Native FileSink pressure comparison

This private diagnostic uses the actual installed Bun 1.3.14 revision
`d1632b2918dfa83f43686946325bcc9cceab6594`. It does not modify a package.

Each of four cases ran once. A real Node child waits 50 ms, reads at most
64 KiB, writes every byte to an owned file, then waits 1 ms between reads.
The parent sends 16 MiB + 17 or 32 MiB + 17 bytes in 16 MiB chunks.
It awaits the actual FileSink write and flush. The second variant additionally
awaits setImmediate after each flush, before publishing success to the next
write or EOF.

All four target files equal the input byte for byte. The test did not reproduce
the production loss. The green comparison does not establish that the known
production last-17-byte failure has the same cause as the upstream FileSink
reentrancy correction. It does not accept the package or propose a timeout
workaround. Each target was killed and awaited in finally after its own exit.

The full target byte files and read-size traces are retained in evidence.
The xorshift pattern is nonperiodic and differs from the formal test pattern.
The target has one input hop. The production Host/Worker pipeline and the
formal suite's preceding history are not reproduced here.
