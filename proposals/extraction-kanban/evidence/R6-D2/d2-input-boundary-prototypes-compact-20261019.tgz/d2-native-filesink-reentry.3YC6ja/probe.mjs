import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { setImmediate as nextTurn } from 'node:timers/promises'
import { join } from 'node:path'

assert.ok(globalThis.Bun, 'This is an actual Bun FileSink probe')
const root = '/private/tmp/d2-native-filesink-reentry.3YC6ja'
const evidence = join(root, 'evidence')
mkdirSync(evidence, { recursive: true })
const hash = bytes => createHash('sha256').update(bytes).digest('hex')
const pattern = size => {
  const bytes = Buffer.alloc(size)
  let value = 0x81261ac3
  for (let index = 0; index < size; index++) {
    value ^= value << 13
    value ^= value >>> 17
    value ^= value << 5
    bytes[index] = value >>> 24
  }
  return bytes
}
const cases = []
for (const size of [16777233, 33554449]) {
  const expected = pattern(size)
  for (const mode of ['microtask-next-write-and-end', 'setImmediate-after-flush']) {
    const name = `${size}-${mode}`
    const output = join(evidence, name + '.bytes')
    const tracePath = join(evidence, name + '.target.json')
    const trace = []
    const child = Bun.spawn(['/opt/homebrew/bin/node', join(root, 'reader.mjs'), output, tracePath], { stdin: 'pipe', stdout: 'ignore', stderr: 'pipe' })
    const stderr = new Response(child.stderr).text()
    let deadline = false
    const watchdog = setTimeout(() => { deadline = true; child.kill('SIGKILL') }, 10000)
    const start = performance.now()
    try {
      for (let position = 0; position < expected.length; position += 16777216) {
        const part = expected.subarray(position, position + 16777216)
        const result = child.stdin.write(part)
        const accepted = await result
        const flushed = await child.stdin.flush()
        trace.push({ position, requested: part.length, writeResultWasPromise: !!result?.then, accepted, flushed, at: performance.now() - start })
        if (mode === 'setImmediate-after-flush') await nextTurn()
      }
      const endResult = await child.stdin.end()
      const code = await child.exited
      const actual = existsSync(output) ? readFileSync(output) : Buffer.alloc(0)
      const target = existsSync(tracePath) ? JSON.parse(readFileSync(tracePath, 'utf8')) : null
      const result = { mode, size, actualSize: actual.length, byteEqual: actual.equals(expected), expectedSha256: hash(expected), actualSha256: hash(actual), missing: size - actual.length, exit: code, signal: child.signalCode, deadline, endResult, stderr: await stderr, trace, target }
      cases.push(result)
      writeFileSync(join(evidence, name + '.json'), JSON.stringify(result, null, 2) + '\n')
      console.log(JSON.stringify(result))
    } finally {
      clearTimeout(watchdog)
      child.kill('SIGKILL')
      await child.exited
    }
  }
}
writeFileSync(join(evidence, 'summary.json'), JSON.stringify({ runtime: Bun.version, revision: Bun.revision, cases, scope: 'Native Bun.spawn FileSink physical pressure diagnostic only. Each case runs once. setImmediate is an event-loop non-reentrancy comparison, not a timeout workaround or a production fix.' }, null, 2) + '\n')
