import { closeSync, openSync, readSync, writeFileSync, writeSync } from 'node:fs'
import { setTimeout as delay } from 'node:timers/promises'

const [outputPath, tracePath] = process.argv.slice(2)
const output = openSync(outputPath, 'wx')
const buffer = Buffer.alloc(65536)
let total = 0
const chunks = []
try {
  await delay(50)
  while (true) {
    const count = readSync(0, buffer, 0, buffer.length, null)
    if (count === 0) break
    chunks.push(count)
    let position = 0
    while (position < count) position += writeSync(output, buffer, position, count - position)
    total += count
    await delay(1)
  }
} finally {
  closeSync(output)
  writeFileSync(tracePath, JSON.stringify({ pid: process.pid, total, chunks, eof: true }) + '\n')
}
