import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { createHash } from 'node:crypto'
import { spawn } from 'node:child_process'

const [repository, product, archive, archiveSHA, prior, evidence] = process.argv.slice(2)
fs.mkdirSync(evidence, { recursive: true })
const scratch = fs.mkdtempSync('/private/tmp/d2-663-typed-runtime-')
const hash = file => createHash('sha256').update(fs.readFileSync(file)).digest('hex')
const save = (name, data) => fs.writeFileSync(path.join(evidence, name), JSON.stringify(data, null, 2))
const files = root => {
  const result = {}
  const visit = directory => {
    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
      const file = path.join(directory, entry.name)
      if (entry.isDirectory()) visit(file)
      else {
        assert.equal(entry.isSymbolicLink(), false)
        result[path.relative(root, file)] = hash(file)
      }
    }
  }
  visit(root)
  return result
}
const signatures = Object.fromEntries(Object.entries(JSON.parse(fs.readFileSync(path.join(prior, 'real-source-inputs.json')))).filter(([name]) => name.endsWith('.fsi')))
const checkSignatures = () => {
  assert.equal(Object.keys(signatures).length, 15)
  for (const [name, expected] of Object.entries(signatures)) assert.equal(hash(path.join(repository, 'src/Wanxiangshu', name)), expected, name)
}
const execute = (host, directory, driver) => new Promise((resolve, reject) => {
  fs.mkdirSync(directory, { recursive: true })
  fs.mkdirSync(path.join(directory, 'home'))
  fs.mkdirSync(path.join(directory, 'tmp'))
  const executable = host === 'node' ? '/opt/homebrew/bin/node' : '/opt/homebrew/bin/bun'
  const env = { PATH: process.env.PATH, HOME: path.join(directory, 'home'), USERPROFILE: path.join(directory, 'home'), TMPDIR: path.join(directory, 'tmp'), GIT_CONFIG_NOSYSTEM: '1', GIT_CONFIG_GLOBAL: '/dev/null' }
  save(`${host}.command.json`, { executable, args: [driver], cwd: directory, env })
  const stdout = fs.openSync(path.join(evidence, `${host}.stdout`), 'w')
  const stderr = fs.openSync(path.join(evidence, `${host}.stderr`), 'w')
  const child = spawn(executable, [driver], { cwd: directory, env, detached: true, stdio: ['ignore', stdout, stderr] })
  let timedOut = false
  const timeout = setTimeout(() => {
    timedOut = true
    try { process.kill(-child.pid, 'SIGKILL') } catch (error) { if (error.code !== 'ESRCH') throw error }
  }, 60000)
  child.on('error', reject)
  child.on('close', (code, signal) => {
    clearTimeout(timeout)
    fs.closeSync(stdout)
    fs.closeSync(stderr)
    const status = { host, code, signal, timedOut, pid: child.pid }
    save(`${host}.status.json`, status)
    resolve(status)
  })
})

try {
  assert.equal(hash(archive), archiveSHA)
  checkSignatures()
  const before = files(product)
  save('products-before.json', before)
  save('unchanged-real-fsi.json', signatures)
  fs.mkdirSync(path.join(scratch, 'program'))
  fs.writeFileSync(path.join(scratch, 'package.json'), JSON.stringify({ name: 'd2-663-independent-typed', private: true, type: 'module' }))
  const consumer = path.join(scratch, 'program/D2TypedConsumer.js')
  const expectedConsumer = 'baa22ffb40cf00ad92b9b85fa4c42037568b468b1116796390239991c46e2c81'
  assert.equal(hash(path.join(prior, 'D2TypedConsumer.js')), expectedConsumer)
  fs.copyFileSync(path.join(prior, 'D2TypedConsumer.js'), consumer)
  fs.copyFileSync(path.join(prior, 'driver.mjs'), path.join(scratch, 'program/driver.mjs'))
  fs.copyFileSync(path.join(prior, 'D2TypedConsumer.fs'), path.join(evidence, 'D2TypedConsumer.fs'))
  fs.copyFileSync(consumer, path.join(evidence, 'D2TypedConsumer.js'))
  fs.copyFileSync(path.join(scratch, 'program/driver.mjs'), path.join(evidence, 'driver.mjs'))
  const links = [[path.join(scratch, 'program/Persistence'), path.join(product, 'dist/Persistence')], [path.join(scratch, 'program/Process'), path.join(product, 'dist/Process')], [path.join(scratch, 'fable_modules'), path.join(product, 'dist/fable_modules')]]
  for (const [from, to] of links) fs.symlinkSync(to, from)
  save('runtime-imports.json', { links, emittedConsumerSHA256: expectedConsumer, noImportRewrite: true, noGeneratedProductionImplementation: true, onlyFixedPackageRuntime: true })
  const results = await Promise.all(['node', 'bun'].map(host => execute(host, path.join(scratch, host), path.join(scratch, 'program/driver.mjs'))))
  assert.deepEqual(files(product), before)
  checkSignatures()
  assert.equal(hash(archive), archiveSHA)
  assert.equal(hash(consumer), expectedConsumer)
  save('products-after.json', files(product))
  save('summary.json', { archiveSHA256: archiveSHA, results, reusedTypeEvidence: prior, reusedTypeEvidenceArchiveSHA256: 'a34ae068c3fb656e73bc2b53f8d0edfd604aef6d4fc10816e2fdf0926a1cc8f6', unchangedRealFsi: 15, newCompileCount: 0, priorPositiveAndFiveNegativesReused: true, sameEmittedConsumerJS: expectedConsumer, scope: 'Same actual F#-compiled consumer using only fixed clean-installed candidate663 dist. No production JS generated or source runtime fallback, no npm d.ts claim.' })
  for (const result of results) {
    assert.equal(result.timedOut, false)
    assert.equal(result.code, 0, fs.readFileSync(path.join(evidence, `${result.host}.stderr`), 'utf8'))
  }
} catch (error) {
  save('harness-error.json', { message: error.message, stack: error.stack })
  process.exitCode = 1
} finally {
  fs.rmSync(scratch, { recursive: true, force: true })
  save('cleanup.json', { scratchRemoved: !fs.existsSync(scratch), fixedInstallationPreserved: fs.existsSync(product), scope: 'Runtime Git scopes close through their actual production capture completion. No independent per-PID sampling claimed.' })
}
