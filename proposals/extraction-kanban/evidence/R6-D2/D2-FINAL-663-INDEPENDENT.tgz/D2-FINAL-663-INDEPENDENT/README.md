# Independent fixed candidate 663 acceptance

The included main archive `packages/wanxiangshu-0.9.0.tgz` has SHA256 `3c0afec4f5aee947cff92a5a2e633a41d4e9728daa515f27295e634ed9b324e0`. It embeds wanxiangli 0.6.12. Runtime came only from `/private/tmp/d2-clean-install-663/node_modules/wanxiangshu`, an actual clean npm installation. The installation lock is included. All 2904 installed product files were hashed before and after and remained identical. No private trace/checkpoint modification was applied to this installation.

One preregistered independent Bun 1.3.14 run of the original 19-case 017 sequence passed 19/19 in 19.07 seconds. `current/017-original.test.mjs` is the original fixture; `017-fixed.test.mjs` only binds its two imports and its cold-child import to absolute fixed-product/helper URLs. `017-import-only.diff` proves those changes. All 19 bodies, assertions and original repository cleanup remained unchanged. The real 33554449, 67108864 and 67108881-byte Git writes and independent cold OS reads passed. No per-block tracing, diagnostic source reads, altered chunk sizes or retry loops were used.

The same emitted F# consumer JavaScript that previously failed on candidate 659 was run unchanged against 663 on Node 26.6.0 and Bun 1.3.14. Both accepted and exited 0. Its SHA256 remains `baa22ffb40cf00ad92b9b85fa4c42037568b468b1116796390239991c46e2c81`. It exercised actual Git exit 7/128 on raw and store channels, exact binary data, combined output limit, 2MiB+17 bytes, cold binary object reading, cold UTF-8 tree ordering, missing objects/trees as errors, exact missing refs as None, permission errors and Unknown handling.

This phase performed zero new F# compiles. It reuses the real candidate-660 Fable compilation and five rejected type-negative programs. All 15 actual .fsi inputs were compared byte-for-byte with that evidence before and after runtime. `prior-fsi-compile-660/` retains the original positive/negative logs and emitted program, and `contracts-repository/` holds the unchanged real signatures for portable comparison. This is an internal F# contract proof, not a claim of npm d.ts declarations.

The runtime stage contained only the original emitted consumer, its unchanged driver and links to the fixed package's dist modules. No generated production implementation or source runtime fallback was created for this replay. Its scratch runtime was removed afterwards. The original 19 fixture used its actual cleanup; this selected run does not separately claim per-PID sampling or the parent's owned-test gate result.

`current/typed-replay.mjs` is the exact replay runner and accepts explicit locations. For a future replay after installing the included fixed main archive, run from this directory with fresh evidence output:

```sh
node current/typed-replay.mjs "$PWD/contracts-repository" "$fixed_product_directory" "$PWD/packages/wanxiangshu-0.9.0.tgz" 3c0afec4f5aee947cff92a5a2e633a41d4e9728daa515f27295e634ed9b324e0 "$PWD/prior-fsi-compile-660" /private/tmp/d2-663-typed-fresh
shasum -a 256 -c MANIFEST.sha256
```

The recorded Bun-017 fixture's original absolute helper/product paths are preserved as provenance; its exact bodies and diff are provided for an explicitly rebound future fixed installation. Do not interpret this single passing sequence as exhaustive platform or reliability proof. The older 659, 661 and 662 red archives remain independent and unchanged. In particular, the 662 EOF diagnosis proved the native Readable retained the exact missing tail after iterator completion. The controlled library checkpoints are archived separately as `D2-LIB-0612-CHECKPOINTS.tgz`; they do not replace this clean-product run. R12-U1 remains deferred.
