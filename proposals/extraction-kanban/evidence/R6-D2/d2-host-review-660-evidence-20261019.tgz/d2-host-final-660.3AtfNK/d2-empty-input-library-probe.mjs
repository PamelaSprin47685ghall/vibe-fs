import { readFileSync } from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'
import { createHash } from 'node:crypto'

const library = process.argv[2]
const { SupervisedProcess } = await import(pathToFileURL(join(library, 'dist/supervision/SupervisedProcess.js')))
const sources = { sha256: createHash('sha256').update(readFileSync(join(library, 'dist/supervision/SupervisedProcess.js'))).digest('hex'), version: JSON.parse(readFileSync(join(library, 'package.json'), 'utf8')).version }
const results = []
for (const scenario of ['wc-empty', 'node-empty', 'node-one-byte']) {
  const node = scenario !== 'wc-empty'
  const session = new SupervisedProcess({ executable: node ? '/opt/homebrew/bin/node' : '/usr/bin/wc', args: node ? ['-e', "const fs=require('node:fs'); const b=fs.readFileSync(0); fs.writeFileSync(1,String(b.length));"] : ['-c'], cwd: '/private/tmp', env: { PATH: process.env.PATH }, tailBytes: 0, maxWriteBytes: 16777216 })
  const chunks = { stdout: [], stderr: [] }
  const capture = (async () => { while (true) { const result = await session.takeOutput(); if (result.kind !== 'Chunk') return result; chunks[result.channel].push(Buffer.from(result.bytes)) } })()
  let beforeStop
  let signal
  const timer = setTimeout(() => { beforeStop = session.inspect(); signal = session.signal('SIGKILL') }, 1500)
  try {
    const started = await session.started()
    const write = scenario === 'node-one-byte' ? await session.write(Uint8Array.of(65)) : null
    session.endInput()
    const terminal = await capture
    const closed = await session.wait(1000)
    const result = { scenario, host: process.execPath, sources, started, write, beforeStop: beforeStop ?? null, signal: signal ?? null, terminal, closed, stdout: Buffer.concat(chunks.stdout).toString('base64'), stderr: Buffer.concat(chunks.stderr).toString('base64') }
    results.push(result)
    console.log(JSON.stringify(result))
  } finally {
    clearTimeout(timer)
    session.signal('SIGKILL')
    session.discardOutput()
    await session.wait(3000)
  }
}
console.log(JSON.stringify({ scope: 'Real fixed public SupervisedProcess; empty EOF vs one-byte write controls.15s is not used to mask any issue;1500ms own-scope watchdog supplies negative observation and cleanup.', results: results.length }))
