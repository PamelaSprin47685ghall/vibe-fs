import assert from 'node:assert/strict'
import {realpathSync} from 'node:fs'
import {fileURLToPath} from 'node:url'
import {join} from 'node:path'
const resolved=import.meta.resolve('wanxiangshu')
assert.equal(realpathSync(fileURLToPath(resolved)),realpathSync(join(process.env.D1_EXPECTED_PRODUCT_ROOT,'dist/OpenCode/Plugin/Plugin.js')))
const {default:plugin}=await import('wanxiangshu')
assert.equal(typeof plugin.server,'function')
console.log(JSON.stringify({case:'npm-public-root-exports-resolved',host:process.execPath,resolved,product:process.env.D1_EXPECTED_PRODUCT_ROOT}))
await import('./requirements/process-execution/tests/013.test.mjs')
