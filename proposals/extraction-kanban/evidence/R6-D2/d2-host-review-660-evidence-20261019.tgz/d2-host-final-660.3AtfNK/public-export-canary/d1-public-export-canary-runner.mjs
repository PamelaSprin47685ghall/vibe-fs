import assert from 'node:assert/strict'
import fs from 'node:fs'
import { spawn } from 'node:child_process'
import { join, dirname, relative, resolve } from 'node:path'
import { createHash } from 'node:crypto'
import { tmpdir } from 'node:os'
import { fileURLToPath } from 'node:url'

const product = resolve(process.argv[2])
const archive = resolve(process.argv[3])
const expected = process.argv[4]
const fixtureRoot = resolve(process.argv[5])
const temporaryRoot = process.env.D1_REVIEW_TMP_ROOT || (fs.existsSync('/private/tmp') ? '/private/tmp' : tmpdir())
const nodeExecutable = process.env.D1_NODE || process.execPath
const bunExecutable = process.env.D1_BUN || 'bun'
const evidence = fs.mkdtempSync(join(temporaryRoot, 'd1-public-export-canary-evidence-'))
const scratch = fs.mkdtempSync(join(temporaryRoot, 'd1-public-export-canary-case-'))
const installRoot = dirname(dirname(product))
const digest = path => createHash('sha256').update(fs.readFileSync(path)).digest('hex')
const save = (name, value) => fs.writeFileSync(join(evidence, name), JSON.stringify(value, null, 2), { mode: 0o600 })
const files = root => {
  const result = {}
  const visit = directory => {
    for (const name of fs.readdirSync(directory).sort()) {
      const path = join(directory, name)
      const stat = fs.lstatSync(path)
      assert.equal(stat.isSymbolicLink(), false)
      if (stat.isDirectory()) visit(path)
      else result[relative(root, path)] = digest(path)
    }
  }
  visit(root)
  return result
}
const selectedFixtures = [
  'requirements/process-execution/tests/013.test.mjs',
  'requirements/process-execution/tests/support/executor.mjs',
  'requirements/verification-system/tests/support/plugin-fixture.mjs',
  'requirements/verification-system/tests/support/routing-home.mjs',
  'requirements/verification-system/tests/support/blogger-ownership.mjs',
]
const run = async (name, executable, args, cwd, env) => {
  const stdout = fs.openSync(join(evidence, `${name}.stdout`), 'w', 0o600)
  const stderr = fs.openSync(join(evidence, `${name}.stderr`), 'w', 0o600)
  save(`${name}.command.json`, { executable, args, cwd, env, timeoutMs: 45000 })
  const child = spawn(executable, args, { cwd, env, detached: true, stdio: ['ignore', stdout, stderr] })
  let timedOut = false
  const timer = setTimeout(() => {
    timedOut = true
    try { process.kill(-child.pid, 'SIGKILL') } catch (error) { if (error.code !== 'ESRCH') throw error }
  }, 45000)
  const result = await new Promise((resolve, reject) => {
    child.once('error', reject)
    child.once('close', (code, signal) => resolve({ code, signal, timedOut, pid: child.pid }))
  })
  clearTimeout(timer)
  fs.closeSync(stdout)
  fs.closeSync(stderr)
  save(`${name}.status.json`, result)
  return result
}

console.log(JSON.stringify({ evidence, scratch, product, archive, expected }))
try {
  assert.equal(digest(archive), expected)
  const before = files(product)
  save('products-before.json', before)
  const lock = join(installRoot, 'package-lock.json')
  const lockSHA256 = digest(lock)
  const canary = join(scratch, 'canary')
  fs.mkdirSync(canary)
  fs.writeFileSync(join(canary, 'package.json'), JSON.stringify({ name: 'd1-independent-public-export-canary', private: true, type: 'module' }))
  fs.symlinkSync(join(installRoot, 'node_modules'), join(canary, 'node_modules'))
  fs.symlinkSync(join(product, 'dist'), join(canary, 'dist'))
  const fixtureDigests = {}
  for (const name of selectedFixtures) {
    const source = join(fixtureRoot, name)
    const destination = join(canary, name)
    fs.mkdirSync(dirname(destination), { recursive: true })
    fs.copyFileSync(source, destination)
    const frozen = join(evidence, 'fixtures', name)
    fs.mkdirSync(dirname(frozen), { recursive: true })
    fs.copyFileSync(source, frozen)
    fixtureDigests[name] = digest(source)
  }
  save('fixture-inputs.json', fixtureDigests)
  const driver = join(canary, 'public-export.test.mjs')
  fs.writeFileSync(driver, "import assert from 'node:assert/strict'\nimport {realpathSync} from 'node:fs'\nimport {fileURLToPath} from 'node:url'\nimport {join} from 'node:path'\nconst resolved=import.meta.resolve('wanxiangshu')\nassert.equal(realpathSync(fileURLToPath(resolved)),realpathSync(join(process.env.D1_EXPECTED_PRODUCT_ROOT,'dist/OpenCode/Plugin/Plugin.js')))\nconst {default:plugin}=await import('wanxiangshu')\nassert.equal(typeof plugin.server,'function')\nconsole.log(JSON.stringify({case:'npm-public-root-exports-resolved',host:process.execPath,resolved,product:process.env.D1_EXPECTED_PRODUCT_ROOT}))\nawait import('./requirements/process-execution/tests/013.test.mjs')\n")
  fs.copyFileSync(driver, join(evidence, 'public-export.test.mjs'))
  const { writeRoutingHome } = await import(join(canary, 'requirements/verification-system/tests/support/routing-home.mjs'))
  const results = await Promise.all([{ host: 'node', executable: nodeExecutable }, { host: 'bun', executable: bunExecutable }].map(async ({ host, executable }) => {
    const home = join(scratch, host, 'home')
    const temporary = join(scratch, host, 'tmp')
    fs.mkdirSync(home, { recursive: true })
    fs.mkdirSync(temporary)
    writeRoutingHome(home)
    const args = host === 'node' ? ['--test', driver] : ['test', driver]
    return { host, result: await run(host, executable, args, canary, { PATH: process.env.PATH, HOME: home, USERPROFILE: home, TMPDIR: temporary, D1_EXPECTED_PRODUCT_ROOT: product, WANXIANGSHU_PROVIDER_LANGUAGE: 'en', WANXIANGSHU_NO_FATAL_EXIT: '1' }) }
  }))
  const after = files(product)
  save('products-after.json', after)
  assert.deepEqual(after, before)
  assert.equal(digest(lock), lockSHA256)
  assert.equal(digest(archive), expected)
  save('summary.json', { results, fixedArchive: expected, installedSubtreeFiles: Object.keys(before).length, productBytesUnchanged: true, archiveUnchanged: true, installLockSHA256: lockSHA256, installLockUnchanged: true, fixtureDigests, consumerRootDistinctFromProductName: true, publicRootExportsLoaded: true, dependencyPath: join(installRoot, 'node_modules'), noBorrowedMainDependencies: true, noSourceImplementationRuntime: true, scope: 'The five copied files are requirement fixtures, not product implementations. Their compiled production imports link only to the clean-installed fixed dist. The actual plugin is imported through npm wanxiangshu public exports and creates registered DevOps hooks; the real run tool checks small, spooled and line-limited output plus zero model sessions/prompts using the existing Host client double. This is not an external OpenCode/model network session.' })
  for (const value of results) {
    assert.equal(value.result.timedOut, false)
    assert.equal(value.result.code, 0, fs.readFileSync(join(evidence, `${value.host}.stderr`), 'utf8'))
    const output = fs.readFileSync(join(evidence, `${value.host}.stdout`), 'utf8') + fs.readFileSync(join(evidence, `${value.host}.stderr`), 'utf8')
    assert.match(output, /npm-public-root-exports-resolved/)
    assert.match(output, /the registered plugin preserves budgets and creates no model session/)
    assert.match(output, /3 pass|pass 3/)
  }
} catch (error) {
  save('harness-error.json', { message: error.message, stack: error.stack })
  process.exitCode = 1
} finally {
  fs.copyFileSync(fileURLToPath(import.meta.url), join(evidence, 'd1-public-export-canary-runner.mjs'))
  fs.rmSync(scratch, { recursive: true, force: true })
  save('cleanup.json', { scratchRemoved: !fs.existsSync(scratch), installationPreserved: fs.existsSync(product), scope: 'The real plugin fixture disposes hooks and shared journal handles. Natural command completion uses production scope/capture closure; no additional per-PID sampling or remote Host session is claimed.' })
}
