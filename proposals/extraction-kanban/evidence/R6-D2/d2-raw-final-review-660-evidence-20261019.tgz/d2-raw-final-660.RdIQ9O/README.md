# Independent D2 final RawStore and actual Hook review — fixed 660

## Fixed inputs and result

Candidate 660 archive SHA-256: `0bb7211c4b1e7eca77c72a59177073b221548233f78d2be97ab4d86d6b98b348`.
Actual clean installation: `/private/tmp/d2-clean-install-660/node_modules/wanxiangshu`.
Its nested wanxiangli package is 0.6.10. This review imports the installed product and invokes its installed standalone Hook; it does not substitute either source checkout.

D1 baseline 652 archive SHA-256: `003bc8818969597f9afd6a1c0767c7aae271dd53e5f0392b146367d156ec3887`.
Actual installation: `/private/tmp/d1-clean-install-652.MIf8Hg/node_modules/wanxiangshu`.
Both exact tarballs are included with distinct filenames.

Node v26.6.0 and Bun 1.3.14 each passed all 11 Raw/Hook groups again against final 660. Every raw log records archive and selected installed-module digests and checks them unchanged after execution. The RawStore module digest remains `b58f21cc6b5d1c2dc3faa50096b248a2187cdb2dc7bbe129156ca8f4354effc9`, as in 659; this is still a new actual-final-package run, not reused 659 verdicts. No shared source was edited.

## Eleven groups per runtime

1. Real object/tree missing returns storage Error with the original normal exit 0, exact complete missing bytes, empty stderr and no invented fault. Only the errno-aware ref-absence branch returns normal null.
2. Controlled missing makes one call, preserves the original receipt and does not fall back or write.
3. Metadata size 99 with successful short body is rejected. A repaired later read works, and mutation of returned bytes does not mutate the cached immutable object.
4. Empty blobs and empty trees remain present values.
5. Real loose-object file EACCES fails; restoration permits a cold read.
6. Real loose-object parent EACCES fails; restoration permits a cold read.
7. Corrupt/truncated zlib fails at metadata/body stages; restored data reads correctly.
8. Packed `.pack` EACCES fails object/tree reads despite Git's normal missing result with empty stderr. The fixture proves the loose object is absent and independently observes filesystem EACCES first.
9. The corresponding `.idx` case fails and restores correctly.
10. The actual installed `resources/git/wanxiang-hook.mjs reference-transaction committed` rejects packed `.pack` EACCES before materialization/publication. The argv audit contains repository discovery, common-dir discovery and batch-check only; no hash-object, mktree, fetch or push. Local events/cache remain absent; local tracking and private remote refs stay unchanged. Restoring access lets the same cold Hook entry exit 0.
11. The same actual Hook failure/recovery proof for `.idx` EACCES.

Raw logs: `node-660.log`, `bun-660.log`. All owned temporary repository roots were removed in finally blocks; each runtime's owned TMPDIR was empty after all runs. The actual Hook fault probe uses a native Git-created v2 empty snapshot and a private bare remote. Its Git argv wrapper observes only that failure boundary and is not used for performance.

## Same Trace2 performance comparison

The performance script differs from the final corrected 659 script only in the candidate label (`D2-660`, including its OID-reuse assertion). It uses each package's real EventStore append handles, actual standalone pre-push resource, private bare remotes and native `GIT_TRACE2_EVENT`, without an extra Git wrapper. Node and Bun samples ran sequentially.

| Runtime | Scenario | D1 652 ms | D2 660 ms | Native Git starts, D1 → D2 |
|---|---|---:|---:|---:|
| Node | clean | 96.40 | 239.40 | 3 → 5 |
| Node | one writer file changes | 210.33 | 970.32 | 11 → 24 |
| Node | two writer files change | 220.88 | 1045.27 | 11 → 25 |
| Bun | clean | 77.28 | 213.73 | 3 → 5 |
| Bun | one writer file changes | 196.46 | 1011.04 | 11 → 24 |
| Bun | two writer files change | 195.89 | 1146.18 | 11 → 25 |

All published writer blobs equal local NDJSON bytes exactly. Scenario fact counts are 2, 3 and 5; local byte counts are 320, 480 and 800. A fresh EventStore observer reads all facts. The clean call performs no transport or object operations and leaves the remote unchanged. Changed-writer cases invoke hash-object exactly 2/3 times (changed writer blobs plus the manifest), preserving reuse of the unchanged writer's OID. Native Git start counts include Git's own transport helpers.

The initial publish is an untraced warmup; its counters are null. These are one local paired sample per runtime and scenario, not a benchmark distribution. The D2 external Hook has a real latency increase versus D1; this review does not claim no performance regression. The same cost was visible in 659. This experiment does not measure local append latency or weaken the local-append zero-Git requirement.

## Attribution and limits

- No new Raw/Hook correctness failure appeared in these final-package groups. This receipt does not replace root's formal requirement 017 or the separate 0.6.10 Worker input/EOF evidence.
- Earlier review/design reasoning that normal cat-file missing proved physical absence was incorrect. The preserved packed-EACCES native counterexample falsified it. Final object/tree Error handling is deliberate, and it preserves Git's actual exit 0 without labelling the command Unknown.
- The 659 evidence and its first-sample harness reporting correction remain intact at `/private/tmp/d2-raw-final-review-659-evidence-20261019.tgz`, SHA-256 `8cba78e5752db0fe4d8963daf4b5a8b52f627fd5ea3c6f1b685623d38e4ad74c`.
- Git >= 2.43 is an explicit requirement for show-ref --exists. These runs used Apple Git 2.50.1; they do not claim an actual Git 2.43 platform run.
- R12-U1 remains deferred. No Unknown occurred here; this does not close natural Unknown handling. Whole convergence/GAP acceptance and CUT-00-R1/R2/R3 are separate.
- The Hook performance cost must remain visible in delivery status or a follow-up performance plan. These local samples do not close that tradeoff by themselves.

## Reproduction

Install the exact included archives separately with declared dependencies; do not substitute source checkout modules. The original installed paths and module/archive hashes are recorded in the logs. With owned temporary directories, run:

```sh
TMPDIR=<node-tmp> node probe.mjs <installed-660-root> candidate-660.tgz
TMPDIR=<bun-tmp> bun probe.mjs <installed-660-root> candidate-660.tgz
TMPDIR=<node-tmp> node performance.mjs <installed-652-root> baseline-652.tgz <installed-660-root> candidate-660.tgz
TMPDIR=<bun-tmp> bun performance.mjs <installed-652-root> baseline-652.tgz <installed-660-root> candidate-660.tgz
```

The physical supervision probes need macOS process inspection. Raw logs are unchanged. `SHA256SUMS` binds the archived scripts, logs, receipt and exact packages. Installed dependency trees/caches are not included.
