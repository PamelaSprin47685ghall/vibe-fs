# D2 ReadRef native Git protocol review

This read-only source review uses an owned temporary bare repository for permission and corruption fixtures. No source or user Git state changed. The fixture repository was deleted after all permission modes were restored.

`node probe.mjs > native.log 2>&1` exited 0 on macOS as UID 501. Git was `/usr/bin/git`, `git version 2.50.1 (Apple Git-155)`. The log contains 17 fixtures × 5 plumbing methods = 85 native commands, separately from setup. Six direct filesystem reads assert real EACCES before observing the Git result.

## Finding

`rev-parse --verify --quiet <valid-full-ref>` returns normal code 1 with empty stdout and stderr for each of:

- A genuinely missing valid ref.
- EACCES on an existing loose ref file.
- EACCES on the parent directory of either an existing or absent child ref.
- EACCES on an operating-system symlink target.

Thus a valid ref name plus code 1 and empty channels is insufficient to prove absence. `show-ref --verify --quiet` has the same ambiguity. `for-each-ref` also silently omits entries below an inaccessible directory, returning code 0 and empty channels. Adding another such query does not establish the missing fact.

`show-ref --exists` gives code 2 for genuine absence, code 1 with `Permission denied` for those EACCES fixtures, and code 1 with `Invalid argument` for malformed loose OID contents. It gives code 0 when a Git symbolic ref exists even if its target is dangling, cyclic, malformed or inaccessible: resolving such an existing ref must still require a successful valid-OID reply; a later resolution failure must remain Error.

All tested commands fail with code 128 and a diagnostic when `packed-refs` itself is inaccessible. `rev-parse` returns an ordinary valid OID for a readable ref pointing to a nonexistent object; this is a ref value, not evidence of object existence. Subsequent object reads own their separate missing/error boundary.

The `--exists` command treats a dangling filesystem symlink and a directory at the exact ref path as absence. These are Git's native ref lookup semantics; the primitive distinguishes errno ENOENT from other lookup errors, rather than promising filesystem-entry existence.

This is a native protocol counterexample, not proof that the wrapper is fixed. The old RawStore sources already hid filesystem read failures or used the ambiguous quiet CLI status, so the finding is an existing error-boundary defect retained in the first D2 candidate, not a D1 regression.

## Compatibility and recommendation

Official [Git 2.43.0 documentation](https://git-scm.com/docs/git-show-ref/2.43.0) includes `--exists`. The [2.43.0 implementation](https://raw.githubusercontent.com/git/git/v2.43.0/builtin/show-ref.c) maps ENOENT to code 2 and other lookup errors to code 1. The [2.42.0 implementation](https://raw.githubusercontent.com/git/git/v2.42.0/builtin/show-ref.c) lacks the option. It was therefore available by 2.43.0, not first added in 2.46.0.

No explicit minimum Git version was found in the repository's README, requirements, scripts or Git source. This machine also has a fallback Git 2.53.0; neither installed binary proves behavior on Git 2.42 or earlier. Adopting `--exists` must declare the capability/minimum-version requirement, or explicitly reject the unavailable capability. An unsupported-option code must not trigger fallback to the ambiguous quiet query and become None.

Suggested sequence: validate the full ref name; require a complete normal `show-ref --exists` receipt; accept only native code 2 as absence; for code 0, resolve and require code 0 plus one valid OID; retain every other result as Error. Two-step concurrent disappearance is an error for that operation, not permission to guess or retry a write.

This evidence does not include a newly built RawStore or final Hook run. It is not a D2 completion receipt.
