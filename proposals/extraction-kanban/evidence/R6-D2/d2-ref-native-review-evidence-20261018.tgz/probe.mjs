import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { chmodSync, mkdirSync, readFileSync, rmSync, symlinkSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

const root = '/private/tmp/d2-ref-native-review.flCHjm'
const repo = join(root, 'owned.git')
const git = '/usr/bin/git'
const env = { ...process.env }
for (const name of ['GIT_DIR', 'GIT_WORK_TREE', 'GIT_COMMON_DIR', 'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES']) delete env[name]
const command = (args, input) => {
  const result = spawnSync(git, ['-C', repo, ...args], { input, env, encoding: 'buffer', timeout: 5000 })
  if (result.error) throw result.error
  return { code: result.status, signal: result.signal, stdout: result.stdout.toString(), stdoutHex: result.stdout.toString('hex'), stderr: result.stderr.toString() }
}
const init = spawnSync(git, ['init', '--bare', '--quiet', repo], { env, encoding: 'utf8' })
assert.equal(init.status, 0, init.stderr)
const oid = command(['hash-object', '-w', '--stdin'], Buffer.from('owned-ref-probe\n')).stdout.trim()
assert.match(oid, /^[0-9a-f]{40}$/)
const base = join(repo, 'refs', 'wanxiang')
mkdirSync(base)
const ref = 'refs/wanxiang/test'
const refPath = join(base, 'test')
const parent = join(base, 'private')
const parentRef = 'refs/wanxiang/private/test'
mkdirSync(parent)
const parentPath = join(parent, 'test')
const packedPath = join(repo, 'packed-refs')
const attempts = []
const controls = []
const methods = [
  ['rev-parse-quiet', ref => ['rev-parse', '--verify', '--quiet', ref]],
  ['show-ref-verify-quiet', ref => ['show-ref', '--verify', '--quiet', ref]],
  ['show-ref-verify', ref => ['show-ref', '--verify', ref]],
  ['show-ref-exists', ref => ['show-ref', '--exists', ref]],
  ['for-each-ref', ref => ['for-each-ref', '--format=%(objectname) %(refname)', ref]],
]
const readFailure = path => {
  try { readFileSync(path); return 'READABLE' }
  catch (error) { return error.code }
}
const sample = (name, target = ref, control) => {
  if (control) {
    assert.equal(control.actual, control.expected)
    controls.push({ name, ...control })
  }
  for (const [method, args] of methods) attempts.push({ name, ref: target, method, ...command(args(target)) })
}
try {
  sample('valid-missing')
  writeFileSync(refPath, `${oid}\n`)
  sample('valid-existing')
  chmodSync(refPath, 0)
  try { sample('ref-file-EACCES', ref, { actual: readFailure(refPath), expected: 'EACCES' }) }
  finally { chmodSync(refPath, 0o600) }
  writeFileSync(parentPath, `${oid}\n`)
  chmodSync(parent, 0)
  try {
    sample('ref-parent-EACCES-existing', parentRef, { actual: readFailure(parentPath), expected: 'EACCES' })
    sample('ref-parent-EACCES-missing', 'refs/wanxiang/private/absent', { actual: readFailure(join(parent, 'absent')), expected: 'EACCES' })
  } finally { chmodSync(parent, 0o700) }
  writeFileSync(refPath, 'not-an-object-id\n')
  sample('malformed-object-id')
  writeFileSync(refPath, `${'a'.repeat(40)}\n`)
  sample('valid-oid-missing-object')
  writeFileSync(refPath, `ref: ${parentRef}\n`)
  sample('symbolic-existing')
  chmodSync(parentPath, 0)
  try { sample('symbolic-target-EACCES', ref, { actual: readFailure(parentPath), expected: 'EACCES' }) }
  finally { chmodSync(parentPath, 0o600) }
  writeFileSync(refPath, 'ref: refs/wanxiang/absent\n')
  sample('symbolic-dangling')
  writeFileSync(refPath, 'ref: invalid[\n')
  sample('symbolic-malformed-target')
  writeFileSync(refPath, 'ref: refs/wanxiang/cycle\n')
  writeFileSync(join(base, 'cycle'), `ref: ${ref}\n`)
  sample('symbolic-cycle')
  rmSync(refPath)
  symlinkSync('absent', refPath)
  sample('filesystem-symlink-dangling')
  rmSync(refPath)
  symlinkSync('private/test', refPath)
  chmodSync(parentPath, 0)
  try { sample('filesystem-symlink-target-EACCES', ref, { actual: readFailure(refPath), expected: 'EACCES' }) }
  finally { chmodSync(parentPath, 0o600) }
  rmSync(refPath)
  mkdirSync(refPath)
  sample('directory-at-ref-path')
  rmSync(refPath, { recursive: true })
  writeFileSync(packedPath, `# pack-refs with: peeled fully-peeled sorted \n${oid} refs/wanxiang/packed\n`)
  sample('packed-existing', 'refs/wanxiang/packed')
  chmodSync(packedPath, 0)
  try { sample('packed-refs-EACCES', 'refs/wanxiang/packed', { actual: readFailure(packedPath), expected: 'EACCES' }) }
  finally { chmodSync(packedPath, 0o600) }
  console.log(JSON.stringify({ git: spawnSync(git, ['--version'], { encoding: 'utf8' }).stdout.trim(), uid: process.getuid(), oid, controls, attempts }, null, 2))
} finally {
  chmodSync(parent, 0o700)
  rmSync(repo, { recursive: true, force: true })
}
