# Candidate 660 independent F# / fixed-package review

Candidate `wanxiangshu-0.9.0.tgz`, SHA256
`0bb7211c4b1e7eca77c72a59177073b221548233f78d2be97ab4d86d6b98b348`.
Actual clean install:
`/private/tmp/d2-clean-install-660/node_modules/wanxiangshu`, including its
installed wanxiangli 0.6.10. Node 26.6.0 and Bun 1.3.14 on macOS arm64 both pass.

## Same source, same emitted JavaScript, actual installed implementation

The consumer was recompiled through the real owner Fable wrapper against the
complete 30-input source closure, including the actual `GitTypes.fsi`,
`ProcessGitRawStore.fsi`, `GitRawSurface.fsi` and `ProcessRequest.fsi`. All
source digests, compiler output and status are retained.

The consumer's F# source SHA256 is
`599ad911c38f5696c84762c87c4703fe9e1e97bd7c7b18898f4bfcb60a5466c4`.
Its emitted JavaScript SHA256 is
`baa22ffb40cf00ad92b9b85fa4c42037568b468b1116796390239991c46e2c81`.
Both are byte-for-byte identical to candidate 659's diagnostic failure. No
input, expected length, byte comparison, limit or failure assertion was relaxed.

All generated production implementation JavaScript was removed before runtime.
The unchanged emitted consumer JS was staged with its original import layout;
only directory links to this clean fixed package's `dist/Persistence`,
`dist/Process` and `dist/fable_modules` were used. Node standard `node:fs` is
the only native consumer import. The package's own installed dependencies
provide runtime library code. No production source implementation or compiler
output was available as a runtime fallback.

Node and Bun each run the same consumer and return `accepted:true`, with:

- Explicit `GitRawRequest.OutputLimit` governing the combined binary channels.
  The exact limit passes, one byte less yields incomplete output with a fault,
  and a negative limit is rejected before physical execution.
- Actual Git exit 7 and 128 preserving 2,097,169 raw stdout bytes, including BOM,
  NUL and 0xff, plus nine exact binary stderr bytes. Known normal failures are
  retained as normal exit evidence, not collapsed to 1 or replaced with signals.
- Controlled store runner injection executes actual Git aliases through the
  production physical runner; `GitStorageFailure.Result` retains the full
  real 7/128 receipts and both original byte channels. Those receipts are not
  manufactured mock results.
- Real blob write and a cold store read, exact byte equality; real cold tree
  read with UTF-8 ordering including LF, tab, U+E000 and U+10000.
- Object and tree missing records are Error, retaining native exit 0, complete
  original `<oid> missing\n` stdout and empty stderr. They are not optional
  successful values. ReadRef retains successful None only for exact missing
  reference semantics; an actual mode-000 ref produces Error.
- A controlled Unconfirmed result remains Error with its fault and byte
  evidence. The actual `GitRawSurface.run` function is exercised with the
  real argument order, input option, output limit, exit 128 and raw channels.

These are internal F# protocol and implementation checks, not a claim that the
npm package has added public .d.ts declarations or a new exported Git subpath.
This gate does not replace production Hook/WriterStreamSync/Gateway entry-chain
tests or the final integration checklist.

## Negative compilation

All five illegal consumers fail at their own source file and intended type:

1. Missing required OutputLimit.
2. Task<Result<byte[],GitStorageFailure>> assigned to Task<byte[]>.
3. Raw byte[] assigned to string.
4. ReadObject assigned to the removed Task<Result<byte[] option,...>> shape.
5. ReadTree assigned to the removed Task<Result<TreeEntry list option,...>> shape.

Their exact F# source, compiler diagnostics and nonzero statuses are included.
Positive compilation happens first, so failures in unrelated production source
cannot stand in for a valid negative control.

## Physical counterexample replay and prior evidence

The exact original single-write 2 MiB+17 cat/tee input was also replayed through
four independent physical layers: fixed main RawRunner, its installed public
SupervisedProcess, installed base Capture ProcessSession and native runtime.
All 12 command/layer comparisons pass on Node and all 12 pass on Bun, including
actual target-written tee files. The target files, stdout and stderr are saved
as binary evidence. Each successful command completes through its real scope/
capture boundary, and each probe removes its temporary Git repository.

The previous 659 red and baseline 0.6.8/0.6.9 differences remain in separate
archives and are not overwritten or relabeled:

- `D2-TYPED-659-BLOCKER-EVIDENCE.tgz`, SHA256
  `4dc9614ad84cc0666492a02b48ccd8faa4f1fc62b2a39002dee87750944c505e`.
- `D2-068-069-OBSERVABLE-COMPARISON.tgz`, SHA256
  `5c914dfa6d6ea9bb77b3467e69765a39c3798c463c5c51316843a4eb36534c68`.
- `D2-LIB-0610-INDEPENDENT-EVIDENCE.tgz`, SHA256
  `eba71aba4542dfbdf065d009cf1a7a8c676b1b0a7bd5853d1d9c34631b22bfd9`,
  independently verifies unchanged original Unknown boundaries, target early
  refusal/exit23, exact tee red/green, types/removal and isolated source builds.

Normal scope completion is used by the typed/physical main-package gate;
independent per-PID sampling is not claimed for every typed Git process.
The separate library-boundary archive records explicit ps samples where used.
The installed product, archive and emitted consumer JS remain byte-for-byte
unchanged. Compiler and runtime scratch were removed. R12-U1 remains excluded.

## Replay

Use a matching source checkout only for the declared Fable test toolchain and
real interface compilation. The replay-source digest argument rejects drift:

```sh
node typed/d2-typed-fixed-package-runner.mjs MATCHING_CHECKOUT CLEAN_INSTALLED_PRODUCT candidate/wanxiangshu-0.9.0.tgz 0bb7211c4b1e7eca77c72a59177073b221548233f78d2be97ab4d86d6b98b348 typed/real-source-inputs.json
```

The physical layered probe needs no checkout or compiler:

```sh
node layered/d2-single-input-probe.mjs CLEAN_INSTALLED_PRODUCT NEW_NODE_BINARY_DIRECTORY > node-layered.json
bun layered/d2-single-input-probe.mjs CLEAN_INSTALLED_PRODUCT NEW_BUN_BINARY_DIRECTORY > bun-layered.json
```

Use the included archive/lock to reconstruct the clean installation rather
than substituting a moving checkout. Verify `MANIFEST.sha256` before replay.
