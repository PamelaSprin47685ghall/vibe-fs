import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { spawnSync } from 'node:child_process'
import { existsSync, mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const products = [
  { label: 'D1-652', path: resolve(process.argv[2]), archive: resolve(process.argv[3]) },
  { label: 'D2-659', path: resolve(process.argv[4]), archive: resolve(process.argv[5]) },
]
const digest = path => createHash('sha256').update(readFileSync(path)).digest('hex')
const fixed = Object.fromEntries(products.flatMap(product => [product.archive, join(product.path, 'resources/git/wanxiang-hook.mjs'), join(product.path, 'dist/Persistence/EventStore/ProcessGitRawStore.js')]).map(path => [path, digest(path)]))
const owned = mkdtempSync(join(tmpdir(), 'd2-hook-performance-'))
const git = '/usr/bin/git'
const env = { ...process.env, GIT_CONFIG_GLOBAL: '/dev/null', GIT_CONFIG_SYSTEM: '/dev/null' }
for (const name of ['GIT_DIR', 'GIT_WORK_TREE', 'GIT_COMMON_DIR', 'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES', 'WANXIANG_GIT_SYNC_ACTIVE', 'GIT_TRACE2_EVENT']) delete env[name]
const native = (cwd, args, input) => {
  const result = spawnSync(git, ['-C', cwd, ...args], { input, env, encoding: 'buffer', timeout: 20000 })
  if (result.error) throw result.error
  assert.equal(result.status, 0, result.stderr.toString())
  return result.stdout
}
const initialize = (path, bare = false) => {
  const result = spawnSync(git, ['init', ...(bare ? ['--bare'] : []), '--quiet', path], { env, encoding: 'utf8' })
  assert.equal(result.status, 0, result.stderr)
  return path
}
const event = digit => ({ id: digit.repeat(40), stream: 'convergence/proof', type: 'JobRequested', parents: [], payload: {}, payloadRefs: [] })
const results = []

try {
  for (const product of products) {
    const storeApi = await import(pathToFileURL(join(product.path, 'dist/Persistence/EventStore/Surface.js')))
    const remote = initialize(join(owned, `${product.label}-remote.git`), true)
    const repo = initialize(join(owned, `${product.label}-client`))
    native(repo, ['remote', 'add', 'origin', remote])
    const common = join(repo, '.git')
    const handles = []
    const open = name => {
      const handle = storeApi.create(common, name)
      handles.push(handle)
      return handle
    }
    const append = async (handle, value) => {
      const result = await storeApi.append(handle, [value])
      assert.equal(result.ok, true, JSON.stringify(result.error))
    }
    const tip = () => native(remote, ['rev-parse', '--verify', 'refs/wanxiang/store']).toString().trim()
    const track = () => native(repo, ['update-ref', 'refs/wanxiang/remotes/origin/store', tip()])
    const allFacts = []
    const inspectRemote = expected => {
      const root = tip()
      const rows = native(remote, ['ls-tree', '-z', `${root}:writers`]).toString().split('\0').filter(Boolean)
      const ids = []
      for (const row of rows) {
        const name = row.slice(row.indexOf('\t') + 1)
        const bytes = native(remote, ['cat-file', 'blob', `${root}:writers/${name}`])
        assert.deepEqual(bytes, readFileSync(join(common, 'wanxiangshu/events', name)))
        for (const line of bytes.toString().split('\n').filter(Boolean)) ids.push(JSON.parse(line).event_id)
      }
      assert.deepEqual(ids.sort(), expected.map(value => value.id).sort())
      return { root, writerFiles: rows.length, facts: ids.length, localBytes: readdirSync(join(common, 'wanxiangshu/events')).filter(name => name.endsWith('.ndjson')).reduce((size, name) => size + readFileSync(join(common, 'wanxiangshu/events', name)).length, 0) }
    }
    const hook = (label, trace = true) => {
      const tracePath = join(owned, `${product.label}-${label}-trace.ndjson`)
      if (trace) writeFileSync(tracePath, '')
      const start = performance.now()
      const result = spawnSync(process.execPath, [join(product.path, 'resources/git/wanxiang-hook.mjs'), 'pre-push', 'origin'], { cwd: repo, env: trace ? { ...env, GIT_TRACE2_EVENT: tracePath } : env, encoding: 'utf8', timeout: 60000 })
      const elapsedMs = performance.now() - start
      if (result.error) throw result.error
      assert.equal(result.status, 0, result.stderr || result.stdout)
      const calls = trace ? readFileSync(tracePath, 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line)).filter(value => value.event === 'start').map(value => value.argv) : []
      const counts = Object.fromEntries(['hash-object', 'mktree', 'cat-file', 'check-ref-format', 'show-ref', 'rev-parse', 'push', 'fetch', 'ls-remote'].map(command => [command, calls.filter(args => args.includes(command)).length]))
      return { product: product.label, label, elapsedMs, nativeGitStarts: trace ? calls.length : null, counts: trace ? counts : null, calls: trace ? calls : null, stderr: result.stderr }
    }
    try {
      const main = open('writer-main')
      const stable = open('writer-stable')
      for (const [handle, value] of [[main, event('1')], [stable, event('2')]]) {
        await append(handle, value)
        allFacts.push(value)
      }
      const warmup = hook('initial-two-writer-publish', false)
      inspectRemote(allFacts)
      track()
      const firstRoot = tip()
      const clean = hook('clean')
      assert.equal(clean.counts.push + clean.counts.fetch + clean.counts['ls-remote'], 0)
      assert.equal(clean.counts['hash-object'] + clean.counts.mktree + clean.counts['cat-file'], 0)
      assert.equal(tip(), firstRoot)
      clean.snapshot = inspectRemote(allFacts)
      results.push(warmup, clean)

      await append(main, event('3'))
      allFacts.push(event('3'))
      const single = hook('one-writer-file-changed')
      assert.ok(single.counts.push > 0)
      assert.notEqual(tip(), firstRoot)
      single.snapshot = inspectRemote(allFacts)
      results.push(single)
      track()

      const extra = open('writer-extra')
      await append(main, event('4'))
      await append(extra, event('5'))
      allFacts.push(event('4'), event('5'))
      const multi = hook('two-writer-files-changed')
      assert.ok(multi.counts.push > 0)
      multi.snapshot = inspectRemote(allFacts)
      results.push(multi)
      if (product.label === 'D2-659') {
        assert.equal(single.counts['hash-object'], 2, 'One changed writer blob plus manifest; stable writer must reuse its OID')
        assert.equal(multi.counts['hash-object'], 3, 'Two changed writer blobs plus manifest; stable writer must reuse its OID')
      }
      const cold = open('observer')
      for (const value of allFacts) assert.deepEqual(storeApi.read(cold, value.id), value)
    } finally {
      for (const handle of handles) storeApi.dispose(handle)
    }
  }
  for (const [path, expected] of Object.entries(fixed)) assert.equal(digest(path), expected)
  console.log(JSON.stringify({ runtime: process.versions.bun ? `Bun ${process.versions.bun}` : process.version, fixed, results, scope: 'One local paired sample per fixed product and scenario. Actual standalone pre-push, actual EventStore append handles, private bare remotes, native GIT_TRACE2_EVENT without an extra Git wrapper. This is neither a benchmark distribution nor the complete convergence matrix.' }, null, 2))
} finally {
  rmSync(owned, { recursive: true, force: true })
  console.log(JSON.stringify({ ownedTemporaryRepositoryRootRemoved: !existsSync(owned) }))
}
