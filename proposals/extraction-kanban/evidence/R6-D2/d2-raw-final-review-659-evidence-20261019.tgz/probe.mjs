import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { spawnSync } from 'node:child_process'
import { chmodSync, existsSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const product = resolve(process.argv[2])
const archive = process.argv[3] ? resolve(process.argv[3]) : null
const surfacePath = join(product, 'dist/Persistence/EventStore/GitRawSurface.js')
const rawPath = join(product, 'dist/Persistence/EventStore/ProcessGitRawStore.js')
const hookPath = join(product, 'resources/git/wanxiang-hook.mjs')
const digest = path => createHash('sha256').update(readFileSync(path)).digest('hex')
const fixed = Object.fromEntries([surfacePath, rawPath, hookPath, ...(archive ? [archive] : [])].map(path => [path, digest(path)]))
const { create, createWithRunner } = await import(pathToFileURL(surfacePath))
const owned = mkdtempSync(join(tmpdir(), 'd2-raw-final-'))
const git = '/usr/bin/git'
const env = { ...process.env }
for (const name of ['GIT_DIR', 'GIT_WORK_TREE', 'GIT_COMMON_DIR', 'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES', 'WANXIANG_GIT_SYNC_ACTIVE']) delete env[name]
const groups = []
const notes = []
const native = (repo, args, input) => {
  const result = spawnSync(git, ['-C', repo, ...args], { input, env, encoding: 'buffer', timeout: 10000 })
  if (result.error) throw result.error
  return result
}
const zero = (repo, args, input) => {
  const result = native(repo, args, input)
  assert.equal(result.status, 0, result.stderr.toString())
  return result.stdout
}
const init = (name, bare = true) => {
  const repo = join(owned, name)
  const result = spawnSync(git, ['init', ...(bare ? ['--bare'] : []), '--quiet', repo], { env, encoding: 'utf8' })
  assert.equal(result.status, 0, result.stderr)
  return repo
}
const ok = result => {
  assert.equal(result.ok, true, result.error?.description)
  return result.value
}
const failed = result => {
  assert.equal(result.ok, false, 'Object or tree failure must not become a normal missing result')
  return result.error
}
const observed = (stdout, stderr = Buffer.alloc(0), exitCode = 0) => ({
  kind: 'Observed', ending: { kind: 'Exited', exitCode }, stopRequested: null,
  output: { stdout, stderr, complete: true }, fault: null,
})
const unreadable = path => {
  assert.throws(() => readFileSync(path), error => error.code === 'EACCES')
}
const group = async (name, action) => {
  await action()
  groups.push(name)
}
const missingOid = 'a'.repeat(40)

try {
  const repo = init('raw.git')
  await group('real missing object/tree are errors; ref absence alone is normal', async () => {
    for (const read of ['readObject', 'readTree']) {
      const error = failed(await create(repo)[read](missingOid))
      assert.deepEqual(error.result.ending, { kind: 'Exited', exitCode: 0 })
      assert.equal(Buffer.from(error.result.output.stdout).toString(), `${missingOid} missing\n`)
      assert.equal(error.result.output.stderr.length, 0)
      assert.equal(error.result.output.complete, true)
      assert.equal(error.result.fault, null)
    }
    assert.equal(ok(await create(repo).readRef('refs/wanxiang/absent')), null)
  })
  await group('controlled missing keeps the original normal receipt and makes no fallback call', async () => {
    for (const read of ['readObject', 'readTree']) {
      let calls = 0
      const receipt = observed(Buffer.from(`${missingOid} missing\n`))
      const store = createWithRunner('/unused', async () => { calls++; return receipt })
      const error = failed(await store[read](missingOid))
      assert.deepEqual(error.result, receipt)
      assert.equal(calls, 1)
    }
  })
  await group('short successful body is refused and does not poison the object cache', async () => {
    const calls = []
    let repaired = false
    const store = createWithRunner('/unused', async request => {
      calls.push(request.arguments)
      return request.arguments.includes('--batch-check')
        ? observed(Buffer.from(`${missingOid} blob 99\n`))
        : observed(repaired ? Buffer.alloc(99, 65) : Buffer.from('short'))
    })
    const error = failed(await store.readObject(missingOid))
    assert.match(error.reason, /truncated|excess/i)
    assert.equal(calls.length, 2)
    repaired = true
    assert.equal(ok(await store.readObject(missingOid)).length, 99)
    assert.equal(calls.length, 4)
    ok(await store.readObject(missingOid)).fill(0)
    assert.equal(ok(await store.readObject(missingOid))[0], 65)
    assert.equal(calls.length, 4)
  })
  await group('empty blob and empty tree remain present values', async () => {
    const store = create(repo)
    const blob = ok(await store.writeBlob(Buffer.alloc(0)))
    const tree = ok(await store.writeTree([]))
    assert.equal(ok(await create(repo).readObject(blob)).length, 0)
    assert.deepEqual(ok(await create(repo).readTree(tree)), [])
  })

  const content = Buffer.from([0, 255, 1, 128, 10, 65])
  const blob = zero(repo, ['hash-object', '-w', '--stdin'], content).toString().trim()
  const directory = join(repo, 'objects', blob.slice(0, 2))
  const object = join(directory, blob.slice(2))
  const compressed = readFileSync(object)
  for (const [name, path, restore] of [['loose file EACCES', object, 0o600], ['loose parent EACCES', directory, 0o700]]) {
    await group(name, async () => {
      chmodSync(path, 0)
      try {
        unreadable(object)
        const error = failed(await create(repo).readObject(blob))
        assert.deepEqual(error.result.ending, { kind: 'Exited', exitCode: 0 })
        assert.match(Buffer.from(error.result.output.stderr).toString(), /Permission denied/)
      } finally { chmodSync(path, restore) }
      assert.deepEqual(Buffer.from(ok(await create(repo).readObject(blob))), content)
    })
  }
  await group('corrupt and truncated loose streams fail without a retry', async () => {
    try {
      writeFileSync(object, Buffer.from('not-a-zlib-stream'))
      const corrupt = failed(await create(repo).readObject(blob))
      assert.deepEqual(corrupt.result.ending, { kind: 'Exited', exitCode: 0 })
      assert.match(Buffer.from(corrupt.result.output.stderr).toString(), /inflate|unpack/)
      writeFileSync(object, compressed.subarray(0, compressed.length - 3))
      const truncated = failed(await create(repo).readObject(blob))
      assert.deepEqual(truncated.result.ending, { kind: 'Exited', exitCode: 128 })
      assert.match(Buffer.from(truncated.result.output.stderr).toString(), /stream/)
    } finally { writeFileSync(object, compressed) }
    assert.deepEqual(Buffer.from(ok(await create(repo).readObject(blob))), content)
  })

  const packed = init('packed.git')
  const packedBlob = zero(packed, ['hash-object', '-w', '--stdin'], content).toString().trim()
  const packedTree = zero(packed, ['mktree', '-z'], Buffer.from(`100644 blob ${packedBlob}\tleaf\0`)).toString().trim()
  zero(packed, ['update-ref', 'refs/wanxiang/probe', packedTree])
  zero(packed, ['repack', '-a', '-d'])
  assert.equal(existsSync(join(packed, 'objects', packedBlob.slice(0, 2), packedBlob.slice(2))), false)
  const packDir = join(packed, 'objects/pack')
  for (const suffix of ['.pack', '.idx']) {
    await group(`packed ${suffix} EACCES is a storage error despite silent native missing`, async () => {
      const file = join(packDir, readdirSync(packDir).find(name => name.endsWith(suffix)))
      chmodSync(file, 0)
      try {
        unreadable(file)
        for (const [method, tip] of [['readObject', packedBlob], ['readTree', packedTree]]) {
          const error = failed(await create(packed)[method](tip))
          assert.deepEqual(error.result.ending, { kind: 'Exited', exitCode: 0 })
          assert.equal(Buffer.from(error.result.output.stdout).toString(), `${tip} missing\n`)
          assert.equal(error.result.output.stderr.length, 0)
          assert.equal(error.result.output.complete, true)
        }
      } finally { chmodSync(file, 0o600) }
      assert.deepEqual(Buffer.from(ok(await create(packed).readObject(packedBlob))), content)
      assert.deepEqual(ok(await create(packed).readTree(packedTree)), [{ mode: '100644', name: 'leaf', oid: packedBlob }])
    })
  }

  const wrapperDirectory = join(owned, 'git-bin')
  mkdirSync(wrapperDirectory)
  const audit = join(owned, 'git-argv.ndjson')
  writeFileSync(join(wrapperDirectory, 'git'), `#!/usr/bin/env node\nimport { appendFileSync } from 'node:fs';\nimport { spawnSync } from 'node:child_process';\nappendFileSync(${JSON.stringify(audit)}, JSON.stringify(process.argv.slice(2)) + '\\n');\nconst result = spawnSync('/usr/bin/git', process.argv.slice(2), {stdio:'inherit'});\nif(result.error) throw result.error;\nif(result.signal) process.kill(process.pid,result.signal);\nelse process.exit(result.status);\n`)
  chmodSync(join(wrapperDirectory, 'git'), 0o755)
  for (const suffix of ['.pack', '.idx']) {
    await group(`actual standalone Hook stops before materialization for ${suffix} EACCES`, async () => {
      const worktree = init(`hook-${suffix.slice(1)}`, false)
      const remote = init(`remote-${suffix.slice(1)}.git`)
      const emptyTree = zero(worktree, ['mktree', '-z'], Buffer.alloc(0)).toString().trim()
      const manifest = zero(worktree, ['hash-object', '-w', '--stdin'], Buffer.from('v2\n')).toString().trim()
      const root = zero(worktree, ['mktree', '-z'], Buffer.from(`040000 tree ${emptyTree}\twriters\0` + `100644 blob ${manifest}\twriter-manifest\0`)).toString().trim()
      zero(worktree, ['remote', 'add', 'origin', remote])
      zero(worktree, ['push', '--no-verify', 'origin', `${root}:refs/wanxiang/store`])
      zero(worktree, ['update-ref', 'refs/wanxiang/remotes/origin/store', root])
      zero(worktree, ['repack', '-a', '-d'])
      const packDirectory = join(worktree, '.git/objects/pack')
      const file = join(packDirectory, readdirSync(packDirectory).find(name => name.endsWith(suffix)))
      const input = `${'0'.repeat(40)} ${root} refs/wanxiang/remotes/origin/store\n`
      const hookEnv = { ...env, PATH: `${wrapperDirectory}:${env.PATH}` }
      writeFileSync(audit, '')
      chmodSync(file, 0)
      try {
        unreadable(file)
        const result = spawnSync(process.execPath, [hookPath, 'reference-transaction', 'committed'], { input, cwd: worktree, env: hookEnv, encoding: 'utf8', timeout: 30000 })
        if (result.error) throw result.error
        assert.equal(result.status, 1, result.stderr)
        assert.match(result.stderr, /git cat-file/)
        const calls = readFileSync(audit, 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line))
        assert.ok(calls.some(args => args.includes('--batch-check')))
        for (const command of ['hash-object', 'mktree', 'push', 'fetch']) assert.ok(!calls.some(args => args.includes(command)), `Unexpected later command ${command}`)
        assert.equal(existsSync(join(worktree, '.git/wanxiangshu/events')), false)
        assert.equal(existsSync(join(worktree, '.git/wanxiangshu/sync-materialization-cache')), false)
        assert.equal(zero(worktree, ['rev-parse', '--verify', 'refs/wanxiang/remotes/origin/store']).toString().trim(), root)
        assert.equal(zero(remote, ['rev-parse', '--verify', 'refs/wanxiang/store']).toString().trim(), root)
        notes.push({ suffix, failedHook: { status: result.status, stderr: result.stderr }, gitCalls: calls })
      } finally { chmodSync(file, 0o600) }
      writeFileSync(audit, '')
      const restored = spawnSync(process.execPath, [hookPath, 'reference-transaction', 'committed'], { input, cwd: worktree, env: hookEnv, encoding: 'utf8', timeout: 30000 })
      if (restored.error) throw restored.error
      assert.equal(restored.status, 0, restored.stderr)
      notes.push({ suffix, restoredHookStatus: restored.status })
    })
  }
  for (const [path, expected] of Object.entries(fixed)) assert.equal(digest(path), expected)
  console.log(JSON.stringify({ runtime: process.versions.bun ? `Bun ${process.versions.bun}` : process.version, product, fixed, passedGroups: groups, notes, scope: 'Independent RawStore backend and actual standalone reference-transaction Hook proof. No final full convergence-matrix claim.' }, null, 2))
} finally {
  rmSync(owned, { recursive: true, force: true })
  console.log(JSON.stringify({ ownedTemporaryRepositoryRootRemoved: !existsSync(owned) }))
}
