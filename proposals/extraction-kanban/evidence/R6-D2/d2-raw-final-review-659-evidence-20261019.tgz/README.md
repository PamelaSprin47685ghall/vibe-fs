# Independent D2 RawStore and actual Hook review — fixed 659

## Inputs and result

Main candidate 659 tarball SHA-256: `a6a78e40f594a4879e278488dc2196e951278a69149f64fa0da0afef253602de`. Actual clean install: `/private/tmp/d2-clean-install-659/node_modules/wanxiangshu`. The package contains wanxiangli 0.6.9. This reviewer consumed the installed package, not the main or sibling source checkout.

D1 performance baseline 652 tarball SHA-256: `003bc8818969597f9afd6a1c0767c7aae271dd53e5f0392b146367d156ec3887`. Actual clean install: `/private/tmp/d1-clean-install-652.MIf8Hg/node_modules/wanxiangshu`. Both exact tarballs are included under distinct filenames.

Node v26.6.0 and Bun 1.3.14 each passed all 11 independent groups in `probe.mjs`. The selected archive/module digests recorded inside each raw log were unchanged before and after execution. No shared source was changed. This is a bounded acceptance receipt for these paths, not the whole convergence/GAP matrix or public declaration compilation.

## Eleven groups, separately for each runtime

1. Genuine object/tree missing records return storage errors, preserving native exit 0 and the exact complete missing record. Only the errno-aware ref absence branch returns normal null.
2. Controlled missing records make one call and retain the original receipt, with no alternate lookup or write.
3. Metadata size 99 with successful body `short` is rejected; a later repaired read is not blocked by a cached failure, and returned-byte mutations do not alter the immutable cache.
4. Empty blobs and empty trees remain present values.
5. Real loose object-file EACCES is a storage error; restoring access permits a fresh read.
6. Real loose parent-directory EACCES is a storage error; restoring access permits a fresh read.
7. Invalid and truncated zlib streams fail at the relevant metadata/body stage; restored bytes read correctly.
8. A packed object's `.pack` EACCES is an error for object and tree reads even though native Git returns normal missing with empty stderr.
9. The same `.idx` EACCES case is an error. The fixture verifies the loose object is absent, and each permission fixture first proves filesystem EACCES independently.
10. The actual installed `resources/git/wanxiang-hook.mjs reference-transaction committed` entry rejects `.pack` EACCES before local materialization or publication. Git argv audit records only repository discovery, common-dir discovery and batch-check; no hash-object, mktree, fetch or push occurs. Local events/cache remain absent and both local tracking and private remote refs remain unchanged. After restoring access, the same cold entry exits 0.
11. The same actual Hook failure/recovery proof for `.idx` EACCES.

The real Hook uses a native Git-created v2 empty snapshot and a private bare remote. The audit wrapper is used only to prove the failure boundary; it is not used for the performance sample.

Raw logs: `node-659.log`, `bun-659.log`. Each runtime's owned repositories were removed by finally cleanup. Temporary directories contained no remaining owned supervision pipes or repositories. A macOS xcrun cache file created by a later native probe was separately removed from the owned TMPDIR.

## Actual Hook performance comparison

`performance.mjs` uses each package's actual EventStore append handles and standalone pre-push resource, a private bare remote, and native `GIT_TRACE2_EVENT`. It does not add a JavaScript wrapper to each Git command. A stable writer and a main writer are initially published; the main writer then appends once; finally the main writer appends again while an extra writer adds a fact. Stable writer bytes stay unchanged.

Every published writer blob equals its local NDJSON bytes exactly. Remote fact counts are 2, 3 and 5, with local bytes 320, 480 and 800; a fresh EventStore observer reads all expected facts. The clean call leaves the remote unchanged and performs no transport or object operations. In 659, single/double writer changes invoke hash-object exactly 2/3 times (changed writers plus the manifest), proving that the stable writer's OID is reused.

Final logged sample, milliseconds:

| Runtime | Scenario | D1 652 | D2 659 | Native Git starts, D1 → D2 |
|---|---|---:|---:|---:|
| Node | clean | 107.61 | 267.60 | 3 → 5 |
| Node | one writer file changes | 222.90 | 1073.21 | 11 → 24 |
| Node | two writer files change | 245.18 | 1115.57 | 11 → 25 |
| Bun | clean | 86.53 | 238.68 | 3 → 5 |
| Bun | one writer file changes | 220.14 | 1028.91 | 11 → 24 |
| Bun | two writer files change | 223.45 | 1134.52 | 11 → 25 |

These are local samples, not a benchmark distribution. The first samples are retained too: 659 changed calls took about 1.10–1.29 s versus D1's 0.25–0.27 s. The added supervised plumbing has a real performance cost; this review does not call it “no performance regression.” These calls occur at the external Git Hook boundary; this experiment does not measure append latency or change the local-append zero-Git requirement. Native Git start counts include Git's own transport helper processes, not only RawStore calls.

The initial publish is a warmup without Trace2 observation. The first harness recorded empty placeholder counters as zero for that warmup; `performance-first-sample.mjs` and both first raw logs are preserved. This was a reporting issue in the review probe, not a production failure. The corrected script records unobserved warmup counters as null and reran both runtimes. The three traced scenario counters were measured in both samples and agree. Final logs are `node-performance-659.log` and `bun-performance-659.log`; the first logs have `-first-sample` suffixes.

## Attribution and remaining boundaries

- The old quiet ref query and raw filesystem/CLI absence handling hid failures. Earlier native archives preserve these old defects.
- The early review/design claim that a normal cat-file missing record confirmed physical absence was wrong. The packed EACCES counterexample falsified it. Candidate 659 removes normal missing from object/tree reads, retains native exit 0 in the storage error, and does not invent execution Unknown.
- First D2 candidate issues (fixed cap, lost stderr, relative repo binding and byte ordering) were migration issues. They must not all be attributed to the original split. This archive does not replace the separate formal 017 evidence for every one of them.
- The review-probe warmup counter correction above is a fixture reporting correction.
- R12-U1 remains outside scope. No Unknown or timeout occurred in this acceptance run; that observation does not close natural Unknown behavior.
- Git >= 2.43 is an explicit new requirement for exact ref existence lookup. This run uses Apple Git 2.50.1 and does not claim an actual Git 2.43 platform run.
- The reported Hook latency increase is a documented architectural cost and needs to remain visible in the delivery decision or a performance plan. No full convergence TODO or GAP is closed by these local samples.

`tree-native.mjs` and `tree-native.log` contain a separate 15-command native malformed-tree metadata check. ls-tree rejects each tested inconsistent header/body size and accepts the correct size. This is an additional native observation, not another set of product test groups.

## Reproduction

Install the included fixed tarballs in separate clean directories with their declared dependencies. Do not substitute source checkout modules. Use an owned temporary directory for each runtime and invoke:

```
TMPDIR=<node-tmp> node probe.mjs <installed-659-root> candidate-659.tgz
TMPDIR=<bun-tmp> bun probe.mjs <installed-659-root> candidate-659.tgz
TMPDIR=<node-tmp> node performance.mjs <installed-652-root> baseline-652.tgz <installed-659-root> candidate-659.tgz
TMPDIR=<bun-tmp> bun performance.mjs <installed-652-root> baseline-652.tgz <installed-659-root> candidate-659.tgz
```

The macOS supervision probes require process inspection. Exact original commands and input paths are in the logs and this receipt. Raw logs are unchanged; `SHA256SUMS` binds the archived files. The archive does not include the npm installations or caches.
