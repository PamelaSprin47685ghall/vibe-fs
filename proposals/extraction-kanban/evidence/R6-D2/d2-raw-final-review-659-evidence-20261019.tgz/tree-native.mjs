import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { chmodSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { deflateSync } from 'node:zlib'

const repo = mkdtempSync(join(tmpdir(), 'd2-tree-native-'))
const call = (args, input) => spawnSync('/usr/bin/git', ['-C', repo, ...args], { input, encoding: 'buffer', timeout: 5000 })
assert.equal(call(['init', '--bare', '--quiet']).status, 0)
const blob = call(['hash-object', '-w', '--stdin'], Buffer.from('x')).stdout.toString().trim()
const tree = call(['mktree', '-z'], Buffer.from(`100644 blob ${blob}\tleaf\0`)).stdout.toString().trim()
const raw = call(['cat-file', 'tree', tree]).stdout
const file = join(repo, 'objects', tree.slice(0, 2), tree.slice(2))
const saved = readFileSync(file)
const results = []
try {
  chmodSync(file, 0o600)
  for (const size of [0, raw.length - 1, raw.length, raw.length + 1, 99]) {
    writeFileSync(file, deflateSync(Buffer.concat([Buffer.from(`tree ${size}\0`), raw])))
    for (const args of [['cat-file', '--batch-check'], ['cat-file', 'tree', tree], ['ls-tree', '--full-tree', '-z', tree]]) {
      const result = call(args, args.includes('--batch-check') ? Buffer.from(`${tree}\n`) : undefined)
      if (result.error) throw result.error
      results.push({ claimedSize: size, realSize: raw.length, args, status: result.status, signal: result.signal, stdoutHex: result.stdout.toString('hex'), stderr: result.stderr.toString() })
    }
  }
  console.log(JSON.stringify(results, null, 2))
} finally {
  writeFileSync(file, saved)
  rmSync(repo, { recursive: true, force: true })
}
