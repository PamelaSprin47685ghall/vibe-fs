# Replay of the independent 0.6.11 review

The original full evidence archive remains at
`/private/tmp/d2-library-host-0611-evidence-20261019.tgz`.
Its SHA256 is
`9be8384eb2db3ec10bcd2b55a3025d27a085acc451c79ca596391e11a7ed1ba8`.
No file in that full archive was changed to make this compact archive.

The compact archive includes the exact npm tgz, installed package, manifests,
all logs and JSON receipts, reviewed source, original controlled fixture,
the predeclared matrix in REVIEW.md and all private replay code. Only successful
32 MiB + 17 and 64 MiB + 17 input/target/stdout files are omitted. Every omission
has its original size/hash and a successful equality receipt in OMISSIONS.json.
The xorshift generator and exact seed remain in code and per-run summaries.
The smaller complete witnesses, all nondeterministic partial-case inputs, and
all partial/closed-input actual bytes remain included.

Run from the restored `d2-library-host-0611.Y1qNrV` folder, which the test-mode
wrapper currently names explicitly. The original private full folder remains
unchanged and is immediately runnable. Each CLI command below ran once:

```sh
node library-input-consumer.mjs "$PWD" "$PWD/evidence/replay-node/input"
node partial-input-consumer.mjs "$PWD" "$PWD/evidence/replay-node/partial"
bun library-input-consumer.mjs "$PWD" "$PWD/evidence/replay-bun/input"
bun partial-input-consumer.mjs "$PWD" "$PWD/evidence/replay-bun/partial"
bun input-callback-worker.mjs success
bun input-callback-worker.mjs exit
bun test ./input-test-mode.test.mjs
```

The CLI driver gave each independent child invocation an outer 50-second guard.
Each physical input case also has its own smaller watchdog, as preserved in code.
No watchdog expired in these successful runs. Replaying the consumers regenerates
the omitted complete input, target and stdout files and records them before the
byte assertions. These finite successes do not close the separate formal 662
last-17-byte failure.
