import { test } from 'bun:test'

test('independent fixed 0.6.11 input consumer under Bun test mode', async () => {
  const root = '/private/tmp/d2-library-host-0611.Y1qNrV'
  process.argv = [process.execPath, `${root}/library-input-consumer.mjs`, root, `${root}/evidence/bun-test/library-input-consumer`]
  await import('./library-input-consumer.mjs')
}, 50000)
