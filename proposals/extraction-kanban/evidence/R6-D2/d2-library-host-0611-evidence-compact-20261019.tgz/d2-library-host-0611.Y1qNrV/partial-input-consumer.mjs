import assert from 'node:assert/strict'
import { createHash, randomBytes } from 'node:crypto'
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { setTimeout as delay } from 'node:timers/promises'

const product = resolve(process.argv[2])
const evidence = resolve(process.argv[3])
mkdirSync(evidence, { recursive: true })
const library = join(product, 'node_modules/wanxiangli')
const modulePath = join(library, 'dist/supervision/SupervisedProcess.js')
const { SupervisedProcess } = await import(pathToFileURL(modulePath))
const sha = bytes => createHash('sha256').update(bytes).digest('hex')
const before = sha(readFileSync(modulePath))
const scratch = mkdtempSync('/private/tmp/d2-partial-input-consumer-')
const handles = []
const results = []
const input = randomBytes(2097169)
writeFileSync(join(evidence, 'input.bin'), input)
try {
  for (const partial of [false, true]) {
    const witness = join(scratch, partial ? 'partial-read' : 'early-close')
    const target = `const fs=require('node:fs'); let received=Buffer.alloc(0); if(${partial}) { const block=Buffer.alloc(65536); let count=0; while(count<block.length) { const size=fs.readSync(0,block,count,block.length-count,null); if(size===0)break; count+=size; } received=block.subarray(0,count); } fs.writeFileSync(${JSON.stringify(witness)},received); fs.closeSync(0); const out=Buffer.alloc(2097169,65); const err=Buffer.alloc(2097175,66); for(let pos=0;pos<out.length;pos+=65536) fs.writeFileSync(1,out.subarray(pos,Math.min(pos+65536,out.length))); for(let pos=0;pos<err.length;pos+=65536) fs.writeFileSync(2,err.subarray(pos,Math.min(pos+65536,err.length))); process.exit(23);`
    const session = new SupervisedProcess({ executable: '/opt/homebrew/bin/node', args: ['-e', target], cwd: scratch, env: { PATH: process.env.PATH }, tailBytes: 0, maxWriteBytes: 16777216 })
    handles.push(session)
    const chunks = { stdout: [], stderr: [] }
    const captured = (async () => {
      await delay(100)
      while (true) {
        const result = await session.takeOutput()
        if (result.kind !== 'Chunk') return result
        chunks[result.channel].push(Buffer.from(result.bytes))
      }
    })()
    const watchdog = setTimeout(() => session.signal('SIGKILL'), 8000)
    let terminal
    let write
    let started
    try {
      started = await session.started()
      assert.equal(started.kind, 'Started')
      write = await session.write(input)
      assert.ok(['Written', 'Unknown'].includes(write.kind))
      session.endInput()
      terminal = await captured
    } finally {
      clearTimeout(watchdog)
    }
    const closed = await session.wait(1000)
    const actual = readFileSync(witness)
    const stdout = Buffer.concat(chunks.stdout)
    const stderr = Buffer.concat(chunks.stderr)
    const name = partial ? 'partial' : 'closed'
    writeFileSync(join(evidence, `${name}.target.bin`), actual)
    writeFileSync(join(evidence, `${name}.stdout.bin`), stdout)
    writeFileSync(join(evidence, `${name}.stderr.bin`), stderr)
    const facts = { host: process.execPath, libraryVersion: JSON.parse(readFileSync(join(library, 'package.json'), 'utf8')).version, partial, started, write, terminal, closed, input: { bytes: input.length, sha256: sha(input) }, target: { bytes: actual.length, sha256: sha(actual), prefixEqual: actual.equals(input.subarray(0, actual.length)) }, stdout: { bytes: stdout.length, sha256: sha(stdout) }, stderr: { bytes: stderr.length, sha256: sha(stderr) } }
    console.log(JSON.stringify(facts))
    results.push(facts)
    assert.equal(terminal.kind, 'Closed')
    assert.equal(terminal.state.failure, null)
    assert.deepEqual(terminal.state.exit, { code: 23, signal: null })
    assert.equal(closed.kind, 'Closed')
    assert.equal(actual.length, partial ? 65536 : 0)
    assert.deepEqual(actual, input.subarray(0, actual.length))
    assert.deepEqual(stdout, Buffer.alloc(2097169, 65))
    assert.deepEqual(stderr, Buffer.alloc(2097175, 66))
  }
  assert.equal(sha(readFileSync(modulePath)), before)
  writeFileSync(join(evidence, 'summary.json'), JSON.stringify({ passed: true, product, supervisionSha256: before, results, scope: 'Actual fixed-package public SupervisedProcess capability, real Node target closes stdin immediately or after one native read, then emits over2MiB on each channel under delayed output consumption and exits23. Original input write result is recorded and never retried. Target witness bytes and both binary channels retained. No Host reinterpretation or npm public Plugin claim.' }, null, 2) + '\n')
} finally {
  for (const session of handles) {
    session.signal('SIGKILL')
    session.discardOutput()
    await session.wait(5000)
  }
  rmSync(scratch, { recursive: true, force: true })
  console.log(JSON.stringify({ cleanup: true, scratchRemoved: !existsSync(scratch), fixedModuleUnchanged: sha(readFileSync(modulePath)) === before }))
}
