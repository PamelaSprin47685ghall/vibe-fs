import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { spawnSync } from 'node:child_process'
import { setTimeout as delay } from 'node:timers/promises'

const installation = resolve(process.argv[2])
const evidence = resolve(process.argv[3])
mkdirSync(evidence, { recursive: true })
const library = join(installation, 'node_modules/wanxiangli')
const modulePath = join(library, 'dist/supervision/SupervisedProcess.js')
const { SupervisedProcess } = await import(pathToFileURL(modulePath))
const sha = bytes => createHash('sha256').update(bytes).digest('hex')
const sourceBefore = sha(readFileSync(modulePath))
const scratch = mkdtempSync('/private/tmp/d2-library-input-run-')
const handles = []
const results = []
const expectedInput = (size, seed) => {
  const bytes = Buffer.alloc(size)
  let state = seed >>> 0
  for (let index = 0; index < size; index++) {
    state ^= state << 13
    state ^= state >>> 17
    state ^= state << 5
    bytes[index] = state >>> 24
  }
  return bytes
}
const describe = bytes => ({ size: bytes.length, sha256: sha(bytes), prefixHex: bytes.subarray(0, 32).toString('hex'), suffixHex: bytes.subarray(-32).toString('hex') })
const capture = async (session, delayMs = 0) => {
  const chunks = { stdout: [], stderr: [] }
  await delay(delayMs)
  while (true) {
    const output = await session.takeOutput()
    if (output.kind !== 'Chunk') return { terminal: output, stdout: Buffer.concat(chunks.stdout), stderr: Buffer.concat(chunks.stderr) }
    chunks[output.channel].push(Buffer.from(output.bytes))
  }
}
const createSession = (executable, args) => {
  const session = new SupervisedProcess({ executable, args, cwd: scratch, env: { PATH: process.env.PATH }, tailBytes: 0, maxWriteBytes: 16777216 })
  handles.push(session)
  return session
}
const waitFor = async (read, description) => {
  const end = performance.now() + 3000
  while (performance.now() < end) {
    const result = read()
    if (result) return result
    await delay(5)
  }
  assert.fail(description)
}
const processState = pid => {
  const state = spawnSync('/bin/ps', ['-p', String(pid), '-o', 'stat='], { encoding: 'utf8' })
  assert.ifError(state.error)
  return state.status === 0 ? state.stdout.trim() : null
}

try {
  for (const size of [2097169, 33554449, 67108881]) {
    const seed = (0x4c6718fa ^ size) >>> 0
    const input = expectedInput(size, seed)
    writeFileSync(join(evidence, `complete-${size}.input.bin`), input)
    const blockHashes = []
    for (let index = 0; index < input.length; index += 65536) blockHashes.push(sha(input.subarray(index, index + 65536)))
    assert.equal(new Set(blockHashes).size, blockHashes.length)
    const witness = join(scratch, `tee-${size}`)
    const slowReader = `const fs=require('node:fs'); const out=fs.openSync(${JSON.stringify(witness)},'wx'); const bytes=Buffer.alloc(65536); const wait=()=>new Promise(resolve=>setTimeout(resolve,1)); (async()=>{while(true){const n=fs.readSync(0,bytes,0,bytes.length,null);if(n===0)break;for(const fd of [out,1]){let pos=0;while(pos<n){const wrote=fs.writeSync(fd,bytes,pos,n-pos);if(wrote<=0)throw new Error('No progress');pos+=wrote;}}await wait();}fs.closeSync(out);})();`
    const session = size === 67108881 ? createSession('/opt/homebrew/bin/node', ['-e', slowReader]) : createSession('/usr/bin/tee', [witness])
    const captured = capture(session, 100)
    const watchdog = setTimeout(() => session.signal('SIGKILL'), 20000)
    const writes = []
    let output
    try {
      assert.equal((await session.started()).kind, 'Started')
      for (let position = 0; position < input.length; position += 16777216) {
        const part = input.subarray(position, position + 16777216)
        const receipt = await session.write(part)
        writes.push(receipt)
        if (receipt.kind !== 'Written') break
      }
      session.endInput()
      output = await captured
    } finally {
      clearTimeout(watchdog)
    }
    const target = readFileSync(witness)
    writeFileSync(join(evidence, `complete-${size}.target.bin`), target)
    writeFileSync(join(evidence, `complete-${size}.stdout.bin`), output.stdout)
    writeFileSync(join(evidence, `complete-${size}.stderr.bin`), output.stderr)
    writeFileSync(join(evidence, `complete-${size}.receipts.json`), JSON.stringify({ size, seed, writes, terminal: output.terminal, actualSize: target.length, outputSize: output.stdout.length }, null, 2) + '\n')
    assert.deepEqual(target, input)
    assert.deepEqual(output.stdout, input)
    assert.equal(output.stderr.length, 0)
    assert.equal(output.terminal.kind, 'Closed')
    assert.equal(output.terminal.state.failure, null)
    assert.deepEqual(output.terminal.state.exit, { code: 0, signal: null })
    const closed = await session.wait(1000)
    assert.equal(closed.kind, 'Closed')
    for (let position = 0; position < input.length; position += 16777216) assert.deepEqual(writes[position / 16777216], { kind: 'Written', bytes: Math.min(16777216, input.length - position) })
    const result = { passed: true, case: size === 67108881 ? 'real-slow-reader-under-input-and-output-pressure' : 'real-tee-under-delayed-output-consumption', host: process.execPath, seed, generator: 'xorshift32, unsigned seed, emit state>>>24 after shifts13/17/5', input: describe(input), target: describe(target), stdout: describe(output.stdout), stderr: describe(output.stderr), unique64KiBBlockHashes: blockHashes.length, writes, terminal: output.terminal, closed, byteEqualityChecked: true, rawLargePayloadRetention: 'Complete input/target/stdout bytes retained.' }
    results.push(result)
    console.log(JSON.stringify(result))
  }

  {
    const ready = join(scratch, 'blocked-target-ready')
    const target = `require('node:fs').writeFileSync(${JSON.stringify(ready)},String(process.pid)); setInterval(()=>{},1000);`
    const session = createSession('/opt/homebrew/bin/node', ['-e', target])
    const captured = capture(session)
    const started = await session.started()
    assert.equal(started.kind, 'Started')
    const targetPid = await waitFor(() => existsSync(ready) ? Number(readFileSync(ready, 'utf8')) : null, 'Own target must publish readiness')
    assert.equal(targetPid, started.pid)
    const supervisorPid = session.inspect().supervisor.pid
    process.kill(supervisorPid, 'SIGSTOP')
    await waitFor(() => processState(supervisorPid)?.includes('T'), 'Own supervisor must be physically stopped before the write')
    let settled = false
    let writeCalls = 0
    const input = expectedInput(16777216, 0x34126abe)
    writeCalls++
    const pending = session.write(input).then(result => { settled = true; return result })
    await delay(100)
    assert.equal(settled, false, 'A16MiB write to the stopped supervisor must still be pending')
    const signal = session.signal('SIGKILL')
    assert.equal(signal.kind, 'Requested')
    const write = await pending
    assert.equal(write.kind, 'Unknown')
    const output = await captured
    const closed = await session.wait(3000)
    assert.equal(closed.kind, 'Closed')
    assert.equal(output.terminal.kind, 'Closed')
    assert.equal(output.terminal.state.exit, null)
    await waitFor(() => {
      const state = processState(targetPid)
      return state === null || state.startsWith('Z')
    }, 'The own target must no longer execute')
    assert.equal(writeCalls, 1)
    const result = { passed: true, case: 'kill-while-one-input-write-is-physically-pending', host: process.execPath, targetPid, supervisorPid, physicalStopBarrier: true, pendingBeforeKill: true, writeCalls, signal, write, terminal: output.terminal, closed, targetNoLongerExecutes: true, noRetry: true, scope: 'Own supervisor is stopped before the one write to make actual pending I/O deterministic. KILL uses the public owned scope. The input result staysUnknown; no target exit is invented, and no business ledger is cleared fromUnknown. Independent ps is only resource cleanup evidence.' }
    results.push(result)
    console.log(JSON.stringify(result))
  }
  assert.equal(sha(readFileSync(modulePath)), sourceBefore)
  writeFileSync(join(evidence, 'summary.json'), JSON.stringify({ passed: true, host: process.execPath, libraryVersion: JSON.parse(readFileSync(join(library, 'package.json'), 'utf8')).version, sourceSha256: sourceBefore, results, scope: 'Actual clean-installed fixed public library package; no copied/private implementation at runtime. Real tee target bytes, delayed capture, nonperiodic input blocks, and actual pending-write/KILL. No main-project integration or npm Plugin evidence is claimed.' }, null, 2) + '\n')
} finally {
  for (const session of handles) {
    session.signal('SIGKILL')
    session.discardOutput()
    await session.wait(5000)
  }
  rmSync(scratch, { recursive: true, force: true })
  console.log(JSON.stringify({ cleanup: true, scratchRemoved: !existsSync(scratch), fixedModuleUnchanged: sha(readFileSync(modulePath)) === sourceBefore }))
}
