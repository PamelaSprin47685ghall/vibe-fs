# Independent review of fixed library 0.6.11

Archive SHA256:
`aa112c11957468cbcfc0cb8e4a340326572484cca2b7803cfdffa2d0b75614a4`.
The package was actually installed offline with npm into this private folder.
All 22 package files match the archive byte for byte. All 25 installed files,
including manifests and lockfiles, are unchanged before and after the runs.
No runtime import falls back to the library workspace or the main project.

## Boundary review

The only production source change under review schedules successful `complete()`
with `setImmediate` after actual FileSink write and flush resolution. It retains
`pendingWrite` and the false `completed` flag until that callback actually runs.
An intervening observed exit or error can therefore complete the operation as
Unknown immediately. The late success then becomes a no-op. `pendingWrite` is
cleared before invoking the callback and is not overwritten afterward, so a
synchronously started next write cannot be erased by the old completion.

This is a local native-adapter responsibility. It does not add a Host branch,
retry, business-ledger decision, timeout extension, or FIFO path.

The two existing controlled fixtures were copied unchanged and run once each
against this installed package. They first write real bytes through a real cat
stdin, then hold only the acknowledgement. `drainMicrotasks()` forms an explicit
native-callback checkpoint. The success case proves the consumer does not resume
inside that checkpoint. The exit case injects an exit observation in the gap
before setImmediate and proves Unknown wins over the scheduled success.
Both passed. The injected exit 23 is controlled evidence, not an actual cat exit
23 or proof of the physical last-17-byte failure's cause. The old red checks are
owned by the root's source evidence and were not rerun here.

## Predeclared physical matrix

Each Node and Bun CLI case ran once: six cases per Host, twelve total.

1. Real tee, 2 MiB + 17 bytes, delayed output consumption.
2. Real tee, 32 MiB + 17 bytes, 16 MiB/16 MiB/17 writes.
3. Real Node reader, 64 MiB + 17 bytes, 16 MiB chunks plus 17. It reads at most
   64 KiB, writes each byte to an owned witness and stdout, then waits 1 ms.
4. Real target closes stdin immediately, emits over 2 MiB on each channel, exits 23.
5. Real target accumulates exactly 64 KiB before closing stdin, emits the same
   two channels, exits 23. The witness equals the input prefix exactly.
6. One real 16 MiB write remains physically pending for 100 ms after the owned
   supervisor has been stopped. Public scope KILL returns Unknown, preserves no
   invented target exit, and independent ps confirms that target no longer runs.

All twelve passed. Complete input, target, stdout and stderr bytes are retained
for each complete-input case before assertions. Partial/closed-input cases also
retain their actual input and both complete channels. The random write receipts
are recorded without retry. In particular, Written at the outer supervision
input is not asserted to mean that the actual target consumed the bytes.

After those CLI results, the same `library-input-consumer.mjs` was imported once
under a Bun test wrapper. The source was unchanged; only process.argv points to
a distinct evidence folder. Its four physical cases passed: three complete
inputs and pending KILL. This is one Bun test, not four separately reported
test-runner tests. Early-close cases were not rerun in that mode.

## Remaining boundary

The root's formal 662 Bun test still loses exactly the final 17 bytes with this
same library version. That failure remains blocking. These finite green cases
do not close the main Host integration, establish the physical loss's unique
cause, or accept D2. In particular, the complete-input witnesses here consume
and emit incrementally; native Git hash-object's consumption/output pattern and
the formal suite's preceding operations differ. No further blind repeats were
performed. The unsuccessful FIFO prototype remains separate and is not wired.

The private consumers were manually adapted from the previous frozen probes:
one extra 64 MiB + 17 slow-reader case, full raw-byte retention before assertion,
and cumulative exact 64 KiB reading for the partial-input case. No production
source or shared test was edited by this reviewer.
