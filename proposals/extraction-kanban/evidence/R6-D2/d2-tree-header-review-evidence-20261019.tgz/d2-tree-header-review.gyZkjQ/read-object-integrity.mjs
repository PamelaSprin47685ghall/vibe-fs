import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { spawnSync } from 'node:child_process'
import { chmodSync, existsSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { deflateSync } from 'node:zlib'

const baseline = resolve(process.argv[2])
const current = resolve(process.argv[3])
const owned = mkdtempSync('/private/tmp/d2-blob-integrity-owned-')
const oldApi = await import(pathToFileURL(join(baseline, 'dist/Persistence/EventStore/ProcessGitRawStore.js')))
const oldTypes = await import(pathToFileURL(join(baseline, 'dist/Persistence/EventStore/GitTypes.js')))
const currentApi = await import(pathToFileURL(join(current, 'dist/Persistence/EventStore/GitRawSurface.js')))
const call = (args, input) => {
  const result = spawnSync('/usr/bin/git', ['-C', owned, ...args], { input, encoding: 'buffer', timeout: 5000 })
  if (result.error) throw result.error
  return result
}
const hash = bytes => createHash('sha1').update(Buffer.concat([Buffer.from(`blob ${bytes.length}\0`), bytes])).digest('hex')
const records = []

try {
  assert.equal(call(['init', '--bare', '--quiet']).status, 0)
  const expected = Buffer.from('abc')
  const oid = call(['hash-object', '-w', '--stdin'], expected).stdout.toString().trim()
  assert.equal(oid, hash(expected))
  const path = join(owned, 'objects', oid.slice(0, 2), oid.slice(2))
  const saved = readFileSync(path)
  chmodSync(path, 0o600)
  const read = async phase => {
    const native = call(['cat-file', 'blob', oid])
    const oldValue = await oldApi.ProcessGitRawStoreModule_create(owned).ReadObject(oldTypes.GitObjectIdModule_create(oid))
    const result = await currentApi.create(owned).readObject(oid)
    records.push({ phase, requestedOid: oid, native: { status: native.status, bytesHex: native.stdout.toString('hex'), stderr: native.stderr.toString() },
      baseline652: oldValue == null ? null : { bytesHex: Buffer.from(oldValue).toString('hex'), oidOfReturnedBytes: hash(Buffer.from(oldValue)) },
      current661: result.ok ? { ok: true, bytesHex: Buffer.from(result.value).toString('hex'), oidOfReturnedBytes: hash(Buffer.from(result.value)) } : result })
    return { oldValue, result }
  }
  const positive = await read('canonical positive')
  assert.deepEqual(Buffer.from(positive.oldValue), expected)
  assert.deepEqual(Buffer.from(positive.result.value), expected)
  writeFileSync(path, deflateSync(Buffer.concat([Buffer.from('blob 3\0'), Buffer.from('ab')])))
  const broken = await read('complete zlib, declared 3, physical body 2, canonical original OID kept')
  assert.equal(Buffer.from(broken.oldValue).toString('hex'), '6162')
  assert.equal(broken.result.ok, false)
  assert.equal(broken.result.error.result.ending.exitCode, 0)
  assert.equal(Buffer.from(broken.result.error.result.output.stdout).toString('hex'), '6162')
  writeFileSync(path, saved)
  const restored = await read('restored cold positive')
  assert.deepEqual(Buffer.from(restored.result.value), expected)
  console.log(JSON.stringify({ runtime: process.versions.bun ? `Bun ${process.versions.bun}` : process.version, baseline, current, records,
    scope: 'Specific physical blob corruption receipt. Native Git streams normal-exit short bytes; current661 length validation rejects them and preserves exit0, while baseline652 returns short invalid bytes. Do not generalize the tree zero-padding behavior to blob streaming. No source change.' }, null, 2))
} finally {
  rmSync(owned, { recursive: true, force: true })
  console.log(JSON.stringify({ ownedRepositoryRemoved: !existsSync(owned) }))
}
