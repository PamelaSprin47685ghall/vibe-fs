import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { spawnSync } from 'node:child_process'
import { chmodSync, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { deflateSync } from 'node:zlib'

const owned = mkdtempSync('/private/tmp/d2-tree-header-owned-')
const git = '/usr/bin/git'
const env = { ...process.env, GIT_CONFIG_GLOBAL: '/dev/null', GIT_CONFIG_SYSTEM: '/dev/null' }
for (const name of ['GIT_DIR', 'GIT_WORK_TREE', 'GIT_COMMON_DIR', 'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES']) delete env[name]
const call = (args, input) => {
  const result = spawnSync(git, ['-C', owned, ...args], { input, env, encoding: 'buffer', timeout: 5000 })
  if (result.error) throw result.error
  return { args, status: result.status, signal: result.signal, stdoutHex: result.stdout.toString('hex'), stdoutUtf8: result.stdout.toString(), stderr: result.stderr.toString() }
}
const zero = (args, input) => {
  const result = call(args, input)
  assert.equal(result.status, 0, result.stderr)
  return Buffer.from(result.stdoutHex, 'hex')
}
const oidOf = bytes => createHash('sha1').update(bytes).digest('hex')
const results = []

try {
  zero(['init', '--bare', '--quiet'])
  const version = zero(['--version']).toString().trim()
  const blob = zero(['hash-object', '-w', '--stdin'], Buffer.from('x')).toString().trim()
  const emptyTree = zero(['mktree'], Buffer.alloc(0)).toString().trim()
  const rawEntry = (mode, oid) => Buffer.concat([Buffer.from(`${mode} leaf\0`), Buffer.from(oid, 'hex')])
  const canonical = rawEntry('100644', blob)
  const fixture = (label, body, claimedSize, addressKind) => {
    const header = Buffer.from(`tree ${claimedSize}\0`)
    const stored = Buffer.concat([header, body])
    const returned = Buffer.alloc(claimedSize)
    body.copy(returned, 0, 0, Math.min(body.length, claimedSize))
    const oid = oidOf(addressKind === 'physical-inflated-bytes' ? stored : Buffer.concat([header, returned]))
    const parent = join(owned, 'objects', oid.slice(0, 2))
    const file = join(parent, oid.slice(2))
    const saved = existsSync(file) ? readFileSync(file) : null
    const savedMode = saved ? statSync(file).mode & 0o777 : null
    mkdirSync(parent, { recursive: true })
    if (saved) chmodSync(file, 0o600)
    writeFileSync(file, deflateSync(stored))
    try {
      const batch = call(['cat-file', '--batch-check'], Buffer.from(`${oid}\n`))
      const bodyReply = call(['cat-file', 'tree', oid])
      const listing = call(['ls-tree', '--full-tree', '-z', oid])
      const hashActualBody = call(['hash-object', '-t', 'tree', '--stdin'], body)
      const hashReturnedBody = bodyReply.status === 0
        ? call(['hash-object', '-t', 'tree', '--stdin'], Buffer.from(bodyReply.stdoutHex, 'hex'))
        : null
      results.push({ label, oid, addressKind, actualSize: body.length, claimedSize,
        actualRawHex: body.toString('hex'), batch, bodyReply, listing, hashActualBody, hashReturnedBody })
    } finally {
      if (saved) {
        writeFileSync(file, saved)
        chmodSync(file, savedMode)
      }
      else rmSync(file)
    }
  }

  for (const size of [0, canonical.length - 1, canonical.length, canonical.length + 1, 99]) {
    for (const addressKind of ['physical-inflated-bytes', 'declared-padded-or-truncated-bytes']) {
      fixture('canonical-entry-forged-header', canonical, size, addressKind)
    }
  }
  for (const addressKind of ['physical-inflated-bytes', 'declared-padded-or-truncated-bytes']) {
    fixture('complete-zlib-but-last-raw-oid-byte-missing', canonical.subarray(0, canonical.length - 1), canonical.length, addressKind)
  }
  for (const mode of ['40000', '040000', '0040000', '100644', '0100644', '100664', '100755', '0100755', '120000', '0120000', '160000', '0160000', '100000', '000000']) {
    const body = rawEntry(mode, mode.endsWith('40000') ? emptyTree : blob)
    fixture(`raw-mode-${mode}`, body, body.length, 'physical-inflated-bytes')
  }

  const positive = results.filter(row => row.label === 'canonical-entry-forged-header' && row.claimedSize === canonical.length)
  assert.equal(positive.length, 2)
  for (const row of positive) {
    assert.equal(row.batch.status, 0)
    assert.equal(row.bodyReply.status, 0)
    assert.equal(row.listing.status, 0)
    assert.equal(row.listing.stdoutUtf8, `100644 blob ${blob}\tleaf\0`)
  }
  console.log(JSON.stringify({ runtime: process.version, git: version, blob, emptyTree, results,
    scope: 'Native Git only, private crafted loose objects with complete zlib streams. SHA-1 and raw object assembly are fixture construction, not a production object database. Each mutated loose file is restored/removed before the next fixture.' }, null, 2))
} finally {
  rmSync(owned, { recursive: true, force: true })
  console.log(JSON.stringify({ ownedRepositoryRemoved: !existsSync(owned) }))
}
