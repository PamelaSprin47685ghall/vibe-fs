# D2 native tree-header hypothesis review and blob contrast

This is a private evidence archive, not a production implementation. No shared source was edited. Native Git: Apple Git 2.50.1 (Git-155); runtime Node v26.6.0. All owned repositories were removed in finally cleanup. The final `probe.mjs` records 28 native fixtures and 149 command receipts, excluding setup; this is not 149 product requirement tests.

## Original tree hypothesis was not confirmed

The requested hypothesis was a complete, valid single-entry raw tree whose zlib stream is complete but whose object header declares a different body size. Its actual body is 32 bytes. The probe tries declared sizes 0, 31, 32, 33 and 99 and two object-path addresses: SHA-1 of the actually inflated malformed bytes, and SHA-1 of the declared-size truncated/padded logical body.

`cat-file --batch-check` reports the forged size with exit 0. For declared 31, 33 and 99, `ls-tree --full-tree -z` returns exit 128 with no row under both address strategies. Exact size 32 returns the expected valid row. The special size-0 fixture at Git's empty-tree OID returns empty output, not a nonempty legal row. These observations do not establish the proposed product bug.

Earlier `native-first24.log` records the first 24 fixtures; the final `native.log` extends the same cases with the controls below. Both remain intact. The archive also preserves intermediate scripts/logs rather than replacing earlier observations.

## Normalized listing cannot reconstruct exact raw size

Native raw directory modes `40000`, `040000` and `0040000` produce 31, 32 and 33 byte single-entry bodies. All three read successfully and emit identical `040000 tree ...` ls-tree rows. Raw `100664`, `100000` and zero-padded regular-file modes are also normalized to `100644` in the listing. Canonical hash-object validation rejects several noncanonical inputs that ls-tree reads successfully.

Therefore summing a normalized row representation cannot prove the original raw byte size and would reject Git-readable noncanonical trees. Adding hash-object validation would change that acceptance boundary too. No such repair is justified by the original hypothesis. The smallest accurate product boundary remains the declared SHA-1 protocol and the four supported semantic modes returned by Git, with strict type/OID/name/UTF-8/row checks. It must not infer original raw mode spelling from normalized output or broaden support to gitlink mode 160000. Git remains the owner of its object storage and parsing.

## Complete zlib with an omitted zero byte: physical difference, same logical tree

The supplementary fixture removes the last raw OID byte while preserving a complete zlib stream and declaring the full size. Native tree reads zero-pad the missing byte. At the actual malformed inflated-byte SHA-1 address, ls-tree rejects the hash mismatch. At the padded logical object's SHA-1 address, it can return a complete valid row.

A decisive control uses a real existing blob whose OID ends in `00` (`1bc80e7a7119e722e4ba9274d7a84c672ef50400`). The canonical 32-byte tree and the complete-zlib 31-byte variant omitting that final zero are presented at the same logical tree OID `1ce6b76d97f4eed62dc72b3c0ba430175de3cd0b`. Both produce identical batch/tree/listing bytes, and both full `fsck --strict` and connectivity-only fsck return exit 0 with empty diagnostics. Logical content and the referenced existing blob do not change.

This proves a Git physical-container tolerance, not product data loss or a D2 regression. Exact-size reconstruction would not detect it because Git's returned logical representation is already full-size. Adding fsck would not detect it either. It must not be used to claim that normal Git results prove the exact inflated physical length, nor to justify rebuilding the object database in the product.

## Blob behavior differs; current length guard works

`read-object-integrity.mjs` compares actual installed fixed 652 and 661 packages with canonical and restored positive controls. The exact packages are included:

- Baseline 652 SHA-256: `003bc8818969597f9afd6a1c0767c7aae271dd53e5f0392b146367d156ec3887`.
- Candidate 661 SHA-256: `34393e1d4b8fcb4b7e3ddbaa9769a681c728fb12ed072a0785c0bb82483f009f`.

A blob whose canonical content is `abc` keeps that canonical OID, but its complete zlib stream now contains header `blob 3` and body `ab`. Native `cat-file blob` exits 0 with the two short bytes, not a padded third byte. Baseline 652 returns those invalid short bytes as a value. Candidate 661 rejects the length mismatch, preserves the actual normal exit 0 and both captured bytes, and does not invent execution Unknown. Restoring the original object permits a fresh correct read. Node and Bun both confirm this in their final logs.

This is evidence for the existing D2 repair of an old path, not a new issue. It does not close the separate large-input Bun OID mismatch investigation or whole D2 acceptance.

## Reviewer and fixture errors retained separately

- `fixture-readonly-red.log`: the first private fixture tried to overwrite the owned native empty-tree object while it still had Git's read-only mode. The fixture was corrected to change/restore only that owned file's mode. Its repository was removed. This is not a product EACCES failure.
- `read-object-integrity-hypothesis.mjs` and its red log: the reviewer initially generalized tree zero-padding to blobs. The actual installed product rejected the short blob, falsifying that expectation.
- `read-object-native-exit-hypothesis.mjs` and the Node/Bun red logs: a second expectation assumed native Git itself returned 128 for that blob. The observed receipt was exit 0; the product's explicit length guard caused rejection. The final probe checks and records that actual behavior.

These are review/probe misjudgments, not defects attributed to the original split or the D2 helper refactor. Final logs were rerun after correcting the expectations; earlier red evidence is unchanged.

## Reproduce

```sh
node probe.mjs > native.log 2>&1
node read-object-integrity.mjs <installed-652-root> <installed-661-root> > node-read-object-integrity.log 2>&1
bun read-object-integrity.mjs <installed-652-root> <installed-661-root> > bun-read-object-integrity.log 2>&1
```

Use the exact included archives with their declared dependencies and a clean Git environment (no inherited GIT_DIR/GIT_WORK_TREE overrides). The installed original paths are in the raw logs. Native fixtures need no product build. Product physical probes need macOS process inspection. SHA256SUMS binds all files. No original package or raw log was edited. R12-U1 remains deferred.
