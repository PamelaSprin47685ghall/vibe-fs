import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { chmodSync, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { spawnSync } from 'node:child_process'
import { pathToFileURL } from 'node:url'
import { setTimeout as delay } from 'node:timers/promises'

const product = resolve(process.argv[2])
const fromProduct = path => import(pathToFileURL(join(product, 'dist', path)))
const raw = await fromProduct('Persistence/EventStore/ProcessGitRawStore.js')
const gateway = await fromProduct('Git/Gateway.js')
const deadline = await fromProduct('Process/Deadline.js')
const list = await fromProduct('fable_modules/fable-library-js.5.13.0/List.js')
const { utcNow } = await fromProduct('fable_modules/fable-library-js.5.13.0/DateOffset.js')
const nativeGit = '/usr/bin/git'
const node = '/opt/homebrew/bin/node'
const hardLimitMs = 1500
const scratch = mkdtempSync('/private/tmp/d2-physical-unknown-write-')
const originalPath = process.env.PATH
const originalTmp = process.env.TMPDIR
const protectedPaths = ['Persistence/EventStore/ProcessGitRawStore.js', 'Persistence/EventStore/WriterStreamSync.js', 'Git/Gateway.js', 'Process/NodeProcessHost.js', 'Process/NodeProcessWait.js']
const sha = bytes => createHash('sha256').update(bytes).digest('hex')
const sourceDigests = () => Object.fromEntries(protectedPaths.map(path => [path, sha(readFileSync(join(product, 'dist', path)))]))
const sourceBefore = sourceDigests()
const ownTargets = new Set()
const native = (repo, args, input) => {
  const result = spawnSync(nativeGit, ['-C', repo, ...args], { input, maxBuffer: 1048576 })
  assert.ifError(result.error)
  assert.equal(result.signal, null)
  return result
}
const waitUntilNotExecuting = async pid => {
  const deadlineMs = performance.now() + 3000
  while (performance.now() < deadlineMs) {
    const status = spawnSync('/bin/ps', ['-p', String(pid), '-o', 'stat='], { encoding: 'utf8' })
    assert.ifError(status.error)
    if (status.status !== 0 || status.stdout.trim().startsWith('Z')) return true
    await delay(10)
  }
  return false
}

try {
  for (const mode of ['before', 'after']) {
    const repo = join(scratch, mode)
    const initialized = spawnSync(nativeGit, ['init', '--quiet', repo])
    assert.equal(initialized.status, 0, initialized.stderr.toString())
    const common = join(repo, '.git')
    const controls = join(repo, 'controls')
    const bin = join(repo, 'bin')
    mkdirSync(controls)
    mkdirSync(bin)
    const evidenceFile = join(controls, 'invocations.ndjson')
    const writerBytes = Buffer.from(JSON.stringify({ event_id: '1'.repeat(40), event_type: 'JobRequested', parents: [], payload: { physical_probe: mode }, payload_refs: [], stream_id: '2'.repeat(40) }) + '\n')
    const expected = native(repo, ['hash-object', '--stdin'], writerBytes)
    assert.equal(expected.status, 0)
    const oid = expected.stdout.toString('ascii').trim()
    assert.match(oid, /^[0-9a-f]{40}$/)
    const loose = join(common, 'objects', oid.slice(0, 2), oid.slice(2))
    assert.equal(existsSync(loose), false)
    const beforeRead = native(repo, ['cat-file', 'blob', oid])
    assert.notEqual(beforeRead.status, 0)
    const events = join(common, 'wanxiangshu/events')
    mkdirSync(events, { recursive: true })
    const writer = join(events, 'writer-local.ndjson')
    writeFileSync(writer, writerBytes)
    const executable = join(bin, 'git')
    writeFileSync(executable, `#!${node}
const fs = require('node:fs');
const cp = require('node:child_process');
const args = process.argv.slice(2);
const input = fs.readFileSync(0);
const record = value => fs.appendFileSync(${JSON.stringify(evidenceFile)}, JSON.stringify(value) + '\\n');
record({ phase: 'invoked', pid: process.pid, args, inputSize: input.length });
if (args[2] === 'hash-object') {
  record({ phase: 'before-native-write', pid: process.pid, mode: ${JSON.stringify(mode)} });
  if (${JSON.stringify(mode)} === 'after') {
    record({ phase: 'native-write-started', pid: process.pid });
    const actual = cp.spawnSync(${JSON.stringify(nativeGit)}, args, { input });
    record({ phase: 'native-write-ended', pid: process.pid, status: actual.status, signal: actual.signal, stdout: actual.stdout.toString('base64'), stderr: actual.stderr.toString('base64') });
    if (actual.status !== 0) process.exit(actual.status || 125);
    fs.writeFileSync(1, actual.stdout);
    fs.writeFileSync(2, actual.stderr);
  }
  record({ phase: 'waiting-for-owned-deadline', pid: process.pid });
  setInterval(() => {}, 1000);
} else {
  const actual = cp.spawnSync(${JSON.stringify(nativeGit)}, args, { input });
  fs.writeFileSync(1, actual.stdout);
  fs.writeFileSync(2, actual.stderr);
  process.exit(actual.status == null ? 125 : actual.status);
}
`)
    chmodSync(executable, 0o755)
    process.env.PATH = `${bin}:${originalPath}`
    process.env.TMPDIR = controls
    const physical = raw.ProcessGitRawStoreModule_createRunner(repo, hardLimitMs)
    const calls = []
    let writeReceipt
    const run = async request => {
      const args = list.toArray(request.Arguments)
      calls.push(args)
      const receipt = await physical(request)
      if (args[0] === 'hash-object') writeReceipt = receipt
      return receipt
    }
    const store = raw.ProcessGitRawStoreModule_createWithRunner(repo, run)
    let locks = 0
    let transportCalls = 0
    const startedAt = performance.now()
    const result = await gateway.GitGateway_converge(
      store, common, async () => { transportCalls++; assert.fail('Incomplete storage execution must stop publication') },
      3, 'origin', undefined,
      async stage => { locks++; return stage() },
      deadline.DeadlineModule_ofBudget(utcNow(), 60000), utcNow,
    )
    const elapsedMs = performance.now() - startedAt
    const invocations = readFileSync(evidenceFile, 'utf8').trim().split('\n').map(line => JSON.parse(line))
    const writeInvocations = invocations.filter(entry => entry.phase === 'invoked' && entry.args[2] === 'hash-object')
    assert.equal(writeInvocations.length, 1)
    const targetPid = writeInvocations[0].pid
    ownTargets.add(targetPid)
    assert.equal(result.tag, 1)
    const error = result.fields[0]
    assert.equal(error.cases()[error.tag], 'GitStorage')
    assert.equal(error.fields[0].Result, writeReceipt)
    assert.equal(writeReceipt.tag, 1)
    const observation = writeReceipt.fields[0]
    assert.equal(observation.StopRequested.cases()[observation.StopRequested.tag], 'DeadlineStopRequested')
    assert.equal(observation.StopRequested.fields[0], hardLimitMs)
    assert.equal(observation.Output.Complete, false)
    assert.equal(calls.filter(args => args[0] === 'hash-object').length, 1)
    assert.equal(calls.filter(args => args[0] === 'mktree').length, 0)
    assert.equal(calls.at(-1)[0], 'hash-object')
    assert.equal(invocations.filter(entry => entry.phase === 'native-write-started').length, mode === 'after' ? 1 : 0)
    assert.equal(invocations.filter(entry => entry.phase === 'native-write-ended').length, mode === 'after' ? 1 : 0)
    assert.ok(invocations.some(entry => entry.phase === 'waiting-for-owned-deadline'))
    assert.equal(locks, 1)
    assert.equal(transportCalls, 0)
    assert.equal(existsSync(join(common, 'wanxiangshu/sync-materialization-cache')), false)
    assert.deepEqual(readFileSync(writer), writerBytes)
    assert.equal(existsSync(loose), mode === 'after')
    const afterRead = native(repo, ['cat-file', 'blob', oid])
    if (mode === 'after') {
      assert.equal(afterRead.status, 0, afterRead.stderr.toString())
      assert.deepEqual(afterRead.stdout, writerBytes)
      assert.equal(invocations.find(entry => entry.phase === 'native-write-ended').status, 0)
    } else assert.notEqual(afterRead.status, 0)
    assert.ok(await waitUntilNotExecuting(targetPid), 'The owned hanging git shim must no longer execute')
    ownTargets.delete(targetPid)
    assert.deepEqual(sourceDigests(), sourceBefore)
    console.log(JSON.stringify({ passed: true, mode, host: process.execPath, oid, expectedSize: writerBytes.length, expectedSha256: sha(writerBytes), elapsedMs, beforeRead: { status: beforeRead.status, stdout: beforeRead.stdout.toString('base64'), stderr: beforeRead.stderr.toString('base64'), loosePresent: false }, afterRead: { status: afterRead.status, stdout: afterRead.stdout.toString('base64'), stderr: afterRead.stderr.toString('base64'), loosePresent: mode === 'after' }, receipt: observation, receiptIdentityPreserved: true, calls, invocations, locks, transportCalls, nextTreeWrites: 0, cacheWritten: false, activeWriterUnchanged: true, ownedTargetNoLongerExecutes: true, productModulesUnchanged: true, sourceDigests: sourceBefore, scope: 'Actual fixed-package binary RawRunner, SupervisedProcess, RawStore, WriterStreamSync and Gateway. Own PATH git shim delegates native /usr/bin/git reads and, in after mode, one actual immutable write; shim then hangs and the real deadline stops it. Independent native Git reads and loose object presence establish before/after. The local lock callback is controlled. A signaled target or Unconfirmed end are both valid; no successful Git storage result is invented.' }))
  }
} finally {
  if (originalPath === undefined) delete process.env.PATH
  else process.env.PATH = originalPath
  if (originalTmp === undefined) delete process.env.TMPDIR
  else process.env.TMPDIR = originalTmp
  for (const pid of ownTargets) {
    try { process.kill(pid, 'SIGKILL') } catch (error) { if (error.code !== 'ESRCH') throw error }
    assert.ok(await waitUntilNotExecuting(pid))
  }
  rmSync(scratch, { recursive: true, force: true })
  console.log(JSON.stringify({ cleanup: true, scratchRemoved: !existsSync(scratch), remainingOwnedTargets: ownTargets.size }))
}
