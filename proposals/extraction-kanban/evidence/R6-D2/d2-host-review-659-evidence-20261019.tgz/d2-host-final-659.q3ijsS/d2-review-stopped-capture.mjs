import assert from 'node:assert/strict'
import { mkdtempSync, mkdirSync, readFileSync, readdirSync, existsSync, rmSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { spawnSync } from 'node:child_process'
import { setTimeout as delay } from 'node:timers/promises'

const product = resolve(process.argv[2])
const requireIncomplete = process.argv[3] === 'incomplete'
const runtime = await import(pathToFileURL(join(product, 'dist/Process/Surface.js')))
const scratch = mkdtempSync('/private/tmp/d2-stopped-capture-')
const controls = join(scratch, 'controls')
mkdirSync(controls)
const ready = join(scratch, 'writer-ready')
const countFile = join(scratch, 'writer-count')
const originalTmp = process.env.TMPDIR
let pending
let writerPid
const until = async (read, label) => {
  const end = performance.now() + 3000
  while (performance.now() < end) {
    const value = read()
    if (value) return value
    await delay(5)
  }
  assert.fail(label)
}
try {
  process.env.TMPDIR = controls
  const writer = `const fs=require('node:fs'); const payload=Buffer.alloc(65536,65); fs.writeFileSync(${JSON.stringify(ready)},String(process.pid)); let count=0; const end=Date.now()+3000; while(Date.now()<end) { fs.writeFileSync(1,payload); count+=payload.length; fs.writeFileSync(${JSON.stringify(countFile)},String(count)); }`
  const target = `const child=require('node:child_process').spawn('/opt/homebrew/bin/node',['-e',${JSON.stringify(writer)}],{stdio:['ignore',1,2]}); child.unref(); process.exit(23)`
  pending = runtime.run(runtime.command('/opt/homebrew/bin/node', ['-e', target], scratch, null), runtime.estimate(10, 1048576, 'medium'), runtime.context(scratch, 500), runtime.createCancellationToken(false))
  await until(() => existsSync(ready), 'Owned writer must be running')
  writerPid = Number(readFileSync(ready, 'utf8'))
  const directory = await until(() => readdirSync(controls).find(name => name.startsWith('wanxiangli-supervision-')), 'Own supervision directory must exist')
  const targetEnd = await until(() => {
    try { return JSON.parse(readFileSync(join(controls, directory, 'exit'), 'utf8')) } catch { return false }
  }, 'Actual target end must be visible while descendant holds output')
  assert.deepEqual(targetEnd, { code: 23, signal: null })
  assert.equal(existsSync(join(controls, directory, 'closed')), false)
  const result = await pending
  const acknowledgedBytes = existsSync(countFile) ? Number(readFileSync(countFile, 'utf8')) : 0
  const receivedBytes = result.output == null ? null : result.output.kind === 'Spooled' ? result.output.totalBytes : Buffer.byteLength(result.output.stdout ?? '')
  const lostAcknowledgedBytes = receivedBytes == null ? null : Math.max(0, acknowledgedBytes - receivedBytes)
  console.log(JSON.stringify({ host: process.execPath, targetEnd, noExtentBeforeStop: true, acknowledgedBytes, receivedBytes, result, lostAcknowledgedBytes, expectation: requireIncomplete ? 'complete-output-not-delivered' : 'observe-baseline' }))
  assert.equal(result.kind, 'Observed')
  assert.deepEqual(result.ending, { kind: 'Exited', exitCode: 23 })
  assert.equal(result.stopRequested.kind, 'DeadlineStopRequested')
  if (requireIncomplete) assert.equal(result.output, null)
  await until(() => {
    const status = spawnSync('/bin/ps', ['-p', String(writerPid), '-o', 'stat='], { encoding: 'utf8' })
    assert.ifError(status.error)
    return status.status !== 0 || status.stdout.trim().startsWith('Z')
  }, 'Owned pipe writer must no longer execute')
} finally {
  if (pending) await pending.catch(() => {})
  if (originalTmp === undefined) delete process.env.TMPDIR
  else process.env.TMPDIR = originalTmp
  rmSync(scratch, { recursive: true, force: true })
  console.log(JSON.stringify({ cleanup: true, scratchRemoved: !existsSync(scratch), writerPid }))
}
