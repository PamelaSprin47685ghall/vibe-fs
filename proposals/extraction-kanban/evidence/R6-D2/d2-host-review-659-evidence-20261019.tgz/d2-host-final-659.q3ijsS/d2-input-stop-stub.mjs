import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { mkdtempSync, readFileSync, writeFileSync, rmSync, existsSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { setTimeout as delay } from 'node:timers/promises'

const product = resolve(process.argv[2])
const scratch = mkdtempSync('/private/tmp/d2-input-stop-capability-')
const stub = join(scratch, 'supervision-stub.mjs')
const hostPath = join(product, 'dist/Process/NodeProcessHost.js')
const protectedFiles = [
  hostPath,
  join(product, 'dist/Process/NodeProcessWait.js'),
  join(product, 'dist/Persistence/EventStore/ProcessGitRawStore.js'),
]
const sha = path => createHash('sha256').update(readFileSync(path)).digest('hex')
const before = Object.fromEntries(protectedFiles.map(path => [path, sha(path)]))
let deregister
let capability
let interceptionCount = 0

try {
  writeFileSync(stub, `
let firstWrite;
let output;
let closed = false;
const writes = [];
let signals = 0;
let inputEnded = 0;
const state = () => ({ phase: closed ? 'Closed' : 'Running', exit: null, failure: null, capture: closed ? 'Closed' : 'Open' });
export function inspectProbe() { return { writes: writes.slice(), signals, inputEnded, closed }; }
export function releaseFirstWrite() { if (firstWrite) firstWrite({kind:'Written'}); }
export function completeProbe() { closed = true; if (output) output({kind:'Closed',state:state()}); }
export class SupervisedProcess {
  constructor() {}
  started() { return Promise.resolve({kind:'Started',pid:1}); }
  inspect() { return state(); }
  signal() { signals++; return {kind:'Failed',error:{message:'controlled KILL failure'}}; }
  write(bytes) {
    writes.push(bytes.length);
    if (writes.length === 1) return new Promise(resolve => { firstWrite = resolve; });
    return Promise.resolve({kind:'Written'});
  }
  endInput() { inputEnded++; }
  takeOutput() { return new Promise(resolve => { output = resolve; }); }
  discardOutput() { closed = true; if (output) output({kind:'Discarded'}); }
  wait() { return Promise.resolve({kind:closed?'Closed':'TimedOut',state:state()}); }
}
`)
  if (typeof globalThis.Bun !== 'undefined') {
    capability = await import(pathToFileURL(stub))
    const { mock } = await import('bun:test')
    mock.module('wanxiangli/supervision', () => {
      interceptionCount++
      return { SupervisedProcess: capability.SupervisedProcess }
    })
  } else {
    const module = await import('node:module')
    const hooks = module.registerHooks({
      resolve(specifier, context, next) {
        if (specifier === 'wanxiangli/supervision' && context.parentURL === pathToFileURL(hostPath).href) {
          interceptionCount++
          return { url: pathToFileURL(stub).href, shortCircuit: true }
        }
        return next(specifier, context)
      },
    })
    deregister = () => hooks.deregister()
  }
  capability ??= await import(pathToFileURL(stub))
  const raw = await import(pathToFileURL(join(product, 'dist/Persistence/EventStore/ProcessGitRawStore.js')))
  const list = await import(pathToFileURL(join(product, 'dist/fable_modules/fable-library-js.5.13.0/List.js')))
  assert.ok(interceptionCount > 0, 'The declared capability must be intercepted before any runner call')
  const run = raw.ProcessGitRawStoreModule_createRunner(scratch, 100)
  const pending = run({
    Arguments: list.ofArray(['hash-object', '-w', '--stdin']),
    Input: new Uint8Array(33554449),
    OutputLimit: 65536,
  })
  const start = performance.now()
  while (capability.inspectProbe().writes.length === 0 && performance.now() - start < 3000) await delay(5)
  assert.equal(capability.inspectProbe().writes.length, 1, 'The first physical capability write must be pending')
  let timer
  let receipt
  try {
    receipt = await Promise.race([pending, new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error('Owned deadline must return unconfirmed')), 3000)
    })])
  } finally {
    clearTimeout(timer)
  }
  assert.equal(receipt.tag, 1)
  assert.equal(receipt.fields[0].End.tag, 1)
  assert.equal(receipt.fields[0].StopRequested.tag, 1)
  assert.equal(receipt.fields[0].Output.Complete, false)
  assert.match(receipt.fields[0].Fault, /controlled KILL failure/)
  assert.equal(capability.inspectProbe().signals, 1)
  capability.releaseFirstWrite()
  await delay(25)
  const after = capability.inspectProbe()
  console.log(JSON.stringify({ host: process.execPath, receipt, afterLateWriteReceipt: after, scope: 'Controlled declared supervision capability. The production binary runner and Host input loop are real fixed-package code. No target process, OS signal or native Git operation is claimed.' }))
  assert.deepEqual(after.writes, [16777216], 'A late Written receipt after Unknown must not send the next chunk')
  assert.equal(after.inputEnded, 1)
  for (const [path, digest] of Object.entries(before)) assert.equal(sha(path), digest)
  console.log(JSON.stringify({ success: true, noLaterChunk: true, productionModulesUnchanged: true, sourceDigests: before }))
} finally {
  capability?.completeProbe()
  await delay(5)
  deregister?.()
  rmSync(scratch, { recursive: true, force: true })
  console.log(JSON.stringify({ cleanup: true, scratchRemoved: !existsSync(scratch), noNativeProcessesCreated: true }))
}
