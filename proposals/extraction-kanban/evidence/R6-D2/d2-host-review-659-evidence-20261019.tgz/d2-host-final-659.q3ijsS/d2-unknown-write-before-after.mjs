import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { spawnSync } from 'node:child_process'
import { pathToFileURL } from 'node:url'

const product = resolve(process.argv[2])
const fromProduct = path => import(pathToFileURL(join(product, 'dist', path)))
const raw = await fromProduct('Persistence/EventStore/ProcessGitRawStore.js')
const types = await fromProduct('Persistence/EventStore/GitTypes.js')
const processTypes = await fromProduct('Process/ProcessRequest.js')
const gateway = await fromProduct('Git/Gateway.js')
const deadline = await fromProduct('Process/Deadline.js')
const list = await fromProduct('fable_modules/fable-library-js.5.13.0/List.js')
const { utcNow } = await fromProduct('fable_modules/fable-library-js.5.13.0/DateOffset.js')
const scratch = mkdtempSync('/private/tmp/d2-unknown-write-')
const common = join(scratch, '.git')
const calls = []
let lostReceipt
let actualWrite
let locks = 0
let transportCalls = 0
const line = Buffer.from(JSON.stringify({ event_id: '1'.repeat(40), event_type: 'JobRequested', parents: [], payload: {}, payload_refs: [], stream_id: '2'.repeat(40) }) + '\n')
const digest = bytes => createHash('sha256').update(bytes).digest('hex')
const protectedPaths = ['Persistence/EventStore/ProcessGitRawStore.js', 'Persistence/EventStore/WriterStreamSync.js', 'Git/Gateway.js']
const sourceDigests = () => Object.fromEntries(protectedPaths.map(path => [path, digest(readFileSync(join(product, 'dist', path)))]))
const sourceBefore = sourceDigests()
const nativeGit = (args, input) => {
  const result = spawnSync('git', ['-C', scratch, ...args], { input, maxBuffer: 1048576 })
  assert.ifError(result.error)
  assert.equal(result.signal, null)
  return result
}
const nativeReceipt = result => new types.GitRawResult(1, [new types.GitRawObservation(
  new processTypes.EndEvidence(0, [new processTypes.ProgramEnd(0, [result.status])]),
  undefined,
  new types.GitRawOutput(result.stdout, result.stderr, true),
  undefined,
)])

try {
  const initialized = spawnSync('git', ['init', '--quiet', scratch])
  assert.equal(initialized.status, 0, initialized.stderr.toString())
  const expected = nativeGit(['hash-object', '--stdin'], line)
  assert.equal(expected.status, 0)
  const oid = expected.stdout.toString('ascii').trim()
  assert.match(oid, /^[0-9a-f]{40}$/)
  const loose = join(common, 'objects', oid.slice(0, 2), oid.slice(2))
  assert.equal(existsSync(loose), false)
  const before = nativeGit(['cat-file', 'blob', oid])
  assert.notEqual(before.status, 0)
  const events = join(common, 'wanxiangshu/events')
  mkdirSync(events, { recursive: true })
  const writer = join(events, 'writer-local.ndjson')
  writeFileSync(writer, line)

  const runner = async request => {
    const args = list.toArray(request.Arguments)
    calls.push(args)
    const observed = nativeGit(args, request.Input)
    if (args[0] !== 'hash-object') return nativeReceipt(observed)
    assert.deepEqual(args, ['hash-object', '-w', '--stdin'])
    assert.equal(observed.status, 0, observed.stderr.toString())
    assert.deepEqual(Buffer.from(request.Input), line)
    actualWrite = { status: observed.status, stdout: observed.stdout.toString('base64'), stderr: observed.stderr.toString('base64') }
    lostReceipt = new types.GitRawResult(1, [new types.GitRawObservation(
      new processTypes.EndEvidence(1, []),
      undefined,
      new types.GitRawOutput(observed.stdout, observed.stderr, false),
      'controlled loss of the terminal execution receipt after the native immutable write',
    )])
    return lostReceipt
  }
  const store = raw.ProcessGitRawStoreModule_createWithRunner(scratch, runner)
  const result = await gateway.GitGateway_converge(
    store, common, async () => { transportCalls++; assert.fail('Unknown storage write must stop publication') },
    3, 'origin', undefined,
    async stage => { locks++; return stage() },
    deadline.DeadlineModule_ofBudget(utcNow(), 60000), utcNow,
  )
  assert.equal(result.tag, 1)
  const error = result.fields[0]
  assert.equal(error.cases()[error.tag], 'GitStorage')
  assert.equal(error.fields[0].Result, lostReceipt)
  assert.equal(error.fields[0].Result.fields[0].End.tag, 1)
  assert.equal(error.fields[0].Result.fields[0].Output.Complete, false)
  assert.equal(calls.filter(args => args[0] === 'hash-object').length, 1)
  assert.equal(calls.filter(args => args[0] === 'mktree').length, 0)
  assert.equal(calls.at(-1)[0], 'hash-object')
  assert.equal(locks, 1)
  assert.equal(transportCalls, 0)
  assert.equal(existsSync(join(common, 'wanxiangshu/sync-materialization-cache')), false)
  assert.deepEqual(readFileSync(writer), line)
  assert.equal(existsSync(loose), true)
  const after = nativeGit(['cat-file', 'blob', oid])
  assert.equal(after.status, 0, after.stderr.toString())
  assert.deepEqual(after.stdout, line)
  assert.deepEqual(sourceDigests(), sourceBefore)
  console.log(JSON.stringify({ passed: true, host: process.execPath, oid, expectedSize: line.length, expectedSha256: digest(line), before: { nativeStatus: before.status, stdout: before.stdout.toString('base64'), stderr: before.stderr.toString('base64'), looseFileAbsent: true }, actualWrite, returnedReceipt: { end: 'Unconfirmed', complete: false, rawOutputRetained: true, identityPreserved: true }, after: { nativeStatus: after.status, bytesEqual: true, sha256: digest(after.stdout), looseFilePresent: true }, calls, locks, transportCalls, nextTreeWrites: 0, cacheWritten: false, activeWriterUnchanged: true, productModulesUnchanged: true, sourceDigests: sourceBefore, scope: 'Real fixed-package ProcessGitRawStore, WriterStreamSync and Gateway; real native Git immutable object write with before/after independent OS-process reads. The injected GitRawRunner intentionally withholds the successful native terminal receipt and supplies Unconfirmed. The lock callback is controlled. No actual supervisor loss, network operation or physical lock proof is claimed.' }))
} finally {
  rmSync(scratch, { recursive: true, force: true })
  console.log(JSON.stringify({ cleanup: true, scratchRemoved: !existsSync(scratch) }))
}
