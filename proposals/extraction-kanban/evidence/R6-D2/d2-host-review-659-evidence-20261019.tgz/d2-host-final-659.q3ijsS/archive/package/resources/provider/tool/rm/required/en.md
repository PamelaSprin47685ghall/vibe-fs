rm: path is required
