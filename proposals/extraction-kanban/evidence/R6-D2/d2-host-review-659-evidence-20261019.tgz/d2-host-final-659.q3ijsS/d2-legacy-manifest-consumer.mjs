import assert from 'node:assert/strict'
import { existsSync, mkdirSync, mkdtempSync, readdirSync, rmSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const product = resolve(process.argv[2])
const fromProduct = path => import(pathToFileURL(join(product, 'dist', path)))
const types = await fromProduct('Persistence/EventStore/GitTypes.js')
const sync = await fromProduct('Persistence/EventStore/WriterStreamSync.js')
const list = await fromProduct('fable_modules/fable-library-js.5.13.0/List.js')
const { FSharpResult$2: Result } = await fromProduct('fable_modules/fable-library-js.5.13.0/Result.js')
const ok = value => new Result(0, [value])
const oid = digit => types.GitObjectIdModule_create(digit.repeat(40))
const oidText = types.GitObjectIdModule_value
const snapshot = new types.StoreSnapshot(types.RootOidModule_create(oid('a')))
const scratch = mkdtempSync('/private/tmp/d2-legacy-manifest-')
const now = Date.now()
const writerText = '{"legacy_boundary_probe":true}\n'
const forbidden = async () => assert.fail('This read-only consumer must not write or read refs')
try {
  for (const format of ['no-manifest-entry', 'v1', 'v2']) {
    const common = join(scratch, format, '.git')
    const events = join(common, 'wanxiangshu/events')
    mkdirSync(events, { recursive: true })
    const before = readdirSync(events)
    const calls = []
    const raw = {
      WriteBlob: forbidden,
      WriteTree: forbidden,
      ReadRef: forbidden,
      ReadTree: async requested => {
        calls.push(['ReadTree', oidText(requested)])
        if (oidText(requested) === oidText(oid('a'))) return ok(list.ofArray([
          new types.TreeEntry('40000', 'writers', oid('b')),
          ...(format === 'no-manifest-entry' ? [] : [new types.TreeEntry('100644', 'writer-manifest', oid('c'))]),
        ]))
        assert.equal(oidText(requested), oidText(oid('b')))
        return ok(list.ofArray([new types.TreeEntry('100644', 'writer-remote.ndjson', oid('d'))]))
      },
      ReadObject: async requested => {
        calls.push(['ReadObject', oidText(requested)])
        if (oidText(requested) === oidText(oid('c'))) {
          if (format === 'v1') return ok(Buffer.from('v1\n'))
          assert.equal(format, 'v2')
          const name = Buffer.from('writer-remote.ndjson').toString('base64url')
          return ok(Buffer.from(`v2\n${name}\t${oidText(oid('d'))}\t${now}\n`))
        }
        assert.equal(format, 'v2', 'Old histories without canonical activity metadata must not read/import their writer blob')
        assert.equal(oidText(requested), oidText(oid('d')))
        return ok(Buffer.from(writerText))
      },
    }
    const result = await sync.readRemoteStreamsAt(raw, common, now, snapshot)
    assert.equal(result.tag, 0)
    const writers = list.toArray(result.fields[0])
    assert.equal(writers.length, format === 'v2' ? 1 : 0)
    if (format === 'v2') {
      assert.equal(writers[0].Text, writerText)
      assert.equal(writers[0].LastActivityMs, now)
    }
    assert.deepEqual(readdirSync(events), before)
    console.log(JSON.stringify({ passed: true, host: process.execPath, format, returnedWriters: writers.length, calls, localFilesUnchanged: true, scope: 'Actual compiled WriterStreamSync.readRemoteStreamsAt with controlled typed raw store. Absence of manifest entry and v1 bytes preserve the existing retention boundary: old writers without activity metadata are ignored. The v2 positive proves a current writer is still read. No import, native Git or network proof is claimed.' }))
  }
} finally {
  rmSync(scratch, { recursive: true, force: true })
  console.log(JSON.stringify({ cleanup: true, scratchRemoved: !existsSync(scratch) }))
}
