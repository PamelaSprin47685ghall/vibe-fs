import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { chmodSync, existsSync, readFileSync, readdirSync, rmSync } from 'node:fs'
import { join } from 'node:path'

const root = '/private/tmp/d2-object-native-review.Ry9C1V'
const repo = join(root, 'owned-pack.git')
const git = '/usr/bin/git'
const env = { ...process.env }
for (const name of ['GIT_DIR', 'GIT_WORK_TREE', 'GIT_COMMON_DIR', 'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES']) delete env[name]
const command = (args, input) => {
  const result = spawnSync(git, ['-C', repo, ...args], { input, env, encoding: 'buffer', timeout: 5000 })
  if (result.error) throw result.error
  return { code: result.status, signal: result.signal, stdoutHex: result.stdout.toString('hex'), stdout: result.stdout.toString(), stderr: result.stderr.toString(), stderrHex: result.stderr.toString('hex') }
}
const init = spawnSync(git, ['init', '--bare', '--quiet', repo], { env, encoding: 'utf8' })
assert.equal(init.status, 0, init.stderr)
const oid = command(['hash-object', '-w', '--stdin'], Buffer.from('owned-packed-object\n')).stdout.trim()
assert.equal(command(['update-ref', 'refs/wanxiang/probe', oid]).code, 0)
assert.equal(command(['repack', '-a', '-d']).code, 0)
assert.equal(existsSync(join(repo, 'objects', oid.slice(0, 2), oid.slice(2))), false)
const packDir = join(repo, 'objects', 'pack')
const names = readdirSync(packDir)
const pack = join(packDir, names.find(name => name.endsWith('.pack')))
const index = join(packDir, names.find(name => name.endsWith('.idx')))
assert.ok(existsSync(pack) && existsSync(index))
const attempts = []
const controls = []
const failure = operation => {
  try { operation(); return 'READABLE' }
  catch (error) { return error.code }
}
const methods = [
  ['batch-check', tip => [['cat-file', '--batch-check'], Buffer.from(`${tip}\n`)]],
  ['batch', tip => [['cat-file', '--batch'], Buffer.from(`${tip}\n`)]],
  ['type', tip => [['cat-file', '-t', tip], undefined]],
  ['body', tip => [['cat-file', 'blob', tip], undefined]],
]
const sample = (name, tip = oid) => {
  for (const [method, args] of methods) {
    const [argv, input] = args(tip)
    attempts.push({ name, oid: tip, method, ...command(argv, input) })
  }
}
const deny = (name, path, mode, restore, operation, target = oid) => {
  chmodSync(path, mode)
  try {
    const actual = failure(operation)
    assert.equal(actual, 'EACCES')
    controls.push({ name, actual })
    sample(name, target)
  } finally { chmodSync(path, restore) }
}
try {
  sample('packed-existing')
  deny('pack-file-EACCES', pack, 0, 0o600, () => readFileSync(pack))
  deny('pack-index-EACCES', index, 0, 0o600, () => readFileSync(index))
  deny('pack-directory-EACCES', packDir, 0, 0o700, () => readFileSync(pack))
  deny('pack-directory-cannot-enumerate', packDir, 0o111, 0o700, () => readdirSync(packDir))
  deny('pack-directory-cannot-enumerate-missing', packDir, 0o111, 0o700, () => readdirSync(packDir), 'a'.repeat(40))
  sample('packed-restored')
  console.log(JSON.stringify({ git: spawnSync(git, ['--version'], { encoding: 'utf8' }).stdout.trim(), oid, controls, attempts }, null, 2))
} finally {
  chmodSync(packDir, 0o700)
  chmodSync(pack, 0o600)
  chmodSync(index, 0o600)
  rmSync(repo, { recursive: true, force: true })
}
