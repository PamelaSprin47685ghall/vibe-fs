# D2 object lookup native Git review

**Follow-up counterexample:** the packed-object experiment below disproves that a complete normal `missing` record plus empty stderr can confirm physical object absence. The earlier loose-object findings remain valid but are insufficient as a general missing predicate. The earlier loose-only archive is preserved under its original SHA.

Command: `node probe.mjs > native.log 2>&1`; exit 0. Runtime Node v26.6.0, macOS UID 501, `/usr/bin/git` version `2.50.1 (Apple Git-155)`. Eleven fixtures × five methods produce 55 native lookup commands, separately from setup. Four direct file reads assert actual EACCES before the corresponding Git observations. The owned bare repository was removed after restoring permissions.

## Native results

| Fixture | batch-check / batch | stderr | cat-file -t / -s / blob |
|---|---|---|---|
| Valid object | 0, metadata / exact body | empty | 0, correct value/body |
| Truly missing object | 0, exact `<oid> missing` | empty | 128, diagnostic |
| Loose object file EACCES | 0, exact `<oid> missing` | Permission denied | 128, diagnostic |
| Parent directory EACCES, existing or absent child | 0, exact `<oid> missing` | Permission denied | 128, diagnostic |
| Entire objects directory EACCES | 128 | not a git repository | 128, diagnostic |
| Invalid zlib stream | 0, exact `<oid> missing` | inflate/unpack error | 128, diagnostic |
| Valid zlib, invalid object header | 0, exact `<oid> missing` | parse-header error | 128, diagnostic |
| Truncated zlib after readable header | batch-check 0 metadata; batch 128 | batch-check empty; batch unable to stream | type/size 0; body 128 |
| Header declares blob 99, actual body `short` | 0 metadata; batch 0 with short body | empty | type/size/body all 0; actual body 5 bytes |
| Restored original object | 0, correct metadata/body | empty | 0, correct value/body |

The log preserves stdout and stderr as both display text and exact hex. The valid blob contains non-UTF8 and NUL bytes; comparison must use hex/bytes, not the display string.

No tested permission/corrupt-header fixture returned `0 + missing + empty stderr`. This is bounded evidence for these native cases, not a proof for every Git backend or every I/O failure. A missing metadata result must require complete output and an empty stderr as well as the exact native missing record; otherwise the current wrapper converts a reported failure into None. Permission and corruption diagnostics must remain the original Result bytes and survive to a bounded user diagnostic.

Normal exit 0 alone also does not prove complete object contents: the synthetic valid-zlib/short-body case returns code 0 and no stderr, but metadata says 99 while the body contains 5 bytes. The candidate's metadata/body length check must reject it. A successful metadata query can precede a failed body read; that second failure must stop the operation and must not become missing or trigger alternate reads/writes.

This review did not run or modify the new RawStore candidate. The fixed657 formal test's reported `Ok None` is consistent with the native behavior, but this archive alone does not claim a wrapper fix or final D2 completion.

## Packed-object counterexample

`node pack-probe.mjs > pack.log 2>&1` exited 0 on the same native Git. A blob was written, referenced in an owned bare repository and packed with native `git repack -a -d`; the probe asserts that its loose object no longer exists. The original and restored packed read both return the same object and bytes. Seven fixtures × four native lookup methods produce 28 additional commands, with five direct filesystem EACCES controls. All permission modes were restored and the owned repository deleted.

| Packed fixture | batch-check / batch | stderr | cat-file -t / blob |
|---|---|---|---|
| Valid existing object | 0, correct metadata/body | empty | 0, correct output |
| `.pack` file EACCES | **0, `<existing oid> missing`** | **empty** | 128, generic missing diagnostic |
| `.idx` file EACCES | **0, `<existing oid> missing`** | **empty** | 128, generic missing diagnostic |
| Pack directory EACCES | 0, missing | unable to open pack directory | 128, diagnostic |
| Pack directory searchable but not enumerable | 0, missing | unable to open pack directory | 128, diagnostic |
| Same inaccessible pack directory, truly absent requested OID | 0, missing | unable to open pack directory | 128, diagnostic |
| Restored object | 0, correct metadata/body | empty | 0, correct output |

The `.pack` and `.idx` controls are an indistinguishability counterexample: object lookup via `cat-file` cannot by itself prove physical nonexistence. Another call to `-t` or `blob` does not fix this; its generic code 128 and message also occur for true absence. An stderr-empty guard remains useful for loose errors but cannot close the general obligation.

The simplest proposed boundary is to inspect all consumers and remove normal `None` from object/tree reads if they only request already-referenced OIDs. Return a storage error when Git does not provide the object, retain the normal native receipt exactly, and do not infer `StorageInvalid` or rewrite the physical exit as Unknown. Ref lookup can keep its separate, errno-aware `show-ref --exists` absence protocol. This proposal needs owner approval, consumer review and updated formal acceptance; no source was changed here.
