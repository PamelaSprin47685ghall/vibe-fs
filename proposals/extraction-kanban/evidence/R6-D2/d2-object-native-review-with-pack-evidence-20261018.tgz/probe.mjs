import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { chmodSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { deflateSync } from 'node:zlib'

const root = '/private/tmp/d2-object-native-review.Ry9C1V'
const repo = join(root, 'owned.git')
const git = '/usr/bin/git'
const env = { ...process.env }
for (const name of ['GIT_DIR', 'GIT_WORK_TREE', 'GIT_COMMON_DIR', 'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES']) delete env[name]
const command = (args, input) => {
  const result = spawnSync(git, ['-C', repo, ...args], { input, env, encoding: 'buffer', timeout: 5000 })
  if (result.error) throw result.error
  return { code: result.status, signal: result.signal, stdout: result.stdout.toString(), stdoutHex: result.stdout.toString('hex'), stderr: result.stderr.toString(), stderrHex: result.stderr.toString('hex') }
}
const init = spawnSync(git, ['init', '--bare', '--quiet', repo], { env, encoding: 'utf8' })
assert.equal(init.status, 0, init.stderr)
const content = Buffer.from([0, 255, 1, 128, 10, 65])
const written = command(['hash-object', '-w', '--stdin'], content)
assert.equal(written.code, 0)
const oid = written.stdout.trim()
assert.match(oid, /^[0-9a-f]{40}$/)
const objects = join(repo, 'objects')
const directory = join(objects, oid.slice(0, 2))
const object = join(directory, oid.slice(2))
const compressed = readFileSync(object)
const missing = `${oid.slice(0, 2)}${'a'.repeat(38)}`
assert.notEqual(missing, oid)
const methods = [
  ['batch-check', tip => [['cat-file', '--batch-check'], Buffer.from(`${tip}\n`)]],
  ['batch', tip => [['cat-file', '--batch'], Buffer.from(`${tip}\n`)]],
  ['type', tip => [['cat-file', '-t', tip], undefined]],
  ['size', tip => [['cat-file', '-s', tip], undefined]],
  ['body', tip => [['cat-file', 'blob', tip], undefined]],
]
const attempts = []
const controls = []
const readFailure = path => {
  try { readFileSync(path); return 'READABLE' }
  catch (error) { return error.code }
}
const sample = (name, tip = oid, control) => {
  if (control) {
    assert.equal(control.actual, control.expected)
    controls.push({ name, ...control })
  }
  for (const [method, args] of methods) {
    const [argv, input] = args(tip)
    attempts.push({ name, oid: tip, method, ...command(argv, input) })
  }
}
try {
  sample('valid-existing')
  sample('valid-missing', missing)
  chmodSync(object, 0)
  try { sample('object-file-EACCES', oid, { actual: readFailure(object), expected: 'EACCES' }) }
  finally { chmodSync(object, 0o600) }
  chmodSync(directory, 0)
  try {
    sample('object-parent-EACCES-existing', oid, { actual: readFailure(object), expected: 'EACCES' })
    sample('object-parent-EACCES-missing', missing, { actual: readFailure(join(directory, missing.slice(2))), expected: 'EACCES' })
  } finally { chmodSync(directory, 0o700) }
  chmodSync(objects, 0)
  try { sample('objects-root-EACCES', oid, { actual: readFailure(object), expected: 'EACCES' }) }
  finally { chmodSync(objects, 0o700) }
  writeFileSync(object, Buffer.from('not-a-zlib-stream'))
  sample('corrupt-zlib')
  writeFileSync(object, compressed.subarray(0, compressed.length - 3))
  sample('truncated-zlib')
  writeFileSync(object, deflateSync(Buffer.from('nonsense-object-header\0body')))
  sample('valid-zlib-invalid-object-header')
  writeFileSync(object, deflateSync(Buffer.from('blob 99\0short')))
  sample('valid-zlib-short-object-body')
  writeFileSync(object, compressed)
  sample('restored-existing')
  console.log(JSON.stringify({ git: spawnSync(git, ['--version'], { encoding: 'utf8' }).stdout.trim(), uid: process.getuid(), oid, contentHex: content.toString('hex'), controls, attempts }, null, 2))
} finally {
  chmodSync(objects, 0o700)
  chmodSync(directory, 0o700)
  chmodSync(object, 0o600)
  rmSync(repo, { recursive: true, force: true })
}
