import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'

const modules = [
  'Persistence/EventStore/GitTypes',
  'Persistence/EventStore/ProcessGitRawStore',
  'Persistence/EventStore/GitRawSurface',
  'Persistence/EventStore/WriterStreamSync',
  'Persistence/EventStore/RetentionSurface',
  'Git/Gateway',
  'Git/Hook/Sync',
  'Process/ProcessRunner',
  'Process/NodeProcessHost',
]
const digest = file => createHash('sha256').update(readFileSync(file)).digest('hex')
const [mode, reference, sourceRoot, packageRoot] = process.argv.slice(2)
assert.ok(mode === 'snapshot' || mode === 'compare')
const current = modules.map(name => ({
  name,
  source: { path: `src/Wanxiangshu/${name}.fs`, sha256: digest(join(sourceRoot, `src/Wanxiangshu/${name}.fs`)) },
  signature: { path: `src/Wanxiangshu/${name}.fsi`, sha256: digest(join(sourceRoot, `src/Wanxiangshu/${name}.fsi`)) },
  artifact: { path: `dist/${name}.js`, sha256: digest(join(packageRoot, `dist/${name}.js`)) },
}))
if (mode === 'snapshot') {
  writeFileSync(reference, JSON.stringify({ sourceRoot: resolve(sourceRoot), installed661: resolve(packageRoot), modules: current,
    scope: '661 artifact hashes and a separately recorded current source/signature snapshot. This mapping alone does not retrospectively prove which exact source bytes compiled the 661 archive. No shared source is modified.' }, null, 2) + '\n')
} else {
  const baseline = JSON.parse(readFileSync(reference, 'utf8'))
  const differences = []
  for (const row of current) {
    const original = baseline.modules.find(candidate => candidate.name === row.name)
    assert.ok(original)
    for (const part of ['source', 'signature', 'artifact']) {
      if (row[part].sha256 !== original[part].sha256) differences.push({ name: row.name, part, baseline: original[part], current: row[part] })
    }
  }
  console.log(JSON.stringify({ unchanged: differences.length === 0, comparedModules: modules.length, differences,
    scope: 'Only the listed D2 source/signature and main JS files. Nested library bytes and whole-product correctness require separate evidence.' }, null, 2))
  if (differences.length) process.exitCode = 1
}
