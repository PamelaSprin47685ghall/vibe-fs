import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { spawnSync } from 'node:child_process'
import { existsSync, mkdtempSync, readFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const product = resolve(process.argv[2])
const archive = resolve(process.argv[3])
const raw = join(product, 'dist/Persistence/EventStore/ProcessGitRawStore.js')
const surface = join(product, 'dist/Persistence/EventStore/GitRawSurface.js')
const digest = path => createHash('sha256').update(readFileSync(path)).digest('hex')
const fixed = Object.fromEntries([archive, raw, surface].map(path => [path, digest(path)]))
const { create, createWithRunner } = await import(pathToFileURL(surface))
const tree = 'a'.repeat(40)
const blob = 'b'.repeat(40)
const valid = Buffer.from(`100644 blob ${blob}\tleaf\0`)
const observed = stdout => ({ kind: 'Observed', ending: { kind: 'Exited', exitCode: 0 },
  stopRequested: null, output: { stdout, stderr: Buffer.alloc(0), complete: true }, fault: null })
const cases = [
  ['invalid UTF-8', Buffer.concat([Buffer.from(`100644 blob ${blob}\t`), Buffer.from([255, 0])]), 32],
  ['missing final NUL', valid.subarray(0, valid.length - 1), 32],
  ['duplicate names', Buffer.concat([valid, valid]), 64],
  ['mode and type mismatch', Buffer.from(`100644 tree ${blob}\tleaf\0`), 32],
  ['unsupported gitlink mode', Buffer.from(`160000 commit ${blob}\tleaf\0`), 32],
  ['extra header field', Buffer.from(`100644 blob ${blob} extra\tleaf\0`), 32],
  ['slash in a direct tree name', Buffer.from(`100644 blob ${blob}\tnested/leaf\0`), 32],
  ['empty output for nonempty metadata', Buffer.alloc(0), 32],
  ['nonempty output for empty metadata', valid, 0],
]
const passed = []
const ok = result => { assert.equal(result.ok, true, result.error?.description); return result.value }

for (const [name, invalid, invalidSize] of cases) {
  let repaired = false
  const calls = []
  const store = createWithRunner('/unused', async request => {
    calls.push(request.arguments)
    if (request.arguments.includes('--batch-check')) {
      return observed(Buffer.from(`${tree} tree ${repaired ? 32 : invalidSize}\n`))
    }
    assert.ok(request.arguments.includes('ls-tree'))
    return observed(repaired ? valid : invalid)
  })
  const result = await store.readTree(tree)
  assert.equal(result.ok, false, name)
  assert.equal(result.error.result.ending.exitCode, 0)
  assert.equal(result.error.result.output.complete, true)
  assert.deepEqual(Buffer.from(result.error.result.output.stdout), invalid)
  assert.equal(result.error.result.fault, null)
  assert.equal(calls.length, 2)
  repaired = true
  const entries = ok(await store.readTree(tree))
  assert.deepEqual(entries, [{ mode: '100644', name: 'leaf', oid: blob }])
  assert.equal(calls.length, 4, 'Rejected tree must not poison or populate the cache')
  entries[0].name = 'caller-mutation'
  assert.equal(ok(await store.readTree(tree))[0].name, 'leaf')
  assert.equal(calls.length, 4)
  passed.push(name)
}

const owned = mkdtempSync(join(tmpdir(), 'd2-tree-protocol-'))
try {
  const env = { ...process.env, GIT_CONFIG_GLOBAL: '/dev/null', GIT_CONFIG_SYSTEM: '/dev/null' }
  for (const name of ['GIT_DIR', 'GIT_WORK_TREE', 'GIT_COMMON_DIR', 'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES']) delete env[name]
  const native = (args, input) => {
    const result = spawnSync('/usr/bin/git', ['-C', owned, ...args], { input, env, encoding: 'buffer', timeout: 5000 })
    if (result.error) throw result.error
    assert.equal(result.status, 0, result.stderr.toString())
    return result.stdout
  }
  native(['init', '--bare', '--quiet'])
  const store = create(owned)
  const blobOid = ok(await store.writeBlob(Buffer.from([0, 255, 128, 10])))
  const emptyTree = ok(await store.writeTree([]))
  const input = [
    { mode: '100644', name: '\u{10000}', oid: blobOid },
    { mode: '100644', name: '\ue000', oid: blobOid },
    { mode: '100644', name: 'with\ttab', oid: blobOid },
    { mode: '100644', name: '\ufeffbom', oid: blobOid },
    { mode: '040000', name: 'folder', oid: emptyTree },
    { mode: '100755', name: 'folder.', oid: blobOid },
    { mode: '120000', name: 'link', oid: blobOid },
  ]
  const oid = ok(await store.writeTree(input))
  const bytes = native(['ls-tree', '--full-tree', '-z', oid])
  const expected = bytes.toString('utf8').split('\0').filter(Boolean).map(row => {
    const tab = row.indexOf('\t')
    const [mode, , entryOid] = row.slice(0, tab).split(' ')
    return { mode: mode === '040000' ? '40000' : mode, name: row.slice(tab + 1), oid: entryOid }
  })
  const cold = ok(await create(owned).readTree(oid))
  assert.deepEqual(cold, expected)
  assert.ok(cold.findIndex(entry => entry.name === '\ue000') < cold.findIndex(entry => entry.name === '\u{10000}'))
  assert.ok(cold.findIndex(entry => entry.name === 'folder.') < cold.findIndex(entry => entry.name === 'folder'))
  assert.deepEqual(new Set(cold.map(entry => entry.mode)), new Set(['100644', '100755', '120000', '40000']))
  passed.push('real Git cold tree: four modes, UTF-8 byte order, BOM, tab, directory ordering')
  for (const [path, expectedDigest] of Object.entries(fixed)) assert.equal(digest(path), expectedDigest)
  console.log(JSON.stringify({ runtime: process.versions.bun ? `Bun ${process.versions.bun}` : process.version,
    product, fixed, passedGroups: passed, coldTree: cold,
    scope: 'Independent installed-package tree protocol and native cold read. No exact physical loose-container integrity or complete requirement-suite claim.' }, null, 2))
} finally {
  rmSync(owned, { recursive: true, force: true })
  console.log(JSON.stringify({ ownedTemporaryRepositoryRootRemoved: !existsSync(owned) }))
}
