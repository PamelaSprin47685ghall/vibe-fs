# D2 candidate 663 independent review

This directory contains a non-author, read-only review of the main package and the Worker input pump. No shared source, test, plan, or Git state was changed by this reviewer.

## Fixed inputs

- Main package 663: `wanxiangshu-0.9.0-663.tgz`, SHA256 `3c0afec4f5aee947cff92a5a2e633a41d4e9728daa515f27295e634ed9b324e0`.
- Library: `wanxiangli-0.6.12.tgz`, SHA256 `a039ba669299c6919776196fd9b462624bcbe515d03593804596dbc86f43ac56`.
- Actual main install: `/private/tmp/d2-clean-install-663/node_modules/wanxiangshu`. The probes imported this install. Its nested `node_modules/wanxiangli` is the actual runtime dependency.
- Runtime: Node 26.6.0 and Bun 1.3.14, macOS.

## Results and scope

`node-raw.log` and `bun-raw.log`: the original 11 groups passed on both runtimes. They cover original native zero-exit missing receipts, no retry or fallback, short body refusal and cache repair, empty blob/tree, loose EACCES, corrupt/truncated zlib, packed .pack/.idx EACCES, and actual standalone reference-transaction Hook cold failure followed by recovery. Hook failures made no later hash-object/mktree/push/fetch call and no materialized event/cache publication.

`node-tree.log` and `bun-tree.log`: 10 groups passed on both runtimes. Nine invalid tree-output receipts retain their exact native zero receipt and bytes, reject the full read, do not fill the cache, and succeed after a later repaired request. The real Git cold read covers all four supported modes, UTF-8 order (U+E000/U+10000), BOM, tab, and directory ordering.

These are installed-package backend and real Hook boundary checks. They are not the main 19-case formal suite, a 32 MiB + 17-byte transfer reproduction, a full convergence matrix, or proof for every platform. The root and the other independent reviewer own those separate receipts.

## Product and source mapping

`artifact-map.json`: all 2054 main-package files were compared between the actual 661 and 663 installs, excluding nested node_modules. Only package.json differs. Thus the main compiled Git/storage implementation did not change in this transition. All 22 unpacked files in the fixed 0.6.12 archive equal the actual nested library install, with no difference.

`main-661-to-663-map.json`: nine D2 modules have unchanged compiled JS and unchanged current FS/FSI bytes against the separately recorded prior source snapshot. The source snapshot was taken after 661 was built; this comparison does not retrospectively prove its compiler input. The root owns build-input closure. `main-661-baseline.json` names every mapped source, signature, and artifact hash.

## Pump review

The reviewed source snapshots are included. Static review found no new defect in the supported source/target stream boundary:

- pending is set before source.read, so a synchronous readable callback cannot enter another read. The stopped check after read prevents bytes returned after a synchronous source error from reaching the target.
- An acknowledged write permits the next read. end received during a pending write only records a fact. target.end is reached only after that acknowledgement and a null read with a true source end fact.
- A source close does not become EOF. A source error stops and reports the source fault. Target write rejection stops and detaches forwarding; it does not destroy borrowed stdin or replace the target's native exit/output.
- Every pump-owned listener is removed at stop. The Worker has one separate, intentionally retained source-error listener for the borrowed stream's full lifetime. A late target callback checks stopped before it can read or end.
- A close observed while a target write is pending is recorded; the premature-close fault is considered after the callback permits another read. This review did not establish a correctness defect in that delay. It does not invent EOF, a successful acknowledgement, or automatic retransmission. External supervision still owns finite process termination.

`writable-callback-order.mjs` independently checks the actual node:stream Writable scheduling used by the private target adapter. On each runtime, 10000 synchronous _write acknowledgements had deferred public callbacks and maximum stack depth 1. A held acknowledgement after target destruction settled once. This rules out the proposed unbounded synchronous callback recursion for this real Writable boundary; it is not a test of an arbitrary object that can violate the Writable contract, nor an installed forwardInput acceptance. The tests reviewer separately owns controlled source read/end/error and actual Worker callback-gate receipts.

## Failure attribution retained

The earlier 661/662 formal Bun test lost the last 17 bytes of a 32 MiB + 17-byte input. The root reported the 662 failure after the 0.6.11 acknowledgement barrier. Those original red receipts must remain in the root's formal evidence and cannot be replaced by the small green callback tests. This reviewer did not rerun or alter those red logs here.

The 0.6.11 setImmediate barrier has a separate, locally proved non-reentry boundary. It did not close the physical tail-loss issue. The 0.6.12 Worker change removes the async iterator whose done state was observed with buffered bytes. Its actual large-transfer acceptance belongs to the separate fixed-663 formal receipts. The Host reviewer participated in the pump prototype; this agent and the tests reviewer are the non-authors.

The prior native tree-header and raw-mode reconstruction hypotheses were falsified and remain in `d2-tree-header-review-evidence-20261019.tgz` (SHA256 `5990cf146da57d52392ccc4175af4c54885f4817a13a78e7b463e92b855c9bc5`). No raw-size reconstruction or second object database was added.

No performance benchmark was repeated for 663. The fixed-660 real Hook Trace2 measurements remain evidence of a substantial Git-plumbing latency cost. No claim of no performance regression is made.

R12-U1 was not investigated or changed. This partial review does not mark all D2 or all extraction work complete.

## Reproduction

Run `node` or `bun` with `probe.mjs <installed-main-root> <main-tgz>` and `tree-protocol.mjs <installed-main-root> <main-tgz>`. Each probe owns and removes its temporary repositories; final log receipts confirm removal. Real supervision needs the process-inspection permissions required by the installed package.

`artifact-map.mjs` uses the recorded absolute installs and unpacked library directory. `main-map.mjs compare main-661-baseline.json <source-root> <installed-main-root>` checks the nine recorded modules. `writable-callback-order.mjs` needs only the selected runtime.
