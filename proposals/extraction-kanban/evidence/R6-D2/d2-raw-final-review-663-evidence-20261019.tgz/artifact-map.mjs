import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { lstatSync, readdirSync, readFileSync, readlinkSync } from 'node:fs'
import { join, relative } from 'node:path'

const hash = file => createHash('sha256').update(readFileSync(file)).digest('hex')
const inventory = root => {
  const files = new Map()
  const walk = directory => {
    for (const name of readdirSync(directory).sort()) {
      if (name === 'node_modules') continue
      const file = join(directory, name)
      const info = lstatSync(file)
      if (info.isDirectory()) walk(file)
      else if (info.isSymbolicLink()) files.set(relative(root, file), { symlink: readlinkSync(file) })
      else files.set(relative(root, file), { size: info.size, sha256: hash(file) })
    }
  }
  walk(root)
  return files
}
const compare = (left, right) => {
  const before = inventory(left)
  const after = inventory(right)
  const differences = []
  for (const name of [...new Set([...before.keys(), ...after.keys()])].sort()) {
    if (JSON.stringify(before.get(name)) !== JSON.stringify(after.get(name))) {
      differences.push({ name, before: before.get(name) ?? null, after: after.get(name) ?? null })
    }
  }
  return { beforeCount: before.size, afterCount: after.size, differences }
}
const main661 = '/private/tmp/d2-clean-install-661/node_modules/wanxiangshu'
const main663 = '/private/tmp/d2-clean-install-663/node_modules/wanxiangshu'
const main = compare(main661, main663)
assert.ok(main.differences.every(row => row.name === 'package.json'), 'Only package dependency metadata may differ in the main archive')
const library = compare('/private/tmp/d2-raw-final-663.RSrD5a/library-0612-unpacked/package', join(main663, 'node_modules/wanxiangli'))
assert.deepEqual(library.differences, [])
const archives = Object.fromEntries([
  '/private/tmp/d2-candidate-661/wanxiangshu-0.9.0.tgz',
  '/private/tmp/d2-candidate-663/wanxiangshu-0.9.0.tgz',
  '/private/tmp/d2-library-0612/wanxiangli-0.6.12.tgz',
].map(file => [file, hash(file)]))
console.log(JSON.stringify({ archives, main, library,
  scope: 'Every regular file and symlink of both installed main packages, excluding node_modules, is compared. Every unpacked library archive file is compared with the nested library actually used by main663. Separate source/signature map covers only the nine recorded modules.' }, null, 2))
