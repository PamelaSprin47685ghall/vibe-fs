import assert from 'node:assert/strict'
import { Writable } from 'node:stream'

const records = []
let depth = 0
let maxDepth = 0
let writing = false
let callbacks = 0
const sink = new Writable({
  write(bytes, _encoding, callback) {
    assert.equal(bytes.length, 1)
    depth++
    maxDepth = Math.max(maxDepth, depth)
    callback()
    depth--
  },
})
const count = 10000
await new Promise((resolve, reject) => {
  sink.on('error', reject)
  const send = () => {
    writing = true
    sink.write(Buffer.from([callbacks % 251]), error => {
      if (error) return reject(error)
      assert.equal(writing, false, 'A synchronous _write acknowledgement must not reenter its caller')
      callbacks++
      if (callbacks === count) sink.end(resolve)
      else send()
    })
    writing = false
  }
  send()
})
assert.equal(callbacks, count)
assert.equal(maxDepth, 1)
records.push({ name: 'real Writable synchronous _write callback is deferred', count, maxDepth })

let release
let callbackCount = 0
const pending = new Writable({ write(_bytes, _encoding, callback) { release = callback } })
pending.on('error', () => {})
pending.write(Buffer.from('held'), () => { callbackCount++ })
pending.destroy(Object.assign(new Error('controlled target rejection'), { code: 'CONTROLLED_REJECTION' }))
await new Promise(resolve => setImmediate(resolve))
const beforeRelease = callbackCount
release()
await new Promise(resolve => setImmediate(resolve))
assert.equal(callbackCount, 1)
records.push({ name: 'held write callback can arrive after target destruction but settles once', beforeRelease, afterRelease: callbackCount })

console.log(JSON.stringify({ runtime: process.versions.bun ? `Bun ${process.versions.bun}` : process.version,
  records, scope: 'Actual node:stream Writable scheduling only. This is not an installed forwardInput acceptance or a physical tail-loss reproduction.' }, null, 2))
