import assert from 'node:assert/strict'
import { drainMicrotasks } from 'bun:jsc'

const cases = []

function createBridge(mode, trace, sink) {
  let pendingWrite
  const write = bytes => new Promise(resolve => {
    let completed = false
    const complete = error => {
      if (completed) return
      completed = true
      pendingWrite = undefined
      trace.push({ event: 'public-receipt', kind: error ? 'Unknown' : 'Written', error: error?.message ?? null })
      resolve(error ? { kind: 'Unknown' } : { kind: 'Written' })
    }
    pendingWrite = complete
    Promise.resolve().then(() => sink.write(bytes)).then(async () => {
      await sink.flush()
      if (mode === 'immediate') setImmediate(() => complete())
      else if (mode === 'microtask') queueMicrotask(() => complete())
      else if (mode === 'early-mark-immediate') {
        if (completed) return
        completed = true
        pendingWrite = undefined
        setImmediate(() => {
          trace.push({ event: 'public-receipt', kind: 'Written', error: null })
          resolve({ kind: 'Written' })
        })
      } else complete()
    }).catch(complete)
  })
  return { write, fail: error => pendingWrite?.(error), pending: () => typeof pendingWrite === 'function' }
}

for (const mode of ['direct', 'microtask', 'immediate']) {
  let nativeCallbackActive = false
  let resolveFlush
  let flushes = 0
  const trace = []
  const sink = {
    write(bytes) { trace.push({ event: 'native-write', size: bytes.length, nativeCallbackActive }); return bytes.length },
    flush() { return ++flushes === 1 ? new Promise(resolve => { resolveFlush = resolve }) : undefined },
    end() { trace.push({ event: 'native-end', nativeCallbackActive }) },
  }
  const bridge = createBridge(mode, trace, sink)
  const consumer = (async () => {
    assert.equal((await bridge.write(Buffer.alloc(32))).kind, 'Written')
    assert.equal((await bridge.write(Buffer.alloc(17))).kind, 'Written')
    sink.end()
  })()
  drainMicrotasks()
  assert.equal(typeof resolveFlush, 'function')
  nativeCallbackActive = true
  trace.push({ event: 'native-callback-enter' })
  resolveFlush()
  drainMicrotasks()
  nativeCallbackActive = false
  trace.push({ event: 'native-callback-return' })
  await consumer
  const tail = trace.find(item => item.event === 'native-write' && item.size === 17)
  const end = trace.find(item => item.event === 'native-end')
  assert.equal(tail.nativeCallbackActive, mode !== 'immediate')
  assert.equal(end.nativeCallbackActive, mode !== 'immediate')
  cases.push({ mode, trace, tailReentered: tail.nativeCallbackActive, endReentered: end.nativeCallbackActive })
}

for (const mode of ['early-mark-immediate', 'immediate']) {
  const trace = []
  let resolveFlush
  const bridge = createBridge(mode, trace, {
    write(bytes) { return bytes.length },
    flush() { return new Promise(resolve => { resolveFlush = resolve }) },
  })
  const result = bridge.write(Buffer.alloc(17))
  drainMicrotasks()
  resolveFlush()
  drainMicrotasks()
  const pendingBeforeExit = bridge.pending()
  bridge.fail(new Error('Process exited before public acknowledgement'))
  const receipt = await result
  await new Promise(setImmediate)
  assert.equal(receipt.kind, mode === 'immediate' ? 'Unknown' : 'Written')
  assert.equal(trace.filter(item => item.event === 'public-receipt').length, 1)
  cases.push({ mode, case: 'exit after native flush but before deferred publication', pendingBeforeExit, receipt, trace })
}

{
  const trace = []
  const bridge = createBridge('immediate', trace, {
    write() { throw new Error('EPIPE') },
    flush() { throw new Error('Unexpected flush') },
  })
  let received = false
  const result = bridge.write(Buffer.alloc(17)).then(receipt => { received = true; return receipt })
  drainMicrotasks()
  assert.equal(received, true)
  assert.equal((await result).kind, 'Unknown')
  assert.equal(bridge.pending(), false)
  cases.push({ mode: 'immediate', case: 'write error remains immediate in current checkpoint', trace })
}

console.log(JSON.stringify({ runtime: Bun.version, revision: Bun.revision, cases,
  scope: 'Real installed Bun microtask draining and setImmediate scheduling, with a controlled native-callback marker and fake sink. It proves callback-order and late-success arbitration only. It neither executes FileSink native onWrite nor reproduces the physical 17-byte loss, and does not identify the binary root cause.' }, null, 2))
