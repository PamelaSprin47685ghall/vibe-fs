# D2 stdin 成功回执非重入边界：独立设计复审

结论：把成功回执放到 `setImmediate`，是一项能说明顺序保证的窄边界修正，可以进入候选验证；它不是已经确认原 17 字节丢失根因的证明。现在不建议把 FIFO 原型接入生产：单跳成功，真实双跳仍有有界失败。整体 D2 继续被原红证据阻断。

本代理只读共享源码；只在此私有目录写原型、日志和说明，没有实施生产修改，也没有重复大输入压力测试。

## 事实与推断

当前 Bun 私有 stdin 桥等待 FileSink write 和 flush 后，在 Promise continuation 中直接 `complete()`。调用者的下一次 write/end 因而可能仍发生在同一个原生回调推进的微任务 checkpoint 内。串行写泵只能保证调用顺序，不能证明已离开原生 drain 回调。

主代理取得的公开同版本 FileSink 源码固定为 `public-tag-1.3.14-FileSink.zig`，SHA-256 `f7d84459278f99753f6f406b1355795e3c406c1f44f41308b8ab86266bb31f1e`。其 onWrite 在推进 runPending 前取得 pending/status，runPending 可推进 JS 微任务，回来后仍按旧 drained 状态及 done 决定结束 writer。flushFromJS 在 pending 时可返回同一个 Promise。这说明一个可信的重入危险类别。当前 main 的实现也有重新读取缓冲状态以防该类问题的说明。[官方 main FileSink](https://github.com/oven-sh/bun/blob/main/src/runtime/webcore/FileSink.rs)

这份公开 tag 文件不是本机 `1.3.14+d1632b2918dfa83f43686946325bcc9cceab6594` 二进制的精确源码证明。不能据此声称原 17 字节失败已确认与某一上游修复同因。main 的事件循环实现把 immediate 与微任务队列分开，可支持这项顺序选择；仍需本机原型与实际交付验证。[官方事件循环实现](https://github.com/oven-sh/bun/blob/main/src/jsc/event_loop.rs)

## 六个小反例的实际结果

`checkpoint.mjs` 在上述实际 Bun revision 上使用 `bun:jsc.drainMicrotasks()`，以一个受控的“原生回调尚未返回”标记检查调度顺序。sink 是受控替身；它不执行真正 FileSink.onWrite，也不制造或复现原来的物理丢尾故障。

| 情况 | 实际结果 |
|---|---|
| 直接成功 complete | 下一次 17 字节 write 与 end 都在标记仍 active 时发生 |
| queueMicrotask 后成功 | 仍在同一 checkpoint 重入，不能形成所需边界 |
| setImmediate 后 complete | 两者都发生在回调 return 之后 |
| 先 completed=true/清 pending，再延迟 callback | 间隙 exit 找不到待完成写入，后来仍错发 Written |
| 延迟调用原 complete，状态留到实际交付 | 间隙 exit 即时得到 Unknown；排队成功回调只做 no-op，无第二回执 |
| write 抛 EPIPE | 本轮 checkpoint 内即时 Unknown，不被成功屏障拖后 |

完整原始顺序见 `checkpoint.log`。此处 32/17 只是受控调度模型中的标签大小，不是缩小实际 16MiB 写入或替代真实大输入反例。没有测量延迟分布，也没有据此声称完整物理输入已可靠交付。

## 最小生产边界

只在共享 Bun 私有 stdin 桥的成功路径，等待 flush 后安排 `setImmediate(() => complete())`。原 complete 继续独占 completed 标记、pendingWrite 清除和一次回执交付。不能先把成功标成 completed 或移走 pending，再延迟下游 callback。失败和 exit 保持原来的即时 `complete(error)`；稍后排到的成功继续经过同一 guard。

这新增的是一个事件循环任务，不是等待任意毫秒，也不缩小原写入块、不修改字节结果、不补写、不重发。成功仍只确认上游原生输入管道的接收，不表示目标已消费或业务完成。职责落在私有物理 I/O 回执边界；不需要公开延迟配置、重试策略或新调度框架。已有输出/监管职责不随本包扩大。

它的成本可以准确说成“每个成功块多一次任务调度”，不能在没有测量时写成固定的毫秒数、零成本或吞吐无变化。Worker 读入后若产生较多小块，相应任务数也会增加。

## FIFO 的已知结果与额外义务

另一个非作者代理提供的真实原型 receipts 已复制到本目录：

- `fifo-direct-node-summary.json` 与 `fifo-direct-bun-summary.json`：单跳 2MiB+17、32MiB+17 逐字节相等；目标关闭 fd0 得 Unknown/EPIPE 并保留 exit23；确认 pending 16MiB 后强杀，得到 Unknown/EPIPE；没有重新发起整次写入，自有 FD 清理完成。
- `fifo-two-hop-failure.json`：真实 Bun stdin iterator→第二 FIFO→tee 在 2,097,169 字节输入中停于 1,589,248，sourceEOF=false，最终 watchdog 强杀后 EPIPE。这是组合红，不能被单跳绿或 summary 中泛称组合能力的 scope 文本覆盖。

原路径分别位于 `/private/tmp/d2-fifo-input-prototype.ZNCo2U/node-direct-evidence/summary.json`、`bun-direct-evidence/summary.json`、`bun-trace-evidence/write-failed-2097169-2.json`。此代理读取并核对这些 receipts，没有重跑它们。没有 FIFO 成本基准，也没有已证明的双跳根因。

FIFO 的优点是绕开 FileSink 输入状态，使用原生 fs.write 的确定正 bytesWritten 只推进已确认前缀；EOF 在最后回调之后通过关闭 writer 传递。这不等于可以把 FileSink 的 write 即时计数也这样解释。FIFO 新增输入 FD 的准备、继承、关闭及失败状态：父进程必须释放保留的 read FD；异步 write 未结算时不能关闭并复用同号 FD；错误后封闭输入，不能从 Unknown 自动重发。目标停读可能占用运行时写 I/O 资源，需证明有界并发停读、独立文件任务和强杀释放的行为，不能只推测线程池饥饿或声称已经排除它。

当前双跳红未解决，因此 FIFO 尚不是可交付替代。即使未来选定一种实现，也不能在 FileSink 失败后自动切 FIFO 重发同一输入。平台可沿用已明确的 Bun POSIX/mkfifo 前提，但新 stdin 的收尾义务仍须独立验证。

## 进入生产前仍需的证据

1. 同一固定运行时和实际包，保留原 33,554,449 字节、原 16MiB 块及末尾 17 字节/EOF；目标真实 witness 与独立原始字节/OID 对照，不以 Written 数量替代。
2. 在实际桥上验证 flush 已完成但成功尚未发布时的 exit/错误竞争：Unknown 优先，只有一次回执，晚到成功不得清掉错误；pending endInput 不越过真实成功回调。
3. 真实停读背压与强杀：不提前报 Written、不忙轮询、不自动补写，退出与输出/owned 收尾保持各自事实。
4. 相关 Process、Supervision、安装包及最终主仓边界验证；原红与重放绿都保留。不因本调度模型通过而关闭 D2，也不追查 R12-U1。

复跑小原型：`bun checkpoint.mjs > checkpoint.log 2>&1`。日志为原始输出。SHA256SUMS 绑定本目录说明、原型、公开 tag 快照与引用的 FIFO receipts。
