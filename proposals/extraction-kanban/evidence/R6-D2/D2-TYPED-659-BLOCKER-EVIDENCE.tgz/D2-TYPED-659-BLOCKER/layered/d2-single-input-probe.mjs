import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { execFileSync, spawn } from 'node:child_process'
import { copyFileSync, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { pathToFileURL } from 'node:url'

const product = path.resolve(process.argv[2])
const evidence = process.argv[3] ? path.resolve(process.argv[3]) : null
if (evidence) mkdirSync(evidence, { recursive: true })
const root = mkdtempSync(path.join(tmpdir(), 'd2-single-input-'))
const { run } = await import(pathToFileURL(path.join(product, 'dist/Persistence/EventStore/GitRawSurface.js')).href)
const candidates = [path.join(product, 'node_modules/wanxiangli'), path.resolve(product, '../wanxiangli')]
const library = candidates.find(candidate => existsSync(path.join(candidate, 'dist/process/ProcessSession.js')))
assert.ok(library)
const { ProcessSession } = await import(pathToFileURL(path.join(library, 'dist/process/ProcessSession.js')).href)
const { SupervisedProcess } = await import(pathToFileURL(path.join(library, 'dist/supervision/SupervisedProcess.js')).href)
const input = Uint8Array.from({ length: 2097169 }, (_, index) => index % 256)
input.set([239, 187, 191], 0)
if (evidence) writeFileSync(path.join(evidence, 'input.bin'), input)
const git = '/usr/bin/git'
const alias = "alias.d2-status=!f() { cat; printf '\\000\\377stderr\\n' >&2; exit \"$1\"; }; f"
const teeAlias = "alias.d2-status=!f() { tee \"$2\"; printf '\\000\\377stderr\\n' >&2; exit \"$1\"; }; f"
const hash = bytes => createHash('sha256').update(bytes).digest('hex')
const expectedOid = createHash('sha1').update(Buffer.from(`blob ${input.length}\0`)).update(input).digest('hex') + '\n'
const handles = []
const results = []
const describe = bytes => ({ bytes: bytes.length, sha256: hash(bytes), first: Buffer.from(bytes).subarray(0, 12).toString('hex'), last: Buffer.from(bytes).subarray(-12).toString('hex') })

async function collect(session) {
  const channels = { stdout: [], stderr: [] }
  while (true) {
    const output = await session.takeOutput()
    if (output.kind !== 'Chunk') return { terminal: output, stdout: Buffer.concat(channels.stdout), stderr: Buffer.concat(channels.stderr) }
    channels[output.channel].push(Buffer.from(output.bytes))
  }
}

async function sessionRun(Constructor, args) {
  const session = Constructor === ProcessSession
    ? new Constructor({ executable: git, args: ['-C', root, ...args], cwd: root, env: { PATH: process.env.PATH }, tailBytes: 0, maxWriteBytes: 16777216 }, 'Capture')
    : new Constructor({ executable: git, args: ['-C', root, ...args], cwd: root, env: { PATH: process.env.PATH }, tailBytes: 0, maxWriteBytes: 16777216 })
  handles.push(session)
  const captured = collect(session)
  const started = await session.started()
  assert.equal(started.kind, 'Started')
  const write = await session.write(input)
  session.endInput()
  const result = await captured
  const closed = await session.wait(5000)
  return { started, write, closed, ...result }
}

async function nativeRun(args) {
  if (globalThis.Bun) {
    const child = Bun.spawn([git, '-C', root, ...args], { cwd: root, env: { PATH: process.env.PATH }, stdin: 'pipe', stdout: 'pipe', stderr: 'pipe' })
    const stdout = new Response(child.stdout).arrayBuffer()
    const stderr = new Response(child.stderr).arrayBuffer()
    const count = await child.stdin.write(input)
    const flushed = await child.stdin.flush()
    const ended = await child.stdin.end()
    return { count, flushed, ended, exit: await child.exited, stdout: Buffer.from(await stdout), stderr: Buffer.from(await stderr) }
  }
  return new Promise((resolve, reject) => {
    const child = spawn(git, ['-C', root, ...args], { cwd: root, env: { PATH: process.env.PATH }, stdio: ['pipe', 'pipe', 'pipe'] })
    const stdout = []
    const stderr = []
    child.stdout.on('data', bytes => stdout.push(Buffer.from(bytes)))
    child.stderr.on('data', bytes => stderr.push(Buffer.from(bytes)))
    child.stdin.on('error', reject)
    child.once('error', reject)
    child.once('close', (code, signal) => resolve({ exit: { code, signal }, stdout: Buffer.concat(stdout), stderr: Buffer.concat(stderr) }))
    child.stdin.end(input)
  })
}

try {
  execFileSync(git, ['-C', root, 'init', '--quiet'])
  for (const command of ['cat', 'hash', 'tee']) {
    const expected = command === 'hash' ? Buffer.from(expectedOid) : Buffer.from(input)
    for (const transport of ['raw', 'supervised', 'base', 'native']) {
      const witnessPath = path.join(root, `${command}-${transport}-consumed`)
      const args = command === 'cat' ? ['-c', alias, 'd2-status', '7']
        : command === 'tee' ? ['-c', teeAlias, 'd2-status', '7', witnessPath]
          : ['hash-object', '--stdin']
      let value
      if (transport === 'raw') {
        const observed = await run(root, 10000, args, input, input.length + 4096)
        value = { observed, stdout: Buffer.from(observed.output.stdout), stderr: Buffer.from(observed.output.stderr) }
        delete observed.output.stdout
        delete observed.output.stderr
      } else if (transport === 'supervised') value = await sessionRun(SupervisedProcess, args)
      else if (transport === 'base') value = await sessionRun(ProcessSession, args)
      else value = await nativeRun(args)
      const { stdout, stderr, ...receipt } = value
      const equal = stdout.equals(expected)
      const witnessedBytes = existsSync(witnessPath) ? readFileSync(witnessPath) : null
      const witness = witnessedBytes ? describe(witnessedBytes) : null
      if (evidence) {
        writeFileSync(path.join(evidence, `${command}-${transport}.stdout.bin`), stdout)
        writeFileSync(path.join(evidence, `${command}-${transport}.stderr.bin`), stderr)
        if (witnessedBytes) copyFileSync(witnessPath, path.join(evidence, `${command}-${transport}.target.bin`))
      }
      results.push({ command, transport, equal, receipt, expected: describe(expected), stdout: describe(stdout), stderr: describe(stderr), witness, witnessPrefixMatchesInput: witnessedBytes ? witnessedBytes.equals(Buffer.from(input).subarray(0, witnessedBytes.length)) : null })
    }
  }
} finally {
  for (const session of handles) {
    session.signal('SIGKILL')
    session.discardOutput()
    await session.wait(5000)
  }
  rmSync(root, { recursive: true, force: true })
  console.log(JSON.stringify({ host: process.versions.bun ? `Bun ${process.versions.bun}` : `Node ${process.version}`, product, library, results, scratchRemoved: !existsSync(root) }, null, 2))
  if (results.some(result => !result.equal)) process.exitCode = 1
}
