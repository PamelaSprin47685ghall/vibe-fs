module D2NegativeBytesAsText

open Wanxiangshu.Persistence.EventStore

let invalid (output: GitRawOutput): string =
    output.Stdout
