module D2NegativeFailureAsNone

open System.Threading.Tasks
open Wanxiangshu.Persistence.EventStore

let invalid (store: IGitRawStore) (oid: GitObjectId): Task<byte[]> =
    store.ReadObject oid
