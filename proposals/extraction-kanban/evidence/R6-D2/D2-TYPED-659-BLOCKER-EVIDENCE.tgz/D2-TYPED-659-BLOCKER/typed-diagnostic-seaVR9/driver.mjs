import assert from 'node:assert/strict'
import { exercise } from './D2TypedConsumer.js'
const result = await exercise(process.cwd())
assert.equal(result.accepted, true)
assert.deepEqual(Array.from(result.rawExitCodes), [7,128])
assert.deepEqual(Array.from(result.storeFailureExitCodes), [7,128])
console.log(JSON.stringify({accepted:true, result, host:process.execPath}))
