module D2NegativeOptionalTree

open System.Threading.Tasks
open Wanxiangshu.Persistence.EventStore

let invalid (store: IGitRawStore) (oid: GitObjectId): Task<Result<TreeEntry list option, GitStorageFailure>> =
    store.ReadTree oid
