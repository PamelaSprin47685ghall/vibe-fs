module D2NegativeMissingLimit

open Wanxiangshu.Persistence.EventStore

let invalid: GitRawRequest =
    { Arguments = [ "version" ]
      Input = None }
