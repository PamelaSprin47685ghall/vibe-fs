module D2NegativeOptionalObject

open System.Threading.Tasks
open Wanxiangshu.Persistence.EventStore

let invalid (store: IGitRawStore) (oid: GitObjectId): Task<Result<byte[] option, GitStorageFailure>> =
    store.ReadObject oid
