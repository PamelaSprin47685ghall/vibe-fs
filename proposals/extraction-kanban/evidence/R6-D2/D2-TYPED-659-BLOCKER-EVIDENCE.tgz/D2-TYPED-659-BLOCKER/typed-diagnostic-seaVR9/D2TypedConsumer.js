
import { equals, Exception } from "../fable_modules/fable-library-js.5.13.0/Util.js";
import { toConsole, replicate, printf, toText } from "../fable_modules/fable-library-js.5.13.0/String.js";
import { append, setItem, initialize, forAll2 } from "../fable_modules/fable-library-js.5.13.0/Array.js";
import { get_UTF8 } from "../fable_modules/fable-library-js.5.13.0/Encoding.js";
import { toString } from "../fable_modules/fable-library-js.5.13.0/Types.js";
import { toArray, reverse, map, singleton, ofArray } from "../fable_modules/fable-library-js.5.13.0/List.js";
import { ProcessGitRawStoreModule_create, ProcessGitRawStoreModule_createWithRunner, ProcessGitRawStoreModule_createRunner, GitRawRequest } from "./Persistence/EventStore/ProcessGitRawStore.js";
import { GitRawResult, GitRawObservation, GitRawOutput, GitObjectIdModule_value, TreeEntry, GitObjectIdModule_create, GitStorageFailureModule_describe } from "./Persistence/EventStore/GitTypes.js";
import { task } from "../fable_modules/fable-library-js.5.13.0/TaskBuilder.js";
import { fromSeconds } from "../fable_modules/fable-library-js.5.13.0/TimeSpan.js";
import { chmodSync, writeFileSync } from "node:fs";
import { fromResult } from "../fable_modules/fable-library-js.5.13.0/Task.js";
import { EndEvidence } from "./Process/ProcessRequest.js";
import { run } from "./Persistence/EventStore/GitRawSurface.js";

function require(condition, message) {
    if (!condition) {
        throw new Exception(message);
    }
}

function requireBytes(expected, actual) {
    let arg, arg_1;
    require(expected.length === actual.length, (arg = (expected.length | 0), (arg_1 = (actual.length | 0), toText(printf("The byte lengths differ: expected=%d actual=%d"))(arg)(arg_1))));
    require(forAll2(equals, expected, actual), "The raw bytes differ");
}

const outputBytes = (() => {
    const bytes = initialize(((2 * 1024) * 1024) + 17, (index) => ((index % 256) & 0xFF), Uint8Array);
    setItem(bytes, 0, 239);
    setItem(bytes, 1, 187);
    setItem(bytes, 2, 191);
    return bytes;
})();

const errorBytes = append(new Uint8Array([0, 255]), get_UTF8().getBytes("stderr\n"), Uint8Array);

function dualArguments(code) {
    return ofArray(["-c", "alias.d2-status=!f() { cat; printf \'\\000\\377stderr\\n\' >&2; exit \"$1\"; }; f", "d2-status", toString(code)]);
}

function request(arguments$, input, outputLimit) {
    return new GitRawRequest(arguments$, input, outputLimit);
}

function requireRaw(code, result) {
    let output, actualCode;
    let matchResult, actualCode_1, output_1;
    if (result.tag === 1) {
        if (result.fields[0].End.tag === 0) {
            if (result.fields[0].End.fields[0].tag === 0) {
                if (result.fields[0].StopRequested == null) {
                    if (result.fields[0].Fault == null) {
                        if ((output = result.fields[0].Output, (actualCode = (result.fields[0].End.fields[0].fields[0] | 0), (actualCode === code) && output.Complete))) {
                            matchResult = 0;
                            actualCode_1 = result.fields[0].End.fields[0].fields[0];
                            output_1 = result.fields[0].Output;
                        }
                        else {
                            matchResult = 1;
                        }
                    }
                    else {
                        matchResult = 1;
                    }
                }
                else {
                    matchResult = 1;
                }
            }
            else {
                matchResult = 1;
            }
        }
        else {
            matchResult = 1;
        }
    }
    else {
        matchResult = 1;
    }
    switch (matchResult) {
        case 0: {
            requireBytes(outputBytes, output_1.Stdout);
            requireBytes(errorBytes, output_1.Stderr);
            break;
        }
        case 1: {
            throw new Exception("The typed raw result lost normal exit evidence or binary channels");
            break;
        }
    }
}

function objectId(_arg) {
    if (_arg.tag === 1) {
        const error = _arg.fields[0];
        throw new Exception(GitStorageFailureModule_describe(error));
    }
    else {
        const oid = _arg.fields[0];
        return oid;
    }
}

function requirePresent(expected, _arg) {
    if (_arg.tag === 1) {
        const error = _arg.fields[0];
        throw new Exception(GitStorageFailureModule_describe(error));
    }
    else {
        const actual = _arg.fields[0];
        requireBytes(expected, actual);
    }
}

function requireFailure(expectedCode, _arg) {
    if (_arg.tag === 0) {
        throw new Exception("A failed Git execution became a successful value");
    }
    else {
        const failure = _arg.fields[0];
        requireRaw(expectedCode, failure.Result);
    }
}

const missingOid = replicate(40, "1");

function requireMissingFailure(_arg) {
    let output;
    let matchResult, output_1;
    if (_arg.tag === 1) {
        if (_arg.fields[0].Result.tag === 1) {
            if (_arg.fields[0].Result.fields[0].End.tag === 0) {
                if (_arg.fields[0].Result.fields[0].End.fields[0].tag === 0) {
                    if (_arg.fields[0].Result.fields[0].End.fields[0].fields[0] === 0) {
                        if (_arg.fields[0].Result.fields[0].StopRequested == null) {
                            if (_arg.fields[0].Result.fields[0].Fault == null) {
                                if ((output = _arg.fields[0].Result.fields[0].Output, output.Complete)) {
                                    matchResult = 0;
                                    output_1 = _arg.fields[0].Result.fields[0].Output;
                                }
                                else {
                                    matchResult = 1;
                                }
                            }
                            else {
                                matchResult = 1;
                            }
                        }
                        else {
                            matchResult = 1;
                        }
                    }
                    else {
                        matchResult = 1;
                    }
                }
                else {
                    matchResult = 1;
                }
            }
            else {
                matchResult = 1;
            }
        }
        else {
            matchResult = 1;
        }
    }
    else {
        matchResult = 1;
    }
    switch (matchResult) {
        case 0: {
            requireBytes(get_UTF8().getBytes(missingOid + " missing\n"), output_1.Stdout);
            requireBytes(new Uint8Array(0), output_1.Stderr);
            break;
        }
        case 1: {
            throw new Exception("An ambiguous missing object became success or lost its raw Git receipt");
            break;
        }
    }
}

export function exercise(repository) {
    const builder$0040 = task();
    return builder$0040.Run(builder$0040.Delay(() => {
        const physical = ProcessGitRawStoreModule_createRunner(repository, fromSeconds(20));
        const limit = (outputBytes.length + errorBytes.length) | 0;
        return builder$0040.Bind(physical(request(ofArray(["init", "--quiet"]), undefined, 4096)), (_arg) => {
            const initialized = _arg;
            return builder$0040.Combine((initialized.tag === 1) ? ((initialized.fields[0].End.tag === 0) ? ((initialized.fields[0].End.fields[0].tag === 0) ? ((initialized.fields[0].End.fields[0].fields[0] === 0) ? ((initialized.fields[0].StopRequested == null) ? (initialized.fields[0].Output.Complete ? ((initialized.fields[0].Fault == null) ? (builder$0040.Zero()) : (((() => {
                throw new Exception("The owned Git repository did not initialize");
            })(), builder$0040.Zero()))) : (((() => {
                throw new Exception("The owned Git repository did not initialize");
            })(), builder$0040.Zero()))) : (((() => {
                throw new Exception("The owned Git repository did not initialize");
            })(), builder$0040.Zero()))) : (((() => {
                throw new Exception("The owned Git repository did not initialize");
            })(), builder$0040.Zero()))) : (((() => {
                throw new Exception("The owned Git repository did not initialize");
            })(), builder$0040.Zero()))) : (((() => {
                throw new Exception("The owned Git repository did not initialize");
            })(), builder$0040.Zero()))) : (((() => {
                throw new Exception("The owned Git repository did not initialize");
            })(), builder$0040.Zero())), builder$0040.Delay(() => builder$0040.Combine(builder$0040.For([7, 128], (_arg_1) => {
                const code = _arg_1 | 0;
                toConsole(printf("D2 typed raw exit %d"))(code);
                return builder$0040.Bind(physical(request(dualArguments(code), outputBytes, limit)), (_arg_2) => {
                    const raw = _arg_2;
                    requireRaw(code, raw);
                    const failingRunner = (original) => {
                        require(original.OutputLimit > 0, "The store omitted its explicit capture budget");
                        return physical(new GitRawRequest(dualArguments(code), outputBytes, limit));
                    };
                    const failedStore = ProcessGitRawStoreModule_createWithRunner(repository, failingRunner);
                    toConsole(printf("D2 typed store error exit %d"))(code);
                    return builder$0040.Bind(failedStore.ReadObject(GitObjectIdModule_create(missingOid)), (_arg_3) => {
                        const failedRead = _arg_3;
                        requireFailure(code, failedRead);
                        return builder$0040.Zero();
                    });
                });
            }), builder$0040.Delay(() => {
                console.log("D2 typed combined limit");
                return builder$0040.Bind(physical(request(dualArguments(7), outputBytes, limit - 1)), (_arg_4) => {
                    let output;
                    const limited = _arg_4;
                    return builder$0040.Combine((limited.tag === 1) ? ((limited.fields[0].Fault != null) ? ((output = limited.fields[0].Output, (require(!output.Complete, "The explicit combined output limit was ignored"), (require((output.Stdout.length + output.Stderr.length) <= (limit - 1), "The combined output budget was exceeded"), builder$0040.Zero())))) : (((() => {
                        throw new Exception("An output-limit fault became complete success or disappeared");
                    })(), builder$0040.Zero()))) : (((() => {
                        throw new Exception("An output-limit fault became complete success or disappeared");
                    })(), builder$0040.Zero())), builder$0040.Delay(() => builder$0040.Bind(physical(request(singleton("version"), undefined, -1)), (_arg_5) => {
                        const rejected = _arg_5;
                        return builder$0040.Combine((rejected.tag === 0) ? ((rejected.fields[0].tag === 0) ? (builder$0040.Zero()) : (((() => {
                            throw new Exception("A negative capture limit reached physical execution");
                        })(), builder$0040.Zero()))) : (((() => {
                            throw new Exception("A negative capture limit reached physical execution");
                        })(), builder$0040.Zero())), builder$0040.Delay(() => {
                            const store = ProcessGitRawStoreModule_create(repository);
                            console.log("D2 typed binary cold object");
                            return builder$0040.Bind(store.WriteBlob(outputBytes), (_arg_6) => {
                                const written = _arg_6;
                                const oid = objectId(written);
                                const coldStore = ProcessGitRawStoreModule_create(repository);
                                return builder$0040.Bind(coldStore.ReadObject(oid), (_arg_7) => {
                                    const coldRead = _arg_7;
                                    requirePresent(outputBytes, coldRead);
                                    const names = ofArray(["aa", "line\nname", "tab\tname", "z", "é", "", "𐀀"]);
                                    const entries = map((name) => (new TreeEntry("100644", name, oid)), reverse(names));
                                    return builder$0040.Bind(store.WriteTree(entries), (_arg_8) => {
                                        const writtenTree = _arg_8;
                                        const treeOid = objectId(writtenTree);
                                        const coldTreeStore = ProcessGitRawStoreModule_create(repository);
                                        console.log("D2 typed UTF-8 cold tree");
                                        return builder$0040.Bind(coldTreeStore.ReadTree(treeOid), (_arg_9) => {
                                            let error, actual;
                                            const coldTree = _arg_9;
                                            return builder$0040.Combine((coldTree.tag === 1) ? ((error = coldTree.fields[0], ((() => {
                                                throw new Exception(GitStorageFailureModule_describe(error));
                                            })(), builder$0040.Zero()))) : ((actual = coldTree.fields[0], (require(equals(map((entry) => entry.Name, actual), names), "The real tree did not use UTF-8 byte order"), builder$0040.Zero()))), builder$0040.Delay(() => {
                                                console.log("D2 typed missing object");
                                                return builder$0040.Bind(coldStore.ReadObject(GitObjectIdModule_create(missingOid)), (_arg_10) => {
                                                    const missingObject = _arg_10;
                                                    requireMissingFailure(missingObject);
                                                    console.log("D2 typed missing tree");
                                                    return builder$0040.Bind(coldTreeStore.ReadTree(GitObjectIdModule_create(missingOid)), (_arg_11) => {
                                                        const missingTree = _arg_11;
                                                        requireMissingFailure(missingTree);
                                                        console.log("D2 typed missing ref");
                                                        return builder$0040.Bind(coldStore.ReadRef("refs/heads/d2-missing"), (_arg_12) => {
                                                            const missingRef = _arg_12;
                                                            return builder$0040.Combine((missingRef.tag === 0) ? ((missingRef.fields[0] == null) ? (builder$0040.Zero()) : (((() => {
                                                                throw new Exception("A valid absent ref was not a successful None");
                                                            })(), builder$0040.Zero()))) : (((() => {
                                                                throw new Exception("A valid absent ref was not a successful None");
                                                            })(), builder$0040.Zero())), builder$0040.Delay(() => {
                                                                const refPath = repository + "/.git/refs/heads/d2-denied";
                                                                writeFileSync(refPath, GitObjectIdModule_value(oid) + "\n");
                                                                chmodSync(refPath, 0);
                                                                return builder$0040.Combine(builder$0040.TryFinally(builder$0040.Delay(() => {
                                                                    console.log("D2 typed denied ref");
                                                                    return builder$0040.Bind(coldStore.ReadRef("refs/heads/d2-denied"), (_arg_13) => {
                                                                        const denied = _arg_13;
                                                                        let matchResult, code_1, output_1;
                                                                        if (denied.tag === 1) {
                                                                            if (denied.fields[0].Result.tag === 1) {
                                                                                if (denied.fields[0].Result.fields[0].End.tag === 0) {
                                                                                    if (denied.fields[0].Result.fields[0].End.fields[0].tag === 0) {
                                                                                        matchResult = 0;
                                                                                        code_1 = denied.fields[0].Result.fields[0].End.fields[0].fields[0];
                                                                                        output_1 = denied.fields[0].Result.fields[0].Output;
                                                                                    }
                                                                                    else {
                                                                                        matchResult = 1;
                                                                                    }
                                                                                }
                                                                                else {
                                                                                    matchResult = 1;
                                                                                }
                                                                            }
                                                                            else {
                                                                                matchResult = 1;
                                                                            }
                                                                        }
                                                                        else {
                                                                            matchResult = 1;
                                                                        }
                                                                        switch (matchResult) {
                                                                            case 0: {
                                                                                require((code_1 !== 0) && (output_1.Stderr.length > 0), "The permission failure lost its actual status or diagnostic bytes");
                                                                                return builder$0040.Zero();
                                                                            }
                                                                            default: {
                                                                                throw new Exception("A real unreadable ref became None or another successful value");
                                                                                return builder$0040.Zero();
                                                                            }
                                                                        }
                                                                    });
                                                                }), () => {
                                                                    chmodSync(refPath, 384);
                                                                }), builder$0040.Delay(() => {
                                                                    const incomplete = (_arg_14) => fromResult(new GitRawResult(/* Observed */ 1, [new GitRawObservation(EndEvidence.Unconfirmed, undefined, new GitRawOutput(new Uint8Array([0, 255]), errorBytes, false), "Controlled missing receipt")]));
                                                                    const unknownStore = ProcessGitRawStoreModule_createWithRunner(repository, incomplete);
                                                                    console.log("D2 typed unknown");
                                                                    return builder$0040.Bind(unknownStore.ReadObject(oid), (_arg_15) => {
                                                                        let output_2;
                                                                        const unknown = _arg_15;
                                                                        return builder$0040.Combine((unknown.tag === 1) ? ((unknown.fields[0].Result.tag === 1) ? ((unknown.fields[0].Result.fields[0].End.tag === 1) ? ((unknown.fields[0].Result.fields[0].Fault != null) ? ((unknown.fields[0].Result.fields[0].Fault === "Controlled missing receipt") ? ((output_2 = unknown.fields[0].Result.fields[0].Output, (require(!output_2.Complete, "Unknown output became complete"), (requireBytes(errorBytes, output_2.Stderr), builder$0040.Zero())))) : (((() => {
                                                                            throw new Exception("Unknown became an absent object");
                                                                        })(), builder$0040.Zero()))) : (((() => {
                                                                            throw new Exception("Unknown became an absent object");
                                                                        })(), builder$0040.Zero()))) : (((() => {
                                                                            throw new Exception("Unknown became an absent object");
                                                                        })(), builder$0040.Zero()))) : (((() => {
                                                                            throw new Exception("Unknown became an absent object");
                                                                        })(), builder$0040.Zero()))) : (((() => {
                                                                            throw new Exception("Unknown became an absent object");
                                                                        })(), builder$0040.Zero())), builder$0040.Delay(() => {
                                                                            console.log("D2 typed raw surface");
                                                                            return builder$0040.Bind(run(repository, 20000, toArray(dualArguments(128)), outputBytes, limit), (_arg_16) => {
                                                                                const surface = _arg_16;
                                                                                require(surface.kind === "Observed", "The real surface result kind differs");
                                                                                require(surface.ending.kind === "Exited", "The surface lost normal exit evidence");
                                                                                require(surface.ending.exitCode === 128, "The surface changed the real exit code");
                                                                                require(surface.output.complete, "The surface changed complete output");
                                                                                requireBytes(outputBytes, surface.output.stdout);
                                                                                requireBytes(errorBytes, surface.output.stderr);
                                                                                return builder$0040.Return({
                                                                                    accepted: true,
                                                                                    inputBytes: outputBytes.length,
                                                                                    stderrBytes: errorBytes.length,
                                                                                    combinedOutputLimit: limit,
                                                                                    rawExitCodes: new Int32Array([7, 128]),
                                                                                    storeFailureExitCodes: new Int32Array([7, 128]),
                                                                                    binaryColdRead: true,
                                                                                    utf8TreeOrder: true,
                                                                                    missingObjectIsError: true,
                                                                                    missingTreeIsError: true,
                                                                                    missingRefIsNone: true,
                                                                                    permissionIsError: true,
                                                                                    unknownIsError: true,
                                                                                    surfaceExit128: true,
                                                                                });
                                                                            });
                                                                        }));
                                                                    });
                                                                }));
                                                            }));
                                                        });
                                                    });
                                                });
                                            }));
                                        });
                                    });
                                });
                            });
                        }));
                    })));
                });
            }))));
        });
    }));
}

