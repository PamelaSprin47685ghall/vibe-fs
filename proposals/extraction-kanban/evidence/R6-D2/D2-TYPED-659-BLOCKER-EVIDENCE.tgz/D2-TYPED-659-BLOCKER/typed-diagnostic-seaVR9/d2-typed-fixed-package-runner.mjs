import assert from 'node:assert/strict'
import fs from 'node:fs'
import { join, dirname, relative, resolve, sep } from 'node:path'
import { createHash } from 'node:crypto'
import { spawn } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import { tmpdir } from 'node:os'

const repository = resolve(process.argv[2])
const product = resolve(process.argv[3])
const archive = resolve(process.argv[4])
const expected = process.argv[5]
const expectedSourceDigestsPath = process.argv[6] ? resolve(process.argv[6]) : null
const compileOnly = process.env.D2_COMPILE_ONLY === '1'
const temporaryRoot = process.env.D2_REVIEW_TMP_ROOT || (fs.existsSync('/private/tmp') ? '/private/tmp' : tmpdir())
const nodeExecutable = process.env.D2_NODE || process.execPath
const bunExecutable = process.env.D2_BUN || 'bun'
const evidence = fs.mkdtempSync(join(temporaryRoot, 'd2-typed-fixed-package-evidence-'))
const scratch = fs.mkdtempSync(join(temporaryRoot, 'd2-typed-fixed-package-case-'))
const compileScratch = join(scratch, 'compile')
const source = join(repository, 'src/Wanxiangshu')
const probeSource = join(dirname(fileURLToPath(import.meta.url)), 'D2TypedConsumer.fs')
const negativeNames = ['D2NegativeMissingLimit', 'D2NegativeFailureAsNone', 'D2NegativeBytesAsText', 'D2NegativeOptionalObject', 'D2NegativeOptionalTree']
const digest = path => createHash('sha256').update(fs.readFileSync(path)).digest('hex')
const save = (name, value) => fs.writeFileSync(join(evidence, name), JSON.stringify(value, null, 2), { mode: 0o600 })
const files = root => {
  const result = {}
  const visit = directory => {
    for (const name of fs.readdirSync(directory).sort()) {
      const path = join(directory, name)
      const stat = fs.lstatSync(path)
      assert.equal(stat.isSymbolicLink(), false)
      if (stat.isDirectory()) visit(path)
      else result[relative(root, path)] = digest(path)
    }
  }
  visit(root)
  return result
}
const run = async (name, executable, args, cwd, env) => {
  const stdout = fs.openSync(join(evidence, `${name}.stdout`), 'w', 0o600)
  const stderr = fs.openSync(join(evidence, `${name}.stderr`), 'w', 0o600)
  save(`${name}.command.json`, { executable, args, cwd, env })
  const child = spawn(executable, args, { cwd, env, detached: true, stdio: ['ignore', stdout, stderr] })
  let timedOut = false
  const timer = setTimeout(() => {
    timedOut = true
    try { process.kill(-child.pid, 'SIGKILL') } catch (error) { if (error.code !== 'ESRCH') throw error }
  }, 60000)
  const result = await new Promise((resolve, reject) => {
    child.once('error', reject)
    child.once('close', (code, signal) => resolve({ code, signal, timedOut, pid: child.pid }))
  })
  clearTimeout(timer)
  fs.closeSync(stdout)
  fs.closeSync(stderr)
  save(`${name}.status.json`, result)
  return result
}

console.log(JSON.stringify({ evidence, scratch, product, archive, expected }))
try {
  if (!compileOnly) assert.equal(digest(archive), expected)
  const before = compileOnly ? null : files(product)
  save('products-before.json', before)
  const { compileOwnerProject, planOwnerCompile } = await import(join(repository, 'scripts/lib/owner-compile.mjs'))
  const project = join(source, 'Wanxiangshu.Owner.durable-events.eventstore-git-raw-surface.fsproj')
  const plan = planOwnerCompile({ projectPath: project })
  const realFsi = ['Persistence/EventStore/GitTypes.fsi', 'Persistence/EventStore/ProcessGitRawStore.fsi', 'Persistence/EventStore/GitRawSurface.fsi', 'Process/ProcessRequest.fsi']
  for (const name of realFsi) assert.ok(plan.compileItems.includes(join(source, name)))
  const inputs = plan.compileItems.map(path => {
    const target = join(compileScratch, 'source', relative(source, path))
    fs.mkdirSync(dirname(target), { recursive: true })
    fs.copyFileSync(path, target)
    return target
  })
  const sourceDigests = Object.fromEntries(plan.compileItems.map(path => [relative(source, path), digest(path)]))
  if (expectedSourceDigestsPath) assert.deepEqual(sourceDigests, JSON.parse(fs.readFileSync(expectedSourceDigestsPath)), 'The replay source must match the frozen real .fsi compilation inputs')
  save('real-source-inputs.json', sourceDigests)
  for (const name of realFsi) fs.copyFileSync(join(source, name), join(evidence, name.split('/').at(-1)))
  const consumer = join(compileScratch, 'source/D2TypedConsumer.fs')
  fs.copyFileSync(probeSource, consumer)
  const compiled = await compileOwnerProject({ projectPath: project, scratchRoot: join(compileScratch, 'output'), stdio: 'pipe', compilePlan: { ...plan, compileItems: [...inputs, consumer] } })
  fs.writeFileSync(join(evidence, 'compile.stdout'), compiled.stdout || '')
  fs.writeFileSync(join(evidence, 'compile.stderr'), compiled.stderr || '')
  save('compile.status.json', { ok: compiled.ok, code: compiled.code, signal: compiled.signal, elapsedMs: compiled.elapsedMs, outputPath: compiled.outputPath, fingerprint: compiled.fingerprint })
  assert.equal(compiled.ok, true, String(compiled.stdout) + String(compiled.stderr))
  const compiledFiles = files(compiled.outputPath)
  const matches = Object.keys(compiledFiles).filter(path => path.endsWith('D2TypedConsumer.js'))
  assert.equal(matches.length, 1)
  const emitted = join(compiled.outputPath, matches[0])
  const emittedBytes = fs.readFileSync(emitted)
  fs.writeFileSync(join(evidence, 'D2TypedConsumer.js'), emittedBytes)
  save('generated-compile-files.json', compiledFiles)
  for (const name of negativeNames) {
    const negativeSource = join(dirname(probeSource), `${name}.fs`)
    const negative = join(compileScratch, 'source', `${name}.fs`)
    fs.copyFileSync(negativeSource, negative)
    fs.copyFileSync(negativeSource, join(evidence, `${name}.fs`))
    const result = await compileOwnerProject({ projectPath: project, scratchRoot: join(compileScratch, name), stdio: 'pipe', compilePlan: { ...plan, compileItems: [...inputs, negative] } })
    fs.writeFileSync(join(evidence, `${name}.stdout`), result.stdout || '')
    fs.writeFileSync(join(evidence, `${name}.stderr`), result.stderr || '')
    save(`${name}.status.json`, { ok: result.ok, code: result.code, signal: result.signal, elapsedMs: result.elapsedMs })
    assert.equal(result.ok, false, `The illegal ${name} call compiled successfully`)
    assert.match(String(result.stdout) + String(result.stderr), new RegExp(name))
  }
  if (compileOnly) {
    save('summary.json', { preparationOnly: true, candidateRuntimeNotRun: true, positiveCompiled: true, negativeCompilesRejected: negativeNames, realFsi, sourceDigests })
    console.log(JSON.stringify({ evidence, preparationOnly: true, positiveCompiled: true, negativeCompilesRejected: negativeNames }))
    process.exitCode = 0
  } else {
  const runtimeRoot = join(scratch, 'runtime')
  const runtime = join(runtimeRoot, 'program')
  fs.mkdirSync(runtime, { recursive: true })
  fs.writeFileSync(join(runtimeRoot, 'package.json'), JSON.stringify({ name: 'd2-typed-fixed-package-consumer', type: 'module', private: true }))
  const entry = join(runtime, 'D2TypedConsumer.js')
  fs.writeFileSync(entry, emittedBytes)
  const imports = [...emittedBytes.toString().matchAll(/from\s+["']([^"']+)["']/g)].map(match => match[1])
  assert.ok(imports.length > 0)
  const links = new Map()
  for (const specifier of imports) {
    let artifactPath
    let stageDirectory
    let component
    if (specifier.startsWith('./Process/') || specifier.startsWith('./Persistence/')) {
      artifactPath = specifier.slice(2)
      stageDirectory = runtime
      component = artifactPath.split('/')[0]
    } else if (specifier.startsWith('../fable_modules/')) {
      artifactPath = specifier.slice(3)
      stageDirectory = runtimeRoot
      component = 'fable_modules'
    } else if (specifier.startsWith('node:')) continue
    else assert.fail(`Compiled consumer has an unexpected import outside the frozen package: ${specifier}`)
    links.set(join(stageDirectory, component), join(product, 'dist', component))
    const target = resolve(product, 'dist', artifactPath)
    assert.ok(target.startsWith(join(product, 'dist') + sep))
    assert.equal(fs.existsSync(target), true, `The frozen package is missing the actual compiled consumer dependency ${specifier}`)
  }
  for (const [from, to] of links) fs.symlinkSync(to, from)
  save('runtime-imports.json', { imports, links: [...links].map(([from, to]) => ({ from, to })), emittedConsumerSHA256: digest(entry), noImportRewrite: true })
  fs.rmSync(compileScratch, { recursive: true, force: true })
  assert.equal(fs.existsSync(compiled.outputPath), false, 'No generated production implementation may remain as a runtime fallback')
  const driver = join(runtime, 'driver.mjs')
  fs.writeFileSync(driver, "import assert from 'node:assert/strict'\nimport { exercise } from './D2TypedConsumer.js'\nconst result = await exercise(process.cwd())\nassert.equal(result.accepted, true)\nassert.deepEqual(Array.from(result.rawExitCodes), [7,128])\nassert.deepEqual(Array.from(result.storeFailureExitCodes), [7,128])\nconsole.log(JSON.stringify({accepted:true, result, host:process.execPath}))\n")
  fs.copyFileSync(driver, join(evidence, 'driver.mjs'))
  const results = await Promise.all([{ host: 'node', executable: nodeExecutable }, { host: 'bun', executable: bunExecutable }].map(async ({ host, executable }) => {
    const directory = join(scratch, host)
    const home = join(directory, 'home')
    const temporary = join(directory, 'tmp')
    fs.mkdirSync(home, { recursive: true })
    fs.mkdirSync(temporary)
    return { host, result: await run(host, executable, [driver], directory, { PATH: process.env.PATH, HOME: home, USERPROFILE: home, TMPDIR: temporary, GIT_CONFIG_NOSYSTEM: '1', GIT_CONFIG_GLOBAL: '/dev/null' }) }
  }))
  assert.deepEqual(files(product), before)
  assert.equal(digest(archive), expected)
  assert.equal(digest(entry), createHash('sha256').update(emittedBytes).digest('hex'))
  save('products-after.json', files(product))
  save('summary.json', { results, fixedArchive: expected, realFsiUsed: realFsi, negativeCompilesRejected: negativeNames, sourceDigests, sourceReplayDigestsChecked: expectedSourceDigestsPath !== null, emittedConsumerUnchanged: true, generatedProductionOutputDeletedBeforeRuntime: true, installedProductUnchanged: true, archiveUnchanged: true, scope: 'Internal F# contract check against real .fsi, followed by the same emitted consumer JS using only the frozen clean-installed package dist modules and their installed dependencies. No npm d.ts or new npm public export is claimed. The compiler may compile copied source implementations for type checking, but those outputs are removed before execution and never used at runtime. The injected store failure runners execute actual Git aliases through the production physical runner; their results are not manufactured receipts.' })
  for (const value of results) {
    assert.equal(value.result.timedOut, false)
    assert.equal(value.result.code, 0, fs.readFileSync(join(evidence, `${value.host}.stderr`), 'utf8'))
  }
  }
} catch (error) {
  save('harness-error.json', { message: error.message, stack: error.stack })
  process.exitCode = 1
} finally {
  fs.copyFileSync(probeSource, join(evidence, 'D2TypedConsumer.fs'))
  fs.copyFileSync(fileURLToPath(import.meta.url), join(evidence, 'd2-typed-fixed-package-runner.mjs'))
  fs.rmSync(scratch, { recursive: true, force: true })
  save('cleanup.json', { scratchRemoved: !fs.existsSync(scratch), installationPreserved: !compileOnly && fs.existsSync(product), compileOnly, scope: 'Normal Git programs complete through the production scope/capture boundary; no independent per-PID sampling is claimed.' })
}
