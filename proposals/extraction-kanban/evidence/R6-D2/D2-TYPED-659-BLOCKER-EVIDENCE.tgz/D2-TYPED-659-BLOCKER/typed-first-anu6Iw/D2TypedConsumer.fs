module D2TypedConsumer

open System
open System.Text
open System.Threading.Tasks
open Fable.Core
open Fable.Core.JsInterop
open Wanxiangshu.Process
open Wanxiangshu.Persistence.EventStore

[<Import("writeFileSync", "node:fs")>]
let private writeText (_path: string) (_text: string): unit = jsNative

[<Import("chmodSync", "node:fs")>]
let private changeMode (_path: string) (_mode: int): unit = jsNative

let private require condition message =
    if not condition then failwith message

let private requireBytes expected actual =
    require (Array.length expected = Array.length actual) "The byte lengths differ"
    require (Array.forall2 (=) expected actual) "The raw bytes differ"

let private outputBytes =
    let bytes = Array.init (2 * 1024 * 1024 + 17) (fun index -> byte (index % 256))
    bytes.[0] <- 0xEFuy
    bytes.[1] <- 0xBBuy
    bytes.[2] <- 0xBFuy
    bytes

let private errorBytes = Array.append [| 0uy; 255uy |] (Encoding.UTF8.GetBytes "stderr\n")

let private dualArguments code =
    [ "-c"
      "alias.d2-status=!f() { cat; printf '\\000\\377stderr\\n' >&2; exit \"$1\"; }; f"
      "d2-status"
      string code ]

let private request arguments input outputLimit: GitRawRequest =
    { Arguments = arguments
      Input = input
      OutputLimit = outputLimit }

let private requireRaw code result =
    match result with
    | GitRawResult.Observed
        { End = EndEvidence.Confirmed(ProgramEnd.Exited actualCode)
          StopRequested = None
          Output = output
          Fault = None } when actualCode = code && output.Complete ->
        requireBytes outputBytes output.Stdout
        requireBytes errorBytes output.Stderr
    | _ -> failwith "The typed raw result lost normal exit evidence or binary channels"

let private objectId = function
    | Ok oid -> oid
    | Error error -> failwith (GitStorageFailure.describe error)

let private requirePresent expected = function
    | Ok actual -> requireBytes expected actual
    | Error error -> failwith (GitStorageFailure.describe error)

let private requireFailure expectedCode = function
    | Error failure -> requireRaw expectedCode failure.Result
    | Ok _ -> failwith "A failed Git execution became a successful value"

let private missingOid = String.replicate 40 "1"

let private requireMissingFailure = function
    | Error
        { Result = GitRawResult.Observed
            { End = EndEvidence.Confirmed(ProgramEnd.Exited 0)
              StopRequested = None
              Output = output
              Fault = None } } when output.Complete ->
        requireBytes (Encoding.UTF8.GetBytes(missingOid + " missing\n")) output.Stdout
        requireBytes Array.empty output.Stderr
    | _ -> failwith "An ambiguous missing object became success or lost its raw Git receipt"

let exercise repository = task {
    let physical: GitRawRunner = ProcessGitRawStore.createRunner repository (TimeSpan.FromSeconds 20.0)
    let limit = outputBytes.Length + errorBytes.Length
    let! initialized = physical (request [ "init"; "--quiet" ] None 4096)
    match initialized with
    | GitRawResult.Observed { End = EndEvidence.Confirmed(ProgramEnd.Exited 0); StopRequested = None; Output = { Complete = true }; Fault = None } -> ()
    | _ -> failwith "The owned Git repository did not initialize"

    for code in [ 7; 128 ] do
        let! raw = physical (request (dualArguments code) (Some outputBytes) limit)
        requireRaw code raw

        let failingRunner (original: GitRawRequest) =
            require (original.OutputLimit > 0) "The store omitted its explicit capture budget"
            physical { original with Arguments = dualArguments code; Input = Some outputBytes; OutputLimit = limit }

        let failedStore: IGitRawStore = ProcessGitRawStore.createWithRunner repository failingRunner
        let! failedRead = failedStore.ReadObject(GitObjectId.create missingOid)
        requireFailure code failedRead

    let! limited = physical (request (dualArguments 7) (Some outputBytes) (limit - 1))
    match limited with
    | GitRawResult.Observed { Output = output; Fault = Some _ } ->
        require (not output.Complete) "The explicit combined output limit was ignored"
        require (output.Stdout.Length + output.Stderr.Length <= limit - 1) "The combined output budget was exceeded"
    | _ -> failwith "An output-limit fault became complete success or disappeared"

    let! rejected = physical (request [ "version" ] None -1)
    match rejected with
    | GitRawResult.NotStarted(NoExecution.InvalidRequest _) -> ()
    | _ -> failwith "A negative capture limit reached physical execution"

    let store: IGitRawStore = ProcessGitRawStore.create repository
    let! written = store.WriteBlob outputBytes
    let oid = objectId written
    let coldStore: IGitRawStore = ProcessGitRawStore.create repository
    let! coldRead = coldStore.ReadObject oid
    requirePresent outputBytes coldRead

    let names = [ "aa"; "line\nname"; "tab\tname"; "z"; "é"; "\uE000"; "\U00010000" ]
    let entries = names |> List.rev |> List.map (fun name -> { Mode = "100644"; Name = name; Oid = oid })
    let! writtenTree = store.WriteTree entries
    let treeOid = objectId writtenTree
    let coldTreeStore: IGitRawStore = ProcessGitRawStore.create repository
    let! coldTree = coldTreeStore.ReadTree treeOid
    match coldTree with
    | Ok actual -> require ((actual |> List.map (fun entry -> entry.Name)) = names) "The real tree did not use UTF-8 byte order"
    | Error error -> failwith (GitStorageFailure.describe error)

    let! missingObject = coldStore.ReadObject(GitObjectId.create missingOid)
    requireMissingFailure missingObject
    let! missingTree = coldTreeStore.ReadTree(GitObjectId.create missingOid)
    requireMissingFailure missingTree

    let! missingRef = coldStore.ReadRef "refs/heads/d2-missing"
    match missingRef with
    | Ok None -> ()
    | _ -> failwith "A valid absent ref was not a successful None"

    let refPath = repository + "/.git/refs/heads/d2-denied"
    writeText refPath (GitObjectId.value oid + "\n")
    changeMode refPath 0
    try
        let! denied = coldStore.ReadRef "refs/heads/d2-denied"
        match denied with
        | Error { Result = GitRawResult.Observed { End = EndEvidence.Confirmed(ProgramEnd.Exited code); Output = output } } ->
            require (code <> 0 && output.Stderr.Length > 0) "The permission failure lost its actual status or diagnostic bytes"
        | _ -> failwith "A real unreadable ref became None or another successful value"
    finally
        changeMode refPath 0o600

    let incomplete: GitRawRunner = fun _ ->
        Task.FromResult(
            GitRawResult.Observed
                { End = EndEvidence.Unconfirmed
                  StopRequested = None
                  Output = { Stdout = [| 0uy; 255uy |]; Stderr = errorBytes; Complete = false }
                  Fault = Some "Controlled missing receipt" })
    let unknownStore: IGitRawStore = ProcessGitRawStore.createWithRunner repository incomplete
    let! unknown = unknownStore.ReadObject oid
    match unknown with
    | Error { Result = GitRawResult.Observed { End = EndEvidence.Unconfirmed; Output = output; Fault = Some "Controlled missing receipt" } } ->
        require (not output.Complete) "Unknown output became complete"
        requireBytes errorBytes output.Stderr
    | _ -> failwith "Unknown became an absent object"

    let! surface = GitRawSurface.run repository 20000.0 (dualArguments 128 |> List.toArray) (Some outputBytes) limit
    require (unbox<string> surface?kind = "Observed") "The real surface result kind differs"
    require (unbox<string> surface?ending?kind = "Exited") "The surface lost normal exit evidence"
    require (unbox<int> surface?ending?exitCode = 128) "The surface changed the real exit code"
    require (unbox<bool> surface?output?complete) "The surface changed complete output"
    requireBytes outputBytes (unbox<byte[]> surface?output?stdout)
    requireBytes errorBytes (unbox<byte[]> surface?output?stderr)

    return createObj
        [ "accepted" ==> true
          "inputBytes" ==> outputBytes.Length
          "stderrBytes" ==> errorBytes.Length
          "combinedOutputLimit" ==> limit
          "rawExitCodes" ==> [| 7; 128 |]
          "storeFailureExitCodes" ==> [| 7; 128 |]
          "binaryColdRead" ==> true
          "utf8TreeOrder" ==> true
          "missingObjectIsError" ==> true
          "missingTreeIsError" ==> true
          "missingRefIsNone" ==> true
          "permissionIsError" ==> true
          "unknownIsError" ==> true
          "surfaceExit128" ==> true ]
}
