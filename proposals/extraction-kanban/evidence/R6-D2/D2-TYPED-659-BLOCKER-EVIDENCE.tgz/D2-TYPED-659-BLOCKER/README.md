# D2 candidate 659 independent typed review: not accepted

Candidate: `wanxiangshu-0.9.0.tgz`, SHA256
`a6a78e40f594a4879e278488dc2196e951278a69149f64fa0da0afef253602de`.
Runtime product: actual npm clean install at
`/private/tmp/d2-clean-install-659/node_modules/wanxiangshu`.
Dependency observed by the layered probe: its nested installed wanxiangli 0.6.9.
Hosts: Node 26.6.0 and Bun 1.3.14, macOS arm64, Git 2.50.1 (Apple Git-155).

The real F# consumer compiled against the complete 30-input owner closure,
including actual GitTypes.fsi, ProcessGitRawStore.fsi, GitRawSurface.fsi and
ProcessRequest.fsi. All five negative programs failed at the intended source:
missing OutputLimit, unwrapped Result, treating byte[] as text, and the removed
ReadObject/ReadTree optional return types. The real source digests are saved.

Before running, all emitted production implementation JS was deleted. The
unchanged emitted consumer JS used directory links only to this installed
product's dist modules, plus Node standard modules. It ran successfully on
Node, covering real exit 7/128 with binary stdout/stderr, Error.Result
preservation, explicit combined OutputLimit, byte-exact cold blob reads,
UTF-8 Git tree ordering, object/tree missing as Error, ref missing as None,
ref EACCES as Error, and injected Unknown as Error. These are internal F#
contracts, not a new npm .d.ts or npm public export.

Bun failed at the very first raw exit-7 binary comparison. Do not report the
candidate as accepted on both hosts. The initial failure is kept in
`typed-first-anu6Iw`; its message lacked the byte lengths. A private diagnostic
change added stages and lengths without changing the expected byte assertion.
The second run, `typed-diagnostic-seaVR9`, checked exactly the same production
source digests and fixed tarball. It observed expected 2,097,169 stdout bytes
versus actual 1,048,576 at `D2 typed raw exit 7`. The matched result had normal
exit 7, no stop, no fault, and complete output. The candidate archive and
installed package files were unchanged after both runs.

## Layered physical localization

The independent JS probe repeats the same BOM/NUL/0xff/all-byte-pattern input
through actual fixed-product RawRunner, its installed SupervisedProcess,
installed base Capture ProcessSession, and native runtime stdin. Each transport
runs real Git aliases which cat/tee stdin, and a hash-object positive control.
No product source or dist is modified.

Node passes all transports and commands. Under Bun:

- RawRunner and direct SupervisedProcess cat produce only approximately
  0.94--1 MiB from a Written 2 MiB+17 input, preserving normal exit 7 and no
  failure. Base Capture and native FileSink controls receive all bytes.
- A real target-side `tee` file contains exactly the same shortened prefix as
  its stdout. This falsifies the initial hypothesis of capture-only output
  loss: the target itself received fewer input bytes. The raw and direct
  supervised target files, stdout and stderr are retained as binary evidence.
- Hash-object receives the full same input on all four transports and returns
  the independently computed original-input Git OID. It does not echo while
  reading, so this positive control does not disprove the pipe/backpressure
  truncation demonstrated by cat/tee.
- Native Bun reports an immediate short write count and flush/end counts of
  zero while its actual target receives every byte. Those counts cannot be
  reinterpreted as evidence of actual partial consumption.

The short count varies by one 64 KiB chunk; it is not a stable product limit.
The final diagnostic explicitly exits 1 if any byte comparison differs.
Earlier diagnostic versions recorded `equal:false` without making the script
exit nonzero; their exit 0 was never treated as acceptance.

The extra failing boundary is the Worker input forwarding hop under a target
which reads and emits output concurrently. A source change has not yet been
tested here, so this archive does not claim a final root cause or repair.
The input/EOF truncation remains a blocker. It is separate from the previous
0.6.9 immediate-FileSink-count repair, and its precise historical attribution
has not been established by this probe.

## Files and cleanup

`binary-red/` retains the actual input, target-side files, stdout and stderr
from the final explicit red run. `layered/` retains initial, witness and red
logs plus the portable probe. `typed-*` retain all original compiler/runtime
outputs, F# consumer programs, negative programs, emitted JS, import links,
commands/statuses, byte digests and scratch cleanup receipts.

The layered sessions reached Closed and the probe removed its temporary Git
repositories after copying binary evidence. Natural-completion/Closed is the
per-scope proof here; independent per-PID sampling is not claimed for every
typed Git execution. The typed runner removes all compilation/runtime scratch
and preserves the fixed installation. No source fallback or dotnet build was
used. R12-U1 remains excluded.

## Replay

With the same matching source checkout and a clean installation of the fixed
tarball, run the typed runner with its adjacent F# programs:

```sh
node typed-diagnostic-seaVR9/d2-typed-fixed-package-runner.mjs MATCHING_CHECKOUT CLEAN_INSTALLED_PRODUCT candidate/wanxiangshu-0.9.0.tgz a6a78e40f594a4879e278488dc2196e951278a69149f64fa0da0afef253602de typed-diagnostic-seaVR9/real-source-inputs.json
```

The compiler uses only the matching checkout as a declared test tool and for
actual interface compilation. Generated production outputs are deleted before
runtime; the consumer's imports point only to the clean fixed package.

The physical localization probe requires no checkout or compiler:

```sh
bun layered/d2-single-input-probe.mjs CLEAN_INSTALLED_PRODUCT NEW_BINARY_EVIDENCE_DIRECTORY > bun-layered.json
node layered/d2-single-input-probe.mjs CLEAN_INSTALLED_PRODUCT > node-layered.json
```

The Bun command is expected to exit 1 on candidate 659. Its stdout JSON exposes
all values and actual target file byte hashes. Do not replace that failure with
a smaller input, a text decoder, or a different expected length.
