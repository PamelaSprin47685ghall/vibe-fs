# Corrected managed-chat-execution/005 independent check

The frozen corrected fixture SHA-256 is `fc265d95f672ee07d939e872cadf0c1f866c3e1354fcd547a2fb6c15f4ae4c86`.
The original fixture SHA-256 is `b5c2998e6dbc1483ef384844a2c808e9165b602a62493961f4d5e72f3beaaac9`.
Both complete source versions and their exact diff are retained.

Only that test file was copied into the existing private baseline checkout. A full comparison of all 7206 checkout records against the original 700 baseline confirms this is the sole changed file. No production, support, requirement or assertion was independently edited by this reviewer.

The same target test was run once for each fixed package/Host pair:

| Fixed package | Host | Actual selected test result |
| --- | --- | --- |
| 697 | Node | 1 pass, 0 fail |
| 697 | Bun | 1 pass, 0 fail; 5 other tests filtered |
| 700 | Node | 1 pass, 0 fail |
| 700 | Bun | 1 pass, 0 fail; 5 other tests filtered |

The unchanged real Plugin fixture still calls public `import('wanxiangshu')` and plugin.server. Public Plugin resolution for every run is recorded against the corresponding fixed installed package. All product files and the selected test input remain unchanged before/after every run. Original stdout/stderr, including native cache diagnostics, and exact command arrays are retained. No parent timeout termination occurs.

The corrected source clones the original complete Host request before the first transform can change its presentation. It explicitly expects the same-physical-user body overwrite to reject with the existing material identity conflict. The following transform with the original request then resolves. Existing assertions retain exactly one durable ProviderStarted, the exact first real observed assistant identity, and no replacement prompt to that physical execution.

This confirms that the negative observation does not prevent this valid replay from completing. It does not claim complete execution health beyond those observations, a real tool-call/result carrier chain, the full WHAT[managed-chat-execution-005] requirement, or a production-code fix. The original invalid body-overwrite fixture remains red in the independently archived 697/700 baseline. interaction-authority/021 and GAP-124 were not retested or reclassified here. R12-U1 was not investigated.

## Input composition and replay

This is an incremental evidence archive. Its complete unchanged source/support, requirements, resources and exact 697/700 package tars are in the prior companion archive `GAP140-B1-RELATED-697-700-BASELINE-20261019.tgz`, SHA-256 `99224599e01cc9a25cda0f227c6905523c716d5698916f68a757b80e9f4b9953`. That archive also retains the original two failures. Apply only the included corrected 005 source snapshot to its private checkout; do not change any support or product file.

For replay, bind the private checkout's dist symlink to the selected fixed product, keep its explicit installed peer dependencies, and run `node run.mjs LABEL HOST ABSOLUTE_PRODUCT_ROOT ABSOLUTE_PRIVATE_CHECKOUT`. The driver verifies the binding, uses only its private HOME/TMPDIR, refuses to overwrite an output directory, and does not alter the dist link while a child is running. Node and Bun are executed together only while they share the same fixed product; the product binding is switched after both finish.

Only regenerable Bun caches are omitted from this incremental archive; every omitted file is listed with its hash. All new raw outputs, metadata, original/corrected fixture bytes and exact driver source are included. The full baseline archive is referenced by its immutable hash rather than duplicated.
