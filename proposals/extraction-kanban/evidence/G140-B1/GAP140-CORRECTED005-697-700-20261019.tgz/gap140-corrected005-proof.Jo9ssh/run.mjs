import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { createHash } from 'node:crypto'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
const [label, host, product, checkout] = process.argv.slice(2)
const root = path.dirname(fileURLToPath(import.meta.url))
const output = path.join(root, label + '-' + host)
if (fs.existsSync(output)) throw new Error('Refuse to overwrite evidence')
if (fs.realpathSync(path.join(checkout, 'dist')) !== fs.realpathSync(path.join(product, 'dist'))) throw new Error('Private dist binding does not match requested product')
const home = path.join(output, 'home')
const tmp = path.join(output, 'tmp')
fs.mkdirSync(home, { recursive: true })
fs.mkdirSync(tmp, { recursive: true })
const env = { ...process.env, HOME: home, USERPROFILE: home, TMPDIR: tmp }
delete env.NODE_TEST_CONTEXT
delete env.NODE_OPTIONS
delete env.WANXIANGSHU_NO_FATAL_EXIT
const hash = bytes => createHash('sha256').update(bytes).digest('hex')
function inventory(base) {
  const rows = []
  function visit(relative = '') {
    for (const item of fs.readdirSync(path.join(base, relative), { withFileTypes: true })) {
      const next = path.join(relative, item.name)
      if (item.isDirectory()) visit(next)
      else if (item.isFile()) rows.push({ file: next, sha256: hash(fs.readFileSync(path.join(base, next))) })
      else rows.push({ file: next, kind: 'symlink', target: fs.readlinkSync(path.join(base, next)) })
    }
  }
  visit()
  return rows.sort((a, b) => a.file.localeCompare(b.file))
}
const input = 'requirements/managed-chat-execution/tests/005.test.mjs'
const pattern = 'transform durably starts the real assistant observed before its attempt plan existed'
const args = host === 'node' ? ['--test', '--test-name-pattern', pattern, input] : ['test', '--test-name-pattern', pattern, input]
const result = { label, host, product, checkout, executable: host === 'node' ? process.execPath : host, args,
  input, beforeInputSha256: hash(fs.readFileSync(path.join(checkout, input))),
  resolvedPublicPlugin: fs.realpathSync(path.join(checkout, 'dist/OpenCode/Plugin/Plugin.js')),
  beforeProduct: inventory(product) }
const started = performance.now()
try {
  const actual = await promisify(execFile)(result.executable, args, { cwd: checkout, env, timeout: 30000, maxBuffer: 16 * 1024 * 1024 })
  result.code = 0
  fs.writeFileSync(path.join(output, 'stdout.log'), actual.stdout)
  fs.writeFileSync(path.join(output, 'stderr.log'), actual.stderr)
} catch (error) {
  result.code = error.code
  result.signal = error.signal
  result.killed = error.killed
  result.message = error.message
  fs.writeFileSync(path.join(output, 'stdout.log'), error.stdout ?? '')
  fs.writeFileSync(path.join(output, 'stderr.log'), error.stderr ?? '')
}
result.elapsedMs = performance.now() - started
result.afterProduct = inventory(product)
result.productUnchanged = JSON.stringify(result.beforeProduct) === JSON.stringify(result.afterProduct)
result.afterInputSha256 = hash(fs.readFileSync(path.join(checkout, input)))
result.inputUnchanged = result.beforeInputSha256 === result.afterInputSha256
fs.writeFileSync(path.join(output, 'run.json'), JSON.stringify(result, null, 2) + '\n')
console.log(JSON.stringify({ label, host, code: result.code, elapsedMs: result.elapsedMs, productUnchanged: result.productUnchanged,
  inputUnchanged: result.inputUnchanged, resolvedPublicPlugin: result.resolvedPublicPlugin }))
if (result.code !== 0 || !result.productUnchanged || !result.inputUnchanged) process.exitCode = 1
