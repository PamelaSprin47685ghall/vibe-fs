# GAP-140 B1 fixed production700 independent acceptance

Fixed npm tar SHA256: `2a7a80267723c9be3fe03cc526257e6585b5f446b5474d6919d3fb17316e5231`.
Actual clean npm installation: 124 packages. Node26.6.0, Bun1.3.14. No shared source edits; no active source reads. The permanent fixture was explicitly frozen by its author and copied byte for byte before execution.

## Product identity

All 2076 packaged files matched the fixed tar before testing and stayed byte identical afterward. The prototype generation2 had 895 dist files; the comparison found exactly two changed files:

- `Interaction/Dispatch/Dispatcher.js`: the expected equivalent joiner success dispatch via `Result_Iterate`, preserving thrown joiner errors.
- `OpenCode/Tools/StaticTools.js`: only the absolute source-path string in an existing MatchFailureException changed from the private prototype source location to the main build location. This is diagnostic text, not an implementation import or repository fallback.

`PromptJournalAdapter` and the other compared dist files were identical. Runtime in every test comes only from the actual clean installed700 product and its declared installed dependencies.

## Independent results: 22 checks, 11 per Host

Six original non-author cases per Host, copied unchanged from the archived prototype evidence:

1. Actual Journal owner/session/occasion/reopen matrix: same Journal owns one shared factory Runtime, fresh durable authority reads, concurrent exact gate sends once, different session/terminal/gate sends independently, completed duplicate does not renew, reopened Journal gets a distinct owner and durable dedupe still rejects replay.
2. Same Journal lawful A accepted → A closed → no authority denies send → B accepted: the cached Runtime sees every actual change and sends only under B.
3. Observed receipt-before-physical case: actual lease registrations `[1,1]`; latest owner receives acceptance `[0,1]`. Send count one.
4. Physical caller ownership: after actual managed acceptance the first replaced waiter remains pending, second receives the real physical id. This is the preserved existing limitation, **not** a claim that both callers settle.
5. Joiner AttachDisposable throws the exact sentinel: only joiner fails with the original Error object, first flight succeeds, no duplicate send, next independent occasion still works.
6. Actual Retryable outcome: joiner does not register; failed sender releases its registration; next independent occasion works.

Five permanent `gate-joiner.fixture.mjs` scenarios per Host, source copied without edits:

- accepted: shared send once, both real leases, replacing/disposing old lease leaves latest observer notified once.
- physical-before-receipt: real managed physical acceptance before controlled transport receipt; first already notified and successful joiner reads the actual landed result; notifications `[1,1]`, registrations `[1,0]`. This is late observation of an existing landing, not callback broadcast.
- attach-throws: original joiner Error object is preserved, first sender remains successful.
- send-fails: no joiner registration; durable Abandoned allows a subsequent exact attempt, send count two after that intentional retry.
- unknown: no joiner registration; exact repeated occasion is AlreadyAdmitted and does not resend, send count one.

All 22 checks exited0. Original Journal NDJSON, raw outputs and receipts are retained. The permanent fixture SHA256 is `b776a2d1616de499c7bb7846bfb273aa6524da09d4ff51352c8348fd8fafb96b`.

## Scope

These are actual fixed-package Journal/HostSessionNudge/managed-acceptance consumers at controlled Host and lease boundaries. They do not send to an external provider. The fixtures consume internal F# emitted modules, not a new public npm JS API. B2 raw-ledger concurrent duplicate facts, cross-process arbitration and the rest of GAP-140 remain separate. A replaced Physical waiter may remain pending in memory; all probe processes still exit and Journal handles are disposed. Do not turn this local evidence into whole-card closure.

The private prototype's original broad broadcast assertion and first-generation missing-joiner evidence remain in the separate immutable prototype archive. This production archive supplements it without replacing or relabeling those results.

## Portable replay

```sh
node replay.mjs /absolute/extracted/review-root /absolute/fresh/output
```

The runner installs the exact archived700 tar in a fresh project, then runs these 22 checks using that installation only. It saves commands, child status, raw outputs and retained Journal receipts. No build, product mutation, source implementation or main dist fallback is allowed. Replaying does not add new semantic cases to the count.

The portable runner was actually executed once against a second fresh npm installation: all 22 checks accepted. Its commands/status/raw outputs and Journal originals are included under `portable-replay`. This is a reproducibility check, not 22 additional distinct semantic cases.
