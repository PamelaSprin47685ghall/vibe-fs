import assert from 'node:assert/strict'
import fs from 'node:fs'
import { join, resolve } from 'node:path'
import { createHash } from 'node:crypto'
import { spawnSync } from 'node:child_process'

const [archiveArg, outputArg] = process.argv.slice(2)
const archive = resolve(archiveArg)
const output = resolve(outputArg)
assert.equal(fs.existsSync(output), false)
fs.mkdirSync(output, { recursive: true })
const tar = join(archive, '700.tgz')
assert.equal(createHash('sha256').update(fs.readFileSync(tar)).digest('hex'), '2a7a80267723c9be3fe03cc526257e6585b5f446b5474d6919d3fb17316e5231')
const env = { ...process.env }
delete env.NODE_OPTIONS
delete env.NODE_TEST_CONTEXT
const commands = []
function run(name, executable, args) {
  const result = spawnSync(executable, args, { cwd: output, env, encoding: 'utf8', timeout: 60000 })
  fs.writeFileSync(join(output, `${name}.stdout`), result.stdout || '')
  fs.writeFileSync(join(output, `${name}.stderr`), result.stderr || '')
  commands.push({ name, executable, args, status: result.status, signal: result.signal, error: result.error?.message || null })
  fs.writeFileSync(join(output, 'commands-status.json'), JSON.stringify(commands, null, 2) + '\n')
  assert.equal(result.status, 0, `${name}: ${result.stderr}`)
  assert.equal(result.signal, null)
}
run('install', 'npm', ['install', '--ignore-scripts', '--no-audit', '--no-fund', tar])
const product = join(output, 'node_modules/wanxiangshu')
for (const host of ['node', 'bun']) {
  run(`${host}-ownership`, host, [join(archive, 'ownership.mjs'), product, join(output, `${host}-ownership`)])
  run(`${host}-root`, host, [join(archive, 'root-lifecycle.mjs'), product, join(output, `${host}-root`)])
  for (const variant of ['observed', 'physical']) run(`${host}-${variant}`, host, [join(archive, 'acceptance-owner-contract.mjs'), product, join(output, `${host}-${variant}`), variant])
  for (const scenario of ['attach-throws', 'send-fails']) run(`${host}-${scenario}`, host, [join(archive, 'joiner-faults.mjs'), product, join(output, `${host}-${scenario}`), scenario])
  for (const scenario of ['accepted', 'physical-before-receipt', 'attach-throws', 'send-fails', 'unknown']) {
    const directory = join(output, `permanent-${host}-${scenario}`)
    run(`permanent-${host}-${scenario}`, host, [join(archive, 'gate-joiner.fixture.mjs'), product, directory, scenario, join(directory, 'result.json')])
  }
}
fs.writeFileSync(join(output, 'summary.json'), JSON.stringify({ accepted: true, cases: 22, fixedProduction: 700,
  existingReplacedPhysicalWaiterCanRemainPending: true, closesGAP140: false }, null, 2) + '\n')
console.log(JSON.stringify({ accepted: true, cases: 22, output }))
