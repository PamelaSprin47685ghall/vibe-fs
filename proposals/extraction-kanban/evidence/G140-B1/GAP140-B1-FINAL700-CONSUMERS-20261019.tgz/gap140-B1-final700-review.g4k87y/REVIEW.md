# B1 final package 700 independent consumer evidence

Exact package: `wanxiangshu-0.9.0.tgz`, SHA-256 `2a7a80267723c9be3fe03cc526257e6585b5f446b5474d6919d3fb17316e5231`.
The private clean installation has its own package lock and explicit peers. No main, prototype, consumer or installed product file was edited.

## Actual outcomes

Each row was run once on Node and once on Bun, with private HOME/routing and separate owned stores:

| Consumer | Result on both Hosts |
| --- | --- |
| original unchanged concurrent-child | original assertion remains red: facts 2 != 1; actual recovery SendPrompt delta 1, handled [true,true], projection count 1 |
| new permanent concurrent-recovery fixture | green: both observations settle, actual recovery SendPrompt delta 1, late identical observe settles and causes no additional send; facts remain diagnostic count 2 |
| actual native write + fsync + owned release then injected exception | green: CommitUnknown at StoreRelease, original cause message, zero SendPrompt, exact repeat adds zero sends/appends; independent cold count 1 |
| actual healthy writer | green: one durable failure fact, one recovery SendPrompt, independent cold count 1 |

This is eight producer processes and four independent cold processes. The original strong fact-count assertion was not weakened, and its two raw failures remain preserved. The new permanent fixture deliberately tests B1 send ownership and settlement; it does not establish B2 fact atomicity. The producer's actual Host-port calls are measured, not external provider network requests.

The original consumer SHA-256 remains `a1003011132a42f914098e878fd6d46659518830ffc2f1f34684d3c6a4090709`. New permanent fixture source is an exact frozen copy of the requested repository file and is archived with its hash. No dynamic import or assertion rewriting is used.

## Input and resource evidence

All 2076 installed product files match the original package tar byte-for-byte after execution. Each producer also hashes the complete installed package before/after; all comparisons are unchanged. Package, installation log, lock, consumer source, exact source hashes, actual NDJSON, complete receipts and stdout/stderr are retained.

Every producer records successful closeRecovery, no owned lock remains, and all processes exit without parent timeout termination. Each cold reader preserves the original event bytes and creates no file for its reader writer identity. The injected native fs wrappers delegate all nonfault calls to the original physical functions; Bun installs them using its public mock.module before product imports. The formatted error exposes cause message and phase, not typed original Error identity/code.

The previous 697 to 700 product difference is recorded by exact file hashes in `697-700-product-diff.json`. The prior 697/B1 prototype comparison, including its original bounded red and duplicate facts, remains in `GAP140-B1-INDEPENDENT-ORIGINAL-CONSUMER-20261019.tgz` (SHA-256 `a34b9a7194e4b91884ee81c3e8bb17c11b3d9a02c638058a7f80cd40876ace29`). Final green B1 evidence does not replace those red artifacts.

## Scope

These experiments directly call concurrent SyncDelegate HandleTurn in one live journal/runtime, bypassing ordinary per-session scheduling. They do not establish ordinary public Host reachability. B2 atomic failure facts and cold ordinary Workflow remain open. The 12-round budget experiment is not repeated because the budget implementation is unchanged; its final 697 evidence remains separate. R12-U1 was not investigated.

## Replay

Install the archived exact tar with the supplied package.json/lock in a fresh private directory. Run `node run.mjs HOST SCENARIO`, with HOST `node` or `bun`, and SCENARIO `original`, `permanent`, `after-release`, or `valid`. Existing output directories are never overwritten. The original scenario is expected to exit 1 at its unchanged fact-count assertion.

Only installed dependencies, the duplicate tar extraction and regenerable Bun caches are omitted from the compact archive. `omissions.json` lists every omitted file and hash. No actual event byte, log, receipt, script, package or failure artifact is omitted.
