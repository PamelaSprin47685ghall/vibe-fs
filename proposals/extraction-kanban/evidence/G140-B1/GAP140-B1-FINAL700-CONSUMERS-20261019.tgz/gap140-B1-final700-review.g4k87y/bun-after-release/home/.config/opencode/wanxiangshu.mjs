export const routingProtocol = 2
export default function route(role) { return { model: 'provider/' + role + '-model', reasoning: 'none' } }
export const predictorConfiguration = () => ({state:'unconfigured',reason:null})
