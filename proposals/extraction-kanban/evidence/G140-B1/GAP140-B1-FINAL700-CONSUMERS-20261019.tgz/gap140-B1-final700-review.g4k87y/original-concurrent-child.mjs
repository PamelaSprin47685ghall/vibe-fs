import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
import { randomUUID } from 'node:crypto'
const [product, directory, receiptPath] = process.argv.slice(2)
const imported = relative => import(pathToFileURL(path.join(product, 'dist', relative)).href)
const sync = await imported('Execution/Delegation/SyncDelegate/Surface.js')
const dispatch = await imported('Interaction/Dispatch/DispatchSurface.js')
const failure = await imported('Participant/Provider/Attempt/Fallback/ProviderFailureSurface.js')
const owner = 'gap140-concurrent-' + randomUUID()
const providerRun = 'gap140-concurrent-provider-' + randomUUID()
const reason = 'GAP140_CONCURRENT_IDENTICAL_FAILURE_' + randomUUID()
const result = { pid: process.pid, runtime: process.version, bun: process.versions.bun ?? null, product, directory, providerRun, reason,
  scope: 'Actual SyncDelegate HandleTurn callable consumer; ordinary production per-session Scheduler is bypassed intentionally' }
let runtime
async function bounded(action, label) {
  let timer
  try { return await Promise.race([action, new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(label + ' did not settle')), 8000) })]) }
  finally { clearTimeout(timer) }
}
try {
  runtime = await sync.createForProviderRecovery(directory, [{ sessionId: owner, agent: 'manager' }])
  const execution = sync.startObserved(runtime, owner, 'GAP140 simultaneous identical failure')
  await bounded(sync.awaitPromptCount(runtime, owner, 'Engineer', 1), 'initial real send')
  assert.equal(sync.returnPromptOutcome(runtime, owner, 'Engineer', 0, dispatch.admittedWithReceipt('concurrent-initial')), true)
  const initial = await sync.confirmManagedPromptPhysical(runtime, owner, 'Engineer', 0, 'concurrent-initial-physical')
  assert.equal(initial.ok, true)
  await bounded(sync.observedAdmission(execution), 'initial admission')
  result.initial = initial
  assert.equal(sync.observeProviderFailureStop(runtime, initial.sessionId, providerRun), true)
  const first = sync.observeExactProviderFailure(runtime, initial.sessionId, initial.physicalUserMessageId, initial.authorityRootUserMessageId, providerRun, reason)
  const second = sync.observeExactProviderFailure(runtime, initial.sessionId, initial.physicalUserMessageId, initial.authorityRootUserMessageId, providerRun, reason)
  result.observations = ['pending', 'pending']
  first.then(value => { result.observations[0] = { handled: value } }, error => { result.observations[0] = { error: error.message } })
  second.then(value => { result.observations[1] = { handled: value } }, error => { result.observations[1] = { error: error.message } })
  await bounded(sync.awaitPromptCount(runtime, owner, 'Engineer', 2), 'one concurrent recovery real send')
  assert.equal(sync.returnPromptOutcome(runtime, owner, 'Engineer', 1, dispatch.admittedWithReceipt('concurrent-retry')), true)
  result.handled = await bounded(Promise.all([first, second]), 'both recovery observations')
  result.totalPrompts = sync.promptCount(runtime, owner, 'Engineer')
  result.sendDelta = result.totalPrompts - 1
  result.state = await sync.withJournal(runtime, async journal => failure.snapshot(journal, initial.sessionId))
  const events = path.join(directory, 'wanxiangshu', 'events')
  result.actualFailureFacts = fs.readdirSync(events).filter(name => name.endsWith('.ndjson')).flatMap(name =>
    fs.readFileSync(path.join(events, name), 'utf8').trimEnd().split('\n').filter(Boolean).map(JSON.parse)).filter(fact => JSON.stringify(fact).includes(reason))
  assert.equal(result.sendDelta, 1)
  assert.equal(result.state.failures, 1)
  assert.equal(result.actualFailureFacts.length, 1)
  result.accepted = true
} catch (error) {
  result.accepted = false
  result.error = { name: error.name, message: error.message, stack: error.stack }
  if (runtime && result.initial) {
    result.totalPromptsAtRefusal = sync.promptCount(runtime, owner, 'Engineer')
    result.sendDeltaAtRefusal = result.totalPromptsAtRefusal - 1
    result.stateAtRefusal = await sync.withJournal(runtime, async journal => failure.snapshot(journal, result.initial.sessionId))
    const events = path.join(directory, 'wanxiangshu', 'events')
    result.actualFailureFactsAtRefusal = fs.readdirSync(events).filter(name => name.endsWith('.ndjson')).flatMap(name =>
      fs.readFileSync(path.join(events, name), 'utf8').trimEnd().split('\n').filter(Boolean).map(JSON.parse)).filter(fact => JSON.stringify(fact).includes(reason))
  }
  process.exitCode = 1
} finally {
  if (runtime) {
    try { await bounded(sync.closeRecovery(runtime), 'owned recovery close'); result.closed = true }
    catch (error) { result.cleanupError = error.message; process.exitCode = 1 }
  }
  fs.writeFileSync(receiptPath, JSON.stringify(result, null, 2) + '\n')
}
