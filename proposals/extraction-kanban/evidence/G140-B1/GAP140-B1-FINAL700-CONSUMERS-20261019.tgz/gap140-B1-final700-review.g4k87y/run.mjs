import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { createHash } from 'node:crypto'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
const [host, scenario] = process.argv.slice(2)
const root = path.dirname(fileURLToPath(import.meta.url))
const product = path.join(root, 'node_modules', 'wanxiangshu')
const output = path.join(root, host + '-' + scenario)
if (fs.existsSync(output)) throw new Error('Refuse to overwrite evidence')
const home = path.join(output, 'home')
const store = path.join(output, 'store')
fs.mkdirSync(path.join(home, '.config', 'opencode'), { recursive: true })
fs.mkdirSync(store, { recursive: true })
fs.writeFileSync(path.join(home, '.config', 'opencode', 'wanxiangshu.mjs'), `export const routingProtocol = 2
export default function route(role) { return { model: 'provider/' + role + '-model', reasoning: 'none' } }
export const predictorConfiguration = () => ({state:'unconfigured',reason:null})
`)
const env = { ...process.env, HOME: home, USERPROFILE: home }
delete env.NODE_TEST_CONTEXT
delete env.NODE_OPTIONS
delete env.WANXIANGSHU_NO_FATAL_EXIT
const hash = bytes => createHash('sha256').update(bytes).digest('hex')
function inventory(base) {
  const rows = []
  function visit(relative = '') {
    for (const entry of fs.readdirSync(path.join(base, relative), { withFileTypes: true })) {
      const next = path.join(relative, entry.name)
      if (entry.isDirectory()) visit(next)
      else if (entry.isFile()) {
        const bytes = fs.readFileSync(path.join(base, next))
        rows.push({ file: next, bytes: bytes.length, sha256: hash(bytes) })
      } else rows.push({ file: next, kind: 'symlink', target: fs.readlinkSync(path.join(base, next)) })
    }
  }
  visit()
  return rows.sort((a, b) => a.file.localeCompare(b.file))
}
const faultScenario = scenario === 'after-release' || scenario === 'valid'
const source = path.join(root, faultScenario ? 'physical-child.mjs' : scenario === 'original' ? 'original-concurrent-child.mjs' : 'permanent-concurrent-recovery.fixture.mjs')
const result = { host, scenario, product, executable: host === 'node' ? process.execPath : host,
  sourceSha256: hash(fs.readFileSync(source)), before: inventory(product), outcomes: [],
  tgz: '/private/tmp/gap140-B1-candidate-700/wanxiangshu-0.9.0.tgz',
  tgzSha256: hash(fs.readFileSync('/private/tmp/gap140-B1-candidate-700/wanxiangshu-0.9.0.tgz')) }
async function child(name, args) {
  const started = performance.now()
  try {
    const value = await promisify(execFile)(result.executable, args, { cwd: output, env, timeout: 20000, maxBuffer: 8 * 1024 * 1024 })
    result.outcomes.push({ name, code: 0, elapsedMs: performance.now() - started })
    fs.writeFileSync(path.join(output, name + '.stdout.log'), value.stdout)
    fs.writeFileSync(path.join(output, name + '.stderr.log'), value.stderr)
    return true
  } catch (error) {
    result.outcomes.push({ name, code: error.code, signal: error.signal, killed: error.killed, message: error.message,
      elapsedMs: performance.now() - started })
    fs.writeFileSync(path.join(output, name + '.stdout.log'), error.stdout ?? '')
    fs.writeFileSync(path.join(output, name + '.stderr.log'), error.stderr ?? '')
    return false
  }
}
const receipt = path.join(output, 'physical.json')
const args = faultScenario ? [product, store, scenario, receipt] : [product, store, receipt]
if (await child('physical', [source, ...args]) && faultScenario) {
  await child('cold', [path.join(root, 'cold-child.mjs'), product, receipt, path.join(output, 'cold.json')])
}
result.after = inventory(product)
result.packageUnchanged = JSON.stringify(result.before) === JSON.stringify(result.after)
result.lockPresentAfterExit = fs.existsSync(path.join(store, 'wanxiangshu.lock'))
result.code = result.outcomes[0]?.code
fs.writeFileSync(path.join(output, 'run.json'), JSON.stringify(result, null, 2) + '\n')
console.log(JSON.stringify({ host, scenario, outcomes: result.outcomes.map(item => ({ name: item.name, code: item.code, elapsedMs: item.elapsedMs })),
  packageUnchanged: result.packageUnchanged, lockPresentAfterExit: result.lockPresentAfterExit }))
if (result.code !== 0 || !result.packageUnchanged || result.lockPresentAfterExit) process.exitCode = 1
