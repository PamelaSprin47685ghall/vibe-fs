# G140-B1 root verification

Base: 8b5dd03f7. Product: candidate-706.tgz, SHA256 8572c309c3c5e64011e51972a70058c044b5cfd1478a650a460e64f2de4d2be2. Library: 8bb1021 / 0.6.12.

source-inputs.tgz preserves every changed program/test file plus the plan/report snapshot. Restore over the exact base checkout; worktree.patch is an additional review diff, not a second overlay to apply after the tar. The archive does not vendor all repository dependencies; use the preserved exact lock and the existing package workflow. No offline or standalone replay is claimed for this root archive.

Raw logs include the unchanged-product baseline 003 red (explicit staleness bypass, not acceptance), first incomplete fixture red, bounded fixture red, private prototype build setup/syntax reds and repairs, format/control-pyramid and JS DU-shape gate reds and fixes, candidate700 focused18pass/2TODO, initial142 related607pass/3fail/6skip/93TODO, R1 deterministic red/green, complete R1 seven-file323pass/0fail/0skip/0TODO on702, corrected142 related609pass/1fail/6skip/93TODO on704, and final148 related653pass/1fail/6skip/95TODO on706. All final files drained; owned group cleanup was accepted. The remaining ordinary failure is the existing GAP124 historical Inspector test; no complete-suite acceptance is claimed.

The product-byte check confirms700 matched2076 package files through704. The700-to706 comparison confirms exactly one changed file, DispatchSurface.js; all2075 other package files are identical. The latter change provides a typed registered JSON boundary for permanent probes, not another recovery implementation. The first private prototype's StaticTools.js delta was only an absolute compiler source path; it is not part of this product change.

recovery-single-send-PwDR0o contains the first fixture's incomplete state without a result receipt; do not call it a completed product observation. recovery-single-send-UoUSxb contains the bounded pre-fix actual concurrent recovery red. gate-joiner-sywGpF contains the formal transport-registration race before the physical child began. The old baseline assertions remain in the logs; passing a retry after an ordinary duplicate is not atomic ledger evidence.

The separate independent archives contain exact fixed-package consumers, Node/Bun JSON contracts, original concurrent facts1 strong red, real writer fault/cold controls, Node26/22.13 real socket/native ordering, and corrected005 four-way baseline. B2 cross-OS red and its compact restore limitations are separate. R12-U1 was not investigated.

No registry publication or Host deployment occurred.
