import assert from 'node:assert/strict'
import fs from 'node:fs'
import { join, resolve } from 'node:path'
import { createHash } from 'node:crypto'
import { spawnSync } from 'node:child_process'

const [archiveArg, outputArg] = process.argv.slice(2)
const archive = resolve(archiveArg)
const output = resolve(outputArg)
assert.equal(fs.existsSync(output), false)
fs.mkdirSync(output, { recursive: true })
const tar = join(archive, '706.tgz')
assert.equal(createHash('sha256').update(fs.readFileSync(tar)).digest('hex'), '8572c309c3c5e64011e51972a70058c044b5cfd1478a650a460e64f2de4d2be2')
const env = { ...process.env }
delete env.NODE_OPTIONS
delete env.NODE_TEST_CONTEXT
const commands = []
function run(name, executable, args) {
  const result = spawnSync(executable, args, { cwd: output, env, encoding: 'utf8', timeout: 20000 })
  fs.writeFileSync(join(output, `${name}.stdout`), result.stdout || '')
  fs.writeFileSync(join(output, `${name}.stderr`), result.stderr || '')
  commands.push({ name, executable, args, status: result.status, signal: result.signal, error: result.error?.message || null })
  fs.writeFileSync(join(output, 'commands-status.json'), JSON.stringify(commands, null, 2) + '\n')
  assert.equal(result.status, 0, `${name}: ${result.stderr}`)
  assert.equal(result.signal, null)
}
run('install', 'npm', ['install', '--ignore-scripts', '--no-audit', '--no-fund', tar])
const product = join(output, 'node_modules/wanxiangshu')
for (const host of ['node', 'bun']) {
  for (const scenario of ['accepted', 'physical-before-receipt', 'attach-throws', 'send-fails', 'unknown']) {
    const directory = join(output, `${host}-${scenario}`)
    run(`${host}-${scenario}`, host, [join(archive, 'gate-joiner.fixture.mjs'), product, directory, scenario, join(directory, 'result.json')])
  }
  run(`${host}-scope`, host, [join(archive, 'surface-scope.mjs'), product, join(output, `${host}-scope`)])
}
fs.writeFileSync(join(output, 'summary.json'), JSON.stringify({ accepted: true, permanentScenarios: 10, scopePrograms: 2,
  surfaceOnlyConsumers: true, fixedProduction: 706, closesGAP140: false }, null, 2) + '\n')
console.log(JSON.stringify({ accepted: true, permanentScenarios: 10, scopePrograms: 2 }))
