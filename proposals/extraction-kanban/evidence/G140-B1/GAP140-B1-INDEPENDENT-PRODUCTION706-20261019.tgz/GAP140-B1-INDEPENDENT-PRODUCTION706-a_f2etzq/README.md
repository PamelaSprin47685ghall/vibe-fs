# B1 final706 registered Surface consumer acceptance

Fixed tar SHA256: `8572c309c3c5e64011e51972a70058c044b5cfd1478a650a460e64f2de4d2be2`.
Real npm clean installation, Node26.6.0 and Bun1.3.14. No shared source edits. All tests below import only the actual fixed package's registered JournalSurface and DispatchSurface. Opaque Journal handles and lease resources are only passed back into those Surfaces.

## Corrected integration boundary

The earlier permanent gate fixture accessed internal Fable union/class representations directly. The final static gate correctly rejected that integration mistake. It was our integration/test-boundary mistake, not an original extraction defect or a reason for a waiver. Earlier raw700/prototype probes remain historical research evidence; they are **not** promoted as the final long-term JS contract acceptance.

The repair adds the declared `sendGateContinuationWithAcceptance` function to the existing DispatchSurface `.fsi`. Its implementation parses the continuation, constructs the typed observer, invokes the real HostSessionNudge with the actual PlainSessionPort and opaque JournalHandle, and converts its typed outcome to JSON `{kind,key,error}`. It duplicates no flight, budget, durable-dedupe or permission algorithm. It does not fabricate success. The Surface owner project now directly references SessionNudge, and the existing manifest is governed by dispatch-protocol law008. Exact `.fs`, `.fsi`, owner project, registry and WHAT bytes are archived under `source-contract`.

The permanent fixture now uses only Surface functions, including existing `disposePhysicalAcceptanceObserver` for every opaque lease. It has no Identity/Model/Nudge imports, union tags/cases or direct opaque-lease member access. The author owns the original static-gate rejection log; this archive records that reported finding without inventing a local static-gate run.

## Product identity

All 2076 packaged files matched tar before testing and stayed identical after testing. Independently compared700→706: **exactly one file changes**, `dist/Interaction/Dispatch/DispatchSurface.js`; all other2075 files are byte identical. Thus prior runtime implementation evidence is explicitly carried as historical research, while this archive separately proves the corrected registered Surface consumers. No raw22-case rerun is counted as new contract evidence.

## Actual final consumers

Ten permanent fixture scenarios: five on each Host, original frozen source copied without edits:

- accepted: one Host send, two real acceptance leases, latest observer notified once; disposing old lease cannot remove current observer.
- physical-before-receipt: actual managed physical acceptance precedes the controlled transport result; the joiner observes the real existing landing, not a synthetic callback broadcast.
- attach-throws: the original joiner Error object is preserved; first sender still succeeds.
- send-fails: no joiner lease; durable abandonment allows the subsequent exact attempt.
- unknown: no joiner lease; exact subsequent request is AlreadyAdmitted and does not resend.

Two independent `surface-scope.mjs` programs, one per Host. Each checks six groups through only the Surfaces:

1. No active authority and unknown continuation: zero Host sends, zero leases, all original durable bytes unchanged.
2. Same exact occasion shares one real send and one plain JSON key; another session remains independent.
3. Actual managed physical acceptance notifies only the latest owner; completed duplicate does not renew.
4. Different terminal/gate occasions remain independent.
5. Reopened Journal reads durable exact-occasion evidence and creates no send/write for a duplicate.
6. Reopened Journal still sends for a fresh independent occasion.

All twelve programs exited0. All original Journal NDJSON, receipts and raw output are retained. Scope assertions use only declared plain values and opaque capabilities; no private Fable representations are inspected.

## Limits and replay

The Host boundary is controlled; this does not send to an external provider. B2 concurrent ledger facts and the rest of GAP-140 remain separate. The existing replaced Physical waiter limitation was not reclassified as fixed. This is not a new public npm-root API or `d.ts` claim; it is consumption through the existing registered internal JS Surface contract.

```sh
node replay.mjs /absolute/extracted/review-root /absolute/fresh/output
```

The replay installs the archived706 tar and runs the same ten fixtures and two scope programs in fresh directories. It saves exact commands/status/raw and Journal originals. It does not compile source, mutate the package, or fall back to repository dist. A replay does not add new distinct semantic cases.

The replay was actually executed once using a second fresh npm installation, and all ten fixtures and both scope programs passed. The full install command/status/raw, lock file and all runtime receipts are included under `portable-replay`. No network fallback or borrowed repository dependencies were needed. Exact source/declaration snapshots are not counted as a new independent F# compilation.
