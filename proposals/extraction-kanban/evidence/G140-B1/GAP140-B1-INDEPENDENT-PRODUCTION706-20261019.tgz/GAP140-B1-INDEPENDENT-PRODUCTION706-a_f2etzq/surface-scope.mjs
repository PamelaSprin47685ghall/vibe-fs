import assert from 'node:assert/strict'
import fs from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'
import { createHash } from 'node:crypto'

const [product, directory] = process.argv.slice(2)
fs.mkdirSync(directory, { recursive: true })
const load = relative => import(pathToFileURL(join(product, 'dist', relative)).href)
const journal = await load('Persistence/Journal/Surface.js')
const dispatch = await load('Interaction/Dispatch/DispatchSurface.js')
const result = { pid: process.pid, product, sends: [], notifications: [0, 0, 0], checks: [] }
const leases = []
const releases = []
const waiters = []
const bytes = () => {
  const paths = path => fs.readdirSync(path).sort().flatMap(name => {
    const next = join(path, name)
    return fs.statSync(next).isDirectory() ? paths(next) : [next]
  })
  return paths(directory).map(path => ({ path: path.slice(directory.length + 1), bytes: fs.statSync(path).size,
    sha256: createHash('sha256').update(fs.readFileSync(path)).digest('hex') }))
}
const port = {
  SubscribeTerminal: () => ({ Dispose() {} }),
  SubscribeFutureTerminal: () => ({ Dispose() {} }),
  SendPrompt(session, text) {
    assert.equal(typeof session, 'string')
    result.sends.push({ session, text })
    for (const waiter of waiters) if (result.sends.length >= waiter.target) { clearTimeout(waiter.timer); waiter.accept() }
    return new Promise(accept => { releases.push(accept) })
  },
}
function awaitSends(target) {
  if (result.sends.length >= target) return Promise.resolve()
  return new Promise((accept, reject) => {
    const timer = setTimeout(() => reject(new Error(`Expected ${target} actual Host sends, saw ${result.sends.length}`)), 5000)
    waiters.push({ target, accept, timer })
  })
}
function releaseAll() {
  for (const accept of releases.splice(0)) accept(dispatch.admittedWithReceipt('controlled-scope-receipt'))
}
const disposeLeases = () => { for (const lease of leases.splice(0)) dispatch.disposePhysicalAcceptanceObserver(lease) }
const safe = pending => pending.then(value => ({ value }), error => ({ error }))
function unwrap(item) {
  assert.equal(item.error, undefined)
  assert.deepEqual(Object.keys(item.value).sort(), ['error', 'key', 'kind'])
  return item.value
}
let opened = await journal.JournalSurface_bootWithWriterId(directory, 'surface-scope-writer', 'surface-scope-runtime', process.pid, new Date().toISOString())
assert.equal(opened.ok, true)
const call = (session, gate = 'same-gate', terminal = 'same-terminal', observer = 0, kind = 'ProviderRetryAttempt') => dispatch.sendGateContinuationWithAcceptance(
  port, opened.journal, directory, session, 'actual Surface scope', kind, gate, terminal,
  () => { result.notifications[observer]++ }, lease => { leases.push(lease) })
try {
  const original = bytes()
  const noAuthority = await call('no-authority')
  assert.equal(noAuthority.kind, 'Failed')
  assert.equal(noAuthority.key, null)
  assert.equal(typeof noAuthority.error, 'string')
  const invalid = await call('no-authority', 'same-gate', 'same-terminal', 0, 'not-a-continuation')
  assert.equal(invalid.kind, 'Failed')
  assert.equal(invalid.key, null)
  assert.match(invalid.error, /Unknown continuation kind/)
  assert.equal(result.sends.length, 0)
  assert.equal(leases.length, 0)
  assert.deepEqual(bytes(), original)
  result.checks.push('no active authority and invalid continuation perform zero Host sends, zero lease registrations and zero durable writes')
  for (const session of ['session-a', 'session-b']) assert.equal((await dispatch.acceptHumanRoot(opened.journal, session, `root-${session}`, 'engineer')).ok, true)
  const first = safe(call('session-a', 'same-gate', 'same-terminal', 0))
  const second = safe(call('session-a', 'same-gate', 'same-terminal', 1))
  const differentSession = safe(call('session-b', 'same-gate', 'same-terminal', 2))
  await awaitSends(2)
  releaseAll()
  const outcomes = (await Promise.all([first, second, differentSession])).map(unwrap)
  assert.ok(outcomes.every(value => value.kind === 'Sent' && typeof value.key === 'string' && value.error === null))
  assert.deepEqual(outcomes[0], outcomes[1])
  assert.notEqual(outcomes[0].key, outcomes[2].key)
  assert.equal(result.sends.length, 2)
  result.checks.push('same exact occasion shares one real send and one JSON key; another session has its own send/key')
  const accepted = await dispatch.acceptManagedPromptClaim(opened.journal, 'session-a', 'scope-physical-a', outcomes[0].key, 'engineer')
  assert.equal(accepted.ok, true)
  assert.deepEqual(result.notifications, [0, 1, 0])
  assert.deepEqual(await call('session-a'), { kind: 'AlreadyAdmitted', key: null, error: null })
  assert.equal(result.sends.length, 2)
  result.checks.push('real managed acceptance notifies only the latest owner; completed duplicate cannot renew')
  const newTerminal = safe(call('session-a', 'same-gate', 'new-terminal'))
  const newGate = safe(call('session-a', 'new-gate', 'same-terminal'))
  await awaitSends(4)
  releaseAll()
  assert.ok((await Promise.all([newTerminal, newGate])).map(unwrap).every(value => value.kind === 'Sent'))
  assert.equal(result.sends.length, 4)
  result.checks.push('different terminal and gate occasions remain independent')
  disposeLeases()
  const durableBeforeReopen = bytes()
  journal.JournalSurface_dispose(opened.journal)
  opened = await journal.JournalSurface_bootWithWriterId(directory, 'surface-scope-reopened', 'surface-scope-reopened-runtime', process.pid, new Date().toISOString())
  assert.equal(opened.ok, true)
  assert.deepEqual(await call('session-a'), { kind: 'AlreadyAdmitted', key: null, error: null })
  assert.equal(result.sends.length, 4)
  assert.deepEqual(bytes(), durableBeforeReopen)
  result.checks.push('reopened Journal uses durable exact-occasion evidence without a new send or durable write')
  const next = safe(call('session-a', 'same-gate', 'fresh-after-reopen'))
  await awaitSends(5)
  releaseAll()
  assert.equal(unwrap(await next).kind, 'Sent')
  assert.equal(result.sends.length, 5)
  result.checks.push('reopened Journal still allows a fresh independent occasion')
  result.accepted = true
} catch (error) {
  result.accepted = false
  result.error = { message: error.message, stack: error.stack }
  process.exitCode = 1
} finally {
  for (const waiter of waiters) clearTimeout(waiter.timer)
  releaseAll()
  disposeLeases()
  if (opened?.ok) journal.JournalSurface_dispose(opened.journal)
  result.closed = true
  fs.writeFileSync(join(directory, 'result.json'), JSON.stringify(result, null, 2) + '\n')
}
