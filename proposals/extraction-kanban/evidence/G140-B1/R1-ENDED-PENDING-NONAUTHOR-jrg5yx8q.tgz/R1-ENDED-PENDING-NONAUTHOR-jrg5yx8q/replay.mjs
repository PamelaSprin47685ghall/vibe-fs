import assert from 'node:assert/strict'
import fs from 'node:fs'
import { join, resolve } from 'node:path'
import { spawnSync } from 'node:child_process'

const [archiveArg, outputArg, minimumRuntime] = process.argv.slice(2)
const archive = resolve(archiveArg)
const output = resolve(outputArg)
assert.equal(fs.existsSync(output), false)
fs.mkdirSync(output, { recursive: true })
const commands = []
const env = { ...process.env }
delete env.NODE_OPTIONS
delete env.NODE_TEST_CONTEXT
function run(name, executable, args) {
  const result = spawnSync(executable, args, { cwd: output, env, encoding: 'utf8', timeout: 20000 })
  fs.writeFileSync(join(output, `${name}.stdout`), result.stdout || '')
  fs.writeFileSync(join(output, `${name}.stderr`), result.stderr || '')
  commands.push({ name, executable, args, status: result.status, signal: result.signal, error: result.error?.message || null })
  fs.writeFileSync(join(output, 'commands-status.json'), JSON.stringify(commands, null, 2) + '\n')
  assert.equal(result.status, 0, `${name}: ${result.stderr}`)
  assert.equal(result.signal, null)
}
for (const [name, executable] of [['current-node', process.execPath], ...(minimumRuntime ? [['minimum-node', resolve(minimumRuntime)]] : [])]) {
  run(`${name}-old-physical`, executable, [join(archive, 'physical-order.mjs'), join(archive, 'baseline'), join(output, `${name}-old`), 'baseline-refusal'])
  run(`${name}-new-physical`, executable, [join(archive, 'physical-order.mjs'), join(archive, 'current'), join(output, `${name}-new`), 'corrected'])
  run(`${name}-boundaries`, executable, [join(archive, 'owner-boundaries.mjs'), join(archive, 'current'), join(output, `${name}-boundaries`)])
}
console.log(JSON.stringify({ accepted: true, runtimes: minimumRuntime ? 2 : 1 }))
