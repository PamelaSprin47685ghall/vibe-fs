import assert from 'node:assert/strict'
import fs from 'node:fs'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { run } from 'node:test'
import { performance } from 'node:perf_hooks'

const [versionRootArg, outputArg, expected] = process.argv.slice(2)
const versionRoot = resolve(versionRootArg)
const output = resolve(outputArg)
fs.mkdirSync(output, { recursive: true })
const { NativeTestSupervision } = await import(pathToFileURL(join(versionRoot, 'native-test-supervision.mjs')).href)
const { createFiniteWaitChannel } = await import(pathToFileURL(join(versionRoot, 'finite-wait-channel.mjs')).href)
const entry = join(output, 'physical.test.mjs')
const helper = pathToFileURL(join(versionRoot, 'finite-physical-wait.mjs')).href
fs.writeFileSync(entry, `import test from 'node:test'
import fs from 'node:fs'
import { withFinitePhysicalWait } from ${JSON.stringify(helper)}
test('first', async t => { await withFinitePhysicalWait(t, { operation: 'first actual operation', limitMs: 2000 }, async () => { fs.writeFileSync(${JSON.stringify(join(output, 'first.json'))}, JSON.stringify({pid:process.pid})); }) })
test('second', async t => { await withFinitePhysicalWait(t, { operation: 'second actual operation', limitMs: 2000 }, async () => { fs.writeFileSync(${JSON.stringify(join(output, 'second.json'))}, JSON.stringify({pid:process.pid})); }) })
`)
const owner = new NativeTestSupervision({ files: [entry], silenceMs: 5000, requireAllocation: true })
const controller = new AbortController()
const log = []
const failures = []
const buffered = []
let nativeSequence = 0
let hold = false
let released = false
let actualFirstCompleteReceived = false
let secondRequest
let secondResponse
let oldDeadline
let channel
let stream
let summary
let timer
const push = (kind, data) => log.push({ at: performance.now(), kind, data })
function deliver(event) {
  push('owner-native-delivery', event)
  const replies = owner.observe(event)
  for (const reply of replies) { push('owner-ack', reply); channel.reply(reply) }
}
function releaseOrderedTransport() {
  if (!secondRequest || !actualFirstCompleteReceived || released) return
  push('controlled-order-new-begin-before-old-native-complete', { request: secondRequest, buffered: buffered.map(event => ({ type: event.type, name: event.data.name, sequence: event.data.nativeSequence })) })
  const before = owner.currentWait(entry)
  assert.equal(before.physical.ended, true)
  secondResponse = owner.control(secondRequest)
  push('second-control-response', { response: secondResponse, wait: owner.currentWait(entry), deadline: owner.nextDeadline() })
  assert.equal(owner.currentWait(entry).physical.deadline, oldDeadline, 'new control cannot replace old absolute deadline')
  for (const reply of secondResponse) channel.reply(reply)
  released = true
  for (const event of buffered.splice(0)) deliver(event)
}
try {
  channel = await createFiniteWaitChannel({ entryFile: entry,
    onError(error) { failures.push({ message: error.message, stack: error.stack }); controller.abort(error) },
    onRequest(request) {
      try {
        push('actual-control', request)
        if (request.phase === 'begin' && request.name === 'second') {
          secondRequest = request
          releaseOrderedTransport()
          return
        }
        const responses = owner.control(request)
        if (request.phase === 'begin' && request.name === 'first') oldDeadline = owner.currentWait(entry).physical?.deadline
        if (request.phase === 'end' && request.name === 'first') {
          hold = true
          oldDeadline = owner.currentWait(entry).physical.deadline
        }
        for (const reply of responses) { push('owner-ack', reply); channel.reply(reply) }
      } catch (error) { failures.push({ message: error.message, stack: error.stack }); controller.abort(error) }
    },
  })
  owner.allocate(entry, channel.runId)
  owner.observe({ type: 'runner:file-start', data: { entryFile: entry, runId: channel.runId } })
  const transport = pathToFileURL(join(versionRoot, 'verdict-transport.mjs'))
  for (const [key, value] of Object.entries({ ...channel.descriptor, runId: channel.runId, workerParentPid: process.pid })) transport.searchParams.set(key, value)
  stream = run({ files: [entry], concurrency: 1, signal: controller.signal, execArgv: [`--import=${transport.href}`] })
  for (const type of ['test:dequeue', 'test:complete']) stream.on(type, data => {
    try {
      nativeSequence++
      const event = { type, data: { ...data, entryFile: entry, nativeSequence } }
      push('actual-native-received', { type, name: data.name, file: data.file, line: data.line, column: data.column, nesting: data.nesting, testId: data.testId, nativeSequence })
      if (hold && !released) {
        buffered.push(event)
        if (type === 'test:complete' && data.name === 'first') actualFirstCompleteReceived = true
        releaseOrderedTransport()
      } else deliver(event)
    } catch (error) { failures.push({ message: error.message, stack: error.stack }); controller.abort(error) }
  })
  timer = setTimeout(() => controller.abort(new Error('Physical transport probe exceeded 12 seconds')), 12000)
  for await (const event of stream) {
    if (event.type === 'test:summary') summary = event.data
    if (event.type === 'test:fail') push('actual-native-fail', { name: event.data.name, message: event.data.details?.error?.message })
  }
  assert.deepEqual(failures, [])
  assert.equal(actualFirstCompleteReceived, true)
  assert.ok(secondRequest)
  assert.equal(released, true)
  assert.equal(fs.existsSync(join(output, 'first.json')), true)
  if (expected === 'baseline-refusal') {
    assert.equal(secondResponse.length, 1)
    assert.equal(secondResponse[0].ok, false)
    assert.equal(fs.existsSync(join(output, 'second.json')), false)
    assert.ok(summary.failed >= 1)
  } else {
    assert.deepEqual(secondResponse, [])
    assert.equal(fs.existsSync(join(output, 'second.json')), true)
    assert.equal(summary.failed, 0)
    assert.equal(summary.passed, 2)
  }
  owner.check()
  owner.observe({ type: 'runner:file-drained', data: { entryFile: entry } })
  fs.writeFileSync(join(output, 'result.json'), JSON.stringify({ accepted: true, expected, runtime: process.version, pid: process.pid,
    actualFirstCompleteReceived, actualTwoNativeTestContexts: true, firstEndAckBeforeSecondBegin: true,
    nativeEventsWereHeldNotFabricated: true, noClockMock: true, secondResponse, summary,
    firstMarker: JSON.parse(fs.readFileSync(join(output, 'first.json'))),
    secondMarker: fs.existsSync(join(output, 'second.json')) ? JSON.parse(fs.readFileSync(join(output, 'second.json'))) : null,
    scope: 'Controlled delivery order between real native events and real Unix control channel; not an unmodified full supervisor run.' }, null, 2) + '\n')
} finally {
  clearTimeout(timer)
  controller.abort()
  if (channel) await channel.close()
  push('cleanup', { socketAbsent: channel ? !fs.existsSync(channel.descriptor.path) : true })
  fs.writeFileSync(join(output, 'transcript.json'), JSON.stringify(log, (key, value) => value instanceof Error ? { message: value.message, stack: value.stack } : value, 2) + '\n')
  fs.writeFileSync(join(output, 'failures.json'), JSON.stringify(failures, null, 2) + '\n')
}
