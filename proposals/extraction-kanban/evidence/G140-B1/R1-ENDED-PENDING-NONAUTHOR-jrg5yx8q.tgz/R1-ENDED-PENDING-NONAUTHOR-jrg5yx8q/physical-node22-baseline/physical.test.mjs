import test from 'node:test'
import fs from 'node:fs'
import { withFinitePhysicalWait } from "file:///private/tmp/r1-ended-pending-independent-20261019/baseline/finite-physical-wait.mjs"
test('first', async t => { await withFinitePhysicalWait(t, { operation: 'first actual operation', limitMs: 2000 }, async () => { fs.writeFileSync("/private/tmp/r1-ended-pending-independent-20261019/physical-node22-baseline/first.json", JSON.stringify({pid:process.pid})); }) })
test('second', async t => { await withFinitePhysicalWait(t, { operation: 'second actual operation', limitMs: 2000 }, async () => { fs.writeFileSync("/private/tmp/r1-ended-pending-independent-20261019/physical-node22-baseline/second.json", JSON.stringify({pid:process.pid})); }) })
