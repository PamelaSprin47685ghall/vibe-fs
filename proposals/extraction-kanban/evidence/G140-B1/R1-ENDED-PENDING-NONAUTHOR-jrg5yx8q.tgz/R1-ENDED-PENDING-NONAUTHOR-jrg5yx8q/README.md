# R1 ended allowance / next invocation independent review

This is a verification-support protocol repair. The prior R1 owner introduced the race; it is not a GAP-140 production regression. No shared code was edited by this reviewer.

Baseline owner: exact `8b5dd03f7:requirements/verification-system/tests/support/native-test-supervision.mjs`. Current owner: author's two-line repair. Six actual support files per version are frozen and hashed; current files were checked byte equal to the source again after verification. The permanent test source is included only as context; independent probes below are separate.

## Static finding

A real next TestContext can issue begin after the preceding end ACK while the preceding native complete is still in the other transport. Old control rejected every begin while any allowance remained, so it rejected this valid sequential request. The repair permits exactly one pending new token only after the old allowance is ended. `bindPending` refuses to grant anything while **any** old allowance remains. Old P is not renewed or released by that pending request. Matching native complete clears the old occurrence, and only a real unique next dequeue can bind the pending request and start its separate fixed P.

The existing per-file clocks, global-before-transition expiry checks, used-token tombstone, native sequence and top-level uniqueness checks remain intact. No authority is inferred from stdout, diagnostics, end ACK alone or provisional time.

## Actual transport evidence

Same `physical-order.mjs` used on Node26.6.0 and actual Node22.13.0, old and current versions once each after correcting the fixture summary assertion:

- Real node:test entry has two real sequential contexts. Each imports the actual finite helper; the actual private preload registers contexts and connects through an actual Unix channel.
- The probe holds *received real native* completion/dequeue events after the first actual end ACK. It waits until both the actual old native complete and the actual second begin have arrived, then deliberately delivers second begin to the owner first. Only afterward does it release the original native events in sequence. It does not fabricate native events, test identities, timestamps or TestContexts.
- Baseline: actual second begin gets `ok:false`; first action marker exists, second does not; real native summary reports one passed/one failed.
- Repair: actual second begin initially gets no ACK and remains pending under the old unchanged deadline. Releasing original complete/dequeue grants it; both action markers exist; real native summary reports two passed/zero failed.
- Node22 actual native transcript has no testId; no removal or simulation was used. Binary path/version/SHA are recorded, not redistributed.

This is a controlled transport-delivery experiment against the actual owner/helper/channel, **not** an unmodified full supervisor run. The fake-free boundary is the native event source and real context/control chain; transport scheduling is deliberately controlled.

## Deterministic owner boundary evidence

`owner-boundaries.mjs` runs against the actual copied current owner with an explicitly injected monotonic clock. Ten groups accepted on both actual runtimes:

1. Same name/line/column, no testId, two sequential occurrences: old occurrence never consumed by new token; new dequeue gets its own fixed P; duplicate begin does not renew.
2. After old complete but before new dequeue: ordinary silence deadline only, no provisional physical time.
3. Missing old native complete: exact original P deadline still expires; late matching complete cannot rescue it.
4. Another active file's earlier deadline still wins.
5. At most one pending token; old spent token and cancelled pending token cannot renew.
6. Next dequeue before old matching complete fails closed.
7. Native complete without end ACK remains invalid.
8. Nested next invocation is rejected without physical allowance.
9. Duplicate native sequence cannot clear or renew a newly granted allowance.
10. Owner stop prevents all later queued control/native grants.

These are model-clock tests of the actual owner, not physical elapsed-time claims.

## Preserved fixture error

The first physical probe completed the relevant native/control/action checks, then incorrectly assumed native `test:summary` had flat `failed`/`passed` fields. Both first CLI runs failed that final assertion. Original source (`physical-order.initial-summary-shape-error.mjs`), raw, markers and transcripts remain untouched. The corrected script preserves the actual native summary object and asserts actual native fail events and action markers instead. No arbitration assertion was weakened. New corrected runs used fresh directories.

## Portable replay

```sh
node replay.mjs /absolute/extracted/review-root /absolute/fresh/output
# Optional actual minimum-runtime check:
node replay.mjs /absolute/extracted/review-root /absolute/fresh/output /absolute/node22.13/bin/node
```

The runner uses the archived actual owner/helper closure only. It writes per-command raw/status and retains all actual test files, markers and native/control transcripts. It does not build or modify production code. A fresh verification of archive file hashes accompanies the archive; baseline diagnostic CLI exits0 because it asserts the expected old native failure, which is retained in its native summary.

The portable runner was actually executed once in a new directory with both runtimes. Its full commands/status/raw, native transcripts and original action markers are included under `portable-replay`. This checks reproducibility and does not add new distinct semantic cases.
