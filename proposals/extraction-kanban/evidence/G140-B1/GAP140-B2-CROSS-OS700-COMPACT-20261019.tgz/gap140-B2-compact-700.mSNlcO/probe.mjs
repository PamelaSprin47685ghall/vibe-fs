import assert from 'node:assert/strict'
import { spawn } from 'node:child_process'
import { createHash } from 'node:crypto'
import fs from 'node:fs'
import path from 'node:path'
import { pathToFileURL, fileURLToPath } from 'node:url'

const [mode, productArg, outputArg, ...rest] = process.argv.slice(2)
const product = path.resolve(productArg)
const output = path.resolve(outputArg)
assert.ok(output.startsWith('/private/tmp/gap140-B2-cross-os-700.'))
const load = relative => import(pathToFileURL(path.join(product, 'dist', relative)).href)
const eventsDirectory = directory => path.join(directory, 'wanxiangshu', 'events')
const physical = directory => fs.existsSync(eventsDirectory(directory))
  ? fs.readdirSync(eventsDirectory(directory)).filter(name => name.endsWith('.ndjson')).sort().map(name => {
    const bytes = fs.readFileSync(path.join(eventsDirectory(directory), name))
    return { name, byteLength: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex'),
      base64: bytes.toString('base64'), events: bytes.toString('utf8').trimEnd().split('\n').filter(Boolean).map(JSON.parse) }
  }) : []
const view = value => JSON.parse(JSON.stringify(value, (_key, item) => typeof item === 'bigint' ? item.toString() : item))

if (mode !== 'driver') {
  const [directory, name, session, providerRun, reason] = rest
  const [journal, failure] = await Promise.all([
    load('Persistence/Journal/Surface.js'), load('Participant/Provider/Attempt/Fallback/ProviderFailureSurface.js'),
  ])
  let opened
  const receipt = { mode, name, directory, session, providerRun, reason, pid: process.pid,
    parentPid: process.ppid, node: process.version, executable: process.execPath, errors: [] }
  try {
    opened = await journal.JournalSurface_bootWithWriterId(directory, name, `runtime-${name}`, process.pid, new Date().toISOString())
    receipt.opened = { ok: opened.ok, error: opened.error ?? null }
    assert.equal(opened.ok, true, JSON.stringify(receipt.opened))
    if (mode === 'seed') {
      receipt.accepted = await failure.acceptHumanRoot(opened.journal, session, 'seed-root', 'engineer')
      assert.equal(receipt.accepted.ok, true, JSON.stringify(receipt.accepted))
    }
    receipt.before = failure.snapshot(opened.journal, session)
    receipt.beforeJournal = journal.JournalSurface_snapshot(opened.journal)
    if (mode === 'worker') {
      assert.equal(receipt.before.failures, 0, 'each independent canonical Current starts stale at zero')
      process.send({ type: 'ready', pid: process.pid, name, before: receipt.before,
        authority: receipt.beforeJournal.sessionProjections[session].providerFailures })
      await new Promise((accept, reject) => {
        const timer = setTimeout(() => reject(new Error('Owned ready barrier expired')), 6000)
        process.once('message', message => {
          clearTimeout(timer)
          if (message?.type !== 'go') reject(new Error('Unexpected coordinator frame'))
          else accept()
        })
      })
      receipt.beforeInvocation = failure.snapshot(opened.journal, session)
      receipt.callStartedAt = performance.now()
      receipt.result = await failure.recordConfirmedFailure(opened.journal, session, providerRun, reason)
      receipt.callEndedAt = performance.now()
    }
    receipt.after = failure.snapshot(opened.journal, session)
    receipt.afterJournal = journal.JournalSurface_snapshot(opened.journal)
    receipt.physical = physical(directory)
    if (mode === 'cold') {
      const beforeObservation = receipt.physical.map(({ name, sha256 }) => ({ name, sha256 }))
      const [canonical, kernel, lists, vocabulary, store] = await Promise.all([
        load('Persistence/EventStore/CanonicalIntegrator.js'), load('Persistence/EventStore/IntegrationKernel.js'),
        load('fable_modules/fable-library-js.5.13.0/List.js'), load('Persistence/EventStore/AuthoritativeVocabulary.js'),
        load('Persistence/EventStore/Store.js'),
      ])
      const observedFaults = []
      const rules = lists.map(rule => new kernel.IntegrationRule(rule.Name, rule.Initial, rule.Accepts, rule.FaultScope,
        (context, current, event) => {
          const result = rule.Integrate(context, current, event)
          if (result.tag === 1) observedFaults.push({ rule: rule.Name, eventId: view(event.EventId),
            stream: view(event.StreamId), reason: result.fields[0] })
          return result
        }, rule.PlanCut, rule.ApplyCut), canonical.baseRules)
      const integrator = canonical.createWithRules(rules, vocabulary.isKnown)
      const observedStore = store.createLocal(directory, `readonly-observer-${name}`, integrator)
      receipt.canonicalFaultObservation = { observedFaults, scope: 'Transparent forwarding observer over actual canonical base rules; every Integrate result is returned unchanged. The real cold Journal snapshot above is unwrapped.' }
      receipt.readonlyObserverCurrentPresent = observedStore.TryCurrent('Journal') !== undefined
      receipt.originalBytesAfterFaultObservation = physical(directory).map(({ name, sha256 }) => ({ name, sha256 }))
      assert.deepEqual(receipt.originalBytesAfterFaultObservation, beforeObservation)
      receipt.coldWriterCreated = receipt.physical.some(file => file.name.startsWith(name))
      assert.equal(receipt.coldWriterCreated, false)
    }
  } catch (error) {
    receipt.errors.push({ name: error.name, message: error.message, stack: error.stack })
    process.exitCode = 1
  } finally {
    if (opened?.ok) journal.JournalSurface_dispose(opened.journal)
    receipt.closed = true
    fs.writeFileSync(path.join(output, `${name}.json`), JSON.stringify(receipt, null, 2) + '\n')
    console.log(JSON.stringify(receipt))
    if (process.connected) process.disconnect()
  }
} else {
  fs.mkdirSync(output, { recursive: true })
  const tracked = new Set()
  const launches = []
  const self = fileURLToPath(import.meta.url)
  function child(childMode, directory, name, session, providerRun = '', reason = '') {
    const child = spawn(process.execPath, [self, childMode, product, output, directory, name, session, providerRun, reason],
      { stdio: ['ignore', 'pipe', 'pipe', 'ipc'], detached: true, env: { ...process.env } })
    tracked.add(child)
    const record = { mode: childMode, name, pid: child.pid, signals: [], stdoutBytes: 0, stderrBytes: 0 }
    launches.push(record)
    const stdout = fs.createWriteStream(path.join(output, `${name}.stdout.log`))
    const stderr = fs.createWriteStream(path.join(output, `${name}.stderr.log`))
    let ready
    const isReady = new Promise(resolve => { ready = resolve })
    let timer
    function kill(reason) {
      if (!tracked.has(child)) return
      record.signals.push({ signal: 'SIGKILL', reason })
      try { process.kill(-child.pid, 'SIGKILL') } catch (error) { record.killError = error.code }
    }
    for (const [stream, sink, key] of [[child.stdout, stdout, 'stdoutBytes'], [child.stderr, stderr, 'stderrBytes']]) {
      stream.on('data', bytes => {
        record[key] += bytes.length
        if (record[key] > 2 * 1024 * 1024) kill('owned output boundary exceeded')
        else sink.write(bytes)
      })
    }
    child.on('message', message => {
      if (message?.type === 'ready') {
        record.ready = message
        ready(message)
      }
    })
    const finished = new Promise((resolve, reject) => {
      timer = setTimeout(() => kill('owned 9s child watchdog'), 9000)
      child.on('error', error => { record.spawnError = error.message })
      child.on('close', (code, signal) => {
        clearTimeout(timer)
        tracked.delete(child)
        stdout.end()
        stderr.end()
        record.exitCode = code
        record.signal = signal
        try { process.kill(-child.pid, 0); record.residualGroup = true } catch (error) { record.residualGroup = error.code !== 'ESRCH' }
        if (record.residualGroup) {
          try { process.kill(-child.pid, 'SIGKILL'); record.residualKilled = true } catch (error) { record.residualKillError = error.code }
        }
        if (code === 0) resolve(JSON.parse(fs.readFileSync(path.join(output, `${name}.json`), 'utf8')))
        else reject(new Error(`Owned child ${name} exited ${code}/${signal}`))
      })
    })
    finished.catch(() => {})
    return { child, isReady, finished, kill }
  }
  const observations = []
  let accepted = false
  try {
    for (const scenario of ['same-identity', 'distinct-identities']) {
      const directory = path.join(output, scenario)
      fs.mkdirSync(directory)
      const session = `session-${scenario}`
      const seed = child('seed', directory, `${scenario}-seed`, session)
      const seeded = await seed.finished
      assert.equal(seeded.after.failures, 0)
      const first = child('worker', directory, `${scenario}-writer-a`, session, 'provider-a', 'same-confirmed-reason')
      const second = child('worker', directory, `${scenario}-writer-b`, session,
        scenario === 'same-identity' ? 'provider-a' : 'provider-b', 'same-confirmed-reason')
      const barrier = await Promise.race([
        Promise.all([first.isReady, second.isReady]),
        Promise.all([first.finished, second.finished]).then(() => { throw new Error('Workers ended before ready') }),
      ])
      assert.equal(barrier[0].before.failures, 0)
      assert.equal(barrier[1].before.failures, 0)
      assert.deepEqual(barrier[0].authority, barrier[1].authority)
      first.child.send({ type: 'go' })
      second.child.send({ type: 'go' })
      const workers = await Promise.all([first.finished, second.finished])
      const original = physical(directory)
      const cold = await child('cold', directory, `${scenario}-cold`, session).finished
      assert.deepEqual(physical(directory).map(({ name, sha256 }) => ({ name, sha256 })),
        original.map(({ name, sha256 }) => ({ name, sha256 })))
      const all = original.flatMap(file => file.events)
      const failureEvents = all.filter(event => event.payload?.Fact?.[1]?.[1]?.[0] === 'FailureRecorded')
      const cuts = all.filter(event => event.event_type === 'ProjectionCutTail')
      const observation = { scenario, directory, seedPid: seeded.pid, workerPids: workers.map(item => item.pid),
        coldPid: cold.pid, barrier, workers: workers.map(({ physical, ...rest }) => rest),
        failureFacts: failureEvents.length, failureEventIds: failureEvents.map(event => event.event_id),
        failureProviderRuns: failureEvents.map(event => event.payload.Fact[1][1][1].ProviderRun),
        persistedCounts: failureEvents.map(event => event.payload.Fact[1][1][1].ConsecutiveFailureCount),
        cutFacts: cuts.length, cold, original }
      observations.push(observation)
      fs.writeFileSync(path.join(output, 'partial-result.json'), JSON.stringify(observations, null, 2) + '\n')
      if (scenario === 'same-identity') {
        assert.equal(failureEvents.length, 2, 'expected red precondition: physical StoreLock does not dedupe prebuilt domain commands')
        assert.equal(cold.after.failures, 1)
        assert.ok(workers.every(item => item.result.ok && item.result.outcome === 'RetryAuthorized'))
      }
    }
    accepted = true
  } finally {
    for (const owned of tracked) {
      try { process.kill(-owned.pid, 'SIGKILL') } catch {}
    }
    const report = { accepted, node: process.version, executable: process.execPath, driverPid: process.pid,
      product, api: 'Actual ProviderFailureSurface.recordConfirmedFailure(handle, session, providerRun, reason)',
      observations, launches, scope: 'B2 falsification precondition, not an implementation green. Actual independent OS Journals, same stale canonical root, real ledger/writer/store, then independent cold OS. No Host send was invoked or measured.' }
    fs.writeFileSync(path.join(output, 'result.json'), JSON.stringify(report, null, 2) + '\n')
    console.log(JSON.stringify({ accepted, observations: observations.map(item => ({ scenario: item.scenario,
      workerPids: item.workerPids, coldPid: item.coldPid, results: item.workers.map(worker => worker.result),
      failureFacts: item.failureFacts, persistedCounts: item.persistedCounts, cutFacts: item.cutFacts,
      cold: item.cold.after, faults: item.cold.canonicalFaultObservation })), launches }))
  }
}
