# Fixed 700: cross-OS stale provider-failure commands

Independent bounded falsification evidence, 2026-10-19. This is B2's failing precondition, not a repaired implementation or GAP-140 closure. No shared source was edited. No activity used the moving main dist. No Host send was called or measured. R12-U1 was not investigated.

## Input and execution

- Product tarball: wanxiangshu-0.9.0.tgz, SHA256 2a7a80267723c9be3fe03cc526257e6585b5f446b5474d6919d3fb17316e5231, fixed generation700.
- Actual installed product: /private/tmp/gap140-B1-independent-700/node_modules/wanxiangshu. All 2076 tarball files matched the installed bytes before and after the probe (package-verification.json and package-post-verification.json).
- Node: actual official darwin-arm64 Node v22.13.0, executable SHA256 5c79f8e198fd2456ea6660aaa6be218f9f44747f2306c7d0f5f97b087b2f2dfc.
- Additional run: Bun 1.3.14, executable SHA256 fb46ac6497104821512b67a3b3157c9fbbab8a99e311fb38da5b7039a373d860. Bun reports process.version v24.3.0 in its Node compatibility API; the bun/ receipts are not Node24 runs.
- API: actual ProviderFailureSurface.recordConfirmedFailure(handle, session, providerRun, reason), production policy licence, ledger, AgentJournal, writer, canonical integrator and physical StoreLock. No fake ledger, prebuilt raw failure injection or rewritten fold was used.

Each scenario uses a fresh private store. A separate seed OS accepts a human Engineer root through the real surface. Two distinct worker OS processes open independent Journals/stores and publish ready only after actually reading the same root/logical run with failures0. The coordinator sends go after both ready frames; each worker invokes the actual failure API against its stale canonical Current. A third OS relative to the two workers opens the resulting Journal and reads the cold budget. Seed/worker/cold PIDs are all distinct. Every child has a finite 9s owned group watchdog and bounded output. The 16 actual children across the two runtime runs exited0 without any signal or residual group. Each runtime was run once; no repetition loop.

## Observed results

| Scenario | Worker results | Physical FailureRecorded | Persisted counts | Cold count | Cold canonical oracle | Durable cuts |
|---|---|---:|---|---:|---|---:|
| Same identity/reason | both RetryAuthorized | 2 | 1, 1 | 1 | no rejection observed | 0 |
| Distinct provider identities, same reason | both RetryAuthorized | 2 | 1, 1 | 1 | one Journal FailureRecorded validation rejection | 0 |

Node22.13 and Bun1.3.14 each produced this result. Same-identity Node worker PIDs28560/28561, cold28562; distinct-identity workers28564/28565, cold28566. Bun workers28858/28859 and28909/28910, cold28883 and28924 respectively. Exact initial root/run, ready frames, results, raw bytes, heads/parents encoded in the canonical envelopes and all process outcomes are retained in result.json and bun/result.json.

The distinct-identity cold Journal boots normally and exposes the last good count1. It does not reject startup and no ProjectionCutTail was physically written. The cold diagnostic observation calls the actual canonical registered rules through a transparent forwarding wrapper: it records an Error and returns exactly that original result. It neither changes a rule nor supplies a substitute algorithm. The unwrapped production cold Journal snapshot is recorded separately before this observer. The exact observed error is: Journal fact 'FailureRecorded' rejected: provider failure violates validation (budget, count or observed identity conflicts).

Cold readers and fault observers did not create writer files or change any original NDJSON bytes; before/after SHA256 comparisons are asserted and stored. This probe does not append a later fact to force cut-tail; it therefore makes no claim about that later path.

The driver accepted=true and exit0 mean that the bounded evidence harness completed and the expected same-identity red was reproduced. They do not mean the product satisfies atomic domain admission. The distinct-identity result was recorded without guessing whether it would reject/cut. These observations falsify the idea that the existing physical StoreLock alone makes prebuilt domain commands atomic across independent OS Currents. They do not establish ordinary public Host concurrent reachability or duplicate provider sends.

## Portable replay

The archive includes the fixed product tarball, original installation lock, and the exact installed node_modules closure as runtime-node_modules.tgz (including nested wanxiangli). No compiler or main-repo source is required for replay. The recorded lock preserves its original temporary file reference; replay uses the archived installed closure instead of pretending that reference is relocatable.

Extract this evidence directory, unpack runtime-node_modules.tgz into a new runtime directory, then run:

```sh
runtime_bin=/absolute/path/to/node-or-bun
replay_root=$(mktemp -d /private/tmp/gap140-B2-cross-os-700.replay.XXXXXX)
"$runtime_bin" /absolute/path/to/evidence/probe.mjs driver \
  /absolute/path/to/runtime/node_modules/wanxiangshu "$replay_root"
```

Use actual Node >=22.13 for the Node run. For Bun use the Bun executable directly; the driver spawns each child using process.execPath. Fresh stores are created under the new owned replay root. Replaying uses real filesystem appends and creates only private test facts. runtime-node_modules.tgz is the recorded runtime closure, not a new npm resolution or registry publication. Hashes are in EVIDENCE-SHA256SUMS.

The original source review and this evidence address different questions: StoreLock is a valid location for a future fresh decision; current append only serializes bytes. Canonical freshness/cost, lazy-init/sequence settlement, atomic prompt ownership, missing Host-stop cold Workflow and all other B2 obligations remain open.
