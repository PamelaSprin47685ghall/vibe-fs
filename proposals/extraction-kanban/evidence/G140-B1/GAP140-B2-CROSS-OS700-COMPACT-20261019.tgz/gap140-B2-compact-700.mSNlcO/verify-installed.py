import hashlib
import json
import pathlib
import sys

evidence = pathlib.Path(__file__).resolve().parent
product = pathlib.Path(sys.argv[1]).resolve()
archive = evidence / 'wanxiangshu-0.9.0.tgz'
expected_archive = '2a7a80267723c9be3fe03cc526257e6585b5f446b5474d6919d3fb17316e5231'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == expected_archive
manifest = json.loads((evidence / 'package-verification.json').read_text())
assert manifest['count'] == 2076 and manifest['allSame']
observations = []
for item in manifest['checks']:
    target = product / item['path']
    actual = hashlib.sha256(target.read_bytes()).hexdigest() if target.is_file() else None
    observations.append({'path': item['path'], 'same': actual == item['sha256']})
failures = [item['path'] for item in observations if not item['same']]
print(json.dumps({'product': str(product), 'fileCount': len(observations), 'mismatches': failures}))
assert len(observations) == 2076 and not failures
