# G140-B2 fixed700 cross-OS evidence — compact variant

This compact archive retains the complete cross-OS observations, probe source, ready barriers, process outcomes, canonical NDJSON originals, cold Journal results, transparent canonical oracle observations, runtime identities, fixed700 product tarball, original npm lock and both 2076-file product identity manifests. The product result remains a B2 red: same-identity concurrent commands physically write two FailureRecorded facts; distinct identities both persist count1 and cold replay rejects one transition. Node22.13 and Bun1.3.14 each ran once in the original evidence. No Host send was invoked or measured, and GAP-140 remains open.

Only the reconstructible installed dependency closure `runtime-node_modules.tgz` is omitted. Its exact path, size and SHA256 are listed in OMITTED.json. The unchanged full original archive is `/private/tmp/gap140-B2-cross-os-700-evidence-20261019.tgz`, SHA256 `faf66502db2cb20f9ece7d1b231868abf52ff154b1e9d526b4f687f8c14243c2`, 33,039,546 bytes. The retained `original-full-README.md` and `original-full-EVIDENCE-SHA256SUMS` describe that historical full archive, including its now-omitted runtime closure; they are not claims that this compact variant contains it.

Independent production700 clean-install and portable replay evidence already exists in `GAP140-B1-INDEPENDENT-PRODUCTION700-20261019.tgz`, SHA256 `775eff01255ed2e3c65ad1a066715448eecf633a89548052cc933bdcc18e3bf4`. Its actual clean npm install and replay are distinct evidence, not an executed restoration of this compact B2 variant.

## Restore exact dependencies before replay

This compact archive is **not self-contained for offline replay**. Restore the exact dependencies from `original-package-lock.json`; npm uses its registry package integrity hashes. Fixed700 bundles wanxiangli0.6.12 within its tarball. Its unresolvable-looking `file:vendor/wanxiangli-0.6.12.tgz` dependency does not require inventing another library source: the lock identifies the installed bundled entry.

From the extracted evidence directory, create this sibling layout so that the original file reference remains valid:

```sh
mkdir -p restore/gap140-B1-candidate-700 restore/install
cp wanxiangshu-0.9.0.tgz restore/gap140-B1-candidate-700/wanxiangshu-0.9.0.tgz
cp original-package-lock.json restore/install/package-lock.json
cat > restore/install/package.json <<'JSON'
{
  "dependencies": {
    "wanxiangshu": "file:../gap140-B1-candidate-700/wanxiangshu-0.9.0.tgz"
  }
}
JSON
(cd restore/install && npm ci --ignore-scripts --no-audit --no-fund)
python3 verify-installed.py restore/install/node_modules/wanxiangshu
replay_root=$(mktemp -d /private/tmp/gap140-B2-cross-os-700.compact-replay.XXXXXX)
node probe.mjs driver "$PWD/restore/install/node_modules/wanxiangshu" "$replay_root"
```

Use actual Node>=22.13. For Bun replace the final `node` with `bun`; the driver spawns its worker/cold processes with the same executable. The final command writes real facts only under the new private replay directory. Do not use main-repository dist or an unrelated installed product. `verify-installed.py` checks the exact product tarball SHA and every one of the 2076 archived product file hashes before replay.

## Restoration attempt in this session

A fresh empty private installation was actually attempted twice with the original lock and fixed700 tarball. npm11.18.0 ran under Node26.6.0. The first offline attempt exited1 with ENOTCACHED for zod-to-json-schema3.25.2; one subsequent ordinary network attempt exited1 with registry.npmjs.org DNS ENOTFOUND. Both logs are retained. No installed node_modules was produced, and the B2 probe was not run from that attempted restoration. These are dependency-restoration/environment failures before product execution, not product failures. No further retries were made.

Therefore the restoration recipe and compact replay are **not validated here**. The original successful observations, exact installed-product proofs, raw evidence and immutable full archive remain valid. A machine with reachable registry packages or a complete integrity-matching npm cache must finish the restoration before claiming a compact replay result. The compact archive does not bundle native binaries or npm cache.
