import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { createHash } from 'node:crypto'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
const [label, host, product] = process.argv.slice(2)
const root = path.dirname(fileURLToPath(import.meta.url))
const output = path.join(root, label + '-' + host)
if (fs.existsSync(output)) throw new Error('Refuse to overwrite existing evidence')
if (!path.isAbsolute(product) || !product.startsWith('/private/tmp/')) throw new Error('Unowned product input')
const home = path.join(output, 'home')
const store = path.join(output, 'store')
fs.mkdirSync(path.join(home, '.config', 'opencode'), { recursive: true })
fs.mkdirSync(store, { recursive: true })
fs.writeFileSync(path.join(home, '.config', 'opencode', 'wanxiangshu.mjs'), `export const routingProtocol = 2
export default function route(role) { return { model: 'provider/' + role + '-model', reasoning: 'none' } }
export const predictorConfiguration = () => ({state:'unconfigured',reason:null})
`)
const env = { ...process.env, HOME: home, USERPROFILE: home }
delete env.NODE_TEST_CONTEXT
delete env.NODE_OPTIONS
delete env.WANXIANGSHU_NO_FATAL_EXIT
function inventory(base) {
  const rows = []
  function visit(relative = '') {
    for (const entry of fs.readdirSync(path.join(base, relative), { withFileTypes: true })) {
      const next = path.join(relative, entry.name)
      if (entry.isDirectory()) visit(next)
      else if (entry.isFile()) {
        const bytes = fs.readFileSync(path.join(base, next))
        rows.push({ file: next, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') })
      } else rows.push({ file: next, kind: 'symlink', target: fs.readlinkSync(path.join(base, next)) })
    }
  }
  visit()
  return rows.sort((a, b) => a.file.localeCompare(b.file))
}
const source = path.join(root, 'concurrent-child.mjs')
const result = { label, host, product, startedAt: new Date().toISOString(),
  consumerSha256: createHash('sha256').update(fs.readFileSync(source)).digest('hex'),
  before: inventory(path.join(product, 'dist')) }
const started = performance.now()
try {
  const value = await promisify(execFile)(host === 'node' ? process.execPath : host,
    [source, product, store, path.join(output, 'physical.json')],
    { cwd: output, env, timeout: 20000, maxBuffer: 8 * 1024 * 1024 })
  result.code = 0
  fs.writeFileSync(path.join(output, 'stdout.log'), value.stdout)
  fs.writeFileSync(path.join(output, 'stderr.log'), value.stderr)
} catch (error) {
  result.code = error.code
  result.signal = error.signal
  result.killed = error.killed
  result.error = error.message
  fs.writeFileSync(path.join(output, 'stdout.log'), error.stdout ?? '')
  fs.writeFileSync(path.join(output, 'stderr.log'), error.stderr ?? '')
}
result.elapsedMs = performance.now() - started
result.after = inventory(path.join(product, 'dist'))
result.distUnchanged = JSON.stringify(result.before) === JSON.stringify(result.after)
result.lockPresentAfterExit = fs.existsSync(path.join(store, 'wanxiangshu.lock'))
fs.writeFileSync(path.join(output, 'run.json'), JSON.stringify(result, null, 2) + '\n')
console.log(JSON.stringify({ label, host, code: result.code, elapsedMs: result.elapsedMs, distUnchanged: result.distUnchanged, lockPresentAfterExit: result.lockPresentAfterExit }))
if (result.code !== 0 || !result.distUnchanged || result.lockPresentAfterExit) process.exitCode = 1
