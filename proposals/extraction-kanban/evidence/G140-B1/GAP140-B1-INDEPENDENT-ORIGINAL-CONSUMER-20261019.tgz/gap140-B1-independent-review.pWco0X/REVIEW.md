# B1 isolated same-runtime consumer experiment

Input prototype: `/private/tmp/gap140-B1-prototype`, stable generation 1 (build log retained).
The prototype uses its own dist and a declared symlink to the main repository's stable node_modules. This is an isolated prototype experiment, not a clean installed-package claim. Neither input tree nor main source was edited.

The original consumer is unchanged: SHA-256 `a1003011132a42f914098e878fd6d46659518830ffc2f1f34684d3c6a4090709`. Its original assertion requires one failure fact and remains enabled. Each Host runs it once against B1, and once against the previously verified exact installed 697 package. All four producer processes run with private HOME/routing and separate owned stores. No old680 rerun was made.

## Results

| Input | Host | New recovery SendPrompt | FailureRecorded facts | Projection count | Observation settlement | Original verdict |
| --- | --- | --- | --- | --- | --- | --- |
| 697 | Node | 2 | 2 | 1 | first true; second waits for an unreturned third prompt receipt until the 8s bound | red, did not settle |
| 697 | Bun | 2 | 2 | 1 | first true; second waits for an unreturned third prompt receipt until the 8s bound | red, did not settle |
| B1 | Node | 1 | 2 | 1 | both return true, about 656ms total | red, facts 2 != 1 |
| B1 | Bun | 1 | 2 | 1 | both return true, about 621ms total | red, facts 2 != 1 |

Counts exclude the initial SendPrompt. The B1 failure is not an observation timeout: both original observation tasks settle successfully before the unchanged fact-count assertion fails. The pending baseline task is rejected only when owned cleanup releases the controlled Host, which is reflected in the stored observations array. Full formatted errors, stack traces, raw facts and stdout/stderr remain in each original receipt.

This directly shows a narrower B1 improvement for the exact same failed identity in one live journal/runtime. The duplicate durable fact remains; B2 atomic facts is open. These results do not refute separate joiner/observer-key counterexamples, and do not establish ordinary public Host reachability. The consumer intentionally bypasses the ordinary per-session Scheduler by calling the actual SyncDelegate HandleTurn surface concurrently. The measured SendPrompt calls are real invocations of the controlled Host port, not provider network requests.

Root supplied an earlier old680 baseline with two sends/two facts in the G140-A archive. This experiment does not independently rerun or reclassify that evidence. Its own freshly measured comparison is 697 versus B1; the earlier independent 692 red also remains in the separate 692 archive.

## Input integrity and cleanup

Every dist file is hashed before and after each execution (`*/run.json`). All four comparisons are unchanged. All four child consumers complete owned closeRecovery, leave no lock and exit; no timeout kill is used. The original 8s bounded wait remains in the unchanged consumer, and the parent adds a 20s OS-process bound.

The B1 input dist is frozen separately in `GAP140-B1-PROTOTYPE-INPUT-20261019.tgz`, SHA-256 `8e994d7143f9d32150bb35eb6430f298637f519d80d2c772d77d274231999ca2`. Its dist hashes are verified against the measured B1 input in `frozen-input-verification.json`. Relevant prototype source snapshots and the stable build log are included for inspection. The source snapshots were read after the experiment; the measured executable identity comes from the dist hashes.

Exactly three emitted files differ from 697: PromptJournalAdapter adds one WeakMap runtime per journal; SessionNudge uses that runtime; StaticTools differs only in the generated source path in MatchFailureException. This interpretation is based on the actual emitted diffs, not a build-name assumption. The full hash comparison is in `comparison.json`.

No production acceptance is inferred from this red experiment. Main source and prototype remain unmodified; R12-U1 was not investigated.

## Replay

Use the frozen input dist with the declared stable dependencies, then run:

```
node run.mjs B1 node /private/tmp/gap140-B1-prototype
node run.mjs B1 bun /private/tmp/gap140-B1-prototype
```

The runner refuses to overwrite an existing evidence directory. For a replay, use a fresh copy of the driver directory. The original consumer is copied only as an immutable artifact; it is never rewritten or rebound internally.

Only Bun generated caches and a duplicate verification extraction are omitted from the compact archive. All original red receipts, actual event bytes, scripts, logs, the frozen executable input, package lock, source snapshots and hash manifests are preserved.
