import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { createHash } from 'node:crypto'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
const [label, product] = process.argv.slice(2)
const root = path.dirname(fileURLToPath(import.meta.url))
const checkout = path.join(root, 'checkout')
const output = path.join(root, label)
if (fs.existsSync(output)) throw new Error('Refuse to overwrite evidence')
const link = path.join(checkout, 'dist')
if (!fs.lstatSync(link).isSymbolicLink()) throw new Error('dist is not the private input link')
fs.unlinkSync(link)
fs.symlinkSync(path.join(product, 'dist'), link)
const home = path.join(output, 'home')
const tmp = path.join(output, 'tmp')
fs.mkdirSync(home, { recursive: true })
fs.mkdirSync(tmp, { recursive: true })
const env = { ...process.env, HOME: home, USERPROFILE: home, TMPDIR: tmp }
delete env.NODE_TEST_CONTEXT
delete env.NODE_OPTIONS
delete env.WANXIANGSHU_NO_FATAL_EXIT
const inputs = ['requirements/interaction-authority/tests/021.test.mjs', 'requirements/managed-chat-execution/tests/005.test.mjs']
const hash = bytes => createHash('sha256').update(bytes).digest('hex')
function inventory(base) {
  const rows = []
  function visit(relative = '') {
    for (const item of fs.readdirSync(path.join(base, relative), { withFileTypes: true })) {
      const next = path.join(relative, item.name)
      if (item.isDirectory()) visit(next)
      else if (item.isFile()) rows.push({ file: next, sha256: hash(fs.readFileSync(path.join(base, next))) })
      else rows.push({ file: next, kind: 'symlink', target: fs.readlinkSync(path.join(base, next)) })
    }
  }
  visit()
  return rows.sort((a, b) => a.file.localeCompare(b.file))
}
const args = ['--test', '--test-name-pattern', 'historical payload survives actual EventStore reopen|transform durably starts the real assistant observed before its attempt plan existed', ...inputs]
const result = { label, product, executable: process.execPath, cwd: checkout, args,
  resolvedDist: fs.realpathSync(link), resolvedPublicPlugin: fs.realpathSync(path.join(link, 'OpenCode/Plugin/Plugin.js')),
  sourceArchive: 'source-8b5dd03f7.tar', sourceArchiveSha256: hash(fs.readFileSync(path.join(root, 'source-8b5dd03f7.tar'))),
  inputHashes: Object.fromEntries(inputs.map(file => [file, hash(fs.readFileSync(path.join(checkout, file)))])),
  beforeProduct: inventory(product), beforeCheckout: inventory(checkout) }
const started = performance.now()
try {
  const actual = await promisify(execFile)(process.execPath, args, { cwd: checkout, env, timeout: 30000, maxBuffer: 16 * 1024 * 1024 })
  result.code = 0
  fs.writeFileSync(path.join(output, 'stdout.log'), actual.stdout)
  fs.writeFileSync(path.join(output, 'stderr.log'), actual.stderr)
} catch (error) {
  result.code = error.code
  result.signal = error.signal
  result.killed = error.killed
  result.message = error.message
  fs.writeFileSync(path.join(output, 'stdout.log'), error.stdout ?? '')
  fs.writeFileSync(path.join(output, 'stderr.log'), error.stderr ?? '')
}
result.elapsedMs = performance.now() - started
result.afterProduct = inventory(product)
result.afterCheckout = inventory(checkout)
result.productUnchanged = JSON.stringify(result.beforeProduct) === JSON.stringify(result.afterProduct)
result.checkoutUnchanged = JSON.stringify(result.beforeCheckout) === JSON.stringify(result.afterCheckout)
fs.writeFileSync(path.join(output, 'run.json'), JSON.stringify(result, null, 2) + '\n')
console.log(JSON.stringify({ label, code: result.code, elapsedMs: result.elapsedMs, productUnchanged: result.productUnchanged,
  checkoutUnchanged: result.checkoutUnchanged, resolvedPublicPlugin: result.resolvedPublicPlugin }))
if (result.code !== 0 || !result.productUnchanged || !result.checkoutUnchanged) process.exitCode = 1
