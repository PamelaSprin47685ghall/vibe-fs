# B1 related failure baseline comparison

## Actual comparison

The current interaction-authority/021 and managed-chat-execution/005 tests, their fixtures, source reads and real Plugin support were frozen by a complete `git archive` of commit `8b5dd03f7d3f3b4575600f1578cc200202c9ede4`. Both selected test files and their support had no diff against main when the comparison began. Their complete original bytes are retained in the private checkout and its input hash records.

Archive SHA-256: `15568febed059b6ac459e175ffea92e8ff8582646aa97d54e0234d4bbbd01899`.
The complete tar remains at `/private/tmp/gap140-related-comparison.f8u4IN/source-8b5dd03f7.tar`.

Exactly the same private checkout and Node command were run once with its private dist symlink bound to clean fixed 697, then once bound to clean fixed 700. Name filtering selects only the two reported cases. The test sources, inputs and assertions were not rewritten. The Plugin fixture still performs real public `import('wanxiangshu')` and plugin.server wiring. Public Plugin resolution is recorded and points to the corresponding fixed installed package. The private dependency symlink points to the clean 700 installation's explicit peer dependencies; each product resolves its own package dependencies through its canonical real path.

Both versions report exactly two tests, zero passes and two failures:

| Case | 697 | 700 |
| --- | --- | --- |
| interaction-authority/021 historical payload survives actual reopen | AppendFailed, cut-tail inference fails because the Inspector legacy fact cannot be decoded | identical failure code and reason |
| managed-chat-execution/005 transform starts observed assistant | Confirmed Host material identity conflict | identical failure message |

The complete stdout, stderr, stack traces and exact commands are in `697/` and `700/`. The original broad related-700 log is preserved separately. Native xcodebuild cache diagnostics are retained; neither failure is classified from those diagnostics.

Every product file and every checkout file is hashed before/after each run, without following the private dist/dependency links. Both products and both checkout instances remain unchanged during their respective runs. The source corpus differs between the two runs only by the deliberate dist symlink target. Test workspaces are cleaned by the original fixtures, both OS executions return normally with exit 1, and no timeout termination is used.

The result proves these two failures already occur in 697 before B1. It does not establish which earlier repair first introduced the behavior, and does not mark the underlying requirements closed.

## Read-only assessment of the 005 fixture premise

The first accepted physical user message carries text `controlled provider request`. The second transform reuses that same physical user info and replaces its part text with `controlled tool result`. That is a change to the original user material, not a tool result with its own typed carrier.

semantic-trace[002] permits the same exact physical part to replay the same material, or the defined tool-call/tool-result facets with matching role, ProviderRun and ToolCallId. prefix-stability[014] requires original physical input for capture and copies for presentation. Capture.sameMaterial checks role/run/kind/tool/call and the body digest; stablePhysicalPartAlreadyCaptured explicitly rejects the conflicting body under the same provenance. The currently observed refusal is therefore consistent with that boundary.

A valid positive fixture should clone the original complete Host request before the first transform mutates presentation, then reuse that unchanged clone with the newly observed followup assistant. It should retain the durable ProviderStarted count of one and no extra prompt assertion. A separate explicit negative should attempt the same physical user's body overwrite and assert the material identity refusal, with unchanged started count and prompt count. This preserves original ownership rather than weakening the product fence.

That positive would demonstrate phase reuse for a later assistant under the same physical execution. It would not by itself demonstrate an actual tool-call/result carrier chain. No proposed fixture or production source was edited in this review, and no corrected fixture run is claimed here.

## Historical identity remains a separate requirement gap

interaction-authority[021] requires immutable historical bytes and a restricted historical audit reader, while rejecting legacy identity at new execution ingress. The existing test tries to establish historical data through today's append ingress. That setup premise and the missing historical reader are separate questions. This review does not label GAP-124 a review misjudgment, and does not erase the actual reader gap merely because the append premise is questionable.

## Reproduction and compact archive

The exact original driver is retained. Recreate the omitted full archive with `git archive --format=tar --output=source-8b5dd03f7.tar 8b5dd03f7d3f3b4575600f1578cc200202c9ede4` from the repository; its hash must match the value above. Both fixed package tars are included. Install them privately, bind the private checkout's node_modules to their explicit dependencies, and run `node run.mjs LABEL ABSOLUTE_PRODUCT_ROOT`. The driver switches only its own dist symlink, rejects an existing output directory, and preserves all raw failure output.

The compact evidence archive omits only the duplicate full Git tar and unrelated previously committed proposals. All executable source, requirements/support, resources, selected historical fixture, vendor package, exact package tars, commands, new raw failures and hashes are retained. `omissions.json` lists the omitted files and their hashes; the original files remain in the private directory. R12-U1 was not investigated.
