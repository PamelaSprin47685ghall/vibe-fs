namespace Wanxiangshu.Process

open System
open System.Threading.Tasks

type ReadPlan =
    | Unknown of string
    | AlreadyInProgress
    | ClosedImmediate
    | Park of TaskCompletionSource<Result<string * bool, string>>

type PtyPort =
    new: ?exitListener: (PtyExitEvent -> unit) * ?handler: PtyBackendHandler -> PtyPort

    member AddExitListener: listener: (PtyExitEvent -> unit) -> IDisposable
    member internal ExitListenerCount: int
    member Close: id: PtyId * ?outcome: Result<string, string> -> unit
    member ClosePty: id: PtyId * ?graceMs: int -> Task<unit>
    member CloseAll: ?graceMs: int -> Task<unit>
    member Complete: id: PtyId * ?outcome: Result<string, string> -> unit
    member CompleteNotStarted: id: PtyId * reason: string -> unit
    member CompleteAborted: id: PtyId * ?message: string -> unit
    member Exists: id: PtyId -> bool
    member FailRead: id: PtyId * reason: string -> unit
    member FailExitObservation: id: PtyId * reason: string -> unit

    member Fork:
        command: string * agentName: string * ?ptyId: PtyId * ?cwd: string * ?recovery: PtyRecoveryBinding -> PtyId

    member Known: id: PtyId -> bool
    member List: unit -> PtyHandle list
    member Read: id: PtyId -> Task<Result<string * bool, string>>
    member ReadResult: id: PtyId * output: string * closed: bool -> unit
    member RegisterExitTask: id: PtyId * task: Task -> unit
    member Send: id: PtyId * command: PtyCommand -> Task<Result<unit, string>>
    member Handler: PtyBackendHandler
    member ExitListener: (PtyExitEvent -> unit) option
