namespace Wanxiangshu.Process

open System
open System.Collections.Generic
open Fable.Core.JsInterop

/// stdout/stderr aggregation, byte counting and spool-threshold handling.
module ProcessOutput =

    /// DSL-state-combination: physical — stdout/stderr byte-buffer spool state
    /// DSL-class: PhysicalHandle — process-owned byte buffers and spool resource; owner ProcessOutput, law PTY output limit, proof process-output.
    type OutputCollector =
        { mutable Stdout: List<byte[]>
          mutable Stderr: List<byte[]>
          mutable Combined: List<byte[]>
          mutable Spool: Spool.StreamingSpool option
          mutable BytesObserved: int64
          mutable Discarded: bool
          OutputLimit: int64 }

    let create (estimate: ProcessEstimate) : OutputCollector =
        { Stdout = List<byte[]>()
          Stderr = List<byte[]>()
          Combined = List<byte[]>()
          Spool = None
          BytesObserved = 0L
          Discarded = false
          OutputLimit = ProcessEstimate.outputThreshold estimate.EstimatedOutput }

    /// 内存积压封顶：超过该预算即在到达 OutputLimit 之前切到 spool，避免跨过
    /// OutputLimit 那一刻把积压的全部字节一次性同步 dump。与 Spool 分块一致。
    let private MemoryBufferBudget: int64 = 204800L

    let private switchToSpool collector =
        let active = Spool.startStreamingSpool ()
        collector.Spool <- Some active

        for previous in collector.Combined do
            Spool.appendStreamingSpool active previous

        collector.Combined.Clear()
        collector.Stdout.Clear()
        collector.Stderr.Clear()

    let discard collector =
        collector.Discarded <- true
        collector.Spool |> Option.iter (fun active -> Spool.delete active.Path)
        collector.Spool <- None
        collector.Combined.Clear()
        collector.Stdout.Clear()
        collector.Stderr.Clear()

    let private appendNewMemory (collector: OutputCollector) (target: List<byte[]>) (bytes: byte[]) =
        let switchThreshold = min collector.OutputLimit MemoryBufferBudget
        target.Add bytes
        collector.Combined.Add bytes

        if collector.BytesObserved > switchThreshold then
            switchToSpool collector

    let private appendInMemory collector target bytes =
        match collector.Spool with
        | Some active -> Spool.appendStreamingSpool active bytes
        | None -> appendNewMemory collector target bytes

    let private addChunk (collector: OutputCollector) (target: List<byte[]>) (bytes: byte[]) =
        if not collector.Discarded && not (isNull bytes) && bytes.Length > 0 then
            collector.BytesObserved <- collector.BytesObserved + int64 bytes.Length
            appendInMemory collector target bytes

    let addStdout (collector: OutputCollector) (bytes: byte[]) : unit =
        addChunk collector collector.Stdout bytes

    let addStderr (collector: OutputCollector) (bytes: byte[]) : unit =
        addChunk collector collector.Stderr bytes

    let private concatBytes (parts: List<byte[]>) =
        if parts.Count = 0 then
            [||]
        else
            parts |> Seq.toArray |> Array.concat

    let decodeText (bytes: byte array) : string =
        emitJsExpr bytes "new TextDecoder('utf-8', { ignoreBOM: true }).decode($0)"

    let buildResult (collector: OutputCollector) : CapturedOutput =
        match collector.Spool with
        | Some active ->
            CapturedOutput.Spooled(active.Path, active.BytesWritten, Spool.chunkCount active.BytesWritten)
        | None ->
            let stdoutBytes = concatBytes collector.Stdout
            let stderrBytes = concatBytes collector.Stderr
            let stdoutText = decodeText stdoutBytes
            let stderrText = decodeText stderrBytes

            CapturedOutput.InMemory(stdoutText, stderrText)
