namespace Wanxiangshu.OpenCode

open System
open System.Collections.Generic
open System.Threading.Tasks
open FsToolkit.ErrorHandling
open Wanxiangshu.Foundation
open Wanxiangshu.Foundation.Identity
open Wanxiangshu.Foundation.Outcome
open Wanxiangshu.Participant.Persona

[<RequireQualifiedAccess>]
module ManagedSessionTermination =

    let private captureResult (operation: unit -> Task<Result<unit, string>>) =
        task {
            try
                return! operation ()
            with ex ->
                return Error ex.Message
        }

    let private captureUnit (operation: unit -> Task) =
        task {
            try
                do! operation ()
                return Ok()
            with ex ->
                return Error ex.Message
        }

    let private combineEffects cancelOutcome abortOutcome =
        match cancelOutcome, abortOutcome with
        | Error error, _ -> Error("descendant cancellation failed: " + error)
        | Ok(), Error error -> Error("Host abort failed: " + error)
        | Ok(), Ok() -> Ok()

    /// managed-session-lifecycle-017: fail-closed termination is one causal CE, not an
    /// attempt-only interrupt followed by a future callback guessing the cause.
    /// Descendant durable cancellation precedes physical teardown; Failed is
    /// published after teardown so the existing fork terminal listener commits
    /// HandleCompleted and pulses the parent join mailbox.
    let terminate
        (cancelSessionChildren: SessionId -> Task)
        (sessionPort: ISessionHostPort)
        (eventPort: IEventObservationPort)
        (sessionId: SessionId)
        (authorityRoot: AuthorityRootUserMessageId)
        (reason: string)
        : Task<Result<unit, string>> =
        if not (sessionPort.IsManagedChild sessionId) then
            Task.FromResult(
                Error "MANAGED-SESSION-016: user-facing/root session may only be interrupted by the external user"
            )
        else
            task {
                let! cancelOutcome = captureUnit (fun () -> cancelSessionChildren sessionId)
                let! abortOutcome = captureResult (fun () -> sessionPort.AbortSession sessionId)

                eventPort.NotifyTerminal
                    sessionId
                    (TerminalOutcome.Failed(TerminalStop.forAuthority authorityRoot reason))
                |> ignore

                return combineEffects cancelOutcome abortOutcome
            }

type InjectedSessionPort
    (
        underlyingPort: IOpenCodePort option,
        eventPort: IEventObservationPort,
        ?familyParent: SessionId -> SessionId option,
        ?isLifecycleTerminated: SessionId -> bool
    ) =
    // DSL-MUTABLE: resource — active terminal listener registry per session
    let activeListeners = Dictionary<SessionId, HashSet<Guid>>()

    let removeActiveListenerToken sessionId token =
        match activeListeners.TryGetValue sessionId with
        | true, listeners ->
            listeners.Remove token |> ignore
            listeners.Count = 0
        | false, _ -> false

    // DSL-MUTABLE: resource — parent-to-child session set map
    let parentChildMap = Dictionary<SessionId, HashSet<SessionId>>()
    // DSL-MUTABLE: resource — child-to-parent session map
    let childParents = Dictionary<SessionId, SessionId>()
    let lockObj = obj ()
    let restoredParent = defaultArg familyParent (fun _ -> None)

    // DSL-MUTABLE: resource — confirmed physical roots in Host
    let knownRoots = HashSet<SessionId>()

    let findRestoredRoot (sessionId: SessionId) =
        let visited = HashSet<SessionId>()

        let nextRestoredStep current =
            match restoredParent current with
            | Some parentId when parentId <> current -> Some parentId
            | _ -> None

        let rec loop current =
            if not (visited.Add current) then
                current
            else
                nextRestoredStep current |> Option.map loop |> Option.defaultValue current

        loop sessionId

    let knownOrDeclaredRoot (sessionId: SessionId) =
        match knownRoots.Contains sessionId with
        | true -> Some sessionId
        | false -> None

    let tryFindKnownRoot (sessionId: SessionId) =
        lock lockObj (fun () ->
            match childParents.TryGetValue sessionId with
            | true, rootId -> Some rootId
            | false, _ -> knownOrDeclaredRoot sessionId)

    let ensureParentChildBucket (rootId: SessionId) =
        match parentChildMap.ContainsKey rootId with
        | true -> ()
        | false -> parentChildMap.[rootId] <- HashSet<SessionId>()

    let recordOneAncestor (discoveredRoot: SessionId) (s: SessionId) =
        match s <> discoveredRoot with
        | false -> ()
        | true ->
            childParents.[s] <- discoveredRoot
            ensureParentChildBucket discoveredRoot
            parentChildMap.[discoveredRoot].Add s |> ignore

    let recordAncestryChain (discoveredRoot: SessionId) (ancestors: SessionId list) =
        lock lockObj (fun () ->
            knownRoots.Add discoveredRoot |> ignore
            ancestors |> List.iter (recordOneAncestor discoveredRoot))

    let stepParentQuery (port: IOpenCodePort) (current: SessionId) = port.GetSessionParent current

    let continueAncestryWalk
        (current: SessionId)
        (walkNext: SessionId -> Task<Result<SessionId, string>>)
        (parentOpt: SessionId option)
        =
        match parentOpt with
        | None -> Task.FromResult(Ok current)
        | Some parentId -> walkNext parentId

    let queryAndWalkParent
        (port: IOpenCodePort)
        (walkAncestry: SessionId -> Task<Result<SessionId, string>>)
        (current: SessionId)
        =
        taskResult {
            let! parentOpt = stepParentQuery port current
            return! continueAncestryWalk current walkAncestry parentOpt
        }

    let rec continueWalkUnvisited
        (port: IOpenCodePort)
        (visited: HashSet<SessionId>)
        (ancestors: ResizeArray<SessionId>)
        (current: SessionId)
        (isCycle: bool)
        : Task<Result<SessionId, string>> =
        match isCycle with
        | true -> Task.FromResult(Error(sprintf "Session ancestry cycle detected at %s" (SessionId.value current)))
        | false ->
            ancestors.Add current
            let nextKnown = tryFindKnownRoot current
            walkAncestryStep port visited ancestors nextKnown current

    and walkAncestryWithKnown
        (port: IOpenCodePort)
        (visited: HashSet<SessionId>)
        (ancestors: ResizeArray<SessionId>)
        (knownRootOpt: SessionId option)
        (current: SessionId)
        : Task<Result<SessionId, string>> =
        match knownRootOpt with
        | Some known -> Task.FromResult(Ok known)
        | None ->
            let isCycle = not (visited.Add current)
            continueWalkUnvisited port visited ancestors current isCycle

    and walkAncestryStep
        (port: IOpenCodePort)
        (visited: HashSet<SessionId>)
        (ancestors: ResizeArray<SessionId>)
        (knownOpt: SessionId option)
        (current: SessionId)
        : Task<Result<SessionId, string>> =
        match knownOpt with
        | Some known -> Task.FromResult(Ok known)
        | None ->
            let nextStep = walkAncestryWithKnown port visited ancestors None
            queryAndWalkParent port nextStep current

    let executeFamilyRootDiscovery (port: IOpenCodePort) (targetId: SessionId) : Task<Result<SessionId, string>> =
        taskResult {
            let visited = HashSet<SessionId>()
            let ancestors = ResizeArray<SessionId>()
            let! root = walkAncestryWithKnown port visited ancestors None targetId
            recordAncestryChain root (ancestors |> Seq.toList)
            return root
        }

    let resolveFamilyRoot (port: IOpenCodePort) (targetId: SessionId) : Task<Result<SessionId, string>> =
        match tryFindKnownRoot targetId with
        | Some known -> Task.FromResult(Ok known)
        | None -> executeFamilyRootDiscovery port targetId

    let familyRoot (sessionId: SessionId) =
        match tryFindKnownRoot sessionId with
        | Some rootId -> rootId
        | None -> findRestoredRoot sessionId

    let managedChild (sessionId: SessionId) =
        lock lockObj (fun () -> childParents.ContainsKey sessionId)
        || restoredParent sessionId |> Option.isSome

    let registerChild (parentId: SessionId) (childId: SessionId) =
        lock lockObj (fun () ->
            let rootId =
                match childParents.TryGetValue parentId with
                | true, value -> value
                | false, _ -> parentId

            match childParents.TryGetValue childId with
            | true, previousRoot when previousRoot <> rootId && parentChildMap.ContainsKey previousRoot ->
                parentChildMap.[previousRoot].Remove childId |> ignore
            | _ -> ()

            if not (parentChildMap.ContainsKey rootId) then
                parentChildMap.[rootId] <- HashSet<SessionId>()

            parentChildMap.[rootId].Add childId |> ignore
            childParents.[childId] <- rootId
            knownRoots.Add rootId |> ignore)

    let forgetChildParents (children: SessionId list) =
        for childId in children do
            childParents.Remove childId |> ignore

    let getAndRemoveChildren (parentId: SessionId) =
        lock lockObj (fun () ->
            if parentChildMap.ContainsKey parentId then
                let children = parentChildMap.[parentId] |> Seq.toList
                parentChildMap.Remove parentId |> ignore
                forgetChildParents children
                children
            else
                [])

    let detachFromRoot (rootId: SessionId) (childId: SessionId) =
        if parentChildMap.ContainsKey rootId then
            parentChildMap.[rootId].Remove childId |> ignore

    let pruneEmptyRoot (rootId: SessionId) =
        if parentChildMap.ContainsKey rootId && parentChildMap.[rootId].Count = 0 then
            parentChildMap.Remove rootId |> ignore

    let detachChild (childId: SessionId) =
        lock lockObj (fun () ->
            match childParents.TryGetValue childId with
            | true, rootId ->
                childParents.Remove childId |> ignore
                detachFromRoot rootId childId
                pruneEmptyRoot rootId
            | false, _ -> ())

    let abortOneChild (childId: SessionId) =
        task {
            match underlyingPort with
            | Some port ->
                let! _ = port.AbortSession childId
                ()
            | None -> ()
        }

    let abortChildren (parentId: SessionId) =
        task {
            let children = getAndRemoveChildren parentId

            for childId in children do
                do! abortOneChild childId
        }

    let routeSendOptions (_sessionId: SessionId) (opts: SessionPromptOptions) =
        // Dispatch admission is intentionally capacity-free. A session is a
        // reusable container, and the async prompt enqueue must never wait for a
        // provider slot. The sole model/capacity owner is chat.message, where the
        // Host is actually preparing this physical user message for execution.
        Ok opts

    let sendThroughPort
        (port: IOpenCodePort)
        (sessionId: SessionId)
        (text: string)
        (sendOptions: OpenCodePromptOptions)
        =
        // Pass the outcome through unchanged. This layer knows less about
        // acceptance than the port does; execution identity is handed off by
        // PromptKey at chat.message -> messages.transform, never by this call stack.
        port.SendPrompt sessionId text sendOptions

    let sendAvailablePort sessionId text sendOptions =
        match underlyingPort with
        | Some port -> sendThroughPort port sessionId text sendOptions
        | None -> Task.FromResult(Fatal "No Host transport: plugin input carried no client, serverUrl, baseUrl or port")

    let sendRoutedPrompt sessionId text opts =
        match routeSendOptions sessionId opts with
        | Error error -> Task.FromResult(Fatal error)
        | Ok sendOptions -> sendAvailablePort sessionId text sendOptions

    let bindSiblingExecution (ownerSessionId: SessionId) (laneId: SessionId) (agent: string option) =
        // A fission lane's participant comes from the durable lane/owner projection
        // and its own Accepted evidence; language follows the live global
        // preference, so there is nothing to bind at this boundary.
        ignore agent

    let bindSiblingLane (port: IOpenCodePort) (ownerSessionId: SessionId) (laneId: SessionId) (agent: string option) =
        taskResult {
            try
                bindSiblingExecution ownerSessionId laneId agent
                return laneId
            with ex ->
                do!
                    task {
                        let! _ = port.AbortSession laneId
                        return ()
                    }
                    |> TaskResultCE.ofTask

                return! Error ex.Message
        }

    let createSiblingSession
        (ownerSessionId: SessionId)
        (physicalParentId: SessionId option)
        (options: OpenCodeChildOptions)
        =
        taskResult {
            let! port =
                underlyingPort
                |> Result.requireSome "No Host transport: cannot create a sibling session"

            let! laneId = port.CreateSession physicalParentId options
            return! bindSiblingLane port ownerSessionId laneId options.Agent
        }

    let createChildSession (parentId: SessionId) (options: OpenCodeChildOptions) =
        taskResult {
            let! port =
                underlyingPort
                |> Result.requireSome "No Host transport: cannot create a child session"

            let! rootId = resolveFamilyRoot port parentId
            // HOST-015: every managed child is physically parented to the
            // family root — a son's son is a son. Recovery proves ownership
            // by the journal-linked SessionId + agent/title, never by the
            // Host parentID.
            let hostParentId = rootId

            let! childId = port.CreateChildSession hostParentId options
            registerChild rootId childId
            return childId
        }

    let listChildren (parentId: SessionId) =
        taskResult {
            let! port =
                underlyingPort
                |> Result.requireSome "No Host transport: cannot list child sessions"

            let! rootId = resolveFamilyRoot port parentId
            return! port.ListChildren rootId
        }

    let interruptManagedAttempt (sessionId: SessionId) =
        task {
            Diagnostic.emit "session-attempt-interrupt" [ "session_id", SessionId.value sessionId ]
            ModelRouting.cancelUnacquiredExecution sessionId |> ignore

            match underlyingPort with
            | Some port -> return! port.AbortSession sessionId
            | None -> return Error "No Host transport: cannot interrupt attempt"
        }

    let abortManagedSession (sessionId: SessionId) =
        task {
            Diagnostic.emit "session-abort" [ "session_id", SessionId.value sessionId ]
            ModelRouting.cancelUnacquiredExecution sessionId |> ignore
            detachChild sessionId
            do! abortChildren sessionId

            match underlyingPort with
            | Some port -> return! port.AbortSession sessionId
            | None -> return Error "No Host transport: cannot abort session"
        }

    interface ISessionHostPort with
        member _.AbortChildren(parentId) = abortChildren parentId

        member me.SubscribeTerminal(sessionId, listener) =
            let token = Guid.NewGuid()

            lock lockObj (fun () ->
                let listeners =
                    match activeListeners.TryGetValue sessionId with
                    | true, current -> current
                    | false, _ ->
                        // DSL-MUTABLE: algorithm-scratch — local created set for batch replay
                        let created = HashSet<Guid>()
                        activeListeners.[sessionId] <- created
                        created

                listeners.Add token |> ignore)

            let sub =
                eventPort.SubscribeTerminalListener(fun sId outcome ->
                    if sId = sessionId then
                        listener sId outcome)

            { new IDisposable with
                member _.Dispose() =
                    sub.Dispose()

                    lock lockObj (fun () ->
                        if removeActiveListenerToken sessionId token then
                            activeListeners.Remove(sessionId) |> ignore) }

        member me.SubscribeFutureTerminal(sessionId, listener) =
            let token = Guid.NewGuid()

            lock lockObj (fun () ->
                let listeners =
                    match activeListeners.TryGetValue sessionId with
                    | true, current -> current
                    | false, _ ->
                        let created = HashSet<Guid>()
                        activeListeners.[sessionId] <- created
                        created

                listeners.Add token |> ignore)

            let sub =
                eventPort.SubscribeFutureTerminalListener(fun sId outcome ->
                    if sId = sessionId then
                        listener sId outcome)

            { new IDisposable with
                member _.Dispose() =
                    sub.Dispose()

                    lock lockObj (fun () ->
                        if removeActiveListenerToken sessionId token then
                            activeListeners.Remove(sessionId) |> ignore) }

        member me.SendPrompt(sessionId, text, opts) =
            let hasListener =
                lock lockObj (fun () ->
                    match activeListeners.TryGetValue sessionId with
                    | true, listeners -> listeners.Count > 0
                    | false, _ -> false)

            if not hasListener then
                // Fatal, not Retryable: the listener is registered by the caller
                // before it sends, so this is a call-order defect. Retrying the
                // same wrong order cannot fix it.
                Task.FromResult(Fatal "AG-LISTENER-BEFORE-SEND: Listener must be registered before sending prompt")
            else
                sendRoutedPrompt sessionId text opts

        member _.InterruptAttempt sessionId =
            let terminated =
                isLifecycleTerminated |> Option.exists (fun check -> check sessionId)

            if not (managedChild sessionId) && not terminated then
                Task.FromResult(
                    Error "MANAGED-SESSION-016: user-facing/root session may only be interrupted by the external user"
                )
            else
                interruptManagedAttempt sessionId

        member _.IsManagedChild(sessionId) = managedChild sessionId

        member me.AbortSession(sessionId) =
            if not (managedChild sessionId) then
                Task.FromResult(
                    Error "MANAGED-SESSION-016: user-facing/root session may only be interrupted by the external user"
                )
            else
                abortManagedSession sessionId

        member _.CreateSiblingSession(ownerSessionId, physicalParentId, options) =
            createSiblingSession ownerSessionId physicalParentId options

        member _.TryGetParentSession(sessionId) =
            match underlyingPort with
            | None -> Task.FromResult(Error "No Host transport: cannot read session parent")
            | Some port -> port.GetSessionParent sessionId

        member me.CreateChildSession(parentId, options) = createChildSession parentId options

        member _.ListChildren(parentId) = listChildren parentId

        member _.FamilyRootOf(sessionId) = familyRoot sessionId
