namespace Wanxiangshu.Strength

open Wanxiangshu.Foundation
open Wanxiangshu.Participant.Provider.Projection

open System
open Wanxiangshu.Foundation.Identity

/// STRENGTH-005: a real, completed readonly tool exchange. Absence of either
/// half is unrepresentable once this value exists; Host collection builds it only
/// after observing both call and result.
type StrengthToolExchange =
    { ToolName: string
      CanonicalArguments: string
      CanonicalResult: string }

/// One completed readonly batch. Material ordinals are dense after filtering;
/// the runtime accounts for provider requests independently.
type StrengthRequestBatch =
    { RequestOrdinal: int
      AssistantText: string list
      Exchanges: StrengthToolExchange list }

/// Cross-session semantic material. It deliberately contains no Replica call id,
/// timestamp, model id, provenance marker or other wire-local identity.
type StrengthFrameBundle =
    { Batches: StrengthRequestBatch list
      Digest: string
      ByteLength: int }

[<RequireQualifiedAccess>]
type StrengthFrameError =
    | EmptyBundle
    | EmptyBatch of requestOrdinal: int
    | InvalidRequestOrdinal of expected: int * actual: int
    | UnsupportedTool of toolName: string

[<RequireQualifiedAccess>]
type StrengthMirrorError =
    | DuplicateToolCallId of ToolCallId
    | OrphanToolResultId of ToolCallId
    | MediaCannotCrossSession

module StrengthFrame =

    /// The read-only evidence the replica is allowed to carry out of the owner's
    /// batch: the Host-native read-only primitives plus the single dedicated
    /// readonly JS surface. Anything else in a mixed owner batch is dropped by
    /// the filter rather than failing the whole frame.
    let private projectionTools = set [ "read"; "glob"; "grep"; "js-predictor" ]

    /// The names a built frame may actually carry. The replica CALLS
    /// `js-predictor`, but its exchange is projected back into the owner's
    /// conversation under the owner's own `js-<role>` name, so the owner sees a
    /// tool it could have called itself. Those projected names must validate.
    let private jsSurfaces =
        Roles.all |> List.map (fun role -> "js-" + Roles.roleLabel role)

    let private allowedTools = Set.union projectionTools (Set.ofList jsSurfaces)

    let isAllowedTool (toolName: string) =
        not (String.IsNullOrWhiteSpace toolName)
        && Set.contains (toolName.Trim().ToLowerInvariant()) allowedTools

    /// The subset a mixed owner batch is filtered down to before anything is
    /// built: only the read-only evidence crosses into the replica.
    let isProjectionTool (toolName: string) =
        not (String.IsNullOrWhiteSpace toolName)
        && Set.contains (toolName.Trim().ToLowerInvariant()) projectionTools

    /// Fable-compatible UTF-8 length. .NET Encoding.GetByteCount is not
    /// available in Fable, while UTF-16 String.Length would undercharge non-ASCII
    /// payloads and make the measured ByteLength platform-dependent.
    let private isUtf16LowSurrogate (code: int) = code >= 0xDC00 && code <= 0xDFFF

    let private utf8Step (text: string) (index: int) =
        let code = int text.[index]

        if code <= 0x7F then
            1, 1
        elif code <= 0x7FF then
            2, 1
        elif
            code >= 0xD800
            && code <= 0xDBFF
            && index + 1 < text.Length
            && isUtf16LowSurrogate (int text.[index + 1])
        then
            4, 2
        else
            3, 1

    let utf8ByteCount (value: string) =
        let text = if isNull value then "" else value

        let rec loop index total =
            if index >= text.Length then
                total
            else
                let width, advance = utf8Step text index
                loop (index + advance) (total + width)

        loop 0 0

    let private canonicalField (value: string) =
        let text = if isNull value then "" else value
        sprintf "%d:%s" (utf8ByteCount text) text

    let private canonicalExchange (exchangeOrdinal: int) (exchange: StrengthToolExchange) =
        String.concat
            "\u001f"
            [ string exchangeOrdinal
              canonicalField (exchange.ToolName.Trim().ToLowerInvariant())
              canonicalField exchange.CanonicalArguments
              canonicalField exchange.CanonicalResult ]

    let private canonicalBatch (batch: StrengthRequestBatch) =
        let exchanges =
            batch.Exchanges
            |> List.mapi (fun index exchange -> canonicalExchange (index + 1) exchange)
            |> String.concat "\u001e"

        let toolMaterial = String.concat "\u001d" [ string batch.RequestOrdinal; exchanges ]

        match batch.AssistantText with
        | [] -> toolMaterial
        | texts ->
            toolMaterial
            + "\u001dtext\u001d"
            + (texts |> List.map canonicalField |> String.concat "\u001e")

    let canonicalText (batches: StrengthRequestBatch list) =
        batches |> List.map canonicalBatch |> String.concat "\u001c"

    let tryBuild
        (sha256: string -> string)
        (batches: StrengthRequestBatch list)
        : Result<StrengthFrameBundle, StrengthFrameError> =
        let rec validateBatches expected remaining =
            match remaining with
            | [] -> Ok()
            | batch :: tail when batch.RequestOrdinal <> expected ->
                Error(StrengthFrameError.InvalidRequestOrdinal(expected, batch.RequestOrdinal))
            | batch :: _ when List.isEmpty batch.Exchanges && List.isEmpty batch.AssistantText ->
                Error(StrengthFrameError.EmptyBatch batch.RequestOrdinal)
            | batch :: tail ->
                batch.Exchanges
                |> List.tryFind (fun exchange -> not (isAllowedTool exchange.ToolName))
                |> Option.map (fun invalid -> Error(StrengthFrameError.UnsupportedTool invalid.ToolName))
                |> Option.defaultWith (fun () -> validateBatches (expected + 1) tail)

        match batches with
        | [] -> Error StrengthFrameError.EmptyBundle
        | _ ->
            validateBatches 1 batches
            |> Result.map (fun () ->
                let canonical = canonicalText batches

                { Batches = batches
                  Digest = sha256 canonical
                  ByteLength = utf8ByteCount canonical })

    /// STRENGTH-009: strip owner-local tool-call identity while preserving the
    /// exact semantic projection and call/result pairing. The resulting IDs are
    /// deterministic for one decision but carry no owner wire identity. Media is
    /// fail-closed because its digest is intentionally one-way and cannot recreate
    /// provider-visible bytes in another Session.
    let tryLocalizeMirror
        (sha256: string -> string)
        (decisionId: StrengthDecisionId)
        (semanticDigest: string)
        (messages: ProviderProjection.WireMessage list)
        : Result<ProviderProjection.WireMessage list, StrengthMirrorError> =
        let localId ordinal =
            String.concat
                "\u001f"
                [ "strength-mirror-v1"
                  StrengthDecisionId.value decisionId
                  string ordinal
                  semanticDigest ]
            |> sha256
            |> ToolCallId.create

        let rec localizeParts
            (isAssistant: bool)
            (parts: ProviderProjection.WirePart list)
            (nextOrdinal: int)
            (idMap: Map<string, ToolCallId>)
            (localized: ProviderProjection.WirePart list)
            =
            match parts with
            | [] -> Ok(List.rev localized, nextOrdinal, idMap)
            | ProviderProjection.WireToolCall(ownerId, name, arguments) :: tail ->
                localizeToolCall isAssistant ownerId name arguments tail nextOrdinal idMap localized
            | ProviderProjection.WireToolResult(ownerId, result) :: tail ->
                localizeToolResult isAssistant ownerId result tail nextOrdinal idMap localized
            | ProviderProjection.WireMedia _ :: _ -> Error StrengthMirrorError.MediaCannotCrossSession
            | part :: tail -> localizeParts isAssistant tail nextOrdinal idMap (part :: localized)

        and localizeToolCall isAssistant ownerId name arguments tail nextOrdinal idMap localized =
            let ownerKey = ToolCallId.value ownerId

            if Map.containsKey ownerKey idMap then
                Error(StrengthMirrorError.DuplicateToolCallId ownerId)
            else
                let replicaId = localId nextOrdinal

                localizeParts
                    isAssistant
                    tail
                    (nextOrdinal + 1)
                    (Map.add ownerKey replicaId idMap)
                    (ProviderProjection.WireToolCall(replicaId, name, arguments) :: localized)

        and localizeToolResult isAssistant ownerId result tail nextOrdinal idMap localized =
            match Map.tryFind (ToolCallId.value ownerId) idMap with
            | Some replicaId ->
                localizeParts
                    isAssistant
                    tail
                    nextOrdinal
                    idMap
                    (ProviderProjection.WireToolResult(replicaId, result) :: localized)
            | None when isAssistant ->
                let ownerKey = ToolCallId.value ownerId
                let replicaId = localId nextOrdinal

                localizeParts
                    isAssistant
                    tail
                    (nextOrdinal + 1)
                    (Map.add ownerKey replicaId idMap)
                    (ProviderProjection.WireToolResult(replicaId, result) :: localized)
            | None -> Error(StrengthMirrorError.OrphanToolResultId ownerId)

        let rec localizeMessages
            (remaining: ProviderProjection.WireMessage list)
            (nextOrdinal: int)
            (idMap: Map<string, ToolCallId>)
            (localized: ProviderProjection.WireMessage list)
            =
            match remaining with
            | [] -> Ok(List.rev localized)
            | message :: tail ->
                let isAssistant =
                    String.Equals(message.Role, "assistant", StringComparison.OrdinalIgnoreCase)

                localizeParts isAssistant message.Parts nextOrdinal idMap []
                |> Result.bind (fun (parts, next, nextMap) ->
                    localizeMessages tail next nextMap ({ message with Parts = parts } :: localized))

        localizeMessages messages 1 Map.empty []

    /// Host-only synthetic message identity for one rendered half of a provider
    /// request batch. This identity is stable across replay/restart and is used by
    /// XTrace provenance to recover the exact Traced cursor range. It never enters
    /// ProviderSemanticProjection or provider-visible content.
    let hostMessageId
        (sha256: string -> string)
        (ownerSessionId: SessionId)
        (decisionId: StrengthDecisionId)
        (requestOrdinal: int)
        (half: string)
        (semanticDigest: string)
        : string =
        String.concat
            "\u001f"
            [ SessionId.value ownerSessionId
              StrengthDecisionId.value decisionId
              string requestOrdinal
              half
              semanticDigest ]
        |> sha256

    /// Cross-session wire identity is derived only from frozen owner/decision and
    /// semantic coordinates. No mechanism/provenance label enters provider bytes.
    let wireToolCallId
        (sha256: string -> string)
        (ownerSessionId: SessionId)
        (decisionId: StrengthDecisionId)
        (requestOrdinal: int)
        (exchangeOrdinal: int)
        (semanticDigest: string)
        : string =
        String.concat
            "\u001f"
            [ SessionId.value ownerSessionId
              StrengthDecisionId.value decisionId
              string requestOrdinal
              string exchangeOrdinal
              semanticDigest ]
        |> sha256
