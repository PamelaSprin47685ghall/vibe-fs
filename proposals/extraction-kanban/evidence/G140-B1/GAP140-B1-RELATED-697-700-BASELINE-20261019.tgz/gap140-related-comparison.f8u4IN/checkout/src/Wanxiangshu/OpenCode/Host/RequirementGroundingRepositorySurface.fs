namespace Wanxiangshu.OpenCode.Host

open System
open System.Threading.Tasks
open Fable.Core.JsInterop
open Wanxiangshu.Foundation.Identity
open Wanxiangshu.OpenCode.Host.RequirementGrounding
open Wanxiangshu.Composition.Durable
open Wanxiangshu.Persistence.Journal
open Wanxiangshu.Repository.Programming.Js
open Wanxiangshu.Repository.Programming.Js.OpenCode
open Wanxiangshu.Requirement.Grounding

module RequirementGroundingRepositorySurface =

    type private RuntimeHandle(handle: JournalHandle, workspace: string, sessionId: string) =
        member _.Handle = handle
        member _.Workspace = workspace
        member _.SessionId = sessionId

    let private runtimeOf (value: obj) = unbox<RuntimeHandle> value

    let private boot workspace sessionId =
        task {
            let! opened =
                JournalSurface.boot workspace "requirement-grounding-js-surface" 0 (DateTimeOffset.UtcNow.ToString("O"))

            if isNull opened?ok || not (unbox<bool> opened?ok) then
                return
                    Error(
                        if isNull opened?error then
                            "journal boot failed"
                        else
                            string opened?error
                    )
            else
                let handle = unbox<JournalHandle> opened?journal
                return Ok(RuntimeHandle(handle, workspace, sessionId))
        }

    let dispose (runtime: obj) : unit =
        JournalSurface.dispose (runtimeOf runtime).Handle

    let private summary (runtime: RuntimeHandle) (outcome: JsToolWorkflow.JsToolOutcome) =
        let handle = runtime.Handle
        let journal = handle.Journal
        let session = SessionId.create runtime.SessionId

        // Surface compatibility projection: preserve the prior observable
        // failure vocabulary via typed matching, not numeric DU knowledge.
        let failureCodeText failure =
            match failure with
            | JsFailure.InvalidProgram -> "invalid_program"
            | JsFailure.ProgramFailed _ -> "program_failed"
            | JsFailure.ProgramTimeout -> "program_timeout"
            | _ -> "unknown"

        let caseName, failureCode, created =
            match outcome with
            | JsToolWorkflow.JsToolOutcome.Succeeded(_, _, created) -> "Succeeded", null, List.toArray created
            | JsToolWorkflow.JsToolOutcome.Failed failure -> "Failed", box (failureCodeText failure), [||]

        box
            {| runtime = (runtime :> obj)
               caseName = caseName
               failureCode = failureCode
               pendingPackages =
                let port = AgentJournalPortAdapter.forRequirementGrounding journal

                RequirementGroundingRuntime.pending port session
                |> List.map _.PackageName
                |> List.toArray
               pendingMaterials =
                let port = AgentJournalPortAdapter.forRequirementGrounding journal

                RequirementGroundingRuntime.pending port session
                |> List.collect _.Materials
                |> List.map _.Path
                |> List.sort
                |> List.toArray
               created = created |}

    let private runAttempt failObservation (workspace: string) (sessionId: string) (program: string) : Task<obj> =
        task {
            match! boot workspace sessionId with
            | Error error -> return raise (InvalidOperationException error)
            | Ok runtime ->
                match
                    JsGeneratorSurface.typedRole "Engineer" "en"
                    |> Option.orElseWith (fun () -> JsGeneratorSurface.typedRole "Coder" "en")
                with
                | None -> return raise (InvalidOperationException "Engineer js surface unavailable")
                | Some surface ->
                    let observe (reads: JsExplicitFileRead list) effectPaths =
                        task {
                            let observed =
                                reads
                                |> List.map (fun read ->
                                    { Path = read.Path
                                      ResultBytes = read.ResultBytes
                                      Coverage = GroundingReadCoverage.CompleteFile })

                            do!
                                RequirementGroundingGate.programObservation
                                    (Some runtime.Handle.Journal)
                                    runtime.Workspace
                                    runtime.SessionId
                                    observed
                                    effectPaths

                            if failObservation then
                                return raise (InvalidOperationException "observation failed after recording effects")
                        }

                    let! outcome =
                        JsToolWorkflow.runWithFileAccessObservation
                            surface.Capabilities
                            runtime.Workspace
                            surface.BaseClassSource
                            program
                            2000
                            (DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() + 60000L)
                            (1 <<< 20)
                            None
                            observe

                    return summary runtime outcome
        }

    let runFirstAttempt (workspace: string) (sessionId: string) (program: string) : Task<obj> =
        runAttempt false workspace sessionId program

    let runWithObservationFailure (workspace: string) (sessionId: string) (program: string) : Task<obj> =
        runAttempt true workspace sessionId program
