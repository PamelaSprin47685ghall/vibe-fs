namespace Wanxiangshu.Process

open System
open System.Threading.Tasks

[<RequireQualifiedAccess>]
type PtySignal =
    | Terminate
    | Kill
    | Interrupt
    | Hangup
    | Quit
    | User1
    | User2

module PtySignal =
    [<Literal>]
    let TermName = "TERM"

    [<Literal>]
    let KillName = "KILL"

    [<Literal>]
    let IntName = "INT"

    [<Literal>]
    let HupName = "HUP"

    [<Literal>]
    let QuitName = "QUIT"

    [<Literal>]
    let User1Name = "USR1"

    [<Literal>]
    let User2Name = "USR2"

    let tryParse (value: string) =
        match value with
        | TermName -> Ok PtySignal.Terminate
        | KillName -> Ok PtySignal.Kill
        | IntName -> Ok PtySignal.Interrupt
        | HupName -> Ok PtySignal.Hangup
        | QuitName -> Ok PtySignal.Quit
        | User1Name -> Ok PtySignal.User1
        | User2Name -> Ok PtySignal.User2
        | _ -> Error(sprintf "Unsupported PTY signal: %s" value)

type PtyRecoveryBinding =
    { Directory: string
      Key: string
      IncarnationId: string }

[<RequireQualifiedAccess>]
type PtyRecoveryExit =
    | Ended of incarnationId: string * stopped: bool * code: int option * signal: string option
    | NotStarted of incarnationId: string * reason: string

type RecoverPty = string -> string -> string option -> int -> Task<PtyRecoveryExit>

[<RequireQualifiedAccess>]
type PtyCommand =
    | Spawn of command: string * cwd: string * recovery: PtyRecoveryBinding option
    | Write of bytes: byte[]
    | Read
    | Signal of signal: PtySignal
    | Resize of width: int * height: int

type PtyId =
    | PtyId of id: string

    member this.Value =
        match this with
        | PtyId id -> id

    static member Create(id: string) = PtyId id

/// Confirmed PTY exit or explicit no-start evidence delivered to listeners.
[<RequireQualifiedAccess>]
type PtyExitEvent =
    | Exited of id: PtyId * outcome: string
    | Failed of id: PtyId * code: string * message: string
    | Aborted of id: PtyId * code: string * message: string
    | NotStarted of id: PtyId * reason: string

    member this.Id =
        match this with
        | Exited(id, _) -> id
        | Failed(id, _, _) -> id
        | Aborted(id, _, _) -> id
        | NotStarted(id, _) -> id

/// One live PTY.
///
/// `Agent` is the selected managed agent name as plain text.
type PtyHandle =
    { Id: PtyId
      Command: string
      StartedAt: DateTimeOffset
      Agent: string }

type PtyRead =
    { Id: PtyId
      Output: string
      Closed: bool }

type PtyBackendHandler = PtyId -> PtyCommand -> Task<Result<unit, string>>

[<RequireQualifiedAccess>]
module PtyOutcome =
    [<Literal>]
    let Closed = "closed"

    [<Literal>]
    let termToKillGraceMs = 5000
