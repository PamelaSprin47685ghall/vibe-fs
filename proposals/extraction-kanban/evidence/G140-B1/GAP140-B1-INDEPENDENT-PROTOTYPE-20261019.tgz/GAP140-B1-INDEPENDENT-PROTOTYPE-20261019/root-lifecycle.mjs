import assert from 'node:assert/strict'
import fs from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'

const [product, directory] = process.argv.slice(2)
fs.mkdirSync(directory, { recursive: true })
const load = path => import(pathToFileURL(join(product, 'dist', path)).href)
const journal = await load('Persistence/Journal/Surface.js')
const dispatch = await load('Interaction/Dispatch/DispatchSurface.js')
const nudge = await load('Interaction/Dispatch/OpenCode/SessionNudge.js')
const identity = await load('Foundation/Identity.js')
const { forJournal } = await load('Composition/Durable/PromptJournalAdapter.js')
const runtime = await load('Interaction/Dispatch/Dispatcher.js')
const model = await load('Interaction/Authority/Model.js')
const { AgentFact } = await load('Composition/Durable/Fact.js')
const { StreamId } = await load('Persistence/Journal/Envelope.js')
const { AgentJournalModule_appendAgent } = await load('Persistence/Journal/AgentJournal.js')
const { PromptFactCases, AuthorityLogicalRunClosedPayload } = await load('Interaction/Authority/Facts.js')
const result = { pid: process.pid, product, sends: [], checks: [] }
const opened = await journal.JournalSurface_bootWithWriterId(directory, 'writer-b1-root-lifecycle', 'runtime-b1-root-lifecycle', process.pid, new Date().toISOString())
assert.equal(opened.ok, true)
try {
  const durable = journal.JournalHandle__get_Journal(opened.journal)
  const owner = forJournal(durable)
  const session = identity.SessionIdModule_create('b1-root-lifecycle')
  const read = () => runtime.Runtime__ProjectionFor_ZD623056(owner, session).ActiveLogicalRun
  assert.equal(read(), undefined)
  assert.equal((await dispatch.acceptHumanRoot(opened.journal, 'b1-root-lifecycle', 'root-a', 'engineer')).ok, true)
  const a = read()
  assert.ok(a)
  const stream = new StreamId(new StreamId(0, []).cases().indexOf('Session'), [session])
  const payload = new AuthorityLogicalRunClosedPayload(session, model.AuthorityExecutionProfile__get_LogicalRunId(a), model.AuthorityExecutionProfile__get_AuthorityRootUserMessageId(a), 'HumanRoot', 'independent-real-closure')
  const closedFact = new PromptFactCases(new PromptFactCases(0, []).cases().indexOf('AuthorityLogicalRunClosed'), [payload])
  const wrapped = new AgentFact(new AgentFact(0, []).cases().indexOf('Prompt'), [closedFact])
  const close = await AgentJournalModule_appendAgent(stream, undefined, wrapped, durable)
  assert.equal(close.tag, 0, JSON.stringify(close))
  assert.equal(read(), undefined, 'same cached owner must see durable closure immediately')
  result.checks.push('same cached runtime reads actual A accepted and A closed, without cached permission')
  const port = {
    SubscribeTerminal: () => ({ Dispose() {} }),
    SubscribeFutureTerminal: () => ({ Dispose() {} }),
    SendPrompt: async (id, text) => { result.sends.push({ session: identity.SessionIdModule_value(id), text }); return dispatch.admittedWithReceipt('actual-transport') },
  }
  const call = () => nudge.trySendGateContinuation(port, { TryRead: () => directory }, session, 'new authority gate', model.tryParseContinuationKind('ProviderRetryAttempt'), undefined, durable, 'B1RootGate', identity.ProviderRunIdentityModule_create('terminal-same'))
  const denied = await call()
  assert.equal(denied.tag, denied.cases().indexOf('Failed'))
  assert.equal(result.sends.length, 0)
  assert.equal((await dispatch.acceptHumanRoot(opened.journal, 'b1-root-lifecycle', 'root-b', 'engineer')).ok, true)
  const b = read()
  assert.ok(b)
  assert.notDeepEqual(model.AuthorityExecutionProfile__get_LogicalRunId(a), model.AuthorityExecutionProfile__get_LogicalRunId(b))
  assert.equal(identity.AuthorityRootUserMessageIdModule_value(model.AuthorityExecutionProfile__get_AuthorityRootUserMessageId(b)), 'root-b')
  assert.equal(forJournal(durable), owner)
  assert.equal((await call()).tag, 0)
  assert.equal(result.sends.length, 1)
  result.checks.push('closed root has no send; same Journal new B root authorizes only its fresh durable profile')
  result.accepted = true
} catch (error) {
  result.accepted = false
  result.error = { message: error.message, stack: error.stack }
  process.exitCode = 1
} finally {
  journal.JournalSurface_dispose(opened.journal)
  result.closed = true
  fs.writeFileSync(join(directory, 'result.json'), JSON.stringify(result, null, 2) + '\n')
}
