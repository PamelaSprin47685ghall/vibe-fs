import assert from 'node:assert/strict'
import fs from 'node:fs'
import { join, resolve } from 'node:path'
import { createHash } from 'node:crypto'
import { spawnSync } from 'node:child_process'

const [archiveArg, outputArg] = process.argv.slice(2)
const archive = resolve(archiveArg)
const output = resolve(outputArg)
assert.equal(fs.existsSync(output), false)
fs.mkdirSync(output, { recursive: true })
const tar = join(archive, 'fixed697.tgz')
assert.equal(createHash('sha256').update(fs.readFileSync(tar)).digest('hex'), '21a3409fe09a626976189b47349122c2e94b405b941d4536a5ad7e837817346f')
const env = { ...process.env }
delete env.NODE_OPTIONS
delete env.NODE_TEST_CONTEXT
const commands = []
function run(name, executable, args) {
  const result = spawnSync(executable, args, { cwd: output, env, encoding: 'utf8', timeout: 60000 })
  fs.writeFileSync(join(output, `${name}.stdout`), result.stdout || '')
  fs.writeFileSync(join(output, `${name}.stderr`), result.stderr || '')
  commands.push({ name, executable, args, status: result.status, signal: result.signal, error: result.error?.message || null })
  fs.writeFileSync(join(output, 'commands-status.json'), JSON.stringify(commands, null, 2) + '\n')
  assert.equal(result.status, 0, `${name}: ${result.stderr}`)
  assert.equal(result.signal, null)
}
run('dependencies-install', 'npm', ['install', '--ignore-scripts', '--no-audit', '--no-fund', tar])
const product = join(output, 'fixed-generation2')
fs.mkdirSync(product)
fs.cpSync(join(archive, 'fixed-generation2/dist'), join(product, 'dist'), { recursive: true })
fs.copyFileSync(join(archive, 'fixed-generation2/package.json'), join(product, 'package.json'))
fs.symlinkSync(join(output, 'node_modules/wanxiangshu/node_modules'), join(product, 'node_modules'))
for (const host of ['node', 'bun']) {
  run(`${host}-ownership`, host, [join(archive, 'ownership.mjs'), product, join(output, `${host}-ownership`)])
  run(`${host}-root`, host, [join(archive, 'root-lifecycle.mjs'), product, join(output, `${host}-root`)])
  for (const variant of ['observed', 'physical']) run(`${host}-${variant}`, host, [join(archive, 'acceptance-owner-contract.mjs'), product, join(output, `${host}-${variant}`), variant])
  for (const scenario of ['attach-throws', 'send-fails']) run(`${host}-${scenario}`, host, [join(archive, 'joiner-faults.mjs'), product, join(output, `${host}-${scenario}`), scenario])
}
fs.writeFileSync(join(output, 'summary.json'), JSON.stringify({ accepted: true, cases: 12, privatePrototypeOnly: true,
  existingReplacedPhysicalWaiterCanRemainPending: true, closesGAP140: false }, null, 2) + '\n')
console.log(JSON.stringify({ accepted: true, cases: 12, output }))
