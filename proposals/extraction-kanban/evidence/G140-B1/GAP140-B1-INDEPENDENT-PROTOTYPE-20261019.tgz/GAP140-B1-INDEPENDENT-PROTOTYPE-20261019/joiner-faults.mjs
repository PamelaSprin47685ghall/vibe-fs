import assert from 'node:assert/strict'
import fs from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'

const [product, directory, scenario] = process.argv.slice(2)
fs.mkdirSync(directory, { recursive: true })
const load = path => import(pathToFileURL(join(product, 'dist', path)).href)
const journal = await load('Persistence/Journal/Surface.js')
const dispatch = await load('Interaction/Dispatch/DispatchSurface.js')
const nudge = await load('Interaction/Dispatch/OpenCode/SessionNudge.js')
const identity = await load('Foundation/Identity.js')
const { tryParseContinuationKind } = await load('Interaction/Authority/Model.js')
const result = { scenario, product, pid: process.pid, sends: 0, registrations: [0, 0] }
const leases = []
const sentinel = new Error('independent joiner lease owner refused')
let release
let nextImmediate = false
const port = {
  SubscribeTerminal: () => ({ Dispose() {} }),
  SubscribeFutureTerminal: () => ({ Dispose() {} }),
  SendPrompt: () => {
    result.sends++
    return nextImmediate ? Promise.resolve(dispatch.admittedWithReceipt('later-positive-control')) : new Promise(resolve => { release = resolve })
  },
}
const opened = await journal.JournalSurface_bootWithWriterId(directory, 'writer-b1-joiner-fault', 'runtime-b1-joiner-fault', process.pid, new Date().toISOString())
assert.equal(opened.ok, true)
try {
  const session = 'b1-joiner-faults'
  assert.equal((await dispatch.acceptHumanRoot(opened.journal, session, 'root-b1-joiner-faults', 'engineer')).ok, true)
  const durable = journal.JournalHandle__get_Journal(opened.journal)
  const call = (index, terminal = 'first-terminal') => nudge.trySendGateContinuationObserved(
    port, { TryRead: () => directory }, identity.SessionIdModule_create(session), 'actual joiner fault boundary',
    tryParseContinuationKind('ProviderRetryAttempt'), undefined, durable, 'B1JoinerFault', identity.ProviderRunIdentityModule_create(terminal), {
      Notify() {},
      AttachDisposable(item) {
        result.registrations[index]++
        leases.push(item)
        if (index === 1 && scenario === 'attach-throws') throw sentinel
      },
    })
  const settle = promise => promise.then(value => ({ value }), error => ({ error, sameSentinel: error === sentinel }))
  const first = settle(call(0))
  const second = settle(call(1))
  for (let step = 0; step < 20 && !release; step++) await new Promise(resolve => setImmediate(resolve))
  assert.equal(result.sends, 1)
  assert.equal(typeof release, 'function')
  release(scenario === 'send-fails' ? dispatch.retryable('actual transport refused') : dispatch.admittedWithReceipt('actual transport succeeded'))
  const outcomes = await Promise.all([first, second])
  if (scenario === 'attach-throws') {
    assert.equal(outcomes[0].value.tag, 0)
    assert.equal(outcomes[1].sameSentinel, true)
    assert.deepEqual(result.registrations, [1, 1])
    result.sameJoinerErrorObjectPreserved = true
    result.firstSuccessfulFlightUnaffected = true
  } else {
    assert.ok(outcomes.every(item => item.value.tag === item.value.cases().indexOf('Failed')))
    assert.deepEqual(result.registrations, [1, 0], 'unsuccessful shared flight cannot attach a joiner lease')
    result.failedFlightHadNoJoinerRegistration = true
  }
  result.outcomes = outcomes.map(item => item.error ? { error: item.error.message, sameSentinel: item.sameSentinel } : { tag: item.value.tag, fields: item.value.fields })
  nextImmediate = true
  const later = await call(0, 'new-independent-terminal')
  assert.equal(later.tag, 0)
  assert.equal(result.sends, 2)
  result.ownerWorksForNextIndependentOccasion = true
  result.accepted = true
} catch (error) {
  result.accepted = false
  result.error = { message: error.message, stack: error.stack }
  process.exitCode = 1
} finally {
  for (const lease of leases) lease.Dispose()
  journal.JournalSurface_dispose(opened.journal)
  result.closed = true
  fs.writeFileSync(join(directory, 'result.json'), JSON.stringify(result, null, 2) + '\n')
}
