# GAP-140 B1 isolated prototype, independent review

No shared source edits. No prototype edits. This is a **private prototype**, not a production package delivery. Main baseline is commit `8b5dd03f7`; first prototype factory commit reported by author is `f273501`. Generation2 adds the joined observer repair, using the exact six source files and hashes archived here.

## Static review

`PromptJournalAdapter.forJournal` maps actual AgentJournal objects to one retained dispatch Runtime through a WeakMap. The value owns the existing gate-nudge flight resource. It holds no budget, retry permission or authority snapshot: projection queries still read the actual Journal. A different Journal receives a different owner. The existing scope key contains session, logical run, continuation kind and exact gate/terminal occasion. Runtime is shared at the HostSessionNudge boundary; other `forPrompts` callers may still create separate Runtime objects.

`RunGateNudgeOnce` invokes `onJoined` only for an actual joiner and only after a successful shared result. The joiner has its own task, so lease attachment failure does not change the first sender's completion. `ObserveGateNudgeAcceptance` reads the fresh exact profile/occasion, attaches a pending lease or immediately reports an existing matching landing. Error results never attach joiner leases. No PhysicalAcceptance broadcast or new permission cache was introduced.

## Independent actual results

The original prototype dist was frozen by the author before tests. Generation2 was additionally copied into `fixed-generation2`, with all 895 dist files compared against the frozen original before and after testing, including its emitted Fable dependency files. External runtime dependencies are explicitly taken from the actual clean fixed697 installation (library 0.6.12), never from repository dist.

Generation2: **six cases per Host, twelve total, Node26.6/Bun1.3.14 accepted**:

1. Real Journal owner/scope matrix: same Journal returns same owner and fresh authority after root acceptance; concurrent exact occasion sends once; other session sends independently; completed exact occasion does not send again; different terminal/gate occasions remain independent; reopened Journal has a new owner while durable dedupe still refuses replay.
2. Same actual Journal A accepted → lawful A closure → no active root refuses send → B accepted. The same Runtime reads each change and sends only under B. No cached permission.
3. Two actual Observed callers, controlled real Host boundary returning a receipt, then actual managed physical acceptance. Both get real leases; only the latest observer is notified: registrations `[1,1]`, Notify `[0,1]`. Host send count is one.
4. Same Physical callers preserve the existing ownership behavior: after actual acceptance the first replaced waiter remains pending and the second returns the real physical id. **This does not claim both callers settle**. Host send count is one.
5. Actual joiner `AttachDisposable` throws an exact sentinel Error: only that joiner rejects with the same object; the first successful send remains successful; no extra send; a new independent occasion still works.
6. Host returns real Retryable outcome: both callers see failure, no joiner lease is registered; the first registration is released and a new independent occasion still works.

All original NDJSON/JSON receipts, raw outputs, source hashes and build logs are retained. The first generation2 syntax build failed due to parentheses and was repaired before the final build; its raw build log is preserved separately. It is not counted as a delivered runtime defect.

## Preserved red evidence and attribution

`acceptance-observers.mjs` initially demanded Notify `[1,1]` and both Physical callers settle. These assertions are overstrict for the existing contract. Fixed697 on Node/Bun already disproves them: two sends, registrations `[1,1]`, Notify `[0,1]`; first Physical waiter pending, second completed. The original four failed runs remain unchanged.

First B1 prototype reduced sends to one but changed ownership: only first observer registered, Notify `[1,0]`; first Physical caller completed, second pending. The original assertions still fail, but the measured **missing joiner registration** is a real prototype semantic change. It motivated generation2. Fixed697 and generation2 were then compared with a separate narrowly declared owner contract, `acceptance-owner-contract.mjs`; all four baseline and four generation2 checks accepted. The original broad assertions were not silently rewritten.

First prototype product JS was not privately copied before its next build; its raw runtime receipts refer to the author's frozen first build path, with source commit `f273501` supplied for reconstruction. Do not represent those first results as a fixed tar. Generation2 product bytes are fully archived and independently compared.

## Scope limits

This proves actual Journal/HostSessionNudge dispatch and acceptance ownership at controlled Host and lease boundaries. It is not a real SDK send to an external provider. The existing replaced Physical waiter can remain pending; that limitation remains explicit. Raw failure-ledger concurrent duplicate facts (B2), cross-process arbitration and the rest of GAP-140 are not closed by this result.

## Portable replay

After extracting the archive, run:

```sh
node replay.mjs /absolute/extracted/review-root /absolute/fresh/output
```

The runner installs archived fixed697 solely for its declared runtime dependencies, copies archived generation2 dist byte for byte, recreates explicit local dependency links, and runs the twelve generation2 cases with raw commands/status. It does not compile source, edit the product, or borrow repository dist. The first-generation failed assertions remain evidence; they are not acceptance criteria for the narrow existing owner protocol.

The portable runner was actually executed once in a fresh directory: all twelve cases accepted. Its commands/status/raw outputs and retained actual Journal originals are included under `portable-replay`, without another duplicate product tree or node_modules.
