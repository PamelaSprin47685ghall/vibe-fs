import assert from 'node:assert/strict'
import fs from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'

const [product, directory, variant] = process.argv.slice(2)
fs.mkdirSync(directory, { recursive: true })
const load = path => import(pathToFileURL(join(product, 'dist', path)).href)
const journal = await load('Persistence/Journal/Surface.js')
const dispatch = await load('Interaction/Dispatch/DispatchSurface.js')
const nudge = await load('Interaction/Dispatch/OpenCode/SessionNudge.js')
const identities = await load('Foundation/Identity.js')
const { tryParseContinuationKind } = await load('Interaction/Authority/Model.js')
const session = 'b1-observed-scope'
const opened = await journal.JournalSurface_bootWithWriterId(directory, 'writer-b1-observers', 'runtime-b1-observers', process.pid, new Date().toISOString())
assert.equal(opened.ok, true)
const result = { pid: process.pid, product, variant, counts: [0, 0], registrations: [0, 0], sends: [], outcomes: [] }
const registrations = [[], []]
const releases = []
const port = {
  SubscribeTerminal: () => ({ Dispose() {} }),
  SubscribeFutureTerminal: () => ({ Dispose() {} }),
  SendPrompt: (id, text, options) => new Promise(resolve => {
    result.sends.push({ session: identities.SessionIdModule_value(id), text, metadata: options.Metadata })
    releases.push(resolve)
  }),
}
const rootWorkspace = { TryRead: () => directory }
let timer
try {
  assert.equal((await dispatch.acceptHumanRoot(opened.journal, session, 'root-b1-observers', 'engineer')).ok, true)
  const durable = journal.JournalHandle__get_Journal(opened.journal)
  const args = [port, rootWorkspace, identities.SessionIdModule_create(session), 'one exact gate occasion', tryParseContinuationKind('ProviderRetryAttempt'), undefined, durable, 'B1AcceptanceGate', identities.ProviderRunIdentityModule_create('terminal-b1-observers')]
  function call(index) {
    if (variant === 'physical') return nudge.trySendGateContinuationPhysical(...args)
    return nudge.trySendGateContinuationObserved(...args, {
      Notify: physical => { result.counts[index]++; result[`accepted${index}`] = identities.PhysicalUserMessageIdModule_value(physical) },
      AttachDisposable: item => { registrations[index].push(item); result.registrations[index]++ },
    })
  }
  const first = call(0)
  const second = call(1)
  for (let step = 0; step < 20 && releases.length === 0; step++) await new Promise(resolve => setImmediate(resolve))
  assert.ok(releases.length > 0, 'actual SendPrompt must be reached')
  await new Promise(resolve => setImmediate(resolve))
  for (const release of releases) release(dispatch.admittedWithReceipt('actual-controlled-transport-receipt'))
  const states = ['pending', 'pending']
  first.then(value => { states[0] = { tag: value.tag, fields: value.fields } }, error => { states[0] = { error: error.message } })
  second.then(value => { states[1] = { tag: value.tag, fields: value.fields } }, error => { states[1] = { error: error.message } })
  for (let step = 0; step < 20; step++) await new Promise(resolve => setImmediate(resolve))
  result.afterTransport = structuredClone(states)
  const claims = dispatch.projectionObservation(opened.journal, session).pendingClaims
  assert.equal(claims.length, 1)
  result.claim = claims[0].promptKey
  result.physical = await dispatch.acceptManagedPromptClaim(opened.journal, session, 'physical-b1-observers', result.claim, 'engineer')
  assert.equal(result.physical.ok, true, JSON.stringify(result.physical))
  const settled = await Promise.race([
    Promise.all([first, second]).then(values => values.map(value => ({ tag: value.tag, fields: value.fields }))),
    new Promise(resolve => { timer = setTimeout(() => resolve('not-settled-after-physical-acceptance'), 1000) }),
  ])
  result.outcomes = settled
  result.statesAfterActualPhysical = structuredClone(states)
  if (variant === 'physical') {
    assert.equal(settled, 'not-settled-after-physical-acceptance', 'existing single-owner contract leaves the replaced first waiter pending')
    assert.equal(states[0], 'pending')
    assert.equal(states[1].tag, 0)
    result.knownExistingReplacedWaiterPending = true
  } else {
    assert.deepEqual(result.registrations, [1, 1], 'both callers acquire a real acceptance lease')
    assert.deepEqual(result.counts, [0, 1], 'latest caller owns actual acceptance under the existing single-owner contract')
  }
  result.scope = 'Existing callback ownership, not a broadcast or both-physical-callers-settle contract.'
  result.accepted = true
} catch (error) {
  result.accepted = false
  result.error = { message: error.message, stack: error.stack }
  process.exitCode = 1
} finally {
  clearTimeout(timer)
  for (const group of registrations) for (const item of group) item.Dispose()
  journal.JournalSurface_dispose(opened.journal)
  result.closed = true
  fs.writeFileSync(join(directory, 'result.json'), JSON.stringify(result, null, 2) + '\n')
}
