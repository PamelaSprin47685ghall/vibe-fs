import assert from 'node:assert/strict'
import fs from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'

const [product, directory] = process.argv.slice(2)
fs.mkdirSync(directory, { recursive: true })
const load = path => import(pathToFileURL(join(product, 'dist', path)).href)
const journal = await load('Persistence/Journal/Surface.js')
const dispatch = await load('Interaction/Dispatch/DispatchSurface.js')
const nudge = await load('Interaction/Dispatch/OpenCode/SessionNudge.js')
const identity = await load('Foundation/Identity.js')
const { forJournal } = await load('Composition/Durable/PromptJournalAdapter.js')
const runtime = await load('Interaction/Dispatch/Dispatcher.js')
const { tryParseContinuationKind } = await load('Interaction/Authority/Model.js')
const result = { product, pid: process.pid, sends: [], checks: [] }
const releases = []
const port = {
  SubscribeTerminal: () => ({ Dispose() {} }),
  SubscribeFutureTerminal: () => ({ Dispose() {} }),
  SendPrompt: (session, text, options) => new Promise(resolve => {
    result.sends.push({ session: identity.SessionIdModule_value(session), text, metadata: options.Metadata })
    releases.push(resolve)
  }),
}
let opened = await journal.JournalSurface_bootWithWriterId(directory, 'writer-b1-ownership', 'runtime-b1-ownership', process.pid, new Date().toISOString())
assert.equal(opened.ok, true)
const durable = () => journal.JournalHandle__get_Journal(opened.journal)
const rootWorkspace = { TryRead: () => directory }
const kind = tryParseContinuationKind('ProviderRetryAttempt')
const call = (session, gate = 'same-gate', provider = 'same-terminal') => nudge.trySendGateContinuation(
  port, rootWorkspace, identity.SessionIdModule_create(session), 'actual same owner gate', kind, undefined, durable(), gate, identity.ProviderRunIdentityModule_create(provider))
async function releaseAll() {
  for (let step = 0; step < 20; step++) await new Promise(resolve => setImmediate(resolve))
  const count = releases.length
  for (const release of releases.splice(0)) release(dispatch.admittedWithReceipt('controlled-actual-transport-receipt'))
  return count
}
try {
  const firstOwner = forJournal(durable())
  assert.equal(forJournal(durable()), firstOwner)
  const sessionA = 'b1-session-a'
  const sessionB = 'b1-session-b'
  assert.equal(runtime.Runtime__ProjectionFor_ZD623056(firstOwner, identity.SessionIdModule_create(sessionA)).ActiveLogicalRun, undefined)
  for (const session of [sessionA, sessionB]) assert.equal((await dispatch.acceptHumanRoot(opened.journal, session, `root-${session}`, 'engineer')).ok, true)
  assert.ok(runtime.Runtime__ProjectionFor_ZD623056(firstOwner, identity.SessionIdModule_create(sessionA)).ActiveLogicalRun)
  assert.equal(forJournal(durable()), firstOwner)
  result.checks.push('one owner per actual AgentJournal; authority reads stay live after root acceptance')
  const a1 = call(sessionA)
  const a2 = call(sessionA)
  const b = call(sessionB)
  assert.equal(await releaseAll(), 2, 'same owner/occasion shares one send, another session stays independent')
  const outcomes = await Promise.all([a1, a2, b])
  assert.ok(outcomes.every(item => item.tag === 0))
  assert.deepEqual(outcomes[0], outcomes[1])
  assert.notDeepEqual(outcomes[0], outcomes[2])
  result.checks.push('concurrent exact occasion sends once; different session sends independently')
  const beforeRepeat = result.sends.length
  const repeated = await call(sessionA)
  assert.equal(repeated.tag, repeated.cases().indexOf('AlreadyAdmitted'))
  assert.equal(result.sends.length, beforeRepeat)
  result.checks.push('completed exact occasion does not renew; durable admission owns the decision')
  const terminal = call(sessionA, 'same-gate', 'new-terminal')
  const gate = call(sessionA, 'new-gate', 'same-terminal')
  assert.equal(await releaseAll(), 2)
  assert.ok((await Promise.all([terminal, gate])).every(item => item.tag === 0))
  result.checks.push('different terminal and gate occasions do not borrow an existing flight')
  journal.JournalSurface_dispose(opened.journal)
  opened = await journal.JournalSurface_bootWithWriterId(directory, 'writer-b1-reopened', 'runtime-b1-reopened', process.pid, new Date().toISOString())
  assert.equal(opened.ok, true)
  const reopenedOwner = forJournal(durable())
  assert.notEqual(reopenedOwner, firstOwner)
  assert.equal(forJournal(durable()), reopenedOwner)
  const afterReopen = result.sends.length
  assert.equal((await call(sessionA)).tag, repeated.tag)
  assert.equal(result.sends.length, afterReopen)
  result.checks.push('new Journal receives a distinct owner; persisted admission still blocks a replay')
  result.accepted = true
} catch (error) {
  result.accepted = false
  result.error = { message: error.message, stack: error.stack }
  process.exitCode = 1
} finally {
  if (opened?.ok) journal.JournalSurface_dispose(opened.journal)
  result.closed = true
  fs.writeFileSync(join(directory, 'result.json'), JSON.stringify(result, null, 2) + '\n')
}
