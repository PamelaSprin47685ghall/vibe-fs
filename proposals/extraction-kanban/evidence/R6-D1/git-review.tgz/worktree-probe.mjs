import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { spawnSync } from 'node:child_process'
import { existsSync, mkdtempSync, readFileSync, rmSync } from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'

const packageRoot = process.argv[2]
const expected = process.argv[3]
assert.ok(packageRoot)
assert.ok(['failure', 'success'].includes(expected))
const watched = ['dist/Git/Operations.js', 'dist/Git/WorktreeResource.js']
const digest = file => createHash('sha256').update(readFileSync(join(packageRoot, file))).digest('hex')
const before = watched.map(file => [file, digest(file)])
const change = await import(pathToFileURL(join(packageRoot, 'dist/Change/Surface.js')).href)
const scratch = mkdtempSync('/private/tmp/d1-git-real-worktree.')
const repo = join(scratch, 'bound')
const foreign = join(scratch, 'foreign')
const worktree = join(scratch, 'worktree')
const originalCwd = process.cwd()
const calls = []
const native = (args, cwd = repo) => {
  const result = spawnSync('git', args, { cwd, encoding: 'utf8', timeout: 10000, env: { ...process.env, GIT_CONFIG_GLOBAL: '/dev/null', GIT_CONFIG_SYSTEM: '/dev/null' } })
  assert.equal(result.error, undefined)
  assert.equal(result.signal, null)
  return result
}
try {
  assert.equal(native(['init', '--quiet', repo], scratch).status, 0)
  assert.equal(native(['init', '--quiet', foreign], scratch).status, 0)
  assert.equal(native(['-c', 'user.name=Owned Review', '-c', 'user.email=review@example.invalid', 'commit', '--allow-empty', '-m', 'owned review seed']).status, 0)
  process.chdir(foreign)
  const runner = async command => {
    const cwd = command.workingDirectory ?? process.cwd()
    const result = native(command.args, cwd)
    calls.push({ args: command.args, cwd, code: result.status, stderr: result.stderr })
    return { kind: 'Observed', ending: { kind: 'Exited', exitCode: result.status }, stopRequested: null, output: { kind: 'InMemory', stdout: result.stdout, stderr: result.stderr }, fault: null }
  }
  const git = change.createGit(repo, runner)
  const created = await change.worktreeCreate(git, 'owned-binding', worktree)
  assert.equal(created.ok, true, created.error)
  assert.equal(existsSync(worktree), true)
  const released = await change.worktreeRelease(created.value)
  if (expected === 'failure') {
    assert.equal(released.ok, false)
    assert.equal(calls.filter(call => call.args[0] === 'branch').length, 0)
    assert.equal(calls.find(call => call.args[1] === 'remove').cwd, foreign)
    assert.equal(existsSync(worktree), true)
    assert.equal(native(['worktree', 'remove', '--force', worktree]).status, 0)
    assert.equal(native(['branch', '-D', 'manager/owned-binding']).status, 0)
  } else {
    assert.equal(released.ok, true, released.error)
    assert.equal(calls.find(call => call.args[1] === 'remove').cwd, repo)
    assert.equal(calls.find(call => call.args[0] === 'branch').cwd, repo)
    assert.equal(existsSync(worktree), false)
    assert.equal(native(['show-ref', '--verify', '--quiet', 'refs/heads/manager/owned-binding']).status, 1)
  }
  assert.deepEqual(watched.map(file => [file, digest(file)]), before)
  console.log(JSON.stringify({ runtime: process.versions.bun ?? process.version, expected, released, calls, unchangedProductDigests: before }, null, 2))
} finally {
  process.chdir(originalCwd)
  rmSync(scratch, { recursive: true, force: true })
}
