import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { existsSync, lstatSync, mkdtempSync, readFileSync, readdirSync, realpathSync, rmSync, writeFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'

const root = process.env.D1_REVIEW_PACKAGE_ROOT ?? '/private/tmp/d1-clean-install-652.MIf8Hg/node_modules/wanxiangshu'
const archive = process.env.D1_REVIEW_PACKAGE_ARCHIVE ?? '/private/tmp/d1-candidate-652.88ET6L/wanxiangshu-0.9.0.tgz'
const archiveDigest = '003bc8818969597f9afd6a1c0767c7aae271dd53e5f0392b146367d156ec3887'
const digest = bytes => createHash('sha256').update(bytes).digest('hex')
assert.equal(digest(readFileSync(archive)), archiveDigest)
const load = relative => import(pathToFileURL(join(root, relative)).href)
const change = await load('dist/Change/Surface.js')
const host = await load('dist/Change/Host/Surface.js')
const request = await load('dist/Process/ProcessRequest.js')
const gateway = await load('dist/Git/Gateway.js')
const sweep = await load('dist/Change/Host/WorktreeCleanup.js')
const identity = await load('dist/Foundation/Identity.js')
const gitTypes = await load('dist/Persistence/EventStore/GitTypes.js')
const { DeadlineModule_ofBudget } = await load('dist/Process/Deadline.js')
const { default: dateOffset } = await load('dist/fable_modules/fable-library-js.5.13.0/DateOffset.js')
const { FSharpResult$2 } = await load('dist/fable_modules/fable-library-js.5.13.0/Result.js')
const { ofArray } = await load('dist/fable_modules/fable-library-js.5.13.0/List.js')
const ok = value => new FSharpResult$2(0, [value])
const error = value => new FSharpResult$2(1, [value])
const observations = []
const scratch = mkdtempSync('/private/tmp/d1-git-proof-scratch.')

function productManifest(directory, prefix = '') {
  const output = []
  for (const entry of readdirSync(directory)) {
    const relative = prefix ? `${prefix}/${entry}` : entry
    const file = join(directory, entry)
    const stat = lstatSync(file)
    if (stat.isSymbolicLink()) continue
    if (stat.isDirectory()) output.push(...productManifest(file, relative))
    else output.push([relative, digest(readFileSync(file))])
  }
  return output
}
const before = productManifest(root)
const requireFromPackage = createRequire(join(root, 'package.json'))
const resolvedDependencies = {
  package: realpathSync(root),
  wanxiangli: realpathSync(join(root, 'node_modules', 'wanxiangli')),
  properLockfile: realpathSync(requireFromPackage.resolve('proper-lockfile')),
}
for (const resolved of Object.values(resolvedDependencies)) assert.equal(resolved.includes('/Users/yuanxi/Workwork/'), false)
const good = (stdout = '', code = 0, stderr = '') => ({ kind: 'Observed', ending: { kind: 'Exited', exitCode: code }, stopRequested: null, output: { kind: 'InMemory', stdout, stderr }, fault: null })
const failed = (name, marker = 'controlled execution failure') => ({
  kind: 'Observed',
  ending: name === 'signal' ? { kind: 'Signaled', signal: 'SIGTERM' } : name === 'fault' ? { kind: 'Exited', exitCode: 0 } : { kind: 'Unconfirmed' },
  stopRequested: name === 'cancel' ? { kind: 'CancellationRequested' } : null,
  output: name === 'output' ? null : { kind: 'InMemory', stdout: '', stderr: 'cannot lock ref expected update-ref' },
  fault: name === 'fault' || name === 'output' ? marker : null,
})
function runnerWith(answer) {
  const calls = []
  return {
    calls,
    runner: async command => {
      const key = command.args.join(' ')
      calls.push(key)
      return answer(command, key) ?? good()
    },
  }
}

try {
  for (const name of ['signal', 'unknown', 'fault', 'cancel', 'output']) {
    for (const method of ['finalize', 'rebase']) {
      const fake = runnerWith((command, key) => key === 'rev-parse --git-path rebase-merge' ? failed(name) : key.startsWith('grep ') ? good('', 1) : undefined)
      const result = method === 'finalize'
        ? await host.finalizeWorktree(fake.runner, 'manager-review', scratch)
        : await change.gitRebase(change.createGit(scratch, fake.runner), scratch, 'main')
      assert.equal(result.ok, false, `${method}:${name}`)
      assert.equal(fake.calls.some(key => key.startsWith('commit ') || key.startsWith('rebase ') || key.startsWith('update-ref ')), false)
      observations.push({ kind: 'query-failure', method, name, result, calls: fake.calls })
    }
    const stale = runnerWith((command, key) => key.startsWith('update-ref ') ? failed(name) : key.startsWith('rev-parse --git-path ') ? good('missing-review-state\n') : key.startsWith('grep ') ? good('', 1) : undefined)
    const result = await host.finalizeWorktree(stale.runner, 'manager-review', scratch)
    assert.equal(result.ok, false)
    assert.equal(stale.calls.some(key => key.startsWith('commit ')), false)
    observations.push({ kind: 'stale-ref-failure', name, result, calls: stale.calls })

    const merge = runnerWith((command, key) => key === 'rev-parse HEAD' ? good(command.workingDirectory === scratch ? 'candidate\n' : 'candidate\n') : key.startsWith('symbolic-ref ') ? good('main\n') : key === 'rev-parse refs/heads/main' ? good('target\n') : key.startsWith('merge --ff-only ') ? failed(name) : undefined)
    const merged = await change.gitFfMerge(change.createGit('/owned/repo', merge.runner), scratch, 'main', 'target', 'candidate')
    assert.equal(merged.ok, false)
    assert.notEqual(merged.error, 'target ref moved')
    observations.push({ kind: 'merge-failure', name, result: merged, calls: merge.calls })
  }

  const positive = runnerWith((command, key) => key.startsWith('rev-parse --git-path ') ? good('missing-review-state\n') : key.startsWith('grep ') ? good('', 1) : undefined)
  assert.equal((await host.finalizeWorktree(positive.runner, 'manager-review', scratch)).ok, true)
  assert.equal(positive.calls.at(-1), 'commit -m candidate: manager-review')
  observations.push({ kind: 'grep-one-positive', calls: positive.calls })

  const blank = runnerWith((command, key) => key.startsWith('grep ') ? good('', 1) : undefined)
  const blankResult = await change.gitRebase(change.createGit(scratch, blank.runner), scratch, 'main')
  assert.equal(blankResult.ok, false)
  assert.equal(blank.calls.some(key => key.startsWith('commit ') || key.startsWith('rebase ') || key.startsWith('update-ref ')), false)
  observations.push({ kind: 'blank-query-rejected', result: blankResult, calls: blank.calls })

  for (const method of ['finalize', 'rebase', 'candidate']) {
    const fake = runnerWith((command, key) => key.startsWith('update-ref ') ? good('', 1, 'cannot lock ref REBASE_HEAD: lock exists') : key.startsWith('rev-parse --git-path ') ? good('missing-review-state\n') : key.startsWith('grep ') ? good('', 1) : undefined)
    const git = change.createGit(scratch, fake.runner)
    const result = method === 'finalize' ? await host.finalizeWorktree(fake.runner, 'manager-review', scratch) : method === 'rebase' ? await change.gitRebase(git, scratch, 'main') : await change.gitCandidateCommit(git, 'candidate-review')
    assert.equal(result.ok, false)
    assert.equal(fake.calls.some(key => key.startsWith('commit ') || key.startsWith('rebase ')), false)
    observations.push({ kind: 'stale-ref-confirmed-one-stops', method, result, calls: fake.calls })
  }

  for (const code of [2, 128, 143]) {
    const fake = runnerWith((command, key) => key.startsWith('symbolic-ref ') ? good('', code) : undefined)
    const result = await change.gitFreezeTargetBranch(change.createGit(scratch, fake.runner))
    assert.equal(result.ok, false)
    assert.doesNotMatch(result.error, /detached/i)
    assert.match(result.error, new RegExp(String(code)))
    observations.push({ kind: 'freeze-error-is-not-detached', code, result, calls: fake.calls })
  }

  for (const [message, expected] of [
    ["fatal: cannot lock ref 'HEAD': Unable to create 'HEAD.lock': File exists.", false],
    ["fatal: cannot lock ref 'HEAD': is at aaaaaa but expected bbbbbb", true],
    ['fatal: unexpected index failure', false],
  ]) {
    const fake = runnerWith((command, key) => key === 'rev-parse HEAD' ? good('candidate\n') : key.startsWith('symbolic-ref ') ? good('main\n') : key === 'rev-parse refs/heads/main' ? good('target\n') : key.startsWith('merge --ff-only ') ? good('', 1, message) : undefined)
    const result = await change.gitFfMerge(change.createGit('/owned/repo', fake.runner), scratch, 'main', 'target', 'candidate')
    assert.equal(result.ok, false)
    assert.equal(result.error === 'target ref moved', expected)
    if (!expected) assert.equal(result.error, message)
    observations.push({ kind: 'confirmed-merge-diagnostic-classification', message, expectedCasMoved: expected, result, calls: fake.calls })
  }

  for (const side of ['remove', 'delete']) {
    const calls = []
    let releaseFirst
    const pendingFirst = new Promise(resolve => { releaseFirst = resolve })
    const port = {
      ListWorktrees: async () => ok(ofArray(side === 'remove' ? [
        [identity.WorktreePathModule_create('/owned/first'), identity.WorktreeIdentityModule_create('manager/first')],
        [identity.WorktreePathModule_create('/owned/second'), identity.WorktreeIdentityModule_create('manager/second')],
      ] : [])),
      ListManagerBranches: async () => ok(ofArray([identity.WorktreeIdentityModule_create('manager/first'), identity.WorktreeIdentityModule_create('manager/second')])),
      RemoveWorktree: value => {
        const name = identity.WorktreePathModule_value(value)
        calls.push(`remove:${name}`)
        return name.endsWith('/first') ? pendingFirst : Promise.resolve(ok(undefined))
      },
      DeleteBranch: value => {
        const name = identity.WorktreeIdentityModule_value(value)
        calls.push(`delete:${name}`)
        return side === 'delete' && name.endsWith('/first') ? pendingFirst : Promise.resolve(ok(undefined))
      },
    }
    const operation = sweep.sweepStaleArtifacts(port, ofArray([]))
    await new Promise(resolve => setImmediate(resolve))
    assert.equal(calls.length, 1)
    releaseFirst(error('execution unconfirmed'))
    const result = await operation
    assert.equal(result.tag, 1)
    assert.equal(calls.length, 1)
    observations.push({ kind: 'sweep-stops', side, calls, error: result.fields[0] })
  }

  const releaseFake = runnerWith((command, key) => key.startsWith('worktree remove ') ? failed('unknown') : undefined)
  const resource = change.worktreeAdopt(change.createGit(scratch, releaseFake.runner), 'manager/review', scratch)
  const firstRelease = change.worktreeRelease(resource)
  const secondRelease = change.worktreeRelease(resource)
  const releaseResults = await Promise.all([firstRelease, secondRelease])
  await change.worktreeDispose(resource)
  assert.equal(releaseResults.every(result => result.ok === false), true)
  assert.equal(releaseFake.calls.length, 1)
  observations.push({ kind: 'release-single-flight-failure', calls: releaseFake.calls, results: releaseResults })

  {
    let finishRemove
    const held = new Promise(resolve => { finishRemove = resolve })
    const fake = runnerWith((command, key) => key.startsWith('worktree remove ') ? held : undefined)
    const created = await change.worktreeCreate(change.createGit(scratch, fake.runner), 'review-owned', scratch)
    assert.equal(created.ok, true)
    const release = change.worktreeRelease(created.value)
    const disposal = change.worktreeDispose(created.value)
    await new Promise(resolve => setImmediate(resolve))
    assert.equal(fake.calls.filter(key => key.startsWith('worktree remove ')).length, 1)
    finishRemove(failed('unknown'))
    assert.equal((await release).ok, false)
    await disposal
    assert.equal((await change.worktreeRelease(created.value)).ok, false)
    assert.equal(fake.calls.filter(key => key.startsWith('worktree remove ')).length, 1)
    assert.equal(fake.calls.some(key => key.startsWith('branch -D ')), false)
    observations.push({ kind: 'owned-release-dispose-concurrent-failure', calls: fake.calls })
  }

  for (const name of ['unknown', 'signal', 'deadline', 'fault']) {
    let now = dateOffset(Date.parse('2026-10-18T15:00:00Z'), 0)
    const deadline = DeadlineModule_ofBudget(now, 1000)
    const snapshot = new gitTypes.StoreSnapshot(gitTypes.RootOidModule_create(gitTypes.GitObjectIdModule_create('a'.repeat(40))))
    const calls = []
    const terminal = name === 'signal' ? new request.EndEvidence(0, [new request.ProgramEnd(1, ['SIGTERM'])]) : name === 'fault' ? new request.EndEvidence(0, [new request.ProgramEnd(0, [0])]) : new request.EndEvidence(1, [])
    const stop = name === 'deadline' ? new request.StopRequest(1, [1000]) : undefined
    const failure = new request.ProcessResult(1, [new request.ProcessObservation(terminal, stop, undefined, name === 'fault' ? 'capture failure' : undefined)])
    const run = async args => {
      calls.push([...args])
      now = dateOffset(Date.parse('2026-10-18T15:00:02Z'), 0)
      return error(failure)
    }
    const result = await gateway.GitGateway_converge({ ReadRef: async () => undefined }, join(scratch, name), run, 3, 'origin', undefined, async () => ok(snapshot), deadline, () => now)
    assert.equal(result.tag, 1)
    assert.equal(result.fields[0].tag, 1)
    assert.equal(calls.length, 1)
    assert.equal(calls[0][0], 'push')
    assert.match(result.fields[0].fields[0], /Process end:/)
    observations.push({ kind: 'push-no-retry-even-after-deadline', name, calls, error: result.fields[0].fields[0] })
  }

  {
    const now = dateOffset(Date.parse('2026-10-18T15:00:00Z'), 0)
    const snapshot = new gitTypes.StoreSnapshot(gitTypes.RootOidModule_create(gitTypes.GitObjectIdModule_create('a'.repeat(40))))
    const calls = []
    let pushes = 0
    const run = async args => {
      const argv = [...args]
      calls.push(argv)
      if (argv[0] === 'push') return ok(new request.TextProcessExit(++pushes === 1 ? 1 : 0, '', pushes === 1 ? 'stale info' : ''))
      assert.equal(argv[0], 'ls-remote')
      return ok(new request.TextProcessExit(0, '', ''))
    }
    const result = await gateway.GitGateway_converge({ ReadRef: async () => undefined }, join(scratch, 'lease-positive'), run, 3, 'origin', undefined, async () => ok(snapshot), DeadlineModule_ofBudget(now, 1000), () => now)
    assert.equal(result.tag, 0)
    assert.deepEqual(calls.map(args => args[0]), ['push', 'ls-remote', 'push'])
    observations.push({ kind: 'confirmed-git-rejection-retries-positive', calls })
  }

  const spool = join(scratch, 'combined-spool')
  writeFileSync(spool, 'stdout-and-stderr-interleaved')
  const spooled = new request.ProcessResult(1, [new request.ProcessObservation(new request.EndEvidence(0, [new request.ProgramEnd(0, [23])]), undefined, new request.CapturedOutput(1, [spool, 29n, 1]), undefined)])
  const projected = await gateway.GitGateway_createProcessRunner(async () => spooled, scratch)(ofArray(['rev-parse', 'HEAD']))
  assert.equal(projected.tag, 1)
  assert.equal(projected.fields[0], spooled)
  assert.equal(existsSync(spool), false)
  observations.push({ kind: 'spool-explicit-rejection-and-delete', preservedEnd: 23, deleted: true })

  assert.deepEqual(productManifest(root), before)
  assert.equal(digest(readFileSync(archive)), archiveDigest)
  console.log(JSON.stringify({ runtime: process.versions.bun ? `Bun ${process.versions.bun}` : `Node ${process.version}`, archiveDigest, productFiles: before.length, unchanged: true, borrowedDeclaredDependencies: false, resolvedDependencies, observations }, null, 2))
} finally {
  rmSync(scratch, { recursive: true, force: true })
}
