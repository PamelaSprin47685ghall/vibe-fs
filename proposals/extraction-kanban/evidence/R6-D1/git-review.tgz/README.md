# D1 text Git review of the final clean installation

Input archive: `wanxiangshu-0.9.0.tgz`, SHA-256 `003bc8818969597f9afd6a1c0767c7aae271dd53e5f0392b146367d156ec3887`. The archive contains 2,076 members. The supplied clean npm installation has 2,904 regular files under its wanxiangshu package tree because npm added nested dependencies. The probe compared every regular installed file before and after the run; the installation and archive stayed unchanged.

Node v26.6.0 and Bun 1.3.14 each passed 41 bounded assertion groups. The two runtimes are separate support observations, not 82 different behaviors. `node.log` and `bun.log` retain the original output and resolved package/dependency locations. No workspace dependency symlink was used. The actual production modules were loaded from the clean installed package; these are internal-module review probes, not a claim that those modules are public npm exports or that the probe was a declaration-compilation test.

The groups cover query signal/Unknown/fault/cancellation/missing output, stale-ref execution failure, merge failure isolation from CAS classification, grep exit 1, empty query refusal, delayed sweep writes, failed release receipt reuse including concurrent owned Release/Dispose, uncertain push refusal after deadline, confirmed Git refusal retry, spool rejection/deletion, confirmed stale deletion exit 1, non-detached query failures, and exact ref-mismatch classification.

The separate `worktree-probe.mjs` used actual native Git commands through the production ChangeSurface command port. Each runtime created two private repositories, changed cwd to the foreign repository, then created and released a worktree bound to the other repository. Remove and branch deletion both used the bound repository. Temporary repositories were removed. This did not exercise physical ProcessRunner supervision; it verifies a real Git consumer and repository binding.

## Replay

The exact package archive is included. Recreate a clean installation using the main delivery's locked install procedure, without a workspace or sibling source dependency. Then set both locations explicitly:

```sh
export D1_REVIEW_PACKAGE_ROOT=/absolute/clean-install/node_modules/wanxiangshu
export D1_REVIEW_PACKAGE_ARCHIVE=/absolute/wanxiangshu-0.9.0.tgz
node probe.mjs > replay-node.log
bun probe.mjs > replay-bun.log
node worktree-probe.mjs "$D1_REVIEW_PACKAGE_ROOT" success > replay-node-worktree.log
bun worktree-probe.mjs "$D1_REVIEW_PACKAGE_ROOT" success > replay-bun-worktree.log
```

The expected archive digest is fixed in the probe. Both probes write only owned temporary scratch directories and remove them. Source files, source builds, a browser, a Host deployment, and remote Git writes are unnecessary. Other D1 process/Host/contract evidence and D2 remain outside these probes.
