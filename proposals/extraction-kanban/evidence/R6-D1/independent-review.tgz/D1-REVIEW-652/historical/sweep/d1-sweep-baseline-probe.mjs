import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { sweepStaleArtifacts } from '/private/tmp/process-cancellation-review-exact.4zZLQr/package/dist/Change/Host/WorktreeCleanup.js'
import { FSharpResult$2 } from '/private/tmp/process-cancellation-review-exact.4zZLQr/package/dist/fable_modules/fable-library-js.5.13.0/Result.js'
import { ofArray, empty } from '/private/tmp/process-cancellation-review-exact.4zZLQr/package/dist/fable_modules/fable-library-js.5.13.0/List.js'
import { WorktreePathModule_create, WorktreePathModule_value, WorktreeIdentityModule_create, WorktreeIdentityModule_value } from '/private/tmp/process-cancellation-review-exact.4zZLQr/package/dist/Foundation/Identity.js'

const source = '/private/tmp/process-cancellation-review-exact.4zZLQr/package/dist/Change/Host/WorktreeCleanup.js'
const digest = () => createHash('sha256').update(readFileSync(source)).digest('hex')
const before = digest()
const ok = value => new FSharpResult$2(0, [value])
const error = value => new FSharpResult$2(1, [value])
const results = []
for (const scenario of ['worktree', 'branch']) {
  const calls = []
  let release
  const first = new Promise(resolve => { release = resolve })
  const paths = ['/owned/a', '/owned/b'].map(WorktreePathModule_create)
  const identities = ['manager/a', 'manager/b'].map(WorktreeIdentityModule_create)
  const port = {
    ListWorktrees: async () => ok(scenario === 'worktree' ? ofArray(paths.map((value, i) => [value, identities[i]])) : empty()),
    ListManagerBranches: async () => ok(scenario === 'branch' ? ofArray(identities) : empty()),
    RemoveWorktree: async path => {
      const value = WorktreePathModule_value(path)
      calls.push(value)
      return value.endsWith('/a') ? first : ok(undefined)
    },
    DeleteBranch: async identity => {
      const value = WorktreeIdentityModule_value(identity)
      calls.push(value)
      return value.endsWith('/a') ? first : ok(undefined)
    },
  }
  const pending = sweepStaleArtifacts(port, empty())
  await new Promise(resolve => setImmediate(resolve))
  const beforeFirstReceipt = [...calls]
  release(error('Controlled missing execution receipt'))
  const result = await pending
  results.push({ scenario, beforeFirstReceipt, after: calls, result: { tag: result.tag, fields: result.fields } })
}
assert.equal(digest(), before)
console.log(JSON.stringify({ host: process.execPath, sourceSHA256: before, exactProductSourceUnchanged: true, productionFunction: 'sweepStaleArtifacts', controlledGitPort: true, realGitMutation: false, results }))
assert.ok(results.every(value => value.beforeFirstReceipt.length === 1 && value.beforeFirstReceipt[0].endsWith('/a')), 'D1 RED: sweep must wait for the first deletion receipt before starting the next deletion')
