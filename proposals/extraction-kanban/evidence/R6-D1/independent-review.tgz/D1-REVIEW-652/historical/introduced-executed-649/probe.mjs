import assert from 'node:assert/strict'
import fs from 'node:fs'
import childProcess from 'node:child_process'
import { syncBuiltinESMExports } from 'node:module'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { parse } from 'smol-toml'

const product = resolve(process.argv[2])
const scratch = resolve(process.argv[3])
const executor = await import(pathToFileURL(join(product, 'dist/OpenCode/Tools/ExecutorToolSurface.js')).href)
const { registerBounded } = await import(pathToFileURL(join(product, 'dist/OpenCode/Codec/ToolHostSurface.js')).href)
const marker = join(scratch, 'target-must-not-run')
const quote = value => "'" + value.replaceAll("'", "'\\''") + "'"
const schema = kind => ({ kind, describe() { return this }, optional() { return this } })
const tools = { tool: { schema: { string: () => schema('string'), number: () => schema('number'), boolean: () => schema('boolean') } } }
const originalSpawn = childProcess.spawn
const originalBunSpawn = globalThis.Bun?.spawn
let blockedAsyncStarts = 0
const block = () => {
  blockedAsyncStarts++
  throw new Error('Controlled worker start callback failed before the real async spawn')
}
let wire
try {
  childProcess.spawn = block
  if (originalBunSpawn) globalThis.Bun.spawn = block
  syncBuiltinESMExports()
  const code = `require('node:fs').writeFileSync(${JSON.stringify(marker)}, 'unexpected execution')`
  wire = await executor.run(tools, {}, { command: `exec /opt/homebrew/bin/node -e ${quote(code)}`, output_budget_bytes: 1024 }, { sessionID: 'd1-no-confirmed-start' }, 'ready')
} finally {
  childProcess.spawn = originalSpawn
  if (originalBunSpawn) globalThis.Bun.spawn = originalBunSpawn
  syncBuiltinESMExports()
}
assert.ok(blockedAsyncStarts > 0, 'The controlled boundary must actually be exercised')
assert.equal(fs.existsSync(marker), false)
const definition = registerBounded({ tool: value => value }, 'run', 'D1 uncertain execution fact', async () => wire)
const visible = await definition.execute({}, { sessionID: 'd1-no-confirmed-start' })
assert.equal(visible, wire)
const value = parse(visible)
assert.equal(value.end_unconfirmed, true)
assert.equal(value.output_complete, false)
assert.equal(value.fault_present, true)
console.log(JSON.stringify({ host: process.execPath, case: 'all-async-spawns-blocked-before-physical-worker-start', blockedAsyncStarts, targetMarkerAbsent: true, registeredWire: visible, parsed: value, scope: 'Controlled worker-start function throws before calling its original async spawn. Bun may perform owned FIFO setup commands before this point; no target execution is authorised by that setup.' }))
assert.notEqual(value.executed, true, 'D1 RED: an unconfirmed start must not be presented as confirmed executed=true')
