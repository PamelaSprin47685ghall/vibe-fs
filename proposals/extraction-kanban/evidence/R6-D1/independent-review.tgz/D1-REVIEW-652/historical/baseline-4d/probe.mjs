import assert from 'node:assert/strict'
import fs from 'node:fs'
import { join } from 'node:path'
import { SupervisedProcess } from 'wanxiangli/supervision'
import * as surface from './dist/Process/Surface.js'
import * as executor from './dist/OpenCode/Tools/ExecutorToolSurface.js'
import * as host from './dist/Change/Host/Surface.js'
import { registerBounded } from './dist/OpenCode/Codec/ToolHostSurface.js'
import { parse } from 'smol-toml'

const scenario = process.argv[2]
const scratch = process.argv[3]
const node = '/opt/homebrew/bin/node'
const quote = value => "'" + value.replaceAll("'", "'\\''") + "'"
const schema = kind => ({ kind, describe() { return this }, optional() { return this } })
const tools = { tool: { schema: { string: () => schema('string'), number: () => schema('number'), boolean: () => schema('boolean') } } }
const owned = []
const emit = value => console.log(JSON.stringify({ host: process.execPath, fixedArchive: '4d594fd547b791b2dd961ace0c8763140b08b06b0242a039e522460f1eaaa162', scenario, ...value }))

try {
  if (scenario === 'native-facts') {
    const observed = []
    for (const [name, code] of [['normal-143', 'process.exit(143)'], ['signal-TERM', "process.kill(process.pid, 'SIGTERM')"]]) {
      const physical = new SupervisedProcess({ executable: node, args: ['-e', code], cwd: scratch, env: {}, tailBytes: 0, maxWriteBytes: 65536 })
      owned.push(physical)
      assert.equal((await physical.started()).kind, 'Started')
      let native
      for (;;) {
        const next = await physical.takeOutput()
        if (next.kind === 'Closed') {
          assert.equal(next.state.failure, null)
          native = next.state.exit
          break
        }
        assert.equal(next.kind, 'Chunk')
        assert.equal(next.bytes.length, 0)
      }
      const product = await surface.run(surface.command(node, ['-e', code], scratch, undefined), surface.estimate(10, 4096, 'medium'), surface.context(scratch, 5000), surface.createCancellationToken(false))
      assert.equal(product.ok, true)
      const wire = await executor.run(tools, {}, { command: `exec ${quote(node)} -e ${quote(code)}`, output_budget_bytes: 4096 }, { sessionID: `d1-baseline-${name}` }, 'ready')
      const registered = registerBounded({ tool: value => value }, 'run', 'D1 native termination review', async () => wire)
      const visible = await registered.execute({}, { sessionID: `registered-${name}` })
      assert.equal(visible, wire)
      observed.push({ name, native, product, wire: parse(wire) })
    }
    assert.deepEqual(observed.map(value => value.native), [{ code: 143, signal: null }, { code: null, signal: 'SIGTERM' }])
    emit({ observed, physicalFactsDistinct: true, publicFactsDistinct: JSON.stringify(observed[0].product) !== JSON.stringify(observed[1].product), visibleFactsDistinct: JSON.stringify(observed[0].wire) !== JSON.stringify(observed[1].wire), expectedBeforeD1: 'The two product and visible facts still collapse; the next assertion is the red acceptance condition.' })
    assert.notDeepEqual(observed[0].product, observed[1].product, 'D1 RED: normal exit 143 and native SIGTERM must remain distinct')
  } else if (scenario === 'query-write') {
    const records = []
    for (const failedCode of [128, 143]) {
      const calls = []
      const runner = async command => {
        calls.push(command.args)
        if (command.args[0] === 'rev-parse') return [failedCode, '', 'Controlled state query failure']
        if (command.args[0] === 'grep') return [1, '', '']
        return [0, '', '']
      }
      const result = await host.finalizeWorktree(runner, 'd1-independent-manager', scratch)
      const query = calls.findIndex(args => args[0] === 'rev-parse')
      assert.notEqual(query, -1)
      const writes = calls.slice(query + 1).filter(args => ['commit', 'rebase', 'update-ref'].includes(args[0]))
      records.push({ failedCode, result, calls, writes })
    }
    emit({ records, commandPortControlled: true, realGitMutation: false, expectedBeforeD1: 'Current int-only consumer continues a write branch after failed state query. This does not classify 143 as a signal.' })
    assert.ok(records.every(value => value.writes.length === 0 && value.result.ok === false), 'D1 RED: failed state query must not lead to later commit, rebase or ref writes')
  } else {
    assert.fail(`Unknown review scenario: ${scenario}`)
  }
} finally {
  for (const value of owned) {
    value.signal('SIGKILL')
    value.discardOutput()
  }
  const ends = await Promise.all(owned.map(value => value.wait(5000)))
  assert.ok(ends.every(value => value.kind === 'Closed'))
  emit({ cleanup: true, ownedPhysicalControls: owned.length, allControlsClosed: true })
}
