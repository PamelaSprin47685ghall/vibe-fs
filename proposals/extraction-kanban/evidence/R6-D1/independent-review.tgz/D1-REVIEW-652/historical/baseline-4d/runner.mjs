import assert from 'node:assert/strict'
import fs from 'node:fs'
import { spawn } from 'node:child_process'
import { dirname, join, relative } from 'node:path'
import { createHash } from 'node:crypto'

const repository = '/Users/yuanxi/Workwork/vibe-fs'
const archive = '/private/tmp/wanxiangshu-cancel-4d594fd.tgz'
const expected = '4d594fd547b791b2dd961ace0c8763140b08b06b0242a039e522460f1eaaa162'
const evidence = fs.mkdtempSync('/private/tmp/d1-independent-baseline-evidence-')
const scratch = fs.mkdtempSync('/private/tmp/d1-independent-baseline-case-')
const digest = path => createHash('sha256').update(fs.readFileSync(path)).digest('hex')
const save = (name, value) => fs.writeFileSync(join(evidence, name), JSON.stringify(value, null, 2), { mode: 0o600 })
const walk = root => {
  const result = {}
  const visit = dir => {
    for (const name of fs.readdirSync(dir).sort()) {
      const path = join(dir, name)
      const stat = fs.lstatSync(path)
      assert.equal(stat.isSymbolicLink(), false)
      if (stat.isDirectory()) visit(path)
      else result[relative(root, path)] = digest(path)
    }
  }
  visit(root)
  return result
}
const run = async (name, executable, args, cwd, env, timeoutMs = 45000) => {
  const stdout = fs.openSync(join(evidence, `${name}.stdout`), 'w', 0o600)
  const stderr = fs.openSync(join(evidence, `${name}.stderr`), 'w', 0o600)
  const child = spawn(executable, args, { cwd, env, detached: true, stdio: ['ignore', stdout, stderr] })
  let timedOut = false
  const timer = setTimeout(() => {
    timedOut = true
    try { process.kill(-child.pid, 'SIGKILL') } catch (error) { if (error.code !== 'ESRCH') throw error }
  }, timeoutMs)
  const result = await new Promise((resolve, reject) => {
    child.once('error', reject)
    child.once('close', (code, signal) => resolve({ code, signal, timedOut, pid: child.pid }))
  })
  clearTimeout(timer)
  fs.closeSync(stdout)
  fs.closeSync(stderr)
  save(`${name}.status.json`, result)
  console.log(JSON.stringify({ name, ...result, evidence }))
  return result
}

console.log(JSON.stringify({ evidence, scratch }))
try {
  assert.equal(digest(archive), expected)
  const extraction = await run('extract', '/usr/bin/tar', ['-xzf', archive, '-C', scratch], scratch, { PATH: '/usr/bin:/bin' })
  assert.equal(extraction.code, 0)
  const product = join(scratch, 'package')
  const before = walk(product)
  fs.symlinkSync(join(product, 'dist'), join(scratch, 'dist'))
  fs.mkdirSync(join(scratch, 'node_modules'))
  fs.symlinkSync(join(product, 'node_modules/wanxiangli'), join(scratch, 'node_modules/wanxiangli'))
  const packageJson = JSON.parse(fs.readFileSync(join(repository, 'package.json')))
  const dependencies = [...new Set([...Object.keys(packageJson.dependencies), ...Object.keys(packageJson.peerDependencies), 'smol-toml'])].filter(name => name !== 'wanxiangli')
  const borrowed = []
  for (const name of dependencies) {
    const path = fs.realpathSync(join(repository, 'node_modules', name))
    const link = join(scratch, 'node_modules', name)
    fs.mkdirSync(dirname(link), { recursive: true })
    fs.symlinkSync(path, link)
    borrowed.push({ name, path, version: JSON.parse(fs.readFileSync(join(path, 'package.json'))).version })
  }
  fs.copyFileSync('/private/tmp/d1-independent-baseline-probe.mjs', join(scratch, 'probe.mjs'))
  fs.writeFileSync(join(scratch, 'package.json'), JSON.stringify({ name: 'd1-independent-baseline', private: true, type: 'module' }))
  const results = await Promise.all(['/opt/homebrew/bin/node', '/opt/homebrew/bin/bun'].flatMap(executable => ['native-facts', 'query-write'].map(async scenario => {
    const host = executable.endsWith('bun') ? 'bun' : 'node'
    const directory = join(scratch, `${host}-${scenario}`)
    const home = join(directory, 'home')
    fs.mkdirSync(home, { recursive: true })
    return { host, scenario, result: await run(`${host}-${scenario}`, executable, ['probe.mjs', scenario, directory], scratch, { PATH: '/opt/homebrew/bin:/usr/bin:/bin', HOME: home, TMPDIR: directory, WANXIANGSHU_PROVIDER_LANGUAGE: 'en', WANXIANGSHU_NO_FATAL_EXIT: '1' }) }
  })))
  assert.deepEqual(walk(product), before)
  assert.equal(digest(archive), expected)
  save('summary.json', { results, expectedRed: true, fixedArchive: expected, productFileCount: Object.keys(before).length, productBytesUnchanged: true, archiveUnchanged: true, borrowed, limit: 'Isolated fixed package and exact bundled wanxiangli; ordinary declared dependencies and TOML oracle borrowed read-only. Query commands are controlled ports, not physical Git mutation. A result code 1 is accepted only after inspecting the specific D1 assertion.' })
  for (const value of results) {
    assert.equal(value.result.timedOut, false)
    assert.equal(value.result.code, 1)
    assert.match(fs.readFileSync(join(evidence, `${value.host}-${value.scenario}.stderr`), 'utf8'), /D1 RED:/)
  }
} finally {
  fs.copyFileSync('/private/tmp/d1-independent-baseline-probe.mjs', join(evidence, 'probe.mjs'))
  fs.copyFileSync('/private/tmp/d1-independent-baseline-runner.mjs', join(evidence, 'runner.mjs'))
  fs.rmSync(scratch, { recursive: true, force: true })
  save('cleanup.json', { scratchRemoved: !fs.existsSync(scratch) })
}
