import assert from 'node:assert/strict'
import fs from 'node:fs'
import { join, dirname, relative, resolve, sep } from 'node:path'
import { createHash } from 'node:crypto'
import { spawn } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const repository = resolve(process.argv[2])
const product = resolve(process.argv[3])
const archive = resolve(process.argv[4])
const expected = process.argv[5]
const evidence = fs.mkdtempSync('/private/tmp/d1-typed-fixed-package-evidence-')
const scratch = fs.mkdtempSync('/private/tmp/d1-typed-fixed-package-case-')
const compileScratch = join(scratch, 'compile')
const source = join(repository, 'src/Wanxiangshu')
const probeSource = join(dirname(fileURLToPath(import.meta.url)), 'D1TypedConsumer.fs')
const digest = path => createHash('sha256').update(fs.readFileSync(path)).digest('hex')
const save = (name, value) => fs.writeFileSync(join(evidence, name), JSON.stringify(value, null, 2), { mode: 0o600 })
const files = root => {
  const result = {}
  const visit = directory => {
    for (const name of fs.readdirSync(directory).sort()) {
      const path = join(directory, name)
      const stat = fs.lstatSync(path)
      assert.equal(stat.isSymbolicLink(), false)
      if (stat.isDirectory()) visit(path)
      else result[relative(root, path)] = digest(path)
    }
  }
  visit(root)
  return result
}
const run = async (name, executable, args, cwd, env) => {
  const stdout = fs.openSync(join(evidence, `${name}.stdout`), 'w', 0o600)
  const stderr = fs.openSync(join(evidence, `${name}.stderr`), 'w', 0o600)
  save(`${name}.command.json`, { executable, args, cwd, env })
  const child = spawn(executable, args, { cwd, env, detached: true, stdio: ['ignore', stdout, stderr] })
  let timedOut = false
  const timer = setTimeout(() => {
    timedOut = true
    try { process.kill(-child.pid, 'SIGKILL') } catch (error) { if (error.code !== 'ESRCH') throw error }
  }, 20000)
  const result = await new Promise((resolve, reject) => {
    child.once('error', reject)
    child.once('close', (code, signal) => resolve({ code, signal, timedOut, pid: child.pid }))
  })
  clearTimeout(timer)
  fs.closeSync(stdout)
  fs.closeSync(stderr)
  save(`${name}.status.json`, result)
  return result
}

console.log(JSON.stringify({ evidence, scratch, product, archive, expected }))
try {
  assert.equal(digest(archive), expected)
  const before = files(product)
  save('products-before.json', before)
  const { compileOwnerProject, planOwnerCompile } = await import(join(repository, 'scripts/lib/owner-compile.mjs'))
  const project = join(source, 'Wanxiangshu.Owner.process-execution.process-runtime.fsproj')
  const plan = planOwnerCompile({ projectPath: project })
  assert.ok(plan.compileItems.includes(join(source, 'Process/ProcessRequest.fsi')))
  assert.ok(plan.compileItems.includes(join(source, 'Process/ProcessRunner.fsi')))
  const inputs = plan.compileItems.map(path => {
    const target = join(compileScratch, 'source', relative(source, path))
    fs.mkdirSync(dirname(target), { recursive: true })
    fs.copyFileSync(path, target)
    return target
  })
  const sourceDigests = Object.fromEntries(plan.compileItems.map(path => [relative(source, path), digest(path)]))
  save('real-source-inputs.json', sourceDigests)
  fs.copyFileSync(join(source, 'Process/ProcessRequest.fsi'), join(evidence, 'ProcessRequest.fsi'))
  fs.copyFileSync(join(source, 'Process/ProcessRunner.fsi'), join(evidence, 'ProcessRunner.fsi'))
  const consumer = join(compileScratch, 'source/D1TypedConsumer.fs')
  fs.copyFileSync(probeSource, consumer)
  const compiled = await compileOwnerProject({ projectPath: project, scratchRoot: join(compileScratch, 'output'), stdio: 'pipe', compilePlan: { ...plan, compileItems: [...inputs, consumer] } })
  fs.writeFileSync(join(evidence, 'compile.stdout'), compiled.stdout || '')
  fs.writeFileSync(join(evidence, 'compile.stderr'), compiled.stderr || '')
  save('compile.status.json', { ok: compiled.ok, code: compiled.code, signal: compiled.signal, elapsedMs: compiled.elapsedMs, outputPath: compiled.outputPath, fingerprint: compiled.fingerprint })
  assert.equal(compiled.ok, true, String(compiled.stdout) + String(compiled.stderr))
  const compiledFiles = files(compiled.outputPath)
  const matches = Object.keys(compiledFiles).filter(path => path.endsWith('D1TypedConsumer.js'))
  assert.equal(matches.length, 1)
  const emitted = join(compiled.outputPath, matches[0])
  const emittedBytes = fs.readFileSync(emitted)
  const runtime = join(scratch, 'runtime')
  fs.mkdirSync(runtime)
  fs.writeFileSync(join(runtime, 'package.json'), JSON.stringify({ name: 'd1-typed-fixed-package-consumer', type: 'module', private: true }))
  const entry = join(runtime, 'D1TypedConsumer.js')
  fs.writeFileSync(entry, emittedBytes)
  fs.writeFileSync(join(evidence, 'D1TypedConsumer.js'), emittedBytes)
  const imports = [...emittedBytes.toString().matchAll(/from\s+["']([^"']+)["']/g)].map(match => match[1])
  assert.ok(imports.length > 0)
  const links = new Set()
  for (const specifier of imports) {
    assert.ok(specifier.startsWith('./'), `Compiled consumer has an unexpected non-package import: ${specifier}`)
    const component = specifier.slice(2).split('/')[0]
    assert.equal(component, '..', false)
    links.add(component)
    const target = resolve(product, 'dist', specifier)
    assert.ok(target.startsWith(join(product, 'dist') + sep))
    assert.equal(fs.existsSync(target), true, `The frozen package is missing the actual compiled consumer dependency ${specifier}`)
  }
  for (const component of links) fs.symlinkSync(join(product, 'dist', component), join(runtime, component))
  save('runtime-imports.json', { imports, links: [...links].map(component => ({ from: join(runtime, component), to: join(product, 'dist', component) })), emittedConsumerSHA256: digest(entry), noImportRewrite: true })
  fs.rmSync(compileScratch, { recursive: true, force: true })
  assert.equal(fs.existsSync(compiled.outputPath), false, 'No generated production implementation may remain as a runtime fallback')
  const driver = join(runtime, 'driver.mjs')
  fs.writeFileSync(driver, "import assert from 'node:assert/strict'\nimport { exercise } from './D1TypedConsumer.js'\nconst result = await exercise('/opt/homebrew/bin/node', process.cwd())\nassert.equal(result, 'typed-contract-and-fixed-package-agree')\nconsole.log(JSON.stringify({accepted:true, result, host:process.execPath}))\n")
  fs.copyFileSync(driver, join(evidence, 'driver.mjs'))
  const results = await Promise.all(['/opt/homebrew/bin/node', '/opt/homebrew/bin/bun'].map(async executable => {
    const host = executable.endsWith('bun') ? 'bun' : 'node'
    const directory = join(scratch, host)
    const home = join(directory, 'home')
    const temporary = join(directory, 'tmp')
    fs.mkdirSync(home, { recursive: true })
    fs.mkdirSync(temporary)
    return { host, result: await run(host, executable, [driver], directory, { PATH: '/opt/homebrew/bin:/usr/bin:/bin', HOME: home, USERPROFILE: home, TMPDIR: temporary }) }
  }))
  assert.deepEqual(files(product), before)
  assert.equal(digest(archive), expected)
  assert.equal(digest(entry), createHash('sha256').update(emittedBytes).digest('hex'))
  save('products-after.json', files(product))
  save('summary.json', { results, fixedArchive: expected, realFsiUsed: ['Process/ProcessRequest.fsi', 'Process/ProcessRunner.fsi'], sourceDigests, emittedConsumerUnchanged: true, generatedProductionOutputDeletedBeforeRuntime: true, installedProductUnchanged: true, archiveUnchanged: true, scope: 'Internal F# contract check against real .fsi, followed by the same emitted consumer JS using only the frozen clean-installed package dist modules and their installed dependencies. No npm d.ts or new npm public export is claimed. The compiler may compile copied source implementations for type checking, but those outputs are removed before execution and never used at runtime.' })
  for (const value of results) {
    assert.equal(value.result.timedOut, false)
    assert.equal(value.result.code, 0, fs.readFileSync(join(evidence, `${value.host}.stderr`), 'utf8'))
  }
} catch (error) {
  save('harness-error.json', { message: error.message, stack: error.stack })
  process.exitCode = 1
} finally {
  fs.copyFileSync(probeSource, join(evidence, 'D1TypedConsumer.fs'))
  fs.copyFileSync(fileURLToPath(import.meta.url), join(evidence, 'd1-typed-fixed-package-runner.mjs'))
  fs.rmSync(scratch, { recursive: true, force: true })
  save('cleanup.json', { scratchRemoved: !fs.existsSync(scratch), installationPreserved: fs.existsSync(product), scope: 'The two actual target programs per host complete through the production Runner natural scope/capture boundary; no independent per-PID sampling is claimed.' })
}
