import assert from 'node:assert/strict'
import fs from 'node:fs'
import { spawn } from 'node:child_process'
import { dirname, join, relative, resolve, sep } from 'node:path'
import { createHash } from 'node:crypto'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'

const product = resolve(process.argv[2])
const archive = resolve(process.argv[3])
const expected = process.argv[4]
const probeDirectory = resolve(process.argv[5] || dirname(fileURLToPath(import.meta.url)))
const evidenceParent = resolve(process.argv[6] || '/private/tmp')
const evidence = fs.mkdtempSync(join(evidenceParent, 'd1-clean-installed-review-evidence-'))
const scratch = fs.mkdtempSync('/private/tmp/d1-clean-installed-review-case-')
const installRoot = dirname(dirname(product))
const digest = path => createHash('sha256').update(fs.readFileSync(path)).digest('hex')
const save = (name, value) => fs.writeFileSync(join(evidence, name), JSON.stringify(value, null, 2), { mode: 0o600 })
const walk = root => {
  const result = {}
  const visit = dir => {
    for (const name of fs.readdirSync(dir).sort()) {
      const path = join(dir, name)
      const stat = fs.lstatSync(path)
      assert.equal(stat.isSymbolicLink(), false, `The fixed product must not use source symlinks: ${path}`)
      if (stat.isDirectory()) visit(path)
      else result[relative(root, path)] = digest(path)
    }
  }
  visit(root)
  return result
}
const run = async (name, executable, args, cwd, env, timeoutMs = 45000) => {
  const stdout = fs.openSync(join(evidence, `${name}.stdout`), 'w', 0o600)
  const stderr = fs.openSync(join(evidence, `${name}.stderr`), 'w', 0o600)
  save(`${name}.command.json`, { executable, args, cwd, env, timeoutMs })
  const child = spawn(executable, args, { cwd, env, detached: true, stdio: ['ignore', stdout, stderr] })
  let timedOut = false
  const timer = setTimeout(() => {
    timedOut = true
    try { process.kill(-child.pid, 'SIGKILL') } catch (error) { if (error.code !== 'ESRCH') throw error }
  }, timeoutMs)
  const result = await new Promise((resolve, reject) => {
    child.once('error', reject)
    child.once('close', (code, signal) => resolve({ code, signal, timedOut, pid: child.pid }))
  })
  clearTimeout(timer)
  fs.closeSync(stdout)
  fs.closeSync(stderr)
  save(`${name}.status.json`, result)
  console.log(JSON.stringify({ name, ...result, evidence }))
  return result
}
const withinInstall = path => path === installRoot || path.startsWith(installRoot + sep)
const packageFor = (name, request) => {
  let path = dirname(fs.realpathSync(request.resolve(name)))
  while (path !== dirname(path)) {
    const metadata = join(path, 'package.json')
    if (fs.existsSync(metadata)) {
      const value = JSON.parse(fs.readFileSync(metadata))
      if (value.name === name) {
        assert.equal(withinInstall(path), true, `Dependency escaped the clean installation: ${path}`)
        return { name, version: value.version, path }
      }
    }
    path = dirname(path)
  }
  assert.fail(`Cannot find declared package metadata for ${name}`)
}

console.log(JSON.stringify({ evidence, scratch, product, archive, expected }))
let results
let before
let lockBefore
try {
  assert.equal(digest(archive), expected)
  assert.equal(fs.realpathSync(product), product)
  before = walk(product)
  assert.equal(Object.keys(before).length, 2076)
  assert.equal(JSON.parse(fs.readFileSync(join(product, 'node_modules/wanxiangli/package.json'))).version, '0.6.8')
  save('products-before.json', before)
  const lockPath = join(installRoot, 'package-lock.json')
  lockBefore = digest(lockPath)
  fs.copyFileSync(lockPath, join(evidence, 'installed-package-lock.json'))
  fs.copyFileSync(join(installRoot, 'package.json'), join(evidence, 'installed-package.json'))
  const metadata = JSON.parse(fs.readFileSync(join(product, 'package.json')))
  const request = createRequire(join(product, 'package.json'))
  const ordinary = [...new Set([...Object.keys(metadata.dependencies), ...Object.keys(metadata.peerDependencies), 'smol-toml'])].filter(name => name !== 'wanxiangli')
  const dependencies = ordinary.map(name => packageFor(name, request))
  dependencies.push({ name: 'wanxiangli', version: '0.6.8', path: join(product, 'node_modules/wanxiangli') })
  save('installed-dependencies.json', dependencies)
  assert.equal((await run('extract-reference', '/usr/bin/tar', ['-xzf', archive, '-C', scratch], scratch, { PATH: '/usr/bin:/bin' })).code, 0)
  assert.deepEqual(walk(join(scratch, 'package')), before, 'The clean installation must be byte-identical to the actual frozen tarball')
  fs.copyFileSync(archive, join(evidence, 'wanxiangshu-0.9.0.tgz'))
  const probes = [
    { name: 'physical', file: 'd1-independent-candidate-consumer.mjs' },
    { name: 'uncertain-start', file: 'd1-independent-observed-executed-probe.mjs' },
  ]
  for (const probe of probes) fs.copyFileSync(join(probeDirectory, probe.file), join(evidence, probe.file))
  results = await Promise.all(['/opt/homebrew/bin/node', '/opt/homebrew/bin/bun'].flatMap(executable => probes.map(async probe => {
    const host = executable.endsWith('bun') ? 'bun' : 'node'
    const directory = join(scratch, `${host}-${probe.name}`)
    const home = join(directory, 'home')
    const temporary = join(directory, 'controls')
    const cases = join(directory, 'cases')
    fs.mkdirSync(home, { recursive: true })
    fs.mkdirSync(temporary, { mode: 0o700 })
    fs.mkdirSync(cases)
    return { host, probe: probe.name, result: await run(`${host}-${probe.name}`, executable, [join(evidence, probe.file), product, cases], directory, { PATH: '/opt/homebrew/bin:/usr/bin:/bin', HOME: home, USERPROFILE: home, TMPDIR: temporary, WANXIANGSHU_PROVIDER_LANGUAGE: 'en', WANXIANGSHU_NO_FATAL_EXIT: '1' }) }
  })))
  const after = walk(product)
  save('products-after.json', after)
  assert.deepEqual(after, before)
  assert.equal(digest(archive), expected)
  assert.equal(digest(lockPath), lockBefore)
  save('summary.json', { results, fixedArchive: expected, productFileCount: Object.keys(before).length, productBytesUnchanged: true, archiveUnchanged: true, installLockSHA256: lockBefore, installLockUnchanged: true, dependencies, noBorrowedMainDependencies: true, noSourceImplementationAtRuntime: true, scope: 'Final clean npm installation of the exact tarball. All tested production and ordinary dependency paths are confined to this installation. D1 uses internal package dist modules; the npm public exports remain the plugin root, and no npm d.ts interface is asserted. Node/Bun hosts execute Node target programs. Actual registerBounded is exercised, not a remote OpenCode model session.' })
  for (const value of results) {
    assert.equal(value.result.timedOut, false)
    assert.equal(value.result.code, 0, `${value.host}/${value.probe} failed: ${evidence}`)
    assert.match(fs.readFileSync(join(evidence, `${value.host}-${value.probe}.stdout`), 'utf8'), /"accepted":true/)
  }
} catch (error) {
  save('harness-error.json', { message: error.message, stack: error.stack, results })
  process.exitCode = 1
} finally {
  fs.copyFileSync(fileURLToPath(import.meta.url), join(evidence, 'd1-clean-installed-review-runner.mjs'))
  fs.rmSync(scratch, { recursive: true, force: true })
  save('cleanup.json', { scratchRemoved: !fs.existsSync(scratch), installationPreserved: fs.existsSync(product), physicalProbe: 'Direct ps sampling covered the manually controlled capture target/descendant and startup target/supervisor. The other natural cases rely on production scope/capture closure receipts.', uncertainStartProbe: 'Worker async spawn callbacks were blocked before their original function; target markers remained absent. Bun may perform bounded FIFO setup first. No per-PID cleanup sampling is claimed for this zero-target scenario.' })
}
