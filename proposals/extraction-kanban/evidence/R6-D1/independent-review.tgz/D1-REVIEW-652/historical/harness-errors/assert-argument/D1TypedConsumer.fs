module D1TypedConsumer

open System
open System.Threading
open System.Threading.Tasks
open Wanxiangshu.Process

let private physical: RunProcess = ProcessRunner.run

let private estimate =
    { EstimatedRuntime = RuntimeSeconds 5.0
      EstimatedOutput = OutputBytes 4096L
      EstimatedMemory = EstimatedMemory.Medium }

let private command executable directory program =
    { FileName = executable
      Arguments = [ "-e"; program ]
      WorkingDirectory = Some directory
      Environment = None
      Stdin = None }

let exercise executable directory =
    task {
        let context =
            { WorkingDirectory = Some directory
              HardLimit = TimeSpan.FromSeconds 5.0 }

        let! exited =
            physical
                (command executable directory "require('node:fs').writeFileSync(1, '\\ufefftyped-body'); process.exit(143)")
                estimate context CancellationToken.None

        match exited with
        | ProcessResult.Observed
            { End = EndEvidence.Confirmed(ProgramEnd.Exited 143)
              StopRequested = None
              Output = Some(CapturedOutput.InMemory(stdout, ""))
              Fault = None } when stdout = "\\ufefftyped-body" -> ()
        | other -> failwith (ProcessResult.describe other)

        match ProcessResult.requireText exited with
        | Ok text when text.ExitCode = 143 && text.Stdout = "\\ufefftyped-body" && text.Stderr = "" -> ()
        | _ -> failwith "A confirmed normal exit did not reach the typed text consumer"

        let! signaled =
            physical
                (command executable directory "require('node:fs').writeFileSync(2, 'signal-body'); process.kill(process.pid, 'SIGTERM')")
                estimate context CancellationToken.None

        match signaled with
        | ProcessResult.Observed
            { End = EndEvidence.Confirmed(ProgramEnd.Signaled "SIGTERM")
              StopRequested = None
              Output = Some(CapturedOutput.InMemory("", "signal-body"))
              Fault = None } -> ()
        | other -> failwith (ProcessResult.describe other)

        match ProcessResult.requireText signaled with
        | Error(ProcessResult.Observed { End = EndEvidence.Confirmed(ProgramEnd.Signaled "SIGTERM") }) -> ()
        | _ -> failwith "The typed consumer turned a signal into a normal exit"

        use cancellation = new CancellationTokenSource()
        cancellation.Cancel()

        let! notStarted =
            physical (command executable directory "throw new Error('Must not start')")
                estimate context cancellation.Token

        match notStarted with
        | ProcessResult.NotStarted NoExecution.CancelledBeforeStart -> ()
        | other -> failwith (ProcessResult.describe other)

        let unconfirmed =
            ProcessResult.Observed
                { End = EndEvidence.Unconfirmed
                  StopRequested = Some StopRequest.CancellationRequested
                  Output = None
                  Fault = Some "Controlled missing receipt" }

        match ProcessResult.requireText unconfirmed with
        | Error(ProcessResult.Observed { End = EndEvidence.Unconfirmed; StopRequested = Some StopRequest.CancellationRequested }) -> ()
        | _ -> failwith "The typed consumer fabricated an exit from an unknown receipt"

        return "typed-contract-and-fixed-package-agree"
    }
