import assert from 'node:assert/strict'
import fs from 'node:fs'
import { spawn } from 'node:child_process'
import { dirname, join, relative } from 'node:path'
import { createHash } from 'node:crypto'

const repository = '/Users/yuanxi/Workwork/vibe-fs'
const archive = '/private/tmp/d1-candidate-650.QHfC4X/wanxiangshu-0.9.0.tgz'
const expected = 'ef26c6cbb4c39fcb85865abba6a01aa3de5da6d3c1063e205df18bfe1a1e60a6'
const probeSource = process.argv[2] || '/private/tmp/d1-independent-candidate-consumer.mjs'
const expectRed = process.argv[3] === 'red'
const evidence = fs.mkdtempSync('/private/tmp/d1-independent-candidate-evidence-')
const scratch = fs.mkdtempSync('/private/tmp/d1-independent-candidate-case-')
const digest = path => createHash('sha256').update(fs.readFileSync(path)).digest('hex')
const save = (name, value) => fs.writeFileSync(join(evidence, name), JSON.stringify(value, null, 2), { mode: 0o600 })
const walk = root => {
  const result = {}
  const visit = dir => {
    for (const name of fs.readdirSync(dir).sort()) {
      const path = join(dir, name)
      const stat = fs.lstatSync(path)
      assert.equal(stat.isSymbolicLink(), false)
      if (stat.isDirectory()) visit(path)
      else result[relative(root, path)] = digest(path)
    }
  }
  visit(root)
  return result
}
const run = async (name, executable, args, cwd, env, timeoutMs = 45000) => {
  const stdout = fs.openSync(join(evidence, `${name}.stdout`), 'w', 0o600)
  const stderr = fs.openSync(join(evidence, `${name}.stderr`), 'w', 0o600)
  save(`${name}.command.json`, { executable, args, cwd, env, timeoutMs })
  const child = spawn(executable, args, { cwd, env, detached: true, stdio: ['ignore', stdout, stderr] })
  let timedOut = false
  const timer = setTimeout(() => {
    timedOut = true
    try { process.kill(-child.pid, 'SIGKILL') } catch (error) { if (error.code !== 'ESRCH') throw error }
  }, timeoutMs)
  const result = await new Promise((resolve, reject) => {
    child.once('error', reject)
    child.once('close', (code, signal) => resolve({ code, signal, timedOut, pid: child.pid }))
  })
  clearTimeout(timer)
  fs.closeSync(stdout)
  fs.closeSync(stderr)
  save(`${name}.status.json`, result)
  console.log(JSON.stringify({ name, ...result, evidence }))
  return result
}

console.log(JSON.stringify({ evidence, scratch }))
let results
let invariantChecked = false
try {
  assert.equal(digest(archive), expected)
  const extraction = await run('extract', '/usr/bin/tar', ['-xzf', archive, '-C', scratch], scratch, { PATH: '/usr/bin:/bin' })
  assert.equal(extraction.code, 0)
  const product = join(scratch, 'package')
  const before = walk(product)
  assert.equal(Object.keys(before).length, 2076)
  assert.equal(JSON.parse(fs.readFileSync(join(product, 'node_modules/wanxiangli/package.json'))).version, '0.6.8')
  save('products-before.json', before)
  fs.mkdirSync(join(scratch, 'node_modules'))
  const packageJson = JSON.parse(fs.readFileSync(join(product, 'package.json')))
  const dependencies = [...new Set([...Object.keys(packageJson.dependencies), ...Object.keys(packageJson.peerDependencies), 'smol-toml'])].filter(name => name !== 'wanxiangli')
  const borrowed = []
  for (const name of dependencies) {
    const path = fs.realpathSync(join(repository, 'node_modules', name))
    const link = join(scratch, 'node_modules', name)
    fs.mkdirSync(dirname(link), { recursive: true })
    fs.symlinkSync(path, link)
    borrowed.push({ name, path, version: JSON.parse(fs.readFileSync(join(path, 'package.json'))).version })
  }
  save('borrowed-dependencies.json', borrowed)
  fs.copyFileSync(probeSource, join(scratch, 'probe.mjs'))
  fs.writeFileSync(join(scratch, 'package.json'), JSON.stringify({ name: 'd1-independent-candidate', private: true, type: 'module' }))
  results = await Promise.all(['/opt/homebrew/bin/node', '/opt/homebrew/bin/bun'].map(async executable => {
    const host = executable.endsWith('bun') ? 'bun' : 'node'
    const directory = join(scratch, host)
    const home = join(directory, 'home')
    const temporary = join(directory, 'controls')
    const cases = join(directory, 'cases')
    fs.mkdirSync(home, { recursive: true })
    fs.mkdirSync(temporary, { mode: 0o700 })
    fs.mkdirSync(cases)
    return { host, result: await run(host, executable, ['probe.mjs', product, cases], scratch, { PATH: '/opt/homebrew/bin:/usr/bin:/bin', HOME: home, USERPROFILE: home, TMPDIR: temporary, WANXIANGSHU_PROVIDER_LANGUAGE: 'en', WANXIANGSHU_NO_FATAL_EXIT: '1' }) }
  }))
  const after = walk(product)
  save('products-after.json', after)
  assert.deepEqual(after, before)
  assert.equal(digest(archive), expected)
  invariantChecked = true
  save('summary.json', { results, expectedRed: expectRed, fixedArchive: expected, productFileCount: Object.keys(before).length, productBytesUnchanged: true, archiveUnchanged: true, borrowed, scope: 'Exact extracted candidate and bundled wanxiangli0.6.8. Other declared ordinary dependencies plus smol-toml oracle borrowed read-only from the main repository. No moving dist or source is imported. Native code targets are Node; Node/Bun are distinct adapter hosts. Registered TOML uses the real registerBounded boundary, not a full external OpenCode session.' })
  for (const value of results) {
    assert.equal(value.result.timedOut, false)
    assert.equal(value.result.code, expectRed ? 1 : 0, `${value.host} failed: ${evidence}`)
    if (expectRed) assert.match(fs.readFileSync(join(evidence, `${value.host}.stderr`), 'utf8'), /D1 RED:/)
    else assert.match(fs.readFileSync(join(evidence, `${value.host}.stdout`), 'utf8'), /"accepted":true/)
  }
} catch (error) {
  save('harness-error.json', { message: error.message, stack: error.stack, invariantChecked, results })
  process.exitCode = 1
} finally {
  fs.copyFileSync(probeSource, join(evidence, 'probe.mjs'))
  fs.copyFileSync('/private/tmp/d1-independent-candidate-runner.mjs', join(evidence, 'runner.mjs'))
  fs.rmSync(scratch, { recursive: true, force: true })
  save('cleanup.json', { scratchRemoved: !fs.existsSync(scratch), physicalProcessCleanupClaim: results?.every(value => value.result.code === 0) ? 'Each probe directly observed its owned targets and supervisors no longer active before accepting.' : 'Do not infer physical cleanup from scratch removal; inspect each raw probe log.' })
}
