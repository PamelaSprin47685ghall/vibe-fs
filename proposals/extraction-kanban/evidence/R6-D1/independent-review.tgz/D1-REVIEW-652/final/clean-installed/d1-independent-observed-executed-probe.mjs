import assert from 'node:assert/strict'
import fs from 'node:fs'
import childProcess from 'node:child_process'
import { createRequire, syncBuiltinESMExports } from 'node:module'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const product = resolve(process.argv[2])
const scratch = resolve(process.argv[3])
const targetNode = process.env.D1_TARGET_NODE || process.execPath
const { parse } = createRequire(join(product, 'package.json'))('smol-toml')
const executor = await import(pathToFileURL(join(product, 'dist/OpenCode/Tools/ExecutorToolSurface.js')).href)
const { registerBounded } = await import(pathToFileURL(join(product, 'dist/OpenCode/Codec/ToolHostSurface.js')).href)
const { refreshGlobalLanguage } = await import(pathToFileURL(join(product, 'dist/Participant/Provider/LanguageSurface.js')).href)
const marker = join(scratch, 'target-must-not-run')
const quote = value => "'" + value.replaceAll("'", "'\\''") + "'"
const schema = kind => ({ kind, describe() { return this }, optional() { return this } })
const tools = { tool: { schema: { string: () => schema('string'), number: () => schema('number'), boolean: () => schema('boolean') } } }
const originalSpawn = childProcess.spawn
const originalBunSpawn = globalThis.Bun?.spawn
let blockedAsyncStarts = 0
const block = () => {
  blockedAsyncStarts++
  throw new Error('Controlled worker start callback failed before the real async spawn')
}
let wire
try {
  childProcess.spawn = block
  if (originalBunSpawn) globalThis.Bun.spawn = block
  syncBuiltinESMExports()
  const code = `require('node:fs').writeFileSync(${JSON.stringify(marker)}, 'unexpected execution')`
  wire = await executor.run(tools, {}, { command: `exec ${quote(targetNode)} -e ${quote(code)}`, output_budget_bytes: 1024 }, { sessionID: 'd1-no-confirmed-start' }, 'ready')
} finally {
  childProcess.spawn = originalSpawn
  if (originalBunSpawn) globalThis.Bun.spawn = originalBunSpawn
  syncBuiltinESMExports()
}
assert.ok(blockedAsyncStarts > 0, 'The controlled boundary must actually be exercised')
assert.equal(fs.existsSync(marker), false)
const definition = registerBounded({ tool: value => value }, 'run', 'D1 uncertain execution fact', async () => wire)
const visible = await definition.execute({}, { sessionID: 'd1-no-confirmed-start' })
assert.equal(visible, wire)
const value = parse(visible)
assert.equal(value.end_unconfirmed, true)
assert.equal(value.output_complete, false)
assert.equal(value.fault_present, true)
assert.equal(value.execution_unconfirmed, true)
console.log(JSON.stringify({ host: process.execPath, case: 'all-async-spawns-blocked-before-physical-worker-start', blockedAsyncStarts, targetMarkerAbsent: true, registeredWire: visible, parsed: value, scope: 'Controlled worker-start function throws before calling its original async spawn. Bun may perform owned FIFO setup commands before this point; no target execution is authorised by that setup.' }))
assert.notEqual(value.executed, true, 'D1 RED: an unconfirmed start must not be presented as confirmed executed=true')
for (const language of ['en', 'zh-CN']) {
  process.env.WANXIANGSHU_PROVIDER_LANGUAGE = language
  refreshGlobalLanguage()
  const context = { sessionID: `d1-uncertain-minimum-${language}` }
  const refusal = parse(await executor.run(tools, {}, { command: 'true', output_budget_bytes: 0 }, context, 'ready'))
  const budget = refusal.minimum_output_budget_bytes
  assert.ok(Number.isInteger(budget) && budget > 0)
  const before = blockedAsyncStarts
  const blockLong = () => {
    blockedAsyncStarts++
    throw new Error('Controlled long uncertain worker start: ' + '\0中文\\\"\n'.repeat(500))
  }
  let boundedWire
  try {
    childProcess.spawn = blockLong
    if (originalBunSpawn) globalThis.Bun.spawn = blockLong
    syncBuiltinESMExports()
    boundedWire = await executor.run(tools, {}, { command: `exec ${quote(targetNode)} -e ${quote(`require('node:fs').writeFileSync(${JSON.stringify(marker)}, 'unexpected')`)}`, output_budget_bytes: budget }, context, 'ready')
  } finally {
    childProcess.spawn = originalSpawn
    if (originalBunSpawn) globalThis.Bun.spawn = originalBunSpawn
    syncBuiltinESMExports()
  }
  assert.equal(blockedAsyncStarts, before + 1)
  assert.equal(fs.existsSync(marker), false)
  const registered = registerBounded({ tool: value => value }, 'run', 'D1 exact minimum uncertain start fault', async () => boundedWire)
  const visibleBounded = await registered.execute({}, context)
  assert.equal(visibleBounded, boundedWire)
  assert.ok(Buffer.byteLength(visibleBounded) <= budget)
  const boundedValue = parse(visibleBounded)
  assert.equal(boundedValue.executed, undefined)
  assert.equal(boundedValue.execution_unconfirmed, true)
  assert.equal(boundedValue.end_unconfirmed, true)
  assert.equal(boundedValue.output_complete, false)
  assert.equal(boundedValue.fault_present, true)
  assert.equal(boundedValue.diagnostic_truncated, true)
  console.log(JSON.stringify({ host: process.execPath, case: 'exact-minimum-uncertain-start-with-long-escaped-diagnostic', language, budget, wireBytes: Buffer.byteLength(visibleBounded), registeredWireUnchanged: true, boundedValue, allAsyncTargetStartsBlocked: true }))
}
console.log(JSON.stringify({ host: process.execPath, accepted: true, uncertainStartDoesNotClaimExecution: true, noTargetWasLaunched: true }))
