import assert from 'node:assert/strict'
import fs from 'node:fs'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { spawnSync } from 'node:child_process'
import { setTimeout as delay } from 'node:timers/promises'
import { tmpdir } from 'node:os'
import { createRequire } from 'node:module'

const productRoot = resolve(process.argv[2])
const caseRoot = resolve(process.argv[3])
const { parse } = createRequire(join(productRoot, 'package.json'))('smol-toml')
const runtime = await import(pathToFileURL(join(productRoot, 'dist/Process/Surface.js')).href)
const executor = await import(pathToFileURL(join(productRoot, 'dist/OpenCode/Tools/ExecutorToolSurface.js')).href)
const { registerBounded } = await import(pathToFileURL(join(productRoot, 'dist/OpenCode/Codec/ToolHostSurface.js')).href)
const { refreshGlobalLanguage } = await import(pathToFileURL(join(productRoot, 'dist/Participant/Provider/LanguageSurface.js')).href)
const controlRoot = resolve(process.env.TMPDIR)
const targetNode = process.env.D1_TARGET_NODE || process.execPath
assert.equal(resolve(tmpdir()), controlRoot, 'The physical spool directory must be this private startup TMPDIR')
assert.equal(fs.existsSync(controlRoot), true)
fs.mkdirSync(caseRoot, { recursive: true })
const emit = value => console.log(JSON.stringify({ host: process.execPath, productRoot, ...value }))
const until = async (read, label, milliseconds = 6000) => {
  const end = performance.now() + milliseconds
  while (performance.now() < end) {
    const value = read()
    if (value) return value
    await delay(5)
  }
  assert.fail(label)
}
const bounded = async (pending, milliseconds, label) => {
  let timer
  try {
    return await Promise.race([pending, new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error(label)), milliseconds)
    })])
  } finally {
    clearTimeout(timer)
  }
}
const isRunning = pid => {
  const result = spawnSync('/bin/ps', ['-p', String(pid), '-o', 'stat='], { encoding: 'utf8' })
  assert.ifError(result.error)
  assert.ok(result.status === 0 || result.status === 1, result.stderr)
  return result.status === 0 && result.stdout.trim().length > 0 && !result.stdout.trim().startsWith('Z')
}
const observe = async (code, token = runtime.createCancellationToken(false), estimate = 4096, environment) => runtime.run(
  runtime.command(targetNode, ['-e', code], caseRoot, null, environment),
  runtime.estimate(10, estimate, 'medium'),
  runtime.context(caseRoot, 10000),
  token,
)
const assertObserved = value => {
  assert.equal(value.kind, 'Observed', JSON.stringify(value))
  assert.equal('ok' in value, false, 'The new consumer must not receive an old Result facade')
  assert.equal('value' in value, false)
  assert.equal('exitCode' in value, false, 'Only an Exited end may carry an exit code')
}

for (const code of [0, 1, 7, 137, 143, 255]) {
  const result = await observe(`process.exit(${code})`)
  assertObserved(result)
  assert.deepEqual(result.ending, { kind: 'Exited', exitCode: code })
  assert.equal(result.stopRequested, null)
  assert.deepEqual(result.output, { kind: 'InMemory', stdout: '', stderr: '' })
  assert.equal(result.fault, null)
  emit({ case: 'native-normal-exit', code, result })
}
for (const signal of ['SIGINT', 'SIGTERM', 'SIGKILL']) {
  const result = await observe(`process.kill(process.pid, ${JSON.stringify(signal)})`)
  assertObserved(result)
  assert.deepEqual(result.ending, { kind: 'Signaled', signal })
  assert.equal('exitCode' in result.ending, false)
  assert.equal(result.stopRequested, null)
  assert.deepEqual(result.output, { kind: 'InMemory', stdout: '', stderr: '' })
  assert.equal(result.fault, null)
  emit({ case: 'native-terminal-signal', signal, result })
}

{
  const quote = value => "'" + value.replaceAll("'", "'\\''") + "'"
  const schema = kind => ({ kind, describe() { return this }, optional() { return this } })
  const tools = { tool: { schema: { string: () => schema('string'), number: () => schema('number'), boolean: () => schema('boolean') } } }
  for (const language of ['en', 'zh-CN']) {
    process.env.WANXIANGSHU_PROVIDER_LANGUAGE = language
    refreshGlobalLanguage()
    const context = { sessionID: `d1-independent-wire-${language}` }
    const refusal = parse(await executor.run(tools, {}, { command: 'true', output_budget_bytes: 0 }, context, 'ready'))
    assert.equal(refusal.executed, false)
    assert.ok(Number.isInteger(refusal.minimum_output_budget_bytes))
    const budget = Math.max(refusal.minimum_output_budget_bytes + 128, 1024)
    const values = []
    for (const [name, code] of [['exit-143', 'process.exit(143)'], ['signal-TERM', "process.kill(process.pid, 'SIGTERM')"]]) {
      const wire = await executor.run(tools, {}, { command: `exec ${quote(targetNode)} -e ${quote(code)}`, output_budget_bytes: budget }, context, 'ready')
      const registered = registerBounded({ tool: value => value }, 'run', 'D1 native target facts', async () => wire)
      const visible = await registered.execute({}, context)
      assert.equal(visible, wire)
      assert.ok(Buffer.byteLength(visible) <= budget)
      assert.ok(Buffer.byteLength(visible) <= 51200)
      assert.ok(visible.split('\n').length <= 2000)
      const value = parse(visible)
      assert.equal(value.executed, true)
      assert.equal(value.output_complete, true)
      assert.equal(value.fault_present, false)
      assert.equal(value.end_unconfirmed, undefined)
      if (name === 'exit-143') {
        assert.equal(value.exit_code, 143)
        assert.equal(value.signal, undefined)
      } else {
        assert.equal(value.signal, 'SIGTERM')
        assert.equal(value.exit_code, undefined)
      }
      values.push(value)
      emit({ case: 'actual-registered-native-facts', language, name, minimum: refusal.minimum_output_budget_bytes, budget, wireBytes: Buffer.byteLength(visible), wireUnchangedAfterRegistration: true, value })
    }
    assert.notDeepEqual(values[0], values[1])
  }
  process.env.WANXIANGSHU_PROVIDER_LANGUAGE = 'en'
  refreshGlobalLanguage()
}

{
  const quote = value => "'" + value.replaceAll("'", "'\\''") + "'"
  const schema = kind => ({ kind, describe() { return this }, optional() { return this } })
  const tools = { tool: { schema: { string: () => schema('string'), number: () => schema('number'), boolean: () => schema('boolean') } } }
  for (const language of ['en', 'zh-CN']) {
    process.env.WANXIANGSHU_PROVIDER_LANGUAGE = language
    refreshGlobalLanguage()
    const context = { sessionID: `d1-exact-minimum-${language}` }
    const refusal = parse(await executor.run(tools, {}, { command: 'true', output_budget_bytes: 0 }, context, 'ready'))
    const budget = refusal.minimum_output_budget_bytes
    assert.ok(Number.isInteger(budget) && budget > 0)
    const text = '中文🔥'.repeat(3000)
    const signalCode = `require('node:fs').writeFileSync(1, ${JSON.stringify(text)}); process.kill(process.pid, 'SIGVTALRM')`
    const signalWire = await executor.run(tools, {}, { command: `exec ${quote(targetNode)} -e ${quote(signalCode)}`, output_budget_bytes: budget }, context, 'ready')
    const signalRegistration = registerBounded({ tool: value => value }, 'run', 'D1 exact minimum signal', async () => signalWire)
    const signalVisible = await signalRegistration.execute({}, context)
    assert.equal(signalVisible, signalWire)
    assert.ok(Buffer.byteLength(signalVisible) <= budget)
    const signalValue = parse(signalVisible)
    assert.equal(signalValue.signal, 'SIGVTALRM')
    assert.equal(signalValue.exit_code, undefined)
    assert.equal(signalValue.output_truncated, true)
    assert.equal(signalValue.output_complete, true)
    assert.ok(signalValue.output.length > 0)
    assert.ok(text.endsWith(signalValue.output))
    assert.equal(signalValue.output.includes('\uFFFD'), false)
    emit({ case: 'exact-minimum-with-terminal-signal-and-large-UTF8-tail', language, budget, wireBytes: Buffer.byteLength(signalVisible), retainedBytes: Buffer.byteLength(signalValue.output), wireUnchangedAfterRegistration: true, signal: signalValue.signal })

    const faultMarker = join(caseRoot, `read-denied-spool-${language}.json`)
    const knownFiles = fs.readdirSync(controlRoot)
    const faultCode = `const fs=require('node:fs'); const path=require('node:path'); const root=${JSON.stringify(controlRoot)}; const known=new Set(${JSON.stringify(knownFiles)}); const text='read-failure-output'.repeat(1000); fs.writeFileSync(1,text); const timer=setInterval(() => { const names=fs.readdirSync(root).filter(name => name.startsWith('spool-') && !known.has(name)); for(const name of names) { const file=path.join(root,name); if(fs.statSync(file).size === Buffer.byteLength(text)) { clearInterval(timer); fs.chmodSync(file,0); fs.writeFileSync(${JSON.stringify(faultMarker)},JSON.stringify({path:file,completeBytes:Buffer.byteLength(text),mode:0})); process.exit(23); } } },5); setTimeout(() => process.exit(98),5000);`
    const faultWire = await executor.run(tools, {}, { command: `exec ${quote(targetNode)} -e ${quote(faultCode)}`, output_budget_bytes: budget }, context, 'ready')
    assert.equal(fs.existsSync(faultMarker), true, 'The target must observe and deny only its own fully written spool before exit23')
    const deniedSpool = JSON.parse(fs.readFileSync(faultMarker, 'utf8'))
    assert.equal(deniedSpool.completeBytes, Buffer.byteLength('read-failure-output'.repeat(1000)))
    assert.equal(deniedSpool.mode, 0)
    assert.ok(deniedSpool.path.startsWith(controlRoot + '/spool-'))
    assert.equal(fs.existsSync(deniedSpool.path), false, 'The consumer must delete the unreadable owned spool after surfacing its fault')
    const faultRegistration = registerBounded({ tool: value => value }, 'run', 'D1 exact minimum post-capture read failure', async () => faultWire)
    const faultVisible = await faultRegistration.execute({}, context)
    assert.equal(faultVisible, faultWire)
    assert.ok(Buffer.byteLength(faultVisible) <= budget)
    const faultValue = parse(faultVisible)
    assert.equal(faultValue.exit_code, 23)
    assert.equal(faultValue.signal, undefined)
    assert.equal(faultValue.executed, true)
    assert.equal(faultValue.output_complete, false)
    assert.equal(faultValue.fault_present, true)
    assert.match(faultValue.diagnostic, /EACCES|permission denied/i)
    emit({ case: 'exact-minimum-preserves-native-exit-after-final-spool-read-EACCES', language, budget, wireBytes: Buffer.byteLength(faultVisible), wireUnchangedAfterRegistration: true, deniedSpool, faultValue, injection: 'The real target waits until its spool has every expected byte, chmods only that file to 000, then exits23; the consumer gets a real OS read denial. No filesystem API is patched.' })
  }
  process.env.WANXIANGSHU_PROVIDER_LANGUAGE = 'en'
  refreshGlobalLanguage()
}

{
  const directory = join(caseRoot, 'capture-failure')
  fs.mkdirSync(directory)
  const marker = join(directory, 'target-started')
  const gate = join(directory, 'release-output')
  const tag = `d1-capture-review-${process.pid}-${Date.now()}`
  const token = runtime.createCancellationToken(false)
  let pending
  let physical
  let actualEnd
  try {
    const descendant = `const fs = require('node:fs'); const gate=${JSON.stringify(gate)}; const timer=setInterval(() => { if(fs.existsSync(gate)) { clearInterval(timer); fs.writeFileSync(1, 'late-output-after-exit23'); setTimeout(() => process.exit(0), 100) } }, 5); setTimeout(() => process.exit(99), 5000)`
    const target = `const fs=require('node:fs'); const child=require('node:child_process').spawn(${JSON.stringify(targetNode)},['-e',${JSON.stringify(descendant)}],{stdio:['ignore',1,2]}); child.unref(); fs.writeFileSync(${JSON.stringify(marker)}, JSON.stringify({target:process.pid,descendant:child.pid})); process.exit(23)`
    pending = observe(target, token, 0, { D1_CAPTURE_TAG: tag })
    physical = await until(() => fs.existsSync(marker) && JSON.parse(fs.readFileSync(marker, 'utf8')), 'The target must publish its owned process identities')
    const ownedDirectory = await until(() => fs.readdirSync(controlRoot)
      .filter(name => name.startsWith('wanxiangli-supervision-'))
      .map(name => join(controlRoot, name))
      .find(path => {
        try { return JSON.parse(fs.readFileSync(join(path, 'request'), 'utf8')).env.D1_CAPTURE_TAG === tag }
        catch (error) { if (error.code === 'ENOENT') return false; throw error }
      }), 'Find the session bound to this unique target environment')
    actualEnd = await until(() => {
      try { return JSON.parse(fs.readFileSync(join(ownedDirectory, 'exit'), 'utf8')) }
      catch (error) { if (error.code === 'ENOENT') return false; throw error }
    }, 'Real target exit must precede the real spool write error')
    assert.deepEqual(actualEnd, { code: 23, signal: null })
    fs.chmodSync(controlRoot, 0o500)
    fs.writeFileSync(gate, 'release')
    const result = await bounded(pending, 6000, 'Capture fault must reach the bounded Runner')
    fs.chmodSync(controlRoot, 0o700)
    assertObserved(result)
    assert.deepEqual(result.ending, { kind: 'Exited', exitCode: 23 })
    assert.equal(result.output, null, 'Failed capture cannot deliver apparently complete output')
    assert.match(result.fault, /EACCES|permission denied/i)
    assert.match(result.fault, /spool-/)
    emit({ case: 'known-target-exit-before-real-spool-write-denied', actualEnd, physical, result, faultInjection: 'Own TMPDIR permissions changed to 0500 after target exit; actual OS write failed, no filesystem function patched.' })
    await until(() => !isRunning(physical.target) && !isRunning(physical.descendant), 'The same owned target and descendant must stop')
  } finally {
    fs.chmodSync(controlRoot, 0o700)
    runtime.cancel(token)
    if (pending) await bounded(pending.catch(() => {}), 7000, 'Owned capture cleanup must finish')
    if (physical) await until(() => !isRunning(physical.target) && !isRunning(physical.descendant), 'Owned capture processes must not remain active', 7000)
  }
}

{
  const directory = join(caseRoot, 'startup-cancellation')
  fs.mkdirSync(directory)
  const marker = join(directory, 'actually-ran')
  const token = runtime.createCancellationToken(false)
  const knownBefore = new Set(fs.readdirSync(controlRoot))
  let pending
  let targetPid
  let supervisorPid
  let stopped = false
  try {
    pending = runtime.run(
      runtime.command('/bin/sh', ['-c', 'printf "%s %s" "$$" "$PPID" > "$D1_MARKER"; exec sleep 2'], directory, null, { D1_MARKER: marker }),
      runtime.estimate(10, 4096, 'medium'),
      runtime.context(directory, 10000),
      token,
    )
    for (let count = 0; count < 100 && fs.readdirSync(controlRoot).every(name => knownBefore.has(name)); count++) await Promise.resolve()
    const ownedNames = fs.readdirSync(controlRoot).filter(name => !knownBefore.has(name) && name.startsWith('wanxiangli-supervision-'))
    assert.equal(ownedNames.length, 1, 'Construct exactly one owned session before blocking its parent event loop')
    const end = performance.now() + 2500
    while ((!fs.existsSync(marker) || fs.readFileSync(marker, 'utf8').trim().split(' ').length < 2) && performance.now() < end) {
      Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 5)
    }
    assert.equal(fs.existsSync(marker), true, 'The real target must start while the consumer event loop is held')
    const identities = fs.readFileSync(marker, 'utf8').trim().split(' ').map(Number)
    targetPid = identities[0]
    supervisorPid = identities[1]
    assert.ok(Number.isInteger(targetPid) && targetPid > 0)
    assert.ok(Number.isInteger(supervisorPid) && supervisorPid > 0)
    const receipt = join(controlRoot, ownedNames[0], 'started')
    assert.equal(JSON.parse(fs.readFileSync(receipt, 'utf8')).pid, targetPid)
    fs.unlinkSync(receipt)
    process.kill(supervisorPid, 'SIGSTOP')
    stopped = true
    const cancelledAt = performance.now()
    runtime.cancel(token)
    const result = await bounded(pending, 300, 'Startup cancellation must not await a missing Started receipt')
    const elapsed = performance.now() - cancelledAt
    assertObserved(result)
    assert.deepEqual(result.ending, { kind: 'Unconfirmed' })
    assert.deepEqual(result.stopRequested, { kind: 'CancellationRequested' })
    assert.equal(result.output, null)
    emit({ case: 'cancel-during-startup-after-target-ran-with-lost-started-receipt', targetPid, supervisorPid, elapsedMilliseconds: elapsed, result, targetWasStarted: true })
  } finally {
    if (stopped) {
      process.kill(supervisorPid, 'SIGCONT')
      stopped = false
    }
    runtime.cancel(token)
    if (pending) await bounded(pending.catch(() => {}), 7000, 'Owned startup cleanup must settle')
    if (targetPid && supervisorPid) await until(() => !isRunning(targetPid) && !isRunning(supervisorPid), 'Owned startup target and supervisor must finish', 7000)
  }
}

emit({ accepted: true, nativeExecutions: 9, registeredExecutorExecutions: 4, exactMinimumSignalExecutions: 2, exactMinimumSpoolReadFailureExecutions: 2, knownExitCaptureFailure: true, startupCancellation: true, ownedProcessesInactive: true })
