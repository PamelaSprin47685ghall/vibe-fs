
import { run } from "./Process/ProcessRunner.js";
import { ProcessResult, ProcessObservation, StopRequest, EndEvidence, ProcessResultModule_requireText, ProcessResultModule_describe, ProcessContext, Command, ProcessEstimate, EstimatedMemory, EstimatedOutput, EstimatedRuntime } from "./Process/ProcessRequest.js";
import { ofArray } from "../fable_modules/fable-library-js.5.13.0/List.js";
import { task } from "../fable_modules/fable-library-js.5.13.0/TaskBuilder.js";
import { fromSeconds } from "../fable_modules/fable-library-js.5.13.0/TimeSpan.js";
import { cancel, createCancellationToken } from "../fable_modules/fable-library-js.5.13.0/Async.js";
import { Exception } from "../fable_modules/fable-library-js.5.13.0/Util.js";

const physical = (cmd) => ((estimate_1) => ((ctx) => ((ct) => run(cmd, estimate_1, ctx, ct))));

const expectedStdout = String.fromCharCode(65279 & 0xFFFF) + "typed-body";

const estimate = new ProcessEstimate(new EstimatedRuntime(5), new EstimatedOutput(4096n), EstimatedMemory.Medium);

function command(executable, directory, program) {
    return new Command(executable, ofArray(["-e", program]), directory, undefined, undefined);
}

export function exercise(executable, directory) {
    const builder$0040 = task();
    return builder$0040.Run(builder$0040.Delay(() => {
        const context = new ProcessContext(directory, fromSeconds(5));
        return builder$0040.Bind(physical(command(executable, directory, "require(\'node:fs\').writeFileSync(1, \'\\ufefftyped-body\'); process.exit(143)"))(estimate)(context)(createCancellationToken()), (_arg) => {
            let stdout, stdout_1, other;
            const exited = _arg;
            return builder$0040.Combine((exited.tag === 1) ? ((exited.fields[0].End.tag === 0) ? ((exited.fields[0].End.fields[0].tag === 0) ? ((exited.fields[0].End.fields[0].fields[0] === 143) ? ((exited.fields[0].StopRequested == null) ? ((exited.fields[0].Output != null) ? ((exited.fields[0].Output.tag === 0) ? ((exited.fields[0].Output.fields[1] === "") ? ((exited.fields[0].Fault == null) ? (((stdout = exited.fields[0].Output.fields[0], stdout === expectedStdout)) ? ((stdout_1 = exited.fields[0].Output.fields[0], builder$0040.Zero())) : ((other = exited, ((() => {
                throw new Exception(ProcessResultModule_describe(other));
            })(), builder$0040.Zero())))) : ((other = exited, ((() => {
                throw new Exception(ProcessResultModule_describe(other));
            })(), builder$0040.Zero())))) : ((other = exited, ((() => {
                throw new Exception(ProcessResultModule_describe(other));
            })(), builder$0040.Zero())))) : ((other = exited, ((() => {
                throw new Exception(ProcessResultModule_describe(other));
            })(), builder$0040.Zero())))) : ((other = exited, ((() => {
                throw new Exception(ProcessResultModule_describe(other));
            })(), builder$0040.Zero())))) : ((other = exited, ((() => {
                throw new Exception(ProcessResultModule_describe(other));
            })(), builder$0040.Zero())))) : ((other = exited, ((() => {
                throw new Exception(ProcessResultModule_describe(other));
            })(), builder$0040.Zero())))) : ((other = exited, ((() => {
                throw new Exception(ProcessResultModule_describe(other));
            })(), builder$0040.Zero())))) : ((other = exited, ((() => {
                throw new Exception(ProcessResultModule_describe(other));
            })(), builder$0040.Zero())))) : ((other = exited, ((() => {
                throw new Exception(ProcessResultModule_describe(other));
            })(), builder$0040.Zero()))), builder$0040.Delay(() => {
                let matchValue, text, text_1;
                return builder$0040.Combine((matchValue = ProcessResultModule_requireText(exited), (matchValue.tag === 0) ? (((text = matchValue.fields[0], ((text.ExitCode === 143) && (text.Stdout === expectedStdout)) && (text.Stderr === ""))) ? ((text_1 = matchValue.fields[0], builder$0040.Zero())) : (((() => {
                    throw new Exception("A confirmed normal exit did not reach the typed text consumer");
                })(), builder$0040.Zero()))) : (((() => {
                    throw new Exception("A confirmed normal exit did not reach the typed text consumer");
                })(), builder$0040.Zero()))), builder$0040.Delay(() => builder$0040.Bind(physical(command(executable, directory, "require(\'node:fs\').writeFileSync(2, \'signal-body\'); process.kill(process.pid, \'SIGTERM\')"))(estimate)(context)(createCancellationToken()), (_arg_1) => {
                    let other_1;
                    const signaled = _arg_1;
                    return builder$0040.Combine((signaled.tag === 1) ? ((signaled.fields[0].End.tag === 0) ? ((signaled.fields[0].End.fields[0].tag === 1) ? ((signaled.fields[0].End.fields[0].fields[0] === "SIGTERM") ? ((signaled.fields[0].StopRequested == null) ? ((signaled.fields[0].Output != null) ? ((signaled.fields[0].Output.tag === 0) ? ((signaled.fields[0].Output.fields[0] === "") ? ((signaled.fields[0].Output.fields[1] === "signal-body") ? ((signaled.fields[0].Fault == null) ? (builder$0040.Zero()) : ((other_1 = signaled, ((() => {
                        throw new Exception(ProcessResultModule_describe(other_1));
                    })(), builder$0040.Zero())))) : ((other_1 = signaled, ((() => {
                        throw new Exception(ProcessResultModule_describe(other_1));
                    })(), builder$0040.Zero())))) : ((other_1 = signaled, ((() => {
                        throw new Exception(ProcessResultModule_describe(other_1));
                    })(), builder$0040.Zero())))) : ((other_1 = signaled, ((() => {
                        throw new Exception(ProcessResultModule_describe(other_1));
                    })(), builder$0040.Zero())))) : ((other_1 = signaled, ((() => {
                        throw new Exception(ProcessResultModule_describe(other_1));
                    })(), builder$0040.Zero())))) : ((other_1 = signaled, ((() => {
                        throw new Exception(ProcessResultModule_describe(other_1));
                    })(), builder$0040.Zero())))) : ((other_1 = signaled, ((() => {
                        throw new Exception(ProcessResultModule_describe(other_1));
                    })(), builder$0040.Zero())))) : ((other_1 = signaled, ((() => {
                        throw new Exception(ProcessResultModule_describe(other_1));
                    })(), builder$0040.Zero())))) : ((other_1 = signaled, ((() => {
                        throw new Exception(ProcessResultModule_describe(other_1));
                    })(), builder$0040.Zero())))) : ((other_1 = signaled, ((() => {
                        throw new Exception(ProcessResultModule_describe(other_1));
                    })(), builder$0040.Zero()))), builder$0040.Delay(() => {
                        let matchValue_1;
                        return builder$0040.Combine((matchValue_1 = ProcessResultModule_requireText(signaled), (matchValue_1.tag === 1) ? ((matchValue_1.fields[0].tag === 1) ? ((matchValue_1.fields[0].fields[0].End.tag === 0) ? ((matchValue_1.fields[0].fields[0].End.fields[0].tag === 1) ? ((matchValue_1.fields[0].fields[0].End.fields[0].fields[0] === "SIGTERM") ? (builder$0040.Zero()) : (((() => {
                            throw new Exception("The typed consumer turned a signal into a normal exit");
                        })(), builder$0040.Zero()))) : (((() => {
                            throw new Exception("The typed consumer turned a signal into a normal exit");
                        })(), builder$0040.Zero()))) : (((() => {
                            throw new Exception("The typed consumer turned a signal into a normal exit");
                        })(), builder$0040.Zero()))) : (((() => {
                            throw new Exception("The typed consumer turned a signal into a normal exit");
                        })(), builder$0040.Zero()))) : (((() => {
                            throw new Exception("The typed consumer turned a signal into a normal exit");
                        })(), builder$0040.Zero()))), builder$0040.Delay(() => builder$0040.Using(createCancellationToken(), (_arg_2) => {
                            const cancellation = _arg_2;
                            cancel(cancellation);
                            return builder$0040.Bind(physical(command(executable, directory, "throw new Error(\'Must not start\')"))(estimate)(context)(cancellation), (_arg_3) => {
                                let other_2;
                                const notStarted = _arg_3;
                                return builder$0040.Combine((notStarted.tag === 0) ? ((notStarted.fields[0].tag === 1) ? (builder$0040.Zero()) : ((other_2 = notStarted, ((() => {
                                    throw new Exception(ProcessResultModule_describe(other_2));
                                })(), builder$0040.Zero())))) : ((other_2 = notStarted, ((() => {
                                    throw new Exception(ProcessResultModule_describe(other_2));
                                })(), builder$0040.Zero()))), builder$0040.Delay(() => {
                                    let matchValue_2;
                                    const unconfirmed = new ProcessResult(/* Observed */ 1, [new ProcessObservation(EndEvidence.Unconfirmed, StopRequest.CancellationRequested, undefined, "Controlled missing receipt")]);
                                    return builder$0040.Combine((matchValue_2 = ProcessResultModule_requireText(unconfirmed), (matchValue_2.tag === 1) ? ((matchValue_2.fields[0].tag === 1) ? ((matchValue_2.fields[0].fields[0].End.tag === 1) ? ((matchValue_2.fields[0].fields[0].StopRequested != null) ? ((matchValue_2.fields[0].fields[0].StopRequested.tag === 0) ? (builder$0040.Zero()) : (((() => {
                                        throw new Exception("The typed consumer fabricated an exit from an unknown receipt");
                                    })(), builder$0040.Zero()))) : (((() => {
                                        throw new Exception("The typed consumer fabricated an exit from an unknown receipt");
                                    })(), builder$0040.Zero()))) : (((() => {
                                        throw new Exception("The typed consumer fabricated an exit from an unknown receipt");
                                    })(), builder$0040.Zero()))) : (((() => {
                                        throw new Exception("The typed consumer fabricated an exit from an unknown receipt");
                                    })(), builder$0040.Zero()))) : (((() => {
                                        throw new Exception("The typed consumer fabricated an exit from an unknown receipt");
                                    })(), builder$0040.Zero()))), builder$0040.Delay(() => builder$0040.Return("typed-contract-and-fixed-package-agree")));
                                }));
                            });
                        })));
                    }));
                })));
            }));
        });
    }));
}

