import assert from 'node:assert/strict'
import { exercise } from './D1TypedConsumer.js'
const result = await exercise(process.env.D1_TARGET_NODE || process.execPath, process.cwd())
assert.equal(result, 'typed-contract-and-fixed-package-agree')
console.log(JSON.stringify({accepted:true, result, host:process.execPath}))
