# D1 非作者复核证据：最终结构候选652

本归档保存本轮独立复核的最终原始收据、输入、同程序类型与运行时验证，以及影响结论的旧反例和探针错误。它不是发布包的替代，也不声明D2、R12-U1、整个项目或部署已经完成。

## 固定输入

- 最终主包：`final/clean-installed/wanxiangshu-0.9.0.tgz`。
- SHA-256：`003bc8818969597f9afd6a1c0767c7aae271dd53e5f0392b146367d156ec3887`。
- 包内库：wanxiangli0.6.8。2076份tarball文件均与干净npm安装逐字节一致。
- 干净安装子树另有828份npm正常嵌套安装的声明依赖zod4.5.4文件，故完整安装子树是2904份；不是tarball多出了程序。
- 安装锁SHA-256：`29beb11dee4da50fe3d1eaac925f7114751a997d057cde8ef30170f61d3cba91`。原package.json、锁、实际依赖版本保存在最终目录。
- Node26.6.0、Bun1.3.14、Darwin25.6.0 arm64。未增加Linux或Windows支持承诺。
- 本轮已读的UPSTREAM-DELIVERY-CHECKLIST.md和CARDS.md快照及摘要在`inputs/`与`receipt.json`。这份复核只贡献其中列明的证据，不能替主仓维护者宣布整张父卡DONE。

## 最终结果

`final/clean-installed/summary.json`保存四个进程的退出状态：Node/Bun分别跑physical和uncertain-start，全部exit0，无超时。每个Host的physical包含19次真实目标执行：6种正常码、3种信号、双语注册后的143/SIGTERM共4次、双语最低预算下信号与后读故障共4次、已知23后实际capture写故障1次、启动期丢回执取消1次。另有capture目标的自有后代；这里不是19个标准requirement用例，也不将两Host相加冒充两倍覆盖。

最低完整wire预算：英文347、中文343字节。SIGVTALRM与大段UTF-8原始尾部的结果恰为347/343，保留74原始字节；实际注册不再切结果。目标确认spool写满19000字节后仅将该文件改为000，再退出23；消费者真实OS后读EACCES仍保留23、fault_present和output_complete=false，最后删除该Spool。写入故障通过目标先退出23、再将自有TMPDIR改为0500触发真实EACCES，未改写文件系统函数。

uncertain-start探针分别阻止async worker原spawn，证明没有目标marker并检查注册结果。最终明确execution_unconfirmed/end_unconfirmed，省略executed；长NUL、Unicode与转义诊断在exact minimum下为345/343字节。Bun可能先执行其自有FIFO setup命令，这不等于目标执行。

手工控制的capture目标/后代与startup目标/监管者用ps独立核对不再active；其他自然案例依据生产Runner的scope/capture收束回执，没有逐PID另采样。前后全部2904安装子树文件、2076归档文件和锁均不变，私有运行目录已清理，原干净安装保留给主协调者使用。raw/status/cleanup与完整字节摘要均在最终目录。

`final/public-export/`另补真正npm公开根入口消费：隔离canary使用独立package name，`import.meta.resolve('wanxiangshu')`在Node/Bun均精确落到同一干净安装652的Plugin.js，随后通过实际`plugin.server`、DevOps授权和已注册`hooks.tool.run.execute`运行现有013测试。两Host各3/3、0fail/skip/TODO，验证small、spooled、line-limited输出以及零模型session/prompt。只复制五份现有requirement夹具，所有生产实现及普通依赖仍来自干净安装；没有远端OpenCode或模型请求。模块根解析、完整raw、夹具摘要、安装字节前后与清理记录均保存。

## 同一个F#程序，声明后再运行实际包

`final/typed-contract/`保存D1TypedConsumer.fs、真实ProcessRequest.fsi/ProcessRunner.fsi、编译日志、81个编译输入的摘要与原始D1TypedConsumer.js。

该F#程序先经实际.fsi和正式owner Fable编译入口编译；同一编译JS未改一字节。运行前删除全部新编译的生产实现，只按编译JS原有相对import布局链接干净安装652的dist/Process及dist/fable_modules。Node/Bun子进程的运行路径不含源码实现，也无新编译实现回退。两Host均执行正常143+BOM输出、SIGTERM+stderr、预取消，并验证requireText不会把Signal或Unknown变成正常退出。原编译Consumer.js SHA-256为`d9c42b456f7f5e283916a38a38a85bddcdf22dd437c3bbbf3364a67d0e651762`。

这是内部F#协议的类型与运行时一致证据；wanxiangshu npm exports仍只有插件根，不能称新增公开子路径或npm d.ts。非法F#调用的正式负控由主协调者的process-execution012收据另行记录，本归档不将正编译当作全部类型保证。

## 问题归因

`historical/baseline-4d/`：固定4d包中正常143与SIGTERM经生产Surface和实际注册TOML混同；真实Host消费者在受控失败查询后继续update-ref/commit。另`sweep/`保留固定4d生产sweep的受控回执反例，删除在首项回执未到时已按b、a启动。均为原有实现问题；查询和sweep的命令口受控，没有物理Git写入，不能冒称完整Git集成。

`historical/introduced-executed-649/`：本轮D1候选649把所有Observed写为executed=true。独立控制worker原spawn前抛错后，两Host真实注册结果仍误称已执行，特定D1 RED命中。该问题属本轮实现引入，最终652的同场景已转绿；不推给原拆分。

`historical/harness-errors/`：保留四类验证夹具前提错误，均不归产品回退。MM45zO中Bun的createReadStream补丁没有触发预期注入，后来改为真实权限故障；VHlqEQ在运行前误要求npm安装子树只有2076文件；PDsMNc在运行前使用错误assert参数；1yUgWC的Fable正编译后错误限定所有import必须是./，实际编译器库路径为../fable_modules，后续保持原JS布局而不是改写JS。首个typed Consumer的BOM预期也在实际执行前校正，未冒称产品失败。

旧raw记录原样保存，包含当时路径。后续绿不抹去这些失败；最终判定使用上述明确通过的final目录。

## 复跑最终安装包探针

`replay/`脚本使用产品根、固定tarball和SHA参数；不含主仓依赖借用。Node/Bun可用D1_NODE/D1_BUN指定，目标程序使用D1_TARGET_NODE（由runner设置）；临时根可用D1_REVIEW_TMP_ROOT指定。工具依赖POSIX信号、chmod与ps，此次只在上述Darwin环境验证，其他系统不能因脚本可携带就宣称通过。

先恢复原锁需要的相对目录形状。以下从归档解压根执行：

```sh
mkdir -p reproduction/consumer reproduction/d1-candidate-652.88ET6L
cp final/clean-installed/installed-package.json reproduction/consumer/package.json
cp final/clean-installed/installed-package-lock.json reproduction/consumer/package-lock.json
cp final/clean-installed/wanxiangshu-0.9.0.tgz reproduction/d1-candidate-652.88ET6L/wanxiangshu-0.9.0.tgz
cd reproduction/consumer
npm ci --ignore-scripts --no-audit --no-fund
cd ../..
```

然后用实际Node/Bun路径设置D1_NODE/D1_BUN，以Node运行：

```sh
node replay/d1-clean-installed-review-runner.mjs reproduction/consumer/node_modules/wanxiangshu reproduction/d1-candidate-652.88ET6L/wanxiangshu-0.9.0.tgz 003bc8818969597f9afd6a1c0767c7aae271dd53e5f0392b146367d156ec3887 replay
```

复跑npm公开根和真实注册Plugin的013，夹具使用归档固定副本：

```sh
node replay/d1-public-export-canary-runner.mjs reproduction/consumer/node_modules/wanxiangshu reproduction/d1-candidate-652.88ET6L/wanxiangshu-0.9.0.tgz 003bc8818969597f9afd6a1c0767c7aae271dd53e5f0392b146367d156ec3887 final/public-export/fixtures
```

重编译同程序需要已准备Fable工具链的主仓checkout，且81个声明/实现输入必须与归档摘要完全相同。使用其正常owner编译入口，没有dotnet build。运行仍只消费上面安装包，不能以新的主仓dist补齐缺文件：

```sh
node replay/d1-typed-fixed-package-runner.mjs /absolute/path/to/matching-checkout reproduction/consumer/node_modules/wanxiangshu reproduction/d1-candidate-652.88ET6L/wanxiangshu-0.9.0.tgz 003bc8818969597f9afd6a1c0767c7aae271dd53e5f0392b146367d156ec3887 final/typed-contract/real-source-inputs.json
```

所有文件的SHA-256见manifest.sha256.json。历史反例包含对应4d与649固定tarball供追溯；历史runner中的原路径不作为长期复跑入口。R12-U1仍暂缓，本轮正常设计出的Unconfirmed/cancel反例没有宣称解决旧的自然Unknown。
