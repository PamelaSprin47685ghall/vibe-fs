import { readFileSync } from 'node:fs'

export function read() {
  return readFileSync('/private/tmp/gap085-host-consumer.MkRCHO/canary/package.json')
}
