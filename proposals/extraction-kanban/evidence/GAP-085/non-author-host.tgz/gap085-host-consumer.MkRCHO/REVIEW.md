# GAP-085 non-author Host review

The final fixed input is generation 667, SHA256
`b0de9b9770139ae4aa977fae3d8b8d59f2d558cf4ff4a41cf4a1289419743297`.
This reviewer did not implement GAP-085 and made no shared source edit.
The reviewed boundary is package self-coverage discovery, actual registered
grounding delivery, mutation fail-open and frozen historical occurrences.
It is not a claim to close the other historical GAP-085/086 obligations.

The consumer has a distinct npm package name. Its node_modules and dist links
point only at the actual clean 667 installation. It asserts that importing
`wanxiangshu` resolves exactly to that installation's public Plugin.js, and
the unmodified fixture really calls its plugin.server registration. Three
existing fixture helpers were copied; their production imports resolve only
into the installed dist. The SDK client is the existing controlled Host double,
not an external OpenCode/model session. No source implementation fallback runs.

## Final finite matrix

Node and Bun each ran the same five tests once, with no skip/TODO/failure.
One provider is used; other provider serialization is outside this small matrix.

1. Legal `/src/**`: native terminal read, actual registered js-manager read,
   controlled Host native write continuation and actual registered js-engineer
   write. The grounding sentinel and one Anchored occurrence are present.
2. External coverage plus positive self-tests rule: discovery and materialize
   reject the configuration. The same four registered operations continue
   correctly while normative material is not read or delivered.
3. The equivalent negated self-tests rule has the same rejection and fail-open
   outcomes. Real source-read facts remain allowed; only new normative
   Requested/Anchored and material delivery are prohibited.
4. The first-`]` class has an actual positive read `src/]` and an outside read
   `src/main]`. The positive still grounds; the outside no longer grounds.
5. One real plugin incarnation seeds and persists a legal occurrence, disposes,
   then a second incarnation reopens the journal after the APPLIES-TO becomes
   invalid and WHAT bytes change. The complete prior wire replays unchanged,
   no new normative occurrence is added, and the original material is not read.
   This is journal reopening in one OS process, not a crash/cross-process proof.

The ordinary matrix contains twelve tool operations per Host, plus the two
class reads and one historical seed read. Native Host file reads/writes use
controlled filesystem continuations; js-manager/js-engineer execute the real
registered tool implementations. Native args retain object identity, values
and own keys. Read operations change no user file. Each mutation changes only
its specified generated file, with the exact intended bytes. The file-effect
comparison excludes internal `.git` journal files, whose expected facts are
captured separately. It does not claim zero journal effects.

## Material-read observation

Every observed read delegates to original fs.readFileSync and returns its real
bytes. Node uses a builtin function wrapper with syncBuiltinESMExports. Bun's
named builtin exports do not follow that assignment: two standalone observation
probes returned zero despite actual reads. Those zeros were not used as proof.
For Bun, a private mock.module wrapper is installed before product imports;
all filesystem exports remain original functions except a readFileSync wrapper
that always calls the original. A standalone probe and the same-host legal
grounding positive controls establish that observation works. The consumer
restores the observation wrapper at teardown. No product file is changed.

Both Hosts have identical actual invocation counts: legal read and js-manager
each read WHAT once; legal native write and js-engineer each read it twice.
The latter counts are reported as observed, not claimed to be one read or a new
regression. All eight illegal-self tool cases per Host read WHAT zero times,
have zero new normative Requested/Anchored facts and contain no illegal norm
sentinel. Class outside coverage and historical replay also read it zero times.
These are API invocation counts, not kernel syscall or uncached-disk-I/O counts.

## Preserved earlier observations

The old fixed 663 package passes the historical frozen-occurrence baseline on
Node and, after correct pre-import isolated routing HOME setup, Bun. The first
Bun launch lacked that isolation and hit an existing missing-estimate admission
error before forming the history proof. Its original failure log remains; it is
not classified as GAP-085 or uniquely attributed to the Bun runtime. The old
baseline consumer revision is retained separately.

On fixed 666, one actual public Plugin Node test reproduced the class leak:
both `src/]` and `src/main]` read 34 real WHAT bytes, persisted normative
Requested/Anchored and injected the material. Raw wire and facts were saved
before the expected negative assertion failed. Generation 667 fixes that real
consumer boundary while retaining the valid class positive. The 666 fixture
revision used the Node observation path; the final revision additionally adds
the Bun observation wrapper and explicit positive-control assertions. The raw
666 results, stack and final replay source are kept rather than presenting 666
as an all-green candidate.

## Replay

The archive includes the exact 667 tgz, package/installation lock inputs, all
logs, actual wire/facts, material call counts, helper/consumer source and file
hash inventories. It does not contain borrowed product source or omit any
failed bytes. Its links must be rebound to the clean installation being tested.

Before either runtime imports the product, use the included writeRoutingHome
helper to create a private routing HOME. Then from canary run:

```sh
GAP085_HOST_SCOPE=all GAP085_EXPECTED_PRODUCT_ROOT=/private/tmp/gap085-clean-install-667/node_modules/wanxiangshu GAP085_EVIDENCE=/private/tmp/gap085-host-consumer.MkRCHO/replay-node HOME=/private/tmp/gap085-host-consumer.MkRCHO/final667-node-home USERPROFILE=/private/tmp/gap085-host-consumer.MkRCHO/final667-node-home node --test ./host-boundaries.test.mjs
GAP085_HOST_SCOPE=all GAP085_EXPECTED_PRODUCT_ROOT=/private/tmp/gap085-clean-install-667/node_modules/wanxiangshu GAP085_EVIDENCE=/private/tmp/gap085-host-consumer.MkRCHO/replay-bun HOME=/private/tmp/gap085-host-consumer.MkRCHO/final667-bun-home USERPROFILE=/private/tmp/gap085-host-consumer.MkRCHO/final667-bun-home bun test ./host-boundaries.test.mjs
```

The filesystem observation is explicitly a controlled observation boundary;
the main package, GlobMatch, Catalog, registered Hook and JS implementations are
the fixed installed product. Plugin/journal handles are disposed and temporary
workspaces are removed by the existing helpers. This review does not replace
the independent GlobMatch algorithm review or the root's formal requirement
suites, and it makes no deployment or complete-WHAT claim.
