import assert from 'node:assert/strict'
import test, { after } from 'node:test'
import fs from 'node:fs'
import { syncBuiltinESMExports } from 'node:module'
import { createHash } from 'node:crypto'
import { mkdirSync, readFileSync, readdirSync, realpathSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'

const expectedProduct = realpathSync(process.env.GAP085_EXPECTED_PRODUCT_ROOT)
const publicModule = realpathSync(fileURLToPath(import.meta.resolve('wanxiangshu')))
assert.equal(publicModule, realpathSync(join(expectedProduct, 'dist/OpenCode/Plugin/Plugin.js')))
const evidence = process.env.GAP085_EVIDENCE
mkdirSync(evidence, { recursive: true })
writeFileSync(join(evidence, 'public-export.json'), JSON.stringify({ resolved: publicModule, expectedProduct, actualPluginServerExport: true, host: process.execPath }, null, 2) + '\n')
const originalReadFileSync = fs.readFileSync
const materialReads = []
let phase = 'idle'
let materialReadObservationProven = false
const observedReadFileSync = function(path, ...args) {
  const result = Reflect.apply(originalReadFileSync, this, [path, ...args])
  if (typeof path === 'string' && path.endsWith('/requirements/alpha/WHAT.md')) {
    materialReads.push({ path, phase, bytes: Buffer.byteLength(result), sha256: createHash('sha256').update(result).digest('hex') })
  }
  return result
}
if (globalThis.Bun) {
  const { mock } = await import('bun:test')
  const observed = { ...fs, readFileSync: observedReadFileSync }
  mock.module('node:fs', () => ({ ...observed, default: observed }))
} else {
  fs.readFileSync = observedReadFileSync
  syncBuiltinESMExports()
}
const catalog = await import('./dist/Requirement/Grounding/Surface.js')
const { acceptAuthorityRoot, openIncumbency, withExecutablePlugin, withRestartablePlugin } = await import('./requirements/verification-system/tests/support/plugin-fixture.mjs')
const { default: plugin } = await import('wanxiangshu')
assert.equal(typeof plugin.server, 'function')
after(async () => {
  if (globalThis.Bun) {
    const { mock } = await import('bun:test')
    mock.module('node:fs', () => ({ ...fs, default: fs }))
  } else {
    fs.readFileSync = originalReadFileSync
    syncBuiltinESMExports()
  }
  writeFileSync(join(evidence, 'material-read-invocations.json'), JSON.stringify({ materialReadObservationProven, method: globalThis.Bun ? 'Transparent builtin module wrapper before product imports' : 'Builtin function wrapper and syncBuiltinESMExports', calls: materialReads, scope: 'Original fs.readFileSync is always called and returns its actual bytes. Zero is evidence only after a same-host legal positive control observes reads. All other filesystem operations are original functions. Fixture snapshots use the saved original function.' }, null, 2) + '\n')
})

const save = (name, value) => writeFileSync(join(evidence, name + '.json'), JSON.stringify(value, null, 2) + '\n')
const source = 'SOURCE-ORIGINAL\r\n'
const ordinaryFiles = directory => {
  const files = {}
  const visit = (parent, prefix) => {
    for (const entry of readdirSync(parent, { withFileTypes: true })) {
      if (entry.name === '.git') continue
      const path = join(parent, entry.name)
      const relative = prefix ? prefix + '/' + entry.name : entry.name
      if (entry.isDirectory()) visit(path, relative)
      else if (entry.isFile()) files[relative] = createHash('sha256').update(originalReadFileSync(path)).digest('hex')
    }
  }
  visit(directory, '')
  return files
}
const factsFor = (directory, sessionID) => readdirSync(join(directory, '.git/wanxiangshu/events'))
  .flatMap(name => readFileSync(join(directory, '.git/wanxiangshu/events', name), 'utf8').split('\n').filter(Boolean).map(JSON.parse))
  .flatMap(event => {
    const fact = event.payload?.Fact
    const host = fact?.[0] === 'Agent' && fact[1]?.[0] === 'Host' ? fact[1][1] : null
    return host?.[1]?.SessionId?.[1] === sessionID ? [host] : []
  })
const normative = facts => facts.filter(fact => ['RequirementGroundingRequested', 'RequirementGroundingAnchored'].includes(fact[0]))
const prepare = (directory, body, mapping) => {
  const packageRoot = join(directory, 'requirements/alpha')
  mkdirSync(packageRoot, { recursive: true })
  mkdirSync(join(directory, 'src'), { recursive: true })
  writeFileSync(join(packageRoot, 'WHAT.md'), body)
  writeFileSync(join(packageRoot, 'APPLIES-TO'), mapping)
  writeFileSync(join(directory, 'src/main.fs'), source)
  return { sourcePath: join(directory, 'src/main.fs'), mappingPath: join(packageRoot, 'APPLIES-TO'), materialPath: join(packageRoot, 'WHAT.md') }
}
const rawResult = (sessionID, tool, callID, args, output) => [{
  info: { id: `result-${sessionID}`, role: 'assistant', sessionID, providerID: 'anthropic' },
  parts: [{ id: `part-${sessionID}`, type: 'tool', tool, callID, state: { status: 'completed', input: args, output, time: { start: 0, end: 1 } } }],
}]
const perform = async (hooks, directory, runtime, sessionID, tool, readName = 'src/main.fs') => {
  if (tool.startsWith('js-')) await acceptAuthorityRoot(runtime, sessionID, tool.slice(3))
  await openIncumbency(runtime, sessionID)
  const sourcePath = join(directory, readName)
  const writePath = join(directory, 'src/generated-' + sessionID + '.fs')
  const content = 'MUTATION-ONCE-' + sessionID + '\n'
  const args = tool === 'js-manager'
    ? { program: "class Js extends JsProgram { async run() { const file = await this.file('src/main.fs'); return file.text(); } }" }
    : tool === 'js-engineer'
      ? { program: `class Js extends JsProgram { async run() { await this.write(${JSON.stringify('src/generated-' + sessionID + '.fs')}, ${JSON.stringify(content)}); return 'PROGRAM-WRITTEN'; } }` }
      : tool === 'write' ? { filePath: writePath, content } : { filePath: sourcePath }
  const input = { tool, sessionID, callID: 'call-' + sessionID }
  const originalInput = structuredClone(input)
  const originalArgs = structuredClone(args)
  const originalKeys = Reflect.ownKeys(args)
  const filesBefore = ordinaryFiles(directory)
  const readsBefore = materialReads.length
  phase = sessionID
  const outgoing = { args }
  await hooks['tool.execute.before'](input, outgoing)
  if (!tool.startsWith('js-')) {
    assert.deepEqual(input, originalInput)
    assert.equal(outgoing.args, args)
    assert.deepEqual(args, originalArgs)
  }
  const executedArgs = outgoing.args
  let output
  if (tool === 'read') output = readFileSync(sourcePath, 'utf8')
  else if (tool === 'write') {
    writeFileSync(outgoing.args.filePath, outgoing.args.content)
    output = 'file written once'
  } else output = await hooks.tool[tool].execute(executedArgs, { sessionID, agent: tool.slice(3) })
  if (tool === 'read') assert.equal(output, source)
  else if (tool === 'js-manager') assert.ok(output.includes('SOURCE-ORIGINAL'))
  else assert.equal(readFileSync(writePath, 'utf8'), content)
  await hooks['tool.execute.after']({ ...input, args: executedArgs }, { title: tool, output, metadata: {} })
  if (!tool.startsWith('js-')) {
    assert.equal(outgoing.args, args)
    assert.deepEqual(args, originalArgs)
    assert.deepEqual(Reflect.ownKeys(args), originalKeys)
  }
  const raw = rawResult(sessionID, tool, input.callID, executedArgs, output)
  const projected = { messages: structuredClone(raw) }
  await hooks['experimental.chat.messages.transform']({}, projected)
  assert.equal(projected.messages.length, raw.length)
  assert.deepEqual(projected.messages.map(row => row.info), raw.map(row => row.info))
  assert.ok(projected.messages[0].parts[0].state.output.startsWith(output))
  const filesAfter = ordinaryFiles(directory)
  const changedFiles = [...new Set([...Object.keys(filesBefore), ...Object.keys(filesAfter)])].filter(path => filesBefore[path] !== filesAfter[path]).sort()
  assert.deepEqual(changedFiles, tool === 'write' || tool === 'js-engineer' ? ['src/generated-' + sessionID + '.fs'] : [])
  const observedReads = materialReads.slice(readsBefore)
  phase = 'idle'
  return { raw, projected: projected.messages, facts: factsFor(directory, sessionID), output, materialReadInvocations: observedReads, changedFiles, actualMutationBytes: tool === 'write' || tool === 'js-engineer' ? readFileSync(writePath, 'utf8') : null }
}

if (!['history', 'class'].includes(process.env.GAP085_HOST_SCOPE)) {
  for (const [mode, illegalRule] of [['legal', null], ['include-self', '/requirements/alpha/tests/**'], ['exclude-self', '!/requirements/alpha/tests/**']]) {
    test(`installed public Plugin ${mode} keeps read/JS/mutation boundaries`, async () => {
      await withExecutablePlugin(async (hooks, directory, _created, runtime) => {
        const body = `NORMATIVE-SENTINEL-${mode}\r\n`
        prepare(directory, body, '/src/**\n' + (illegalRule ? illegalRule + '\n' : ''))
        if (illegalRule) {
          assert.throws(() => catalog.discoverPackages(directory), /must not declare package self coverage/)
          assert.throws(() => catalog.materializePackage(directory, 'alpha'), /must not declare package self coverage/)
        } else assert.deepEqual(catalog.discoverPackages(directory), ['alpha'])
        for (const tool of ['read', 'js-manager', 'write', 'js-engineer']) {
          const sessionID = `gap085-${mode}-${tool}`
          const result = await perform(hooks, directory, runtime, sessionID, tool)
          const wire = result.projected[0].parts[0].state.output
          if (illegalRule) {
            assert.equal(wire.includes(body), false)
            assert.equal(wire.includes('requirement_source_path = "requirements/alpha/WHAT.md"'), false)
            assert.deepEqual(normative(result.facts), [])
            if (materialReadObservationProven) assert.deepEqual(result.materialReadInvocations, [])
          } else {
            assert.ok(wire.includes(body))
            assert.equal(result.facts.filter(fact => fact[0] === 'RequirementGroundingAnchored').length, 1)
            assert.ok(result.materialReadInvocations.length > 0, 'The actual material read observation requires a same-host legal positive control')
            materialReadObservationProven ||= result.materialReadInvocations.length > 0
          }
          save(sessionID, { mode, tool, ...result, sourceReadFactsAllowed: true, realRegisteredJsExecution: tool.startsWith('js-'), nativeHostContinuationControlled: !tool.startsWith('js-') })
        }
      })
    })
  }
}

if (process.env.GAP085_HOST_SCOPE !== 'history') {
  test('installed public Plugin character-class boundary cannot leak coverage through alternation', async () => {
    await withExecutablePlugin(async (hooks, directory, _created, runtime) => {
      const body = 'CHARACTER-CLASS-BOUNDARY-MATERIAL\n'
      prepare(directory, body, '/src/[]|]\n')
      writeFileSync(join(directory, 'src/]'), source)
      writeFileSync(join(directory, 'src/main]'), source)
      const legal = await perform(hooks, directory, runtime, 'gap085-class-legal', 'read', 'src/]')
      assert.ok(legal.projected[0].parts[0].state.output.includes(body))
      assert.ok(legal.materialReadInvocations.length > 0)
      materialReadObservationProven ||= legal.materialReadInvocations.length > 0
      save('character-class-positive', legal)
      const outside = await perform(hooks, directory, runtime, 'gap085-class-outside', 'read', 'src/main]')
      save('character-class-outside', outside)
      assert.equal(outside.projected[0].parts[0].state.output.includes(body), false)
      assert.deepEqual(normative(outside.facts), [])
      if (materialReadObservationProven) assert.deepEqual(outside.materialReadInvocations, [])
    })
  })
}

if (process.env.GAP085_HOST_SCOPE !== 'class') {
test('installed public Plugin history replays after current mapping becomes invalid', async () => {
  await withRestartablePlugin(async (start, directory, lifecycle) => {
    const paths = prepare(directory, 'SAVED-LEGAL-NORMATIVE\r\n', '/src/**\n')
    const sessionID = 'gap085-frozen-occurrence'
    const first = await start()
    let seeded
    await lifecycle.withRuntime(async runtime => {
      seeded = await perform(first, directory, runtime, sessionID, 'read')
      assert.ok(seeded.projected[0].parts[0].state.output.includes('SAVED-LEGAL-NORMATIVE\r\n'))
      assert.equal(seeded.facts.filter(fact => fact[0] === 'RequirementGroundingAnchored').length, 1)
      assert.ok(seeded.materialReadInvocations.length > 0)
      materialReadObservationProven ||= seeded.materialReadInvocations.length > 0
    })
    await lifecycle.stop(first)
    writeFileSync(paths.mappingPath, '/src/**\n/requirements/alpha/**\n')
    writeFileSync(paths.materialPath, 'INVALID-CURRENT-NORMATIVE-MUST-NOT-REPLACE-SAVED\n')
    assert.throws(() => catalog.discoverPackages(directory), /must not declare package self coverage/)
    const second = await start()
    const replay = { messages: structuredClone(seeded.raw) }
    const readsBeforeReplay = materialReads.length
    phase = 'history-replay'
    await second['experimental.chat.messages.transform']({}, replay)
    phase = 'idle'
    assert.deepEqual(replay.messages, seeded.projected)
    assert.equal(JSON.stringify(replay.messages).includes('INVALID-CURRENT-NORMATIVE'), false)
    assert.deepEqual(normative(factsFor(directory, sessionID)), normative(seeded.facts))
    const replayReads = materialReads.slice(readsBeforeReplay)
    if (materialReadObservationProven) assert.deepEqual(replayReads, [])
    save('historical-occurrence-after-invalid-mapping', { seeded, replay: replay.messages, materialReadObservationProven, replayReads, facts: factsFor(directory, sessionID), mapping: readFileSync(paths.mappingPath, 'utf8'), material: originalReadFileSync(paths.materialPath, 'utf8'), scope: 'Two real plugin incarnations with disposed/reopened journal ownership in one process. Current discovery is invalid; previously durable occurrence remains frozen. No cross-process crash claim.' })
    await lifecycle.stop(second)
  })
})
}
