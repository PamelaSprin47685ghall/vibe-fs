import assert from 'node:assert/strict'
import test from 'node:test'
import { mkdirSync, readFileSync, readdirSync, realpathSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import * as catalog from './dist/Requirement/Grounding/Surface.js'
import { acceptAuthorityRoot, openIncumbency, withExecutablePlugin, withRestartablePlugin } from './requirements/verification-system/tests/support/plugin-fixture.mjs'

const expectedProduct = realpathSync(process.env.GAP085_EXPECTED_PRODUCT_ROOT)
const publicModule = realpathSync(fileURLToPath(import.meta.resolve('wanxiangshu')))
assert.equal(publicModule, realpathSync(join(expectedProduct, 'dist/OpenCode/Plugin/Plugin.js')))
const { default: plugin } = await import('wanxiangshu')
assert.equal(typeof plugin.server, 'function')
const evidence = process.env.GAP085_EVIDENCE
mkdirSync(evidence, { recursive: true })
writeFileSync(join(evidence, 'public-export.json'), JSON.stringify({ resolved: publicModule, expectedProduct, actualPluginServerExport: true, host: process.execPath }, null, 2) + '\n')

const save = (name, value) => writeFileSync(join(evidence, name + '.json'), JSON.stringify(value, null, 2) + '\n')
const source = 'SOURCE-ORIGINAL\r\n'
const factsFor = (directory, sessionID) => readdirSync(join(directory, '.git/wanxiangshu/events'))
  .flatMap(name => readFileSync(join(directory, '.git/wanxiangshu/events', name), 'utf8').split('\n').filter(Boolean).map(JSON.parse))
  .flatMap(event => {
    const fact = event.payload?.Fact
    const host = fact?.[0] === 'Agent' && fact[1]?.[0] === 'Host' ? fact[1][1] : null
    return host?.[1]?.SessionId?.[1] === sessionID ? [host] : []
  })
const normative = facts => facts.filter(fact => ['RequirementGroundingRequested', 'RequirementGroundingAnchored'].includes(fact[0]))
const prepare = (directory, body, mapping) => {
  const packageRoot = join(directory, 'requirements/alpha')
  mkdirSync(packageRoot, { recursive: true })
  mkdirSync(join(directory, 'src'), { recursive: true })
  writeFileSync(join(packageRoot, 'WHAT.md'), body)
  writeFileSync(join(packageRoot, 'APPLIES-TO'), mapping)
  writeFileSync(join(directory, 'src/main.fs'), source)
  return { sourcePath: join(directory, 'src/main.fs'), mappingPath: join(packageRoot, 'APPLIES-TO'), materialPath: join(packageRoot, 'WHAT.md') }
}
const rawResult = (sessionID, tool, callID, args, output) => [{
  info: { id: `result-${sessionID}`, role: 'assistant', sessionID, providerID: 'anthropic' },
  parts: [{ id: `part-${sessionID}`, type: 'tool', tool, callID, state: { status: 'completed', input: args, output, time: { start: 0, end: 1 } } }],
}]
const perform = async (hooks, directory, runtime, sessionID, tool) => {
  if (tool.startsWith('js-')) await acceptAuthorityRoot(runtime, sessionID, tool.slice(3))
  await openIncumbency(runtime, sessionID)
  const sourcePath = join(directory, 'src/main.fs')
  const writePath = join(directory, 'src/generated-' + sessionID + '.fs')
  const content = 'MUTATION-ONCE-' + sessionID + '\n'
  const args = tool === 'js-manager'
    ? { program: "class Js extends JsProgram { async run() { const file = await this.file('src/main.fs'); return file.text(); } }" }
    : tool === 'js-engineer'
      ? { program: `class Js extends JsProgram { async run() { await this.write(${JSON.stringify('src/generated-' + sessionID + '.fs')}, ${JSON.stringify(content)}); return 'PROGRAM-WRITTEN'; } }` }
      : tool === 'write' ? { filePath: writePath, content } : { filePath: sourcePath }
  const input = { tool, sessionID, callID: 'call-' + sessionID }
  const originalInput = structuredClone(input)
  const originalArgs = structuredClone(args)
  const originalKeys = Reflect.ownKeys(args)
  const outgoing = { args }
  await hooks['tool.execute.before'](input, outgoing)
  if (!tool.startsWith('js-')) {
    assert.deepEqual(input, originalInput)
    assert.equal(outgoing.args, args)
    assert.deepEqual(args, originalArgs)
  }
  const executedArgs = outgoing.args
  let output
  if (tool === 'read') output = readFileSync(sourcePath, 'utf8')
  else if (tool === 'write') {
    writeFileSync(outgoing.args.filePath, outgoing.args.content)
    output = 'file written once'
  } else output = await hooks.tool[tool].execute(executedArgs, { sessionID, agent: tool.slice(3) })
  if (tool === 'read') assert.equal(output, source)
  else if (tool === 'js-manager') assert.ok(output.includes('SOURCE-ORIGINAL'))
  else assert.equal(readFileSync(writePath, 'utf8'), content)
  await hooks['tool.execute.after']({ ...input, args: executedArgs }, { title: tool, output, metadata: {} })
  if (!tool.startsWith('js-')) {
    assert.equal(outgoing.args, args)
    assert.deepEqual(args, originalArgs)
    assert.deepEqual(Reflect.ownKeys(args), originalKeys)
  }
  const raw = rawResult(sessionID, tool, input.callID, executedArgs, output)
  const projected = { messages: structuredClone(raw) }
  await hooks['experimental.chat.messages.transform']({}, projected)
  assert.equal(projected.messages.length, raw.length)
  assert.deepEqual(projected.messages.map(row => row.info), raw.map(row => row.info))
  assert.ok(projected.messages[0].parts[0].state.output.startsWith(output))
  return { raw, projected: projected.messages, facts: factsFor(directory, sessionID), output, actualMutationBytes: tool === 'write' || tool === 'js-engineer' ? readFileSync(writePath, 'utf8') : null }
}

if (process.env.GAP085_HOST_SCOPE !== 'history') {
  for (const [mode, illegalRule] of [['legal', null], ['include-self', '/requirements/alpha/tests/**'], ['exclude-self', '!/requirements/alpha/tests/**']]) {
    test(`installed public Plugin ${mode} keeps read/JS/mutation boundaries`, async () => {
      await withExecutablePlugin(async (hooks, directory, _created, runtime) => {
        const body = `NORMATIVE-SENTINEL-${mode}\r\n`
        prepare(directory, body, '/src/**\n' + (illegalRule ? illegalRule + '\n' : ''))
        if (illegalRule) {
          assert.throws(() => catalog.discoverPackages(directory), /must not declare package self coverage/)
          assert.throws(() => catalog.materializePackage(directory, 'alpha'), /must not declare package self coverage/)
        } else assert.deepEqual(catalog.discoverPackages(directory), ['alpha'])
        for (const tool of ['read', 'js-manager', 'write', 'js-engineer']) {
          const sessionID = `gap085-${mode}-${tool}`
          const result = await perform(hooks, directory, runtime, sessionID, tool)
          const wire = result.projected[0].parts[0].state.output
          if (illegalRule) {
            assert.equal(wire.includes(body), false)
            assert.equal(wire.includes('requirement_source_path = "requirements/alpha/WHAT.md"'), false)
            assert.deepEqual(normative(result.facts), [])
          } else {
            assert.ok(wire.includes(body))
            assert.equal(result.facts.filter(fact => fact[0] === 'RequirementGroundingAnchored').length, 1)
          }
          save(sessionID, { mode, tool, ...result, sourceReadFactsAllowed: true, realRegisteredJsExecution: tool.startsWith('js-'), nativeHostContinuationControlled: !tool.startsWith('js-') })
        }
      })
    })
  }
}

test('installed public Plugin history replays after current mapping becomes invalid', async () => {
  await withRestartablePlugin(async (start, directory, lifecycle) => {
    const paths = prepare(directory, 'SAVED-LEGAL-NORMATIVE\r\n', '/src/**\n')
    const sessionID = 'gap085-frozen-occurrence'
    const first = await start()
    let seeded
    await lifecycle.withRuntime(async runtime => {
      seeded = await perform(first, directory, runtime, sessionID, 'read')
      assert.ok(seeded.projected[0].parts[0].state.output.includes('SAVED-LEGAL-NORMATIVE\r\n'))
      assert.equal(seeded.facts.filter(fact => fact[0] === 'RequirementGroundingAnchored').length, 1)
    })
    await lifecycle.stop(first)
    writeFileSync(paths.mappingPath, '/src/**\n/requirements/alpha/**\n')
    writeFileSync(paths.materialPath, 'INVALID-CURRENT-NORMATIVE-MUST-NOT-REPLACE-SAVED\n')
    assert.throws(() => catalog.discoverPackages(directory), /must not declare package self coverage/)
    const second = await start()
    const replay = { messages: structuredClone(seeded.raw) }
    await second['experimental.chat.messages.transform']({}, replay)
    assert.deepEqual(replay.messages, seeded.projected)
    assert.equal(JSON.stringify(replay.messages).includes('INVALID-CURRENT-NORMATIVE'), false)
    assert.deepEqual(normative(factsFor(directory, sessionID)), normative(seeded.facts))
    save('historical-occurrence-after-invalid-mapping', { seeded, replay: replay.messages, facts: factsFor(directory, sessionID), mapping: readFileSync(paths.mappingPath, 'utf8'), material: readFileSync(paths.materialPath, 'utf8'), scope: 'Two real plugin incarnations with disposed/reopened journal ownership in one process. Current discovery is invalid; previously durable occurrence remains frozen. No cross-process crash claim.' })
    await lifecycle.stop(second)
  })
})
