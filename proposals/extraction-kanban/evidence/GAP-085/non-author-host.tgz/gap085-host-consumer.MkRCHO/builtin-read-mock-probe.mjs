import fs from 'node:fs'
import { mock } from 'bun:test'

const original = fs.readFileSync
let count = 0
const observed = { ...fs, readFileSync: (...args) => {
  count++
  return original(...args)
} }
mock.module('node:fs', () => ({ ...observed, default: observed }))
const consumer = await import('./builtin-read-consumer.mjs')
consumer.read()
console.log(JSON.stringify({ transparentBuiltinModuleObservationCount: count }))
