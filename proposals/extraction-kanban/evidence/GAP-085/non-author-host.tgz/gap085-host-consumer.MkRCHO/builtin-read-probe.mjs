import fs from 'node:fs'
import { syncBuiltinESMExports } from 'node:module'

const original = fs.readFileSync
let count = 0
fs.readFileSync = (...args) => {
  count++
  return original(...args)
}
syncBuiltinESMExports()
const consumer = await import('./builtin-read-consumer.mjs')
consumer.read()
fs.readFileSync = original
syncBuiltinESMExports()
console.log(JSON.stringify({ dynamicAfterPatchCount: count }))
