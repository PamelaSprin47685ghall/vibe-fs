import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { mkdtempSync, mkdirSync, readFileSync, rmSync, writeFileSync, existsSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const product = resolve(process.argv[2] ?? '/private/tmp/d2-clean-install-661/node_modules/wanxiangshu')
const matcherPath = join(product, 'dist/Foundation/GlobMatch.js')
const catalogPath = join(product, 'dist/Requirement/Grounding/Catalog.js')
const { matchesPathPattern } = await import(pathToFileURL(matcherPath))
const grounding = await import(pathToFileURL(join(product, 'dist/Requirement/Grounding/Surface.js')))
const digest = file => createHash('sha256').update(readFileSync(file)).digest('hex')
const fixed = { [matcherPath]: digest(matcherPath), [catalogPath]: digest(catalogPath) }
const owned = mkdtempSync('/private/tmp/gap085-witness-owned-')
const root = join(owned, 'requirements/alpha')
mkdirSync(root, { recursive: true })
writeFileSync(join(root, 'WHAT.md'), '# alpha\n')
const examples = [
  ['/requirements/alpha/WHAT.md', 'requirements/alpha/WHAT.md'],
  ['/requirements/alpha/tests/**', 'requirements/alpha/tests/future.mjs'],
  ['!/requirements/alpha/tests/**', 'requirements/alpha/tests/future.mjs'],
  ['/requirements/alpha', 'requirements/alpha'],
  ['**/*.fs', 'requirements/alpha/future.fs'],
  ['*.fs', 'requirements/alpha/future.fs'],
  ['**/tests/**', 'requirements/alpha/tests/future.mjs'],
  ['/requirements/**/future?.fs', 'requirements/alpha/future1.fs'],
  ['/requirements/a?pha/**', 'requirements/alpha/tests/future.mjs'],
  ['/requirements/[a-z]*/tests/**', 'requirements/alpha/tests/future.mjs'],
  ['/requirements/alpha/[!a]*.fs', 'requirements/alpha/future.fs'],
]
const legalControls = ['/src/**/*.fs', '/src/Wanxiangshu/**/*Surface.fs', '/requirements/beta/tests/**', '/requirements/alpha-old/**', '/requirements/a[!l]pha/**']
const records = []
try {
  for (const [rule, witness] of examples) {
    const pattern = rule.startsWith('!') ? rule.slice(1) : rule
    const result = matchesPathPattern(pattern, witness)
    assert.equal(result.tag, 0)
    assert.equal(result.fields[0], true)
    writeFileSync(join(root, 'APPLIES-TO'), `${rule}\n`)
    let currentAccepted = false
    let error = null
    try { grounding.discoverPackages(owned); currentAccepted = true } catch (caught) { error = caught.message }
    records.push({ rule, witness, witnessExists: existsSync(join(owned, witness)), actualMatcherMatches: true,
      contractClassification: 'self-overlap: configuration error under WHAT002, including future paths', currentAccepted, error })
  }
  for (const rule of legalControls) {
    writeFileSync(join(root, 'APPLIES-TO'), `${rule}\n`)
    grounding.discoverPackages(owned)
    records.push({ rule, contractClassification: 'disjoint literal directory prefix; legal control', currentAccepted: true })
  }
  for(const [path, expected] of Object.entries(fixed)) assert.equal(digest(path), expected)
  console.log(JSON.stringify({ product, fixed, records,
    scope: 'Known witness checks through the existing actual matcher and small isolated Catalog discovery only. No second glob oracle, no general intersection implementation, and no whole-repository test run.' }, null, 2))
} finally {
  rmSync(owned, { recursive: true, force: true })
  console.log(JSON.stringify({ ownedWorkspaceRemoved: !existsSync(owned) }))
}
