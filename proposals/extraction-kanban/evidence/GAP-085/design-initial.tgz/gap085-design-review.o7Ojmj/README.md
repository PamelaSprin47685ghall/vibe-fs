# GAP-085 自子树规则校验：独立只读准备

没有认领或修改生产源码，没有实现另一套 glob，没有跑全仓。主代理仍优先处理 D2；本文件仅为下一工作包定边界和反例。

## 现有规范下的结论

WHAT002 禁止 APPLIES-TO 声明或取消自身整个 requirements 目录。Catalog.selfMatch 也明确包括目录本身与任意后代。判断应逐条看规则语言是否与这个自子树相交，普通规则和前导 ! 一样；不能先把多行 include/exclude 抵消后才判断。即使某条 ! 暂时没有改变最终结果，只要它声明排除自身，仍违反002。

因此 `**/*.fs`、`*.fs` 和 `**/tests/**` 按当前规范都不合法：它们可能命中本包以后新增的文件。当前没有自身 .fs 文件不能使其变成包外声明。这个修复不需要为保留漏拒而放宽002。

已读当前活动广域规则：structured-workflow 的 `/src/Wanxiangshu/**/*.fs` 与 js-semantic-surface 的 `/src/Wanxiangshu/**/*Surface.fs` 明确限定 src，不与自身 requirements 相交，仍合法。声明其它包 `/requirements/other/...` 也应保留。扫描当前活动 APPLIES-TO 时未见全局 `**/*.fs`；不能把仓库实际锚定 src 的规则误说成全局通配。

## 实际小例与现状

`witnesses.mjs` 消费实际固定661安装包的 Foundation.GlobMatch 和 Grounding Surface，创建一个只含 alpha/WHAT.md 的自有临时工作区。每个非法例先用同一个现有 matcher 检查一个明确自身 witness，再观察当前 discoverPackages。不是新的相交算法，也没有靠枚举当前目录证明未来路径不存在。

11个自身相交例中，现有实现拒绝 WHAT.md 及会命中 WHAT.md 的 `a?pha/**` 两项；其余9项仍被接受：

- `/requirements/alpha/tests/**` 和对应 ! 排除；
- `/requirements/alpha` 目录本身；
- `**/*.fs`、`*.fs`、`**/tests/**`；
- `/requirements/**/future?.fs`；
- `/requirements/[a-z]*/tests/**`；
- `/requirements/alpha/[!a]*.fs`。

其中大多数 witness 文件尚不存在。5个不相交对照仍被接受：限定 src 的两项、beta 的 tests、alpha-old 子树、不能匹配 alpha 的字符类。实际输出在 `witnesses.log`；首次相同结果的日志也保留。自有工作区已清理。

固定661包 SHA-256：`34393e1d4b8fcb4b7e3ddbaa9769a681c728fb12ed072a0785c0bb82483f009f`，归档包含该确切包。日志记录所用 matcher/Catalog JS 摘要。源码快照只供审查；不冒充此日志全部编译输入的回溯证明。

## 最小可行公共契约

在 Foundation.GlobMatch 加一个纯查询，例如 `mayMatchSubtree(pattern, directory) : Result<bool, GlobPatternError>`。directory 是匹配器使用的工作区相对规范化目录；结果表示模式是否可能命中目录本身或任意未来规范化后代。它不访问文件系统，不知道包名或 APPLIES-TO 的 Include 字段。Catalog 只构造自身目录、调用查询、拒绝 true；不把 glob 解析复制到 Grounding。

先把已有 leading slash/bare-name 规范化与 wildmatch 解析提成一个私有 token/字符集合表示。现有正则编译和新查询共享它。保持 `compilePattern` 与 `matchesPathPattern` 对既有消费者的含义，不引入新的 glob 库或外置通用 automata 框架。

新查询可从同一 token 表示得到有限状态前沿，消费固定目录与 `/` 前缀，再检查是否存在合法后代可到达接受态。另检查 exact directory。`**/` 必须保留零层分支；状态应去重，避免按所有 wildcard 组合递归爆炸。这是查询现有匹配语言，不是拿一组固定 WHAT/tests 路径代替存在性判断。

## 实施时易错的边界

- 保留当前实际 dialect：单 `*`/`?`、`**`、`**/`、bare-name 隐含 `**/`、字符类取反/范围及错误处理都走同一个解析。不要在此工作包悄悄加 brace 或换一种 Git glob 语义。
- 字符类不能一律假定“有某个可用字符”。前缀消费必须与现有 matcher 一致，剩余语言也须知道字符集合是否可满足；否则只检测 `a` 或固定样例仍会漏报。
- exact root 不可漏，alpha-old 不可误拒。目录后代应采用既有规范化路径语义；不能把带 glob 的 pattern 本身交给 path.resolve 消掉 `..`，那会改变匹配语言。包含重复分隔符或点段的死模式，也不能凭另造路径规则悄悄改义。
- 工作区别名、未存在路径、符号链接逃逸沿现有 workspaceRelative/canonicalTarget 验证；纯语言查询不遍历当前 symlink，也不从当前文件树推测未来范围。
- 非法声明不能被消费成材料，但 WHAT008 的 mutation fail-open 要保留。修正 scope 校验不能变成新的 Host 修改准入。
- 本工作包只处理002的自子树约束，不能顺带关闭 GAP-085 表里 legacy/user、UTF-8 或其它完整 Host 证明边界。

## 必要验收

先把现002的 TODO 漏拒转为正式反例，并加入上面的 root/future/*/?/class/正负规则。补合法 src、其它包、alpha-old、class 排除自身的对照；规则顺序不得掩盖单条自排除。匹配器重构要保留已有正则匹配测试，并对小而完整的语法/字符域比较现有 match 与新查询的 witness 一致性；有限枚举只能作反例检查，不能宣称证明所有无限路径。

最后通过真实 discover/grounding 材料消费入口、工作区别名/符号链接与008无准入回退，以及相关 requirement 和安装消费者。没有这些证据前不施工后宣称整项闭合。

复现此处只读现状：安装归档661及依赖后执行 `node witnesses.mjs <installed-661-root>`。SHA256SUMS 固定说明、源快照、实际包、小例和原日志。
