# GAP-085 scope clarification addendum

This is a separate correction and evidence addendum. It does not rewrite the earlier immutable design or final-review archives.

The current plan is `REMAINING-REPAIRS-2026-10-16.md`, GAP-085 lines 189–197: entire self-rule validation, positive/negative declarations, legal external rules, future paths, workspace aliases and escapes, and real grounding refusal without consuming illegal materials. It explicitly does not rebuild discovery or batch-migrate user configuration.

The earlier independent archive's statement that the entire GAP-085 could not be closed was too broad if interpreted as a judgment on this current card. Historic material/UTF8/full-plugin items sharing the old GAP number are not unfinished acceptance items of this frozen card. The root's combined 667 rule, Host, cold replay, relevant requirement and consumer evidence can close the card after final integration gates pass. A limited reviewer receipt alone is not a reason to reopen or expand it.

The literal-backslash package-name issue is not outside WHAT002 itself: it violates that clause's broader natural self-coverage promise. It is, however, an unchanged old path-domain issue outside the current self-declaration validation and hookup repair. It must remain explicitly recorded as an unresolved old WHAT002 boundary, without blocking this card or claiming every valid POSIX package name has been fixed.

`probe.mjs` uses actual fixed 663 and 667 installs. Both discover the real package named `a\\b`, but neither resolves that package's own WHAT.md back to it. The same owned workspace and same real file are used for both. The observed results are asserted as a retained limitation, not as contract success. Node 26.6.0, macOS; no Bun claim is made by this addendum. The workspace is removed in finally.

Earlier archives remain unchanged:

- Final 667 review: SHA256 `76f37ce625ce0cd07f74be80358b62d2ec26a9e92a08dca8c9f6b3a912d4cf04`.
- Design-domain review: SHA256 `c4a668b486e323209438caff79cf03cdc69da218995af4d89f980c70c3f83324`.

No shared source, tests, report or Git state was changed by this reviewer. This addendum does not close the old backslash-name defect, redefine WHAT002, or investigate R12-U1.
