import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, rmSync, existsSync } from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'

const inputs = [
  ['663', '/private/tmp/d2-clean-install-663/node_modules/wanxiangshu', '/private/tmp/d2-candidate-663/wanxiangshu-0.9.0.tgz'],
  ['667', '/private/tmp/gap085-clean-install-667/node_modules/wanxiangshu', '/private/tmp/gap085-candidate-667/wanxiangshu-0.9.0.tgz'],
]
const workspace = mkdtempSync('/private/tmp/gap085-name-comparison-owned-')
try {
  const name = 'a\\b'
  const directory = join(workspace, 'requirements', name)
  mkdirSync(directory, { recursive: true })
  writeFileSync(join(directory, 'WHAT.md'), '# package\n')
  const records = []
  for (const [version, product, archive] of inputs) {
    const api = await import(pathToFileURL(join(product, 'dist/Requirement/Grounding/Surface.js')))
    const discovered = api.discoverPackages(workspace)
    const resolvedOwnWhat = api.resolvePackages(workspace, join(directory, 'WHAT.md'))
    assert.deepEqual(discovered, [name])
    assert.deepEqual(resolvedOwnWhat, [])
    records.push({ version, product, archive, archiveSha256: createHash('sha256').update(readFileSync(archive)).digest('hex'),
      name, discovered, resolvedOwnWhat })
  }
  console.log(JSON.stringify({ runtime: process.version, records,
    classification: 'Confirmed unchanged old natural-self-coverage limitation under complete WHAT002; not introduced by the 667 self-rule validation repair.' }, null, 2))
} finally {
  rmSync(workspace, { recursive: true, force: true })
  console.log(JSON.stringify({ ownedWorkspaceRemoved: !existsSync(workspace) }))
}
