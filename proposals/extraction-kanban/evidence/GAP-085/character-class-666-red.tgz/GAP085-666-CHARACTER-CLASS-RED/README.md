# GAP-085 candidate 666: targeted character-class rejection

This superseded candidate was not given full acceptance. Its exact archive is included, SHA256 `1a96ab67b257acfd6ce1f47e0cfad4e252df801d903e74e1a0bcd55a23c6849f`. The actual clean installation contained 2904 unchanged files; its lock and before/after hashes are retained.

One preregistered targeted probe per Host, Node 26.6.0 and Bun 1.3.14, failed with the intended normal assertion and exit 1. There was no import, environment or timeout failure. The pattern `/src/[]|]` produced these actual fixed-package results on both Hosts:

- Point matching `requirements/alpha/future]`: true.
- Subtree query for `requirements/alpha`: false.
- discoverPackages still accepted the rule.
- Actual external `src/]` matched, but `src/|` did not.

The shared legacy character-class lexer allowed a leading closing bracket to escape the intended regex class and expose alternation. The new subtree machine could consequently disagree with the actual point matcher. This artifact proves the remaining implementation issue; it does not characterize the entire discovery system.

The exact probe `gap085-class-boundary-probe.mjs` is retained for unchanged replay against the correction. Its expected result is consistent rooted character-class semantics: self point=false, subtree=false, both external class members `]` and `|` match, and the legal external rule is accepted.

```sh
node gap085-class-boundary-probe.mjs "$fixed_product_directory" /private/tmp/gap085-class-node-fresh
bun gap085-class-boundary-probe.mjs "$fixed_product_directory" /private/tmp/gap085-class-bun-fresh
shasum -a 256 -c MANIFEST.sha256
```

Small private filesystem fixtures are intentionally retained. No journal or child process is used by this probe, no source compilation is performed, and no shared source or installed candidate file was changed.

`gap085-review-hypothesis-refuted.json` separately records a review hypothesis about the unflagged JavaScript `$` anchor. Actual Node/Bun behavior disproved it before it became a product finding; no source change was requested for it. The wrongly classified `/requirements/al**/a/**` positive fixture is also separately explained by its actual self witness. These are review/fixture attribution, not additional product defects. R12-U1 remains deferred.
