actual alpha material
