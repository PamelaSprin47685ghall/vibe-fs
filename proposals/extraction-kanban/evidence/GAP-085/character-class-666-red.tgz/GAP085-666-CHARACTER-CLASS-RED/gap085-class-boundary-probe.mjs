import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { pathToFileURL } from 'node:url'

const [product, evidence] = process.argv.slice(2)
fs.mkdirSync(evidence, { recursive: true })
const point = await import(pathToFileURL(path.join(product, 'dist/Foundation/GlobMatch.js')).href)
const catalog = await import(pathToFileURL(path.join(product, 'dist/Requirement/Grounding/Surface.js')).href)
const root = path.join(evidence, 'workspace')
const packageRoot = path.join(root, 'requirements/alpha')
fs.mkdirSync(packageRoot, { recursive: true })
fs.writeFileSync(path.join(packageRoot, 'WHAT.md'), 'actual alpha material\n')
const pattern = '/src/[]|]'
fs.writeFileSync(path.join(packageRoot, 'APPLIES-TO'), pattern + '\n')
const value = result => {
  assert.equal(result.tag, 0)
  return result.fields[0]
}
const capture = action => {
  try { return { value: action() } }
  catch (error) { return { error: { name: error.name, message: error.message } } }
}
const record = {
  host: process.execPath, product, pattern,
  ownWitness: 'requirements/alpha/future]',
  ownPoint: value(point.matchesPathPattern(pattern, 'requirements/alpha/future]')),
  subtreeQuery: value(point.mayMatchSubtree(pattern, 'requirements/alpha')),
  externalClosingBracket: value(point.matchesPathPattern(pattern, 'src/]')),
  externalVerticalBar: value(point.matchesPathPattern(pattern, 'src/|')),
  discovery: capture(() => catalog.discoverPackages(root)),
  externalBracketResolution: capture(() => catalog.resolvePackages(root, path.join(root, 'src/]'))),
  externalBarResolution: capture(() => catalog.resolvePackages(root, path.join(root, 'src/|'))),
}
try {
  assert.equal(record.ownPoint, record.subtreeQuery, 'the actual point engine and subtree query must agree on this concrete own-subtree witness')
  assert.equal(record.ownPoint, false, 'a rooted src character-class rule cannot match requirements')
  assert.equal(record.externalClosingBracket, true)
  assert.equal(record.externalVerticalBar, true)
  assert.deepEqual(record.discovery.value, ['alpha'])
  assert.deepEqual(record.externalBracketResolution.value, ['alpha'])
  assert.deepEqual(record.externalBarResolution.value, ['alpha'])
  record.accepted = true
} catch (error) {
  record.accepted = false
  record.assertion = { message: error.message, stack: error.stack }
  process.exitCode = 1
} finally {
  fs.writeFileSync(path.join(evidence, 'record.json'), JSON.stringify(record, null, 2))
  console.log(JSON.stringify(record))
}
