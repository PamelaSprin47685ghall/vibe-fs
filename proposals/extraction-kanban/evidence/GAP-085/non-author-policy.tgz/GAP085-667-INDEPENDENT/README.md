# GAP-085 self-subtree validation: independent candidate 667 evidence

Scope: validate each APPLIES-TO rule against the package's own directory and possible descendants, including absent future paths. This evidence does not redesign discovery or close unrelated historical GAP-085/086 work. R12-U1 remains deferred.

## Fixed inputs

Candidate archive is included as `packages/wanxiangshu-0.9.0.tgz`, SHA256 `b0de9b9770139ae4aa977fae3d8b8d59f2d558cf4ff4a41cf4a1289419743297`. It was actually clean-installed at `/private/tmp/gap085-clean-install-667/node_modules/wanxiangshu`; its lock is retained. The old fixed baseline is candidate 663, SHA256 `3c0afec4f5aee947cff92a5a2e633a41d4e9728daa515f27295e634ed9b324e0`, actually installed at `/private/tmp/d2-clean-install-663/node_modules/wanxiangshu`.

Both installations had 2904 files, identical before and after this review. Between the two installed products, only `dist/Foundation/GlobMatch.js` and `dist/Requirement/Grounding/Catalog.js` differ. Exact hashes and the two-file comparison are retained. No source implementation fallback, product mutation or new compilation was used by this reviewer.

To avoid duplicating the old package, recover the exact 663 tar from the already retained `D2-FINAL-663-INDEPENDENT.tgz`, SHA256 `096b9160f02b9f668d0f4454a10d69d8670e3ba144a1ca3f4e73c46632746db3`, member `D2-FINAL-663-INDEPENDENT/packages/wanxiangshu-0.9.0.tgz`. It is also recorded in the repository under the R6-D2 evidence directory.

## Results, separately by Host

Node 26.6.0 and Bun 1.3.14 each passed the unchanged eight final 002 test bodies against candidate 667: 8 pass, 0 fail, 0 TODO. The copies only change the module import to the fixed installation, as shown by the two import diffs. Against fixed 663, the same bodies each produced 4 pass / 4 real assertion failures. Those old failures concern future self declarations, exact UTF16 self directory matches, the line-end self case, and the leading closing-bracket parser defect. They are retained as red evidence, not counted as failed candidate checks.

The witness probe uses actual old/new point matching and actual catalog/runtime modules. It contains no independent glob parser or automaton oracle. Each supposedly forbidden rule has an explicit concrete self witness that both actual point engines first confirm. The future descendant does not exist in the fixture. Per Host, the unchanged non-policy cases all passed:

- 24 self witnesses: 12 concrete rules, each ordinary and negated; the old package accepted them and the candidate rejected them.
- 16 disjoint external rule cases: eight rules, ordinary and negated; old and new discovery/resolution agree.
- One ordered include/exclude/reinclude case.
- 16 actual point-matcher compatibility cases, including separators, UTF16, line ends and malformed patterns.

Two actual grounding policy cases were run with the same corrected map, `/src/**` plus the forbidden self/tests declaration. On Node the candidate rejected before material reads (0), with empty pending/grounded state; a legal-map positive control performed one actual material read and one request. Fixed 663 accepted the bad declaration, actually read the material once and requested alpha. The read observer delegates to the real node:fs function, updates live named bindings, and restores them. Its positive control proves it sees the actual product read. On Bun the same real rejection/request/state comparison passed; fs read counts are explicitly null and are not claimed as measured.

The 57 non-policy cases plus the two corrected policy cases form 59 distinct checks per Host. The original candidate-policy case was strengthened when the old policy fixture was corrected; it is not counted twice. Formal 002 and the separate class probe are reported separately, not added to inflate witness coverage.

The exact original `gap085-class-boundary-probe.mjs` that failed against candidate 666 was replayed unchanged on 667 and passed on both Hosts. Rooted `/src/[]|]` now gives self point=false and subtree=false, while both actual external class members `src/]` and `src/|` match and resolve normally. Its original red archive remains `GAP085-666-CHARACTER-CLASS-RED.tgz`, SHA256 `d62101e0d5665d5706e8f106d090ac1dde7eea59e3364e354fb25cec7fca4ccf`. This deliberate correction to the old leading-`]` bug is separate from ordinary legacy matching compatibility.

## Preserved harness mistakes and review attribution

The first 59-case run was 58/59 on both Hosts because the old-runtime material fixture declared only a tests rule but requested src/main. The old code correctly found no covered package for that input; the expected old material request was a fixture error. Both candidate and old policy inputs were strengthened with the same `/src/**` rule. Only these two affected cases were rerun per Host; the other 57 cases were not repeated. Original scripts, failing logs, corrected script/diff and the preregistered correction are retained.

The first Bun 002 command mistakenly used `bun --test`. Bun executed zero formal tests and reported that `bun test` was required. Both initial logs are retained as command failures. The corrected `bun test` runs are the actual eight-case candidate/baseline results. Neither initial command error is attributed to the product.

`gap085-review-hypothesis-refuted.json` separately records the disproved unflagged-`$` hypothesis and the mistaken classification of `/requirements/al**/a/**` as a legal external rule. That rule has a real self witness `requirements/alpha/a/future.fs`; `/requirements/zz**/a/**` is the disjoint positive control. Review or fixture mistakes are not merged with implementation defects.

## Replay

The actual probe scripts accept explicit fixed product locations and fresh evidence directories. The original script is retained with its disclosed fixture error. For a future complete replay using the corrected inputs, run from this directory:

```sh
node evidence/gap085-policy-probes-corrected.mjs "$candidate_product" "$old_product" /private/tmp/gap085-node-fresh
bun evidence/gap085-policy-probes-corrected.mjs "$candidate_product" "$old_product" /private/tmp/gap085-bun-fresh
```

Without a filter, that script also runs the unchanged 57 non-policy cases. This complete corrected replay is offered for future use; it was not added as another complete run in this review. The actual recorded corrected runs selected only the two affected material cases:

```sh
node evidence/gap085-policy-probes-corrected.mjs "$candidate_product" "$old_product" /private/tmp/gap085-node-policy-fresh material
bun evidence/gap085-policy-probes-corrected.mjs "$candidate_product" "$old_product" /private/tmp/gap085-bun-policy-fresh material
node evidence/gap085-class-boundary-probe.mjs "$candidate_product" /private/tmp/gap085-node-class-fresh
bun evidence/gap085-class-boundary-probe.mjs "$candidate_product" /private/tmp/gap085-bun-class-fresh
```

The original 002 fixture can be staged without rewriting its body or import. Copy `evidence/002-source.test.mjs` into `requirements/requirement-grounding/tests/002.test.mjs` beneath a fresh directory and link that directory's `dist` to the selected fixed product's `dist`. Then use `node --test` or `bun test` on the copied fixture. This preserves its original relative module binding while using the actual fixed installed product.

The actual registered 007/008 read/JS/mutation chains and the complete related 13-file suite were run by the implementation owner and are not claimed as repeated here. This independent evidence covers the fixed package's actual catalog/grounding consumers and concrete rule rejection boundary. Small fixture files and raw journals remain intentionally retained; journals were explicitly disposed. No independent per-PID sampling is claimed for the runtime policy calls.

```sh
shasum -a 256 -c MANIFEST.sha256
```
