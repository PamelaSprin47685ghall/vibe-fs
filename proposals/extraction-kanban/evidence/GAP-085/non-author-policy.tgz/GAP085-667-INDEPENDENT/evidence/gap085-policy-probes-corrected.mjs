import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
import { syncBuiltinESMExports } from 'node:module'

const [candidateRoot, oldRoot, evidence] = process.argv.slice(2)
fs.mkdirSync(evidence, { recursive: true })
const moduleAt = (root, file) => import(pathToFileURL(path.join(root, 'dist', file)).href)
const current = await moduleAt(candidateRoot, 'Requirement/Grounding/Surface.js')
const previous = await moduleAt(oldRoot, 'Requirement/Grounding/Surface.js')
const point = await moduleAt(candidateRoot, 'Foundation/GlobMatch.js')
const oldPoint = await moduleAt(oldRoot, 'Foundation/GlobMatch.js')
const runtime = await moduleAt(candidateRoot, 'OpenCode/Host/RequirementGroundingSurface.js')
const oldRuntime = await moduleAt(oldRoot, 'OpenCode/Host/RequirementGroundingSurface.js')
const records = []
const observe = action => {
  try { return { returned: action() } }
  catch (error) { return { error: { name: error.name, message: error.message } } }
}
const bool = result => {
  assert.equal(result.tag, 0)
  return result.fields[0]
}
const fixture = (name, packageName, rule) => {
  const directory = path.join(evidence, 'fixtures', name)
  const packageDirectory = path.join(directory, 'requirements', packageName)
  fs.mkdirSync(packageDirectory, { recursive: true })
  fs.writeFileSync(path.join(packageDirectory, 'WHAT.md'), `material for ${packageName}\n`)
  fs.writeFileSync(path.join(packageDirectory, 'APPLIES-TO'), rule + '\n')
  return directory
}
const check = async (name, action) => {
  if (process.argv[5] && !name.includes(process.argv[5])) return
  const record = { name }
  try {
    await action(record)
    record.accepted = true
  } catch (error) {
    record.accepted = false
    record.assertion = { message: error.message, stack: error.stack }
    process.exitCode = 1
  }
  records.push(record)
}

const selfCases = [
  ['exact-directory', 'alpha', '/requirements/alpha', 'requirements/alpha'],
  ['literal-future', 'alpha', '/requirements/alpha/tests/future.fs', 'requirements/alpha/tests/future.fs'],
  ['zero-directory', 'alpha', '/requirements/alpha/**/future.fs', 'requirements/alpha/future.fs'],
  ['many-directories', 'alpha', '/requirements/**/future?.fs', 'requirements/alpha/deep/future1.fs'],
  ['range', 'alpha', '/requirements/[a-c]lpha/tests/**', 'requirements/alpha/tests/future.fs'],
  ['question', 'alpha', '/requirements/alph?/tests/**', 'requirements/alpha/tests/future.fs'],
  ['negative-class', 'alpha', '/requirements/alpha/tests/[!x].fs', 'requirements/alpha/tests/a.fs'],
  ['literal-unicode', 'alpha', '/requirements/alpha/tests/雪😀.fs', 'requirements/alpha/tests/雪😀.fs'],
  ['unanchored-basename', 'alpha', 'future.fs', 'requirements/alpha/future.fs'],
  ['two-stars-basename', 'alpha', '**/*.fs', 'requirements/alpha/future.fs'],
  ['embedded-recursive-directory', 'alpha', '/requirements/al**/a/**', 'requirements/alpha/a/future.fs'],
  ['unicode-package-code-units', '雪😀', '/requirements/雪??/tests/**', 'requirements/雪😀/tests/future.fs'],
]

for (const [name, packageName, rule, witness] of selfCases) {
  for (const polarity of ['', '!']) {
    await check(`${name}-${polarity ? 'exclude' : 'include'}`, record => {
      Object.assign(record, { packageName, rule: polarity + rule, witness })
      record.oldPoint = bool(oldPoint.matchesPathPattern(rule, witness))
      record.candidatePoint = bool(point.matchesPathPattern(rule, witness))
      assert.equal(record.oldPoint, true, 'the explicit witness must match the actual old point engine')
      assert.equal(record.candidatePoint, true, 'point matching must retain the explicit witness')
      const directory = fixture(`${name}-${polarity ? 'exclude' : 'include'}`, packageName, polarity + rule)
      record.futureWitnessExists = fs.existsSync(path.join(directory, witness))
      if (name !== 'exact-directory') assert.equal(record.futureWitnessExists, false)
      record.oldDiscovery = observe(() => previous.discoverPackages(directory))
      record.candidateDiscovery = observe(() => current.discoverPackages(directory))
      assert.match(record.candidateDiscovery.error?.message ?? '', /must not declare package self coverage/)
    })
  }
}

const externalCases = [
  ['alpha-old', '/requirements/alpha-old/**', 'requirements/alpha-old/future.fs'],
  ['selfalpha', '/requirements/selfalpha/**', 'requirements/selfalpha/future.fs'],
  ['class-excludes-self', '/requirements/[b-z]lpha/**', 'requirements/blpha/future.fs'],
  ['negated-class-excludes-self', '/requirements/alph[!a]/**', 'requirements/alphb/future.fs'],
  ['required-separator', '/requirements/zz**/a/**', 'requirements/zz/a/future.fs'],
  ['external-directory', '/requirements/alpha-old', 'requirements/alpha-old'],
  ['root-source', '/src/**', 'src/future.fs'],
  ['relative-source', 'src/**', 'src/future.fs'],
]
for (const [name, rule, witness] of externalCases) {
  for (const polarity of ['', '!']) {
    await check(`${name}-${polarity ? 'exclude' : 'include'}`, record => {
      Object.assign(record, { packageName: 'alpha', rule: polarity + rule, witness })
      assert.equal(bool(oldPoint.matchesPathPattern(rule, witness)), true)
      assert.equal(bool(point.matchesPathPattern(rule, witness)), true)
      const directory = fixture(`external-${name}-${polarity ? 'exclude' : 'include'}`, 'alpha', polarity + rule)
      record.oldDiscovery = previous.discoverPackages(directory)
      record.candidateDiscovery = current.discoverPackages(directory)
      assert.deepEqual(record.candidateDiscovery, ['alpha'])
      record.oldResolution = previous.resolvePackages(directory, path.join(directory, witness))
      record.candidateResolution = current.resolvePackages(directory, path.join(directory, witness))
      assert.deepEqual(record.candidateResolution, polarity ? [] : ['alpha'])
      assert.deepEqual(record.candidateResolution, record.oldResolution)
    })
  }
}

await check('ordered-external-positive-exclude-reinclude', record => {
  const rule = '# ordered rules\n/src/**\n!/src/generated/**\n/src/generated/keep.fs\n'
  const directory = fixture('ordered-external', 'alpha', rule)
  record.results = ['src/main.fs', 'src/generated/drop.fs', 'src/generated/keep.fs'].map(file => current.resolvePackages(directory, path.join(directory, file)))
  assert.deepEqual(record.results, [['alpha'], [], ['alpha']])
})

const pointCases = [
  ['/src/**/*.fs', 'src/main.fs'], ['/src/**/*.fs', 'src/deep/main.fs'],
  ['/src/*.fs', 'src/deep/main.fs'], ['*.fs', 'src/deep/main.fs'],
  ['/requirements/al**/a/**', 'requirements/alpha/a/future.fs'],
  ['/requirements/zz**/a/**', 'requirements/zz/a/future.fs'],
  ['?', '😀'], ['??', '😀'], ['/requirements/雪??/tests/**', 'requirements/雪😀/tests/future.fs'],
  ['/requirements/alpha', 'requirements/alpha\n'],
  ['/requirements/alpha', 'requirements/alpha\r'],
  ['/requirements/alpha', 'requirements/alpha\u2028'],
  ['/requirements/alpha', 'requirements/alpha\u2029'],
  ['[', 'src/main.fs'], ['[z-a]', 'a'], ['**', 'src/line\nname.fs'],
]
for (const [pattern, target] of pointCases) {
  await check(`legacy-point-${JSON.stringify(pattern)}-${JSON.stringify(target)}`, record => {
    Object.assign(record, { pattern, target })
    record.old = observe(() => {
      const result = oldPoint.matchesPathPattern(pattern, target)
      return result.tag === 0 ? { ok: true, value: result.fields[0] } : { ok: false }
    })
    record.candidate = observe(() => {
      const result = point.matchesPathPattern(pattern, target)
      return result.tag === 0 ? { ok: true, value: result.fields[0] } : { ok: false }
    })
    assert.deepEqual(record.candidate, record.old)
  })
}

await check('actual-grounding-rejects-before-material-read-with-live-positive-control', async record => {
  const directory = fixture('actual-grounding-policy', 'alpha', '/src/**\n/requirements/alpha/tests/**')
  fs.mkdirSync(path.join(directory, 'src'))
  const source = path.join(directory, 'src/main.fs')
  fs.writeFileSync(source, 'actual code content\n')
  const material = path.join(directory, 'requirements/alpha/WHAT.md')
  const opened = await runtime.createJournal(directory)
  assert.equal(opened.ok, true)
  const originalRead = fs.readFileSync
  const readAttempts = []
  const observed = !process.versions.bun
  try {
    if (observed) {
      fs.readFileSync = function (file, ...args) {
        if (typeof file === 'string' && path.resolve(file) === material) readAttempts.push(file)
        return originalRead.call(this, file, ...args)
      }
      syncBuiltinESMExports()
    }
    try { await runtime.requestPaths(opened.journal, directory, 'invalid', [source]) }
    catch (error) { record.rejection = { name: error.name, message: error.message } }
    assert.match(record.rejection?.message ?? '', /must not declare package self coverage/)
    record.pendingAfterInvalid = runtime.pendingPackages(opened.journal, 'invalid')
    record.groundedAfterInvalid = runtime.groundedIdentities(opened.journal, 'invalid')
    assert.deepEqual(record.pendingAfterInvalid, [])
    assert.deepEqual(record.groundedAfterInvalid, [])
    record.materialReadAttemptsAfterInvalid = observed ? readAttempts.length : null
    if (observed) assert.equal(readAttempts.length, 0)
    fs.writeFileSync(path.join(directory, 'requirements/alpha/APPLIES-TO'), '/src/**\n')
    record.validControl = await runtime.requestPaths(opened.journal, directory, 'valid-control', [source])
    assert.equal(record.validControl.ok, true)
    assert.deepEqual(record.validControl.packages, ['alpha'])
    record.materialReadAttemptsAfterValid = observed ? readAttempts.length : null
    if (observed) assert.ok(readAttempts.length > 0, 'the observer must see the real positive material read')
    record.readCounterScope = observed ? 'Delegates actual node:fs readFileSync; Node live named bindings updated and restored. Positive control proves the actual product hook.' : 'Bun not instrumented; only actual rejection and empty state are asserted.'
  } finally {
    if (observed) {
      fs.readFileSync = originalRead
      syncBuiltinESMExports()
    }
    runtime.disposeJournal(opened.journal)
  }
})

await check('old-baseline-actual-invalid-self-rule-requests-material', async record => {
  const directory = fixture('old-actual-grounding-policy', 'alpha', '/src/**\n/requirements/alpha/tests/**')
  fs.mkdirSync(path.join(directory, 'src'))
  const source = path.join(directory, 'src/main.fs')
  fs.writeFileSync(source, 'actual code content\n')
  const material = path.join(directory, 'requirements/alpha/WHAT.md')
  const opened = await oldRuntime.createJournal(directory)
  assert.equal(opened.ok, true)
  const originalRead = fs.readFileSync
  const readAttempts = []
  const observed = !process.versions.bun
  try {
    if (observed) {
      fs.readFileSync = function (file, ...args) {
        if (typeof file === 'string' && path.resolve(file) === material) readAttempts.push(file)
        return originalRead.call(this, file, ...args)
      }
      syncBuiltinESMExports()
    }
    record.baselineInvalidRequest = await oldRuntime.requestPaths(opened.journal, directory, 'old-invalid', [source])
    assert.equal(record.baselineInvalidRequest.ok, true)
    assert.deepEqual(record.baselineInvalidRequest.packages, ['alpha'])
    record.pendingAfterInvalid = oldRuntime.pendingPackages(opened.journal, 'old-invalid')
    assert.deepEqual(record.pendingAfterInvalid, ['alpha'])
    record.materialReadAttempts = observed ? readAttempts.length : null
    if (observed) assert.ok(readAttempts.length > 0)
    record.scope = 'A reproduced old bug: invalid self rule is accepted and its actual material is read and requested. It is not a successful candidate policy result.'
  } finally {
    if (observed) {
      fs.readFileSync = originalRead
      syncBuiltinESMExports()
    }
    oldRuntime.disposeJournal(opened.journal)
  }
})

const summary = { candidateRoot, oldRoot, host: process.execPath, selectedCaseNameSubstring: process.argv[5] ?? null, cases: records.length, passed: records.filter(record => record.accepted).length, failed: records.filter(record => !record.accepted).length, records, cleanup: 'Journals disposed; small private fixture files retained intentionally. No source compilation, source runtime fallback or independent glob oracle.' }
fs.writeFileSync(path.join(evidence, 'summary.json'), JSON.stringify(summary, null, 2))
console.log(JSON.stringify(summary))
