# GAP-085 final 667 non-author review

This reviewer did not edit shared source, tests, reports or Git state. The root authored the production changes. This archive preserves a confirmed candidate-666 failure and the bounded independent acceptance of fixed candidate 667. It does not close all historic GAP-085 work.

## Fixed inputs

- Baseline 663 main archive: SHA256 `3c0afec4f5aee947cff92a5a2e633a41d4e9728daa515f27295e634ed9b324e0`.
- Rejected 666 archive: SHA256 `1a96ab67b257acfd6ce1f47e0cfad4e252df801d903e74e1a0bcd55a23c6849f`.
- Accepted, scoped 667 archive: SHA256 `b0de9b9770139ae4aa977fae3d8b8d59f2d558cf4ff4a41cf4a1289419743297`.
- Final actual clean install: `/private/tmp/gap085-clean-install-667/node_modules/wanxiangshu`.
- Node 26.6.0 and Bun 1.3.14, macOS. All three main tgz files are included. Reviewed final source/signature/test snapshots are references; compiler input closure belongs to the root's build evidence.

## Old problems, new implementation defect and review mistakes

The original self-rule validation checked only WHAT.md and missed future self descendants. That is the pre-existing target problem.

An additional pre-existing matcher error was confirmed in the fixed 663 baseline: a class whose first member was an unescaped closing bracket could end the native JS class before the common lexer expected. The remaining raw class body could become outer regex syntax. For `/src/[]|]`, the generated native source was `^src\\/[]|]$`; its right alternation matched alpha paths ending in closing bracket, despite the apparent src prefix.

Candidate 666 introduced a new subtree query that assumed each raw CharacterClass fragment was one character or empty language. That premise was false for the old leaking class fragments. Actual ordinary matches still returned true for an own path while the new query returned false and Catalog accepted the rule. This was a new query implementation defect and an acceptance blocker. It did not change ordinary matchesPathPattern, and is not evidence of a newly introduced user-visible regression relative to the older WHAT-only validation, which also missed those cases.

`class-leak-666.mjs` records three such contradictions on both hosts through the actual frozen 666 bytes, plus actual Catalog acceptance. Logs named `*-confirmed-red.log` preserve the observed receipts. Logs named `*-required-red.log` additionally assert the required faithful-query behavior and exit 1 after confirming owned-workspace cleanup. The red package is kept; those failures were not rewritten as green tests.

Candidate 667 deliberately corrects the old matcher as well as the new query: the common class lexer escapes a count-zero closing bracket as a literal class member. This is an intentional behavior correction, not complete equivalence with the old dialect. It keeps proper []a], []] and []|] members within one class and stops outer alternation leakage.

This reviewer previously treated unusual leading-bracket fragments as uniformly empty language and claimed every old class fragment was one character or empty. That review assumption was wrong and was withdrawn after the actual counterexample. It is separate from the production defect. The earlier proposed final-LF exception for native JS `$` was also falsified on both runtimes and withdrawn by the root. The root's two proposed `/requirements/al**/...` legal fixtures were found to overlap future alpha descendants; those were test expectation mistakes, not reasons to loosen the correct NFA. The first two private design probes also used the wrong Fable Result representation; their fixture-error originals are retained in the earlier design archive.

## Final 667 results

`node-667.log` and `bun-667.log` passed these independent checks:

- Eighteen patterns outside the intentional leading-] correction retain exact RegExp.source against fixed 663. All 234 actual pattern/path pairs agree. This includes recursive and single stars, character classes, newline and surrogate cases, and the explicitly retained old negation dialect.
- Twenty-seven subtree cases cover exact directory, empty suffix, dot/dot-dot/repeated/trailing separators, future paths, bare patterns, the two mistaken recursive fixtures, invalid suffix characters, emoji directory UTF16 semantics, and a newline package that distinguishes a required **/ separator from an incorrect self-loop epsilon exit.
- Positive cases outside the intended correction have a concrete self-path witness accepted by the old actual matcher. No separate glob parser, NFA oracle or future-file scan was implemented.
- Six corrected leading-bracket class cases are checked against explicit native class sources and actual members/nonmembers. Disjoint src prefixes no longer leak to alpha paths. Own classes do cause self-rule rejection.
- Empty/unclosed patterns remain errors and an invalid range still throws; none becomes a normal false result.
- Actual Catalog rejects nine self rules for each of the positive and negative declaration signs before the future file exists, and accepts five disjoint or impossible-in-domain legal rules.

Each final probe removed its owned workspace. The two hosts produced the same final results.

`node-667-consumer-glob.log` and `bun-667-consumer-glob.log` additionally exercise the actual installed FilesystemSurface consumer. Glob []a] lists only src/] and src/a. Glob and grep []|] select only src/] and src/|, with no other/file] leakage. The same corrected .gitignore rule excludes only those src members and preserves other/file]. Ordinary **/*.fs enumeration, build exclusion and .git skipping pass. This is real glob/grep/ignore composition, not a second matcher.

`native-class-correction.mjs` separately records native JS regex checks for the proposed literal closing-bracket fragments, ordinary negation, a possible proper negated closing bracket, and invalid native ranges. Its proper-negated-bracket case is a feasibility check only; it does not claim production implemented that additional grammar change.

## Static and artifact review

The final shared lexer supplies both regex rendering and the small private NFA. The NFA's recursive-directory entry may skip zero levels or enter a separate wildcard state that can exit only through slash. Prefix traversal is UTF16 (`directory.split('')` in the fixed compiled bytes). Epsilon and suffix reachability are finite visited-state searches. Class existence scans the allowed code units with early termination; no second class parser or arbitrary regex fallback was introduced. Catalog calls the new query per rule, irrespective of include/exclude sign. The public fsi declares the new query. No filesystem probing was added to Foundation.

`artifact-map.json` compares all 2054 main package files of actual 663 and 667 installs, excluding nested node_modules. Only Foundation/GlobMatch.js and Requirement/Grounding/Catalog.js differ. The actual nested wanxiangli libraries compare equal across all 22 files. Thus the completed D2 implementation bytes were not changed in this package. This mapping is not proof of all runtime behavior or retrospective compiler inputs.

## Retained boundaries

This package keeps current Catalog slash-string semantics, including lexical dot/empty/trailing segments. It does not resolve glob patterns as physical paths or change target canonicalization. Earlier design evidence contains actual Node backslash-filename witnesses and Bun realpath differences. Directory inputs outside Catalog's non-NUL/non-backslash output alphabet have no actual intersection. Raw package names containing backslashes expose a pre-existing implicit self-coverage limitation and are not silently repaired here.

The count-zero leading-bracket correction does not rewrite [!]] or [^] grammar. Those retain their old dialect, as do other unmodified glob rules. Full gitignore/wildmatch conformance is not claimed. The root separately owns the requirement suites, mutation fail-open validation, build/static gates and final plan status. The independent small checks are not a substitute for those suites.

Historic GAP-085 legacy/user material separation, invalid UTF8 and complete Host/plugin integration boundaries are not closed by this self-rule repair. R12-U1 was not investigated.

## Reproduction

Unpack the fixed tgz archives into separate directories. For each desired host, run `probe.mjs <667-package-root> <667-tgz> <663-package-root>` and `consumer-glob.mjs <667-package-root>`.

For the retained failure run `class-leak-666.mjs <666-package-root> <666-tgz> <663-package-root> --assert-required`. Expected exit is 1 after the raw mismatch and cleanup receipts. Without the flag it only records the mismatch and exits 0; that is not contract acceptance.

`artifact-map.mjs <663-package-root> <667-package-root>` compares all relevant packaged bytes, including bundled library files. `probe-pre-class-fix-prepared-only.mjs` is the earlier unexecuted draft of the acceptance probe before the intentional syntax correction; it is kept as fixture history and is not the final contract.

Related design archive: `gap085-nfa-design-review-evidence-20261019.tgz`, SHA256 `c4a668b486e323209438caff79cf03cdc69da218995af4d89f980c70c3f83324`.
