import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { lstatSync, readdirSync, readFileSync, readlinkSync } from 'node:fs'
import { join, relative, resolve } from 'node:path'

const hash = file => createHash('sha256').update(readFileSync(file)).digest('hex')
const inventory = root => {
  const records = new Map()
  const visit = directory => {
    for (const name of readdirSync(directory).sort()) {
      if (name === 'node_modules') continue
      const file = join(directory, name)
      const info = lstatSync(file)
      if (info.isDirectory()) visit(file)
      else if (info.isSymbolicLink()) records.set(relative(root, file), { symlink: readlinkSync(file) })
      else records.set(relative(root, file), { size: info.size, sha256: hash(file) })
    }
  }
  visit(root)
  return records
}
const compare = (left, right) => {
  const before = inventory(left)
  const after = inventory(right)
  const differences = []
  for (const file of [...new Set([...before.keys(), ...after.keys()])].sort()) {
    if (JSON.stringify(before.get(file)) !== JSON.stringify(after.get(file))) {
      differences.push({ file, before: before.get(file) ?? null, after: after.get(file) ?? null })
    }
  }
  return { beforeCount: before.size, afterCount: after.size, differences }
}
const baseline = resolve(process.argv[2] ?? '/private/tmp/d2-clean-install-663/node_modules/wanxiangshu')
const product = resolve(process.argv[3] ?? '/private/tmp/gap085-clean-install-667/node_modules/wanxiangshu')
const main = compare(baseline, product)
assert.deepEqual(main.differences.filter(row => row.file.endsWith('.js')).map(row => row.file), [
  'dist/Foundation/GlobMatch.js', 'dist/Requirement/Grounding/Catalog.js',
])
const library = compare(join(baseline, 'node_modules/wanxiangli'), join(product, 'node_modules/wanxiangli'))
assert.deepEqual(library.differences, [])
console.log(JSON.stringify({ baseline, product, main, library,
  scope: 'All main package files except nested node_modules, and all nested library files. This is artifact comparison, not retrospective proof of compiler inputs or full runtime equivalence of the two changed modules.' }, null, 2))
