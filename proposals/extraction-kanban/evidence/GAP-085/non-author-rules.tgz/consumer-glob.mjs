import assert from 'node:assert/strict'
import { mkdtempSync, mkdirSync, rmSync, writeFileSync, existsSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const product = resolve(process.argv[2])
const surface = await import(pathToFileURL(join(product, 'dist/Repository/Programming/Js/FilesystemSurface.js')))
const ok = result => { assert.equal(result.ok, true, result.code); return result.value }
const workspace = mkdtempSync('/private/tmp/gap085-glob-owned-')
try {
  for (const directory of ['src/deep', 'other', 'build', '.git/objects']) mkdirSync(join(workspace, directory), { recursive: true })
  for (const file of ['src/]', 'src/a', 'src/|', 'other/file]', 'src/deep/keep.fs', 'build/hidden.fs', '.git/objects/private]']) {
    writeFileSync(join(workspace, file), 'needle ' + file + '\n')
  }
  writeFileSync(join(workspace, '.gitignore'), '/build/\n')
  const bracketMembers = ok(await surface.glob(workspace, '/src/[]a]')).paths
  assert.deepEqual(bracketMembers, ['src/]', 'src/a'])
  const pipeMembers = ok(await surface.glob(workspace, '/src/[]|]')).paths
  assert.deepEqual(pipeMembers, ['src/]', 'src/|'])
  const grep = ok(await surface.grep(workspace, { kind: 'exact', text: 'needle' }, '/src/[]|]')).matches
  assert.deepEqual(grep.map(hit => hit.path), ['src/]', 'src/|'])
  const fsPaths = ok(await surface.glob(workspace, '**/*.fs')).paths
  assert.deepEqual(fsPaths, ['src/deep/keep.fs'])
  writeFileSync(join(workspace, '.gitignore'), '/build/\n/src/[]|]\n')
  const ignoredMembers = ok(await surface.glob(workspace, '/src/[]|]')).paths
  assert.deepEqual(ignoredMembers, [])
  const surviving = ok(await surface.glob(workspace, '**/*')).paths
  assert.ok(surviving.includes('other/file]'), 'A corrected ignore class must not leak outside src')
  assert.ok(surviving.includes('src/a'))
  assert.ok(!surviving.includes('src/]'))
  assert.ok(!surviving.includes('src/|'))
  assert.ok(!surviving.some(path => path.startsWith('.git/') || path.startsWith('build/')))
  console.log(JSON.stringify({ runtime: process.versions.bun ? `Bun ${process.versions.bun}` : process.version,
    product, bracketMembers, pipeMembers, grep, fsPaths, ignoredMembers, surviving,
    scope: 'Actual installed FilesystemSurface glob, grep candidate selection and gitignore consumer of the shared compiler. No custom matcher or second glob parser.' }, null, 2))
} finally {
  rmSync(workspace, { recursive: true, force: true })
  console.log(JSON.stringify({ ownedWorkspaceRemoved: !existsSync(workspace) }))
}
