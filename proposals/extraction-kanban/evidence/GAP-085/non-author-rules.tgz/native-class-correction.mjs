import assert from 'node:assert/strict'

const cases = [
  { source: '[\\]a]', members: [']', 'a'], nonmembers: ['|', 'b'] },
  { source: '[\\]|]', members: [']', '|'], nonmembers: ['a', 'b'] },
  { source: '[\\]]', members: [']'], nonmembers: ['a', '|'] },
  { source: '[^a]', members: [']', '|', 'b', '\n'], nonmembers: ['a'] },
  { source: '[^\\]]', members: ['a', '|', '\n'], nonmembers: [']'] },
]
const records = []
for (const { source, members, nonmembers } of cases) {
  const single = new RegExp('^' + source + '$')
  for (const character of members) assert.equal(single.test(character), true)
  for (const character of nonmembers) assert.equal(single.test(character), false)
  const combined = new RegExp('^src/' + source + '$')
  assert.equal(combined.test('requirements/alpha/future]'), false)
  assert.equal(combined.test('requirements/alpha/a]'), false)
  records.push({ source, members, nonmembers, disjointPrefixLeak: false })
}
assert.throws(() => new RegExp('[z-a]'))
console.log(JSON.stringify({ runtime: process.versions.bun ? `Bun ${process.versions.bun}` : process.version,
  records,
  scope: 'Native JS regex proof for the proposed corrected class fragment only. This does not implement a glob lexer or accept a future production candidate; malformed glob syntax remains owned by the common lexer.' }, null, 2))
