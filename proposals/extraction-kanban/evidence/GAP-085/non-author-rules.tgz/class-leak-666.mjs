import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { mkdtempSync, mkdirSync, readFileSync, rmSync, writeFileSync, existsSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const product = resolve(process.argv[2] ?? '/private/tmp/gap085-candidate-review.WRQQJQ/unpacked/package')
const archive = resolve(process.argv[3] ?? '/private/tmp/gap085-candidate-666/wanxiangshu-0.9.0.tgz')
const baseline = resolve(process.argv[4] && !process.argv[4].startsWith('--') ? process.argv[4] : '/private/tmp/d2-clean-install-663/node_modules/wanxiangshu')
const glob = await import(pathToFileURL(join(product, 'dist/Foundation/GlobMatch.js')))
const old = await import(pathToFileURL(join(baseline, 'dist/Foundation/GlobMatch.js')))
const grounding = await import(pathToFileURL(join(product, 'dist/Requirement/Grounding/Surface.js')))
const ok = result => { assert.equal(result.tag, 0); return result.fields[0] }
const cases = [
  ['/src/[]|]', 'requirements/alpha/future]'],
  ['/requirements/alpha/[]|a]', 'requirements/alpha/a]'],
  ['/src/[]|a]', 'requirements/alpha/a]'],
]
const records = []
for (const [pattern, witness] of cases) {
  const oldMatch = ok(old.matchesPathPattern(pattern, witness))
  const actualMatch = ok(glob.matchesPathPattern(pattern, witness))
  const actualSubtree = ok(glob.mayMatchSubtree(pattern, 'requirements/alpha'))
  assert.equal(oldMatch, true)
  assert.equal(actualMatch, true)
  assert.equal(actualSubtree, false, 'This receipt preserves the confirmed 666 mismatch, not acceptance of that behavior')
  records.push({ pattern, witness, regexSource: ok(glob.compilePattern(pattern)).source,
    oldMatch, actualMatch, actualSubtree, requiredSubtree: true })
}
const workspace = mkdtempSync('/private/tmp/gap085-class-leak-owned-')
try {
  const root = join(workspace, 'requirements/alpha')
  mkdirSync(root, { recursive: true })
  writeFileSync(join(root, 'WHAT.md'), '# alpha\n')
  for (const [pattern] of cases) {
    writeFileSync(join(root, 'APPLIES-TO'), pattern + '\n')
    assert.deepEqual(grounding.discoverPackages(workspace), ['alpha'])
  }
  console.log(JSON.stringify({ runtime: process.versions.bun ? `Bun ${process.versions.bun}` : process.version,
    product, archive, archiveSha256: createHash('sha256').update(readFileSync(archive)).digest('hex'), records,
    actualCatalog: 'All three rules are accepted in 666 although the actual matcher covers alpha paths',
    classification: 'Existing class-to-regex leakage; new subtree query fails to represent it. A GAP-085 closure blocker, not a change to ordinary matchesPathPattern behavior.' }, null, 2))
} finally {
  rmSync(workspace, { recursive: true, force: true })
  console.log(JSON.stringify({ ownedWorkspaceRemoved: !existsSync(workspace) }))
}
if (process.argv.includes('--assert-required')) {
  for (const row of records) {
    assert.equal(row.actualSubtree, row.requiredSubtree, row.pattern + ' must account for its actual own-path witness')
  }
}
