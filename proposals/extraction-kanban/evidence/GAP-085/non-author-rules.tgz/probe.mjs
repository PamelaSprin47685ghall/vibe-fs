import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { mkdtempSync, mkdirSync, readFileSync, rmSync, writeFileSync, existsSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const product = resolve(process.argv[2])
const archive = resolve(process.argv[3])
const baseline = resolve(process.argv[4] ?? '/private/tmp/d2-clean-install-663/node_modules/wanxiangshu')
const hash = file => createHash('sha256').update(readFileSync(file)).digest('hex')
const fixed = Object.fromEntries([archive, join(product, 'dist/Foundation/GlobMatch.js'),
  join(product, 'dist/Requirement/Grounding/Catalog.js'), join(product, 'dist/Requirement/Grounding/Surface.js')]
  .map(file => [file, hash(file)]))
const glob = await import(pathToFileURL(join(product, 'dist/Foundation/GlobMatch.js')))
const old = await import(pathToFileURL(join(baseline, 'dist/Foundation/GlobMatch.js')))
const grounding = await import(pathToFileURL(join(product, 'dist/Requirement/Grounding/Surface.js')))
const ok = result => { assert.equal(result.tag, 0); return result.fields[0] }
const groups = []

const patterns = ['*.fs', '/src/**/*.fs', '?', '**/', '***', '****/', '[!]', '[!]]', '[^]', '[\\]',
  '[/]', '[^/]', '[a-z]', '/requirements/😀/**', 'a/**/b', '/a/***/b', '/a/[!x]/*', '/requirements/**/[!a]']
const paths = ['', 'a', '/', 'requirements/alpha/', 'requirements/alpha/.', 'requirements/alpha/test.fs',
  'requirements/😀', 'requirements/😀/x', 'src\n/a.fs', 'x\n', 'x\ud800', '\\', 'a/\n/b']
for (const pattern of patterns) {
  assert.equal(ok(glob.compilePattern(pattern)).source, ok(old.compilePattern(pattern)).source, pattern)
  for (const path of paths) {
    assert.equal(ok(glob.matchesPathPattern(pattern, path)), ok(old.matchesPathPattern(pattern, path)), `${pattern} @ ${path}`)
  }
}
groups.push({ name: 'existing regex compilation and actual path matches preserved', patterns: patterns.length, pathPairs: patterns.length * paths.length })

const alpha = 'requirements/alpha'
const examples = [
  ['/requirements/alpha', alpha, true, alpha],
  ['/requirements/alpha/', alpha, true, alpha + '/'],
  ['/requirements/alpha/.', alpha, true, alpha + '/.'],
  ['/requirements/alpha/..', alpha, true, alpha + '/..'],
  ['/requirements/alpha//', alpha, true, alpha + '//'],
  ['/requirements/alpha/a/', alpha, true, alpha + '/a/'],
  ['/requirements/alpha/tests/**', alpha, true, alpha + '/tests/future.fs'],
  ['/requirements/al**/pha/**', alpha, true, alpha + '/future.fs'],
  ['/requirements/al**/a/**', alpha, true, alpha + '/a/future.fs'],
  ['**/*.fs', alpha, true, alpha + '/future.fs'],
  ['*.fs', alpha, true, alpha + '/future.fs'],
  ['/requirements/alpha/[!]', alpha, true, alpha + '/x'],
  ['/requirements/alpha/[\n]', alpha, true, alpha + '/\n'],
  ['/requirements/alpha/[\\]', alpha, false],
  ['/requirements/alpha/[\u0000]', alpha, false],
  ['/requirements/alpha-old/**', alpha, false],
  ['/requirements/beta/**', alpha, false],
  ['/requirements/zz**/a/**', alpha, false],
  ['/src/Wanxiangshu/**/*Surface.fs', alpha, false],
  ['/requirements/?', 'requirements/😀', false],
  ['/requirements/??', 'requirements/😀', true, 'requirements/😀'],
  ['/requirements/[😀]', 'requirements/😀', false],
  ['/requirements/[😀][😀]', 'requirements/😀', true, 'requirements/😀'],
  ['/requirements/😀', 'requirements/😀', true, 'requirements/😀'],
  ['/requirements/**/[!a]', 'requirements/x\n', false],
  ['/requirements/***/[!a]', 'requirements/x\n', true, 'requirements/x\n/x'],
  ['/requirements/[\\]/**', 'requirements/\\', false],
]
const subtreeRecords = []
for (const [pattern, directory, expected, witness] of examples) {
  if (witness !== undefined) {
    assert.ok(witness === directory || witness.startsWith(directory + '/'))
    assert.equal(ok(old.matchesPathPattern(pattern, witness)), true, 'A positive witness must be accepted by the unchanged actual matcher')
  }
  const actual = ok(glob.mayMatchSubtree(pattern, directory))
  assert.equal(actual, expected, `${pattern} overlaps ${JSON.stringify(directory)}`)
  subtreeRecords.push({ pattern, directory, actual, witness: witness ?? null })
}
groups.push({ name: 'known subtree witnesses and disjoint or impossible-language controls', cases: subtreeRecords })

const correctedClasses = [
  { pattern: '/src/[]a]', source: '^src/[\\]a]$', accepted: ['src/a', 'src/]'], rejected: ['src/|'], self: false },
  { pattern: '/src/[]]', source: '^src/[\\]]$', accepted: ['src/]'], rejected: ['src/a'], self: false },
  { pattern: '/src/[]|]', source: '^src/[\\]|]$', accepted: ['src/]', 'src/|'], rejected: ['src/a]'], self: false },
  { pattern: '/src/[]|a]', source: '^src/[\\]|a]$', accepted: ['src/]', 'src/|', 'src/a'], rejected: ['src/a]'], self: false },
  { pattern: '/requirements/alpha/[]a]', source: '^requirements/alpha/[\\]a]$',
    accepted: [alpha + '/a', alpha + '/]'], rejected: [alpha + '/a]'], self: true },
  { pattern: '/requirements/alpha/[]|a]', source: '^requirements/alpha/[\\]|a]$',
    accepted: [alpha + '/a', alpha + '/]', alpha + '/|'], rejected: [alpha + '/a]'], self: true },
]
for (const { pattern, source, accepted, rejected, self } of correctedClasses) {
  assert.equal(ok(glob.compilePattern(pattern)).source, new RegExp(source).source)
  for (const path of accepted) assert.equal(ok(glob.matchesPathPattern(pattern, path)), true)
  for (const path of rejected) assert.equal(ok(glob.matchesPathPattern(pattern, path)), false)
  assert.equal(ok(glob.mayMatchSubtree(pattern, alpha)), self)
}
for (const pattern of ['/src/[]|]', '/src/[]|a]']) {
  assert.equal(ok(old.matchesPathPattern(pattern, alpha + '/a]')), true, 'The old full regex leak is preserved as a historical control')
  assert.equal(ok(glob.matchesPathPattern(pattern, alpha + '/a]')), false, 'The corrected class must not escape its src prefix')
}
groups.push({ name: 'intentional leading-close-bracket class correction and no outer regex leakage', cases: correctedClasses })

for (const pattern of ['', '/', '[', '*[', '[]', '[]a']) {
  assert.equal(glob.compilePattern(pattern).tag, 1)
  assert.equal(glob.mayMatchSubtree(pattern, alpha).tag, 1)
}
assert.throws(() => old.compilePattern('[z-a]'))
assert.throws(() => glob.compilePattern('[z-a]'))
assert.throws(() => glob.mayMatchSubtree('[z-a]', alpha))
groups.push({ name: 'malformed patterns retain errors instead of false or normal self absence' })

const workspace = mkdtempSync('/private/tmp/gap085-candidate-owned-')
try {
  const root = join(workspace, alpha)
  mkdirSync(root, { recursive: true })
  writeFileSync(join(root, 'WHAT.md'), '# alpha\n')
  const rules = ['/requirements/alpha/', '/requirements/alpha/.', '/requirements/alpha/..',
    '/requirements/alpha//', '/requirements/al**/a/**', '**/*.fs', '*.fs',
    '/requirements/alpha/[]a]', '/requirements/alpha/[]|a]']
  for (const pattern of rules) {
    for (const prefix of ['', '!']) {
      writeFileSync(join(root, 'APPLIES-TO'), prefix + pattern + '\n')
      assert.throws(() => grounding.discoverPackages(workspace), /must not declare package self coverage/)
    }
  }
  for (const pattern of ['/requirements/alpha/[\\]', '/requirements/zz**/a/**', '/src/**/*.fs', '/requirements/alpha-old/**', '/src/[]|]']) {
    writeFileSync(join(root, 'APPLIES-TO'), pattern + '\n')
    assert.deepEqual(grounding.discoverPackages(workspace), ['alpha'])
  }
  assert.equal(existsSync(join(root, 'future.fs')), false)
  groups.push({ name: 'actual Catalog rejects both declaration signs before future files exist and accepts legal disjoint rules' })
  for (const [file, expected] of Object.entries(fixed)) assert.equal(hash(file), expected)
  console.log(JSON.stringify({ runtime: process.versions.bun ? `Bun ${process.versions.bun}` : process.version,
    product, fixed, groups,
    scope: 'Independent bounded installed-package review. Positive cases use the old actual regex as a witness check; no second lexer, NFA, future-file scan or general glob oracle was implemented.' }, null, 2))
} finally {
  rmSync(workspace, { recursive: true, force: true })
  console.log(JSON.stringify({ ownedWorkspaceRemoved: !existsSync(workspace) }))
}
