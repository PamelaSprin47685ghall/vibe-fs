# GAP-085 subtree-query design review

Read-only non-author design review. The proposed subtree query has not been implemented or tested by this agent. No shared source or plan was changed. These small probes use the fixed installed 663 package, Node 26.6.0 and Bun 1.3.14 on macOS.

Fixed main archive: `wanxiangshu-0.9.0-663.tgz`, SHA256 `3c0afec4f5aee947cff92a5a2e633a41d4e9728daa515f27295e634ed9b324e0`.

## Recommended minimal contract

The root decided to retain Catalog's current path-string semantics rather than migrate physical path interpretation in this package. The query should ask whether the existing glob language intersects the current implicit self-match domain: exact `directory`, or `directory + '/' + suffix`, where suffix may be empty and may contain dot, dot-dot, repeated or trailing separators. Suffix characters exclude NUL and literal backslash because Catalog's slash replacement does not emit them.

This matches current `selfMatch`, which accepts exact directory or any string starting with directory plus slash. There is no nonempty-suffix check in that function. Do not call path.resolve on patterns and do not restrict the query to current files.

One private lexer should continue to own the current normalization and tokens. Existing compilation produces the same no-flags native RegExp. The subtree query builds a small NFA from those tokens, consumes the fixed directory, checks exact acceptance, consumes slash, then does finite visited-state reachability along epsilon edges or character edges with a nonempty intersection with the suffix alphabet. Since any suffix over that alphabet is permitted, no segment DFA or product automaton is needed. A reachable path supplies one allowed character per consuming edge; their concatenation remains in the permitted suffix language.

DoubleStarSlash needs a separate entry and wildcard state. Entry may skip the whole token or enter the wildcard state. The wildcard state may consume dot-matching characters, and may exit only by consuming slash. Letting that state epsilon-exit would incorrectly accept xleaf for **/leaf.

Do not merge adjacent star tokens. The current lexer gives different languages to **/leaf and ***/leaf: the former's dot loop does not consume LF, while the latter's final single-star loop can consume LF before slash. Preserve bare-pattern implicit **/, leading-slash normalization, character-class construction, and malformed-class error behavior. A failed class compilation must not silently mean no intersection.

## Actual path-domain evidence

`normalized-domain.mjs` created only owned temporary workspaces and real POSIX filenames under alpha. On Node, filename `.\\x` becomes lexical `requirements/alpha/./x` after Catalog's replacement; `..\\x`, `a\\\\b`, and `a\\` similarly produce dot-dot, empty, and trailing segments. Another package's exact rules for those strings really match the file. This disproves the initial assumption that realpath plus current slash replacement has already removed those segments. Both owned workspaces were removed.

`alias-domain.mjs` also created real files at the workspace root with backslash-containing filenames corresponding to `requirements/alpha/`, `requirements/alpha/.`, `requirements/alpha/..`, and further repeated/trailing segments. On Node, native realpath retains those valid filenames, Catalog maps them to those exact lexical strings, and both alpha selfMatch and beta's exact external rule match. Thus empty suffix, exact dot and exact dot-dot are not hypothetical false positives under the current consumer. They are already part of the implicit lexical self domain.

Bun's actual realpath observations differ: it can normalize literal backslashes as separators or return ENOENT while existsSync reports that filename exists. `bun-domain.log` retains the first assertion failure, and `bun-alias-domain.log` records native realpath and resolve results without pretending they equal Node. This is a pre-existing runtime/path behavior, not a failure of a new subtree implementation. No fallback or path migration was added.

Using all UTF16 suffix characters would overreject old rules that match only literal backslash or NUL, because those characters cannot occur in Catalog's output domain. The proposed restricted alphabet avoids that. Exact src prefixes, other-package prefixes and alpha-old remain disjoint controls. Global **/*.fs and bare *.fs intentionally become invalid for alpha: their future alpha files witness self coverage, even if no such file exists today.

Directory input should have an explicit current-output-domain precondition. Raw package names can theoretically contain POSIX backslashes; current selfMatch constructs its prefix from the raw package name while Catalog normalizes the target path. That pre-existing self-coverage limitation must not be silently repaired by normalizing package names in this package, nor counted as fixed by the query. A fixed directory outside the current output alphabet has no actual intersection with that output image.

## Character-class existence

The existing private class constructor can supply the only character predicate. With no global, Unicode, or anchor flags, a valid single class matches one UTF16 code unit or has empty language. Therefore existence can be computed by an early-exit scan of the allowed UTF16 units, optionally caching repeated classes within one parsed pattern.

An alternative is testing that same unanchored class RegExp against one bounded string containing every allowed UTF16 unit exactly once. For the final suffix alphabet it has 65534 units (all except NUL and backslash). Native RegExp.test then performs the existence search without a second class parser. This is only suitable for a single unanchored class atom; do not test a ^class$ predicate against the whole alphabet string.

`edge-cases.mjs` compares those two methods for ten classes including only slash, dot, backslash, NUL, newline, an empty class language, a surrogate, and FFFF. Node/Bun agree. Small timings demonstrate feasibility only, not a benchmark or reason to introduce an unbounded global class cache. The earlier segment-DFA alphabet logs are retained as intermediate design evidence; that alphabet excluded dot/slash and is not the final query domain.

## Falsified regex assumption and fixture errors

Both actual runtimes return false for /^x$/ against x followed by LF, CR, CRLF, U+2028 or U+2029. The current no-flags native regex has no final-LF exception. The root withdrew that premise. Do not add a special LF branch or claim it was an existing mismatch.

The first two probe attempts used the wrong representation for Fable Result: first a string tag, then an array element based on its JSON display. The actual object has numeric tag 0 and fields. Those original scripts and logs remain as `*-wrong-result-shape*`; they are reviewer fixture mistakes and are not product failures.

## Reproduction and limits

Run node or bun with `edge-cases.mjs`, `normalized-domain.mjs`, or `alias-domain.mjs`, optionally followed by an installed main package root. The default is the recorded actual 663 install. The contained fixed archive can be unpacked to supply the pure Catalog and GlobMatch modules without changing their bytes.

Only old matcher behavior, real Catalog path-domain witnesses, native class predicates and minimal design were checked. No new NFA implementation, requirement suite, full repository run, performance acceptance, or complete GAP-085 closure is claimed. R12-U1 was not investigated.
