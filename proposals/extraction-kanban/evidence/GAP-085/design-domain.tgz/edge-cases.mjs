import assert from 'node:assert/strict'
import { performance } from 'node:perf_hooks'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const product = resolve(process.argv[2] ?? '/private/tmp/d2-clean-install-663/node_modules/wanxiangshu')
const { matchesPathPattern } = await import(pathToFileURL(join(product, 'dist/Foundation/GlobMatch.js')))

const matched = (pattern, path) => {
  const result = matchesPathPattern(pattern, path)
  assert.equal(result.tag, 0)
  return result.fields[0]
}
const checks = []
for (const [pattern, path, expected] of [
  ['/requirements/alpha/**/leaf', 'requirements/alpha/leaf', true],
  ['/requirements/alpha/**/leaf', 'requirements/alpha/nested/leaf', true],
  ['/requirements/alpha/**/leaf', 'requirements/alpha/xleaf', false],
  ['/requirements/alpha/**/leaf', 'requirements/alpha/\n/leaf', false],
  ['/requirements/alpha/*/leaf', 'requirements/alpha/\n/leaf', true],
  ['/requirements/alpha/***/leaf', 'requirements/alpha/\n/leaf', true],
  ['/requirements/alpha/[\\]', 'requirements/alpha/\\', true],
  ['/requirements/alpha/...', 'requirements/alpha/...', true],
  ['/requirements/alpha/.', 'requirements/alpha/.\n', false],
  ['/requirements/alpha/..', 'requirements/alpha/..\r\n', false],
]) {
  const actual = matched(pattern, path)
  assert.equal(actual, expected)
  checks.push({ pattern, path, actual })
}
const endAnchors = ['\n', '\r', '\r\n', '\u2028', '\u2029'].map(suffix => ({
  suffix, actual: /^x$/.test('x' + suffix),
}))
assert.ok(endAnchors.every(row => row.actual === false))

// This is an existence query on a shared native class predicate, not a glob parser.
const allowed = code => code !== 0 && code !== 92
const universe = Array.from({ length: 65536 }, (_, code) => allowed(code) ? String.fromCharCode(code) : '').join('')
assert.equal(universe.length, 65534)
const classSources = ['[.]', '[/]', '[\\\\]', '[\u0000]', '[\n]', '[a-z]', '[^]', '[]a]', '[\ud800]', '[\uffff]']
const classes = []
for (const source of classSources) {
  const predicate = new RegExp(source)
  const startLoop = performance.now()
  let loop = false
  let checked = 0
  for (let code = 0; code < 65536; code++) {
    if (allowed(code)) {
      checked++
      if (predicate.test(String.fromCharCode(code))) {
        loop = true
        break
      }
    }
  }
  const loopMilliseconds = performance.now() - startLoop
  const startUniverse = performance.now()
  const onUniverse = predicate.test(universe)
  const universeMilliseconds = performance.now() - startUniverse
  assert.equal(onUniverse, loop)
  classes.push({ source, existsOther: loop, checked, loopMilliseconds, universeMilliseconds })
}
console.log(JSON.stringify({ runtime: process.versions.bun ? `Bun ${process.versions.bun}` : process.version,
  checks, endAnchors, classes,
  scope: 'Current installed glob and native class predicates only. No NFA or subtree query is implemented or accepted here. Timing is a small feasibility sample, not a benchmark.' }, null, 2))
