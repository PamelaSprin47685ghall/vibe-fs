import assert from 'node:assert/strict'
import { mkdtempSync, mkdirSync, rmSync, writeFileSync, existsSync, realpathSync } from 'node:fs'
import { join, relative, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const product = resolve(process.argv[2] ?? '/private/tmp/d2-clean-install-663/node_modules/wanxiangshu')
const { discoverPackages, resolvePackages } = await import(pathToFileURL(join(product, 'dist/Requirement/Grounding/Surface.js')))

const workspace = mkdtempSync('/private/tmp/gap085-alias-owned-')
try {
  for (const name of ['alpha', 'beta']) {
    const root = join(workspace, 'requirements', name)
    mkdirSync(root, { recursive: true })
    writeFileSync(join(root, 'WHAT.md'), '# requirement\n')
  }
  const records = []
  for (const suffix of ['', '.', '..', 'a//b', 'a/']) {
    const lexical = 'requirements/alpha/' + suffix
    const filename = lexical.replaceAll('/', '\\')
    const file = join(workspace, filename)
    writeFileSync(file, 'actual workspace-root POSIX filename\n')
    const pattern = '/' + lexical
    writeFileSync(join(workspace, 'requirements/beta/APPLIES-TO'), pattern + '\n')
    assert.deepEqual(discoverPackages(workspace), ['alpha', 'beta'])
    let actualRealpath = null
    let realpathError = null
    try { actualRealpath = realpathSync(file) }
    catch (error) { realpathError = { code: error.code, message: error.message } }
    const packages = resolvePackages(workspace, file)
    if (!process.versions.bun) assert.deepEqual(packages, ['alpha', 'beta'])
    records.push({ suffix, lexical, filename, exists: existsSync(file), actualRealpath, realpathError,
      normalizedRealpath: actualRealpath && relative(workspace, actualRealpath).replaceAll('\\', '/'), packages })
  }
  console.log(JSON.stringify({ runtime: process.versions.bun ? `Bun ${process.versions.bun}` : process.version,
    records, scope: 'Actual installed Catalog self-prefix alias image. No NFA or subtree query implementation.' }, null, 2))
} finally {
  rmSync(workspace, { recursive: true, force: true })
  console.log(JSON.stringify({ ownedWorkspaceRemoved: !existsSync(workspace) }))
}
