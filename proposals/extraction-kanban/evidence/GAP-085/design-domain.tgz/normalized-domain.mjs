import assert from 'node:assert/strict'
import { mkdtempSync, mkdirSync, rmSync, writeFileSync, existsSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const product = resolve(process.argv[2] ?? '/private/tmp/d2-clean-install-663/node_modules/wanxiangshu')
const { discoverPackages, resolvePackages } = await import(pathToFileURL(join(product, 'dist/Requirement/Grounding/Surface.js')))

const workspace = mkdtempSync('/private/tmp/gap085-domain-owned-')
try {
  const alpha = join(workspace, 'requirements/alpha')
  const beta = join(workspace, 'requirements/beta')
  for (const directory of [alpha, beta]) {
    mkdirSync(directory, { recursive: true })
    writeFileSync(join(directory, 'WHAT.md'), '# requirement\n')
  }
  const records = []
  for (const [filename, spelling] of [
    ['.\\x', './x'],
    ['..\\x', '../x'],
    ['a\\\\b', 'a//b'],
    ['a\\', 'a/'],
  ]) {
    writeFileSync(join(alpha, filename), 'actual POSIX filename\n')
    const pattern = `/requirements/alpha/${spelling}`
    writeFileSync(join(beta, 'APPLIES-TO'), pattern + '\n')
    assert.deepEqual(discoverPackages(workspace), ['alpha', 'beta'])
    const packages = resolvePackages(workspace, join(alpha, filename))
    assert.deepEqual(packages, ['alpha', 'beta'])
    records.push({ filename, pattern, packages,
      observation: 'An actual canonical realpath can gain dot, empty, or trailing segments after Catalog replaces literal POSIX backslashes with slashes.' })
  }
  console.log(JSON.stringify({ runtime: process.versions.bun ? `Bun ${process.versions.bun}` : process.version,
    records, scope: 'Actual installed Catalog path normalization only, without a proposed subtree query implementation.' }, null, 2))
} finally {
  rmSync(workspace, { recursive: true, force: true })
  console.log(JSON.stringify({ ownedWorkspaceRemoved: !existsSync(workspace) }))
}
