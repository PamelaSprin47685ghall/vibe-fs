const fs = require('node:fs')
const path = require('node:path')
const cp = require('node:child_process')
const { EventEmitter } = require('node:events')
const { syncBuiltinESMExports } = require('node:module')
const context = JSON.parse(fs.readFileSync(path.join(__dirname, 'context.json'), 'utf8'))
const processRoot = path.join(context.evidence, `pid-${process.pid}`)
fs.mkdirSync(processRoot, { recursive: true, mode: 0o700 })
let sequence = 0
const streams = new WeakMap()
const children = new WeakMap()
const save = (file, value) => fs.writeFileSync(path.join(processRoot, file), JSON.stringify(value, null, 2), { mode: 0o600 })
save('process.json', { pid: process.pid, ppid: process.ppid, argv: process.argv, execArgv: process.execArgv, executable: process.execPath, cwd: process.cwd(), env: process.env, versions: process.versions })
const rawEmit = EventEmitter.prototype.emit
EventEmitter.prototype.emit = function (event, ...args) {
  const output = streams.get(this)
  if (output && event === 'data') {
    const value = typeof args[0] === 'string' ? Buffer.from(args[0]) : args[0]
    fs.appendFileSync(output, value, { mode: 0o600 })
  }
  const child = children.get(this)
  if (child && event === 'message') fs.appendFileSync(path.join(processRoot, `${child}.ipc.jsonl`), JSON.stringify(args[0]) + '\n', { mode: 0o600 })
  return Reflect.apply(rawEmit, this, [event, ...args])
}
const environment = pairs => pairs ? Object.fromEntries(pairs.map(pair => {
  const at = pair.indexOf('=')
  return [pair.slice(0, at), pair.slice(at + 1)]
})) : process.env
const rawSpawn = cp.ChildProcess.prototype.spawn
cp.ChildProcess.prototype.spawn = function (options) {
  const id = `spawn-${++sequence}`
  const originalArgs = Array.from(options.args ?? [])
  const cwd = options.cwd ? String(options.cwd) : process.cwd()
  const fixture = originalArgs.some(arg => typeof arg === 'string' && arg.endsWith('.mjs') && path.resolve(cwd, arg).startsWith(context.canary + path.sep + 'requirements' + path.sep))
  const executable = path.basename(String(options.file))
  if (fixture && /^(node|bun)$/.test(executable) && !originalArgs.includes(__filename)) {
    options = { ...options, args: [originalArgs[0], executable === 'bun' ? '--preload' : '--require', __filename, ...originalArgs.slice(1)] }
  }
  save(`${id}.start.json`, { caller: process.pid, executable: options.file, originalArgs, effectiveArgs: options.args, cwd, env: environment(options.envPairs), fixture, observation: 'passive existing data and IPC events; no added stream consumer' })
  const result = Reflect.apply(rawSpawn, this, [options])
  children.set(this, id)
  for (const channel of ['stdout', 'stderr']) {
    const file = path.join(processRoot, `${id}.${channel}`)
    fs.writeFileSync(file, '', { mode: 0o600 })
    if (this[channel]) streams.set(this[channel], file)
  }
  this.once('spawn', () => save(`${id}.spawn.json`, { pid: this.pid }))
  this.once('error', error => save(`${id}.error.json`, { message: error.message, code: error.code, stack: error.stack }))
  this.once('exit', (code, signal) => save(`${id}.exit.json`, { pid: this.pid, code, signal }))
  this.once('close', (code, signal) => save(`${id}.close.json`, { pid: this.pid, code, signal, stdoutAvailable: !!this.stdout, stderrAvailable: !!this.stderr }))
  return result
}
for (const name of ['spawnSync', 'execFileSync', 'execSync']) {
  const original = cp[name]
  cp[name] = function (...args) {
    const id = `${name}-${++sequence}`
    const options = args.find(value => value && typeof value === 'object' && !Array.isArray(value)) ?? {}
    save(`${id}.start.json`, { caller: process.pid, command: args[0], args: Array.isArray(args[1]) ? args[1] : [], cwd: options.cwd ?? process.cwd(), env: options.env ?? process.env })
    try {
      const result = Reflect.apply(original, this, args)
      if (name === 'spawnSync') {
        fs.writeFileSync(path.join(processRoot, `${id}.stdout`), result.stdout ?? '', { mode: 0o600 })
        fs.writeFileSync(path.join(processRoot, `${id}.stderr`), result.stderr ?? '', { mode: 0o600 })
        save(`${id}.close.json`, { status: result.status, signal: result.signal, error: result.error?.message })
      } else {
        fs.writeFileSync(path.join(processRoot, `${id}.stdout`), result ?? '', { mode: 0o600 })
        save(`${id}.close.json`, { status: 0, stderrAvailable: false, note: 'successful sync API does not expose stderr' })
      }
      return result
    } catch (error) {
      fs.writeFileSync(path.join(processRoot, `${id}.stdout`), error.stdout ?? '', { mode: 0o600 })
      fs.writeFileSync(path.join(processRoot, `${id}.stderr`), error.stderr ?? '', { mode: 0o600 })
      save(`${id}.close.json`, { status: error.status, signal: error.signal, message: error.message })
      throw error
    }
  }
}
syncBuiltinESMExports()
