import assert from 'node:assert/strict'
import { execFileSync, spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { cpSync, existsSync, lstatSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, symlinkSync } from 'node:fs'
import { join, relative } from 'node:path'
import { deriveExpectedClosure, runExternalConsumer, validateArtifact } from '/Users/yuanxi/Workwork/vibe-fs/scripts/verify-package.mjs'

const repository = '/Users/yuanxi/Workwork/vibe-fs'
const archive = join(repository, '.fable-build/verify-logs/package/wanxiangshu-0.9.0.tgz')
const digest = path => createHash('sha256').update(readFileSync(path)).digest('hex')
const expected = '6cc27a69236fa29da2012fbec29ae448d278da27eb859bfb69ad327b5fda7762'
assert.equal(digest(archive), expected)
const checked = await validateArtifact(archive, deriveExpectedClosure({ root: repository }))
assert.equal(checked.ok, true, JSON.stringify(checked.issues))
const directory = mkdtempSync('/private/tmp/process-r7-main-package-')
const files = root => {
  const result = {}
  const visit = path => {
    for (const name of readdirSync(path).sort()) {
      const file = join(path, name)
      const info = lstatSync(file)
      assert.equal(info.isSymbolicLink(), false)
      if (info.isDirectory()) visit(file)
      else result[relative(root, file)] = digest(file)
    }
  }
  visit(root)
  return result
}
try {
  execFileSync('tar', ['-xzf', archive, '-C', directory])
  await runExternalConsumer({ root: repository, tarballPath: archive, extractedPackageDir: join(directory, 'package'), scratchDir: directory })
  const installed = join(directory, 'runtime-root/node_modules/wanxiangshu')
  assert.equal(JSON.parse(readFileSync(join(installed, 'node_modules/wanxiangli/package.json'))).version, '0.6.7')
  assert.equal(existsSync(join(directory, 'runtime-root/node_modules/wanxiangli')), false)
  const before = files(installed)
  const canary = join(directory, 'runtime-root/canary')
  mkdirSync(canary)
  cpSync(join(repository, 'requirements'), join(canary, 'requirements'), { recursive: true })
  cpSync(join(repository, 'scripts'), join(canary, 'scripts'), { recursive: true })
  symlinkSync(join(installed, 'dist'), join(canary, 'dist'), 'dir')
  mkdirSync(join(canary, 'node_modules'))
  symlinkSync(join(installed, 'node_modules/wanxiangli'), join(canary, 'node_modules/wanxiangli'), 'dir')
  cpSync(join(repository, 'node_modules/smol-toml'), join(canary, 'node_modules/smol-toml'), { recursive: true })
  assert.equal(JSON.parse(readFileSync(join(canary, 'node_modules/smol-toml/package.json'))).version, '1.8.0')
  const home = join(directory, 'home')
  const temporary = join(directory, 'tmp')
  mkdirSync(home, { recursive: true })
  mkdirSync(temporary)
  const env = { PATH: process.env.PATH, HOME: home, USERPROFILE: home, TMPDIR: temporary, WANXIANGSHU_PROVIDER_LANGUAGE: 'en', WANXIANGSHU_NO_FATAL_EXIT: '1' }
  for (const runtime of [process.execPath, '/opt/homebrew/bin/bun']) {
    const arguments_ = runtime === process.execPath ? ['--test'] : ['test']
    const output = execFileSync(runtime, [...arguments_, 'requirements/process-execution/tests/011.test.mjs', 'requirements/process-execution/tests/014.test.mjs'], { cwd: canary, env, encoding: 'utf8', timeout: 90000, maxBuffer: 4 * 1024 * 1024, stdio: ['ignore', 'pipe', 'pipe'] })
    process.stdout.write(output)
    console.log(JSON.stringify({ installedRuntime: runtime, boundedRunAndWire: true }))
  }
  for (let repeat = 0; repeat < 5; repeat++) {
    const output = spawnSync('/opt/homebrew/bin/bun', ['test', '--test-name-pattern', 'capture_spools_every_byte', 'requirements/process-execution/tests/009.test.mjs'], { cwd: canary, env, encoding: 'utf8', timeout: 45000, maxBuffer: 4 * 1024 * 1024 })
    assert.ifError(output.error)
    assert.equal(output.status, 0, output.stdout + output.stderr)
    assert.match(output.stderr, /\b1 pass\b/)
    assert.match(output.stderr, /\b0 fail\b/)
    process.stdout.write(output.stdout + output.stderr)
    console.log(JSON.stringify({ installedBun128MiBSpoolRepeat: repeat + 1, completeBytesAndHash: true }))
  }
  if (!process.argv.includes('--large-only')) {
    const arguments_ = process.argv.includes('--pty-local-only')
      ? ['--test', '--test-name-pattern=local late-not-started.*\\(bun\\)', 'requirements/managed-session-lifecycle/tests/025.test.mjs']
      : ['--test', 'requirements/managed-session-lifecycle/tests/025.test.mjs']
    const output = execFileSync(process.execPath, arguments_, { cwd: canary, env, encoding: 'utf8', timeout: 180000, maxBuffer: 8 * 1024 * 1024, stdio: ['ignore', 'pipe', 'inherit'] })
    process.stdout.write(output)
  }
  assert.deepEqual(files(installed), before)
  assert.equal(digest(archive), expected)
  console.log(JSON.stringify({ archiveSha256: expected, installedFiles: Object.keys(before).length, installedBytesUnchanged: true, bundledWanxiangliOnly: true, ptyScope: process.argv.includes('--large-only') ? 'not-run' : process.argv.includes('--pty-local-only') ? 'late-not-started-bun-only' : 'complete-025' }))
} finally {
  rmSync(directory, { recursive: true, force: true })
  assert.equal(existsSync(directory), false)
  console.log(JSON.stringify({ cleaned: directory }))
}
