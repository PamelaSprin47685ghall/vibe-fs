# B2 canonical-frontier precondition: independent review

Confirmed within the stated boundary. No main source or installed product was edited.

The original script was copied byte-for-byte (SHA-256 `a1fddf77a6053dd745104e2fcb5866545efcbc75ff75d3b2d489671cf927f831`) and run once on Node and once on Bun against the fixed clean 706 package. Both scenarios passed on each Host:

- Known writer A writes 50; B writes 60 with parent 50. The actual writer set merges as [50,60]. A then appends 10 with parent 50. The actual physical streams merge as [50,10,60]; the previous canonical order is no longer a prefix. A's original bytes remain unchanged at the beginning of its file.
- A fresh C instead reads the current head 60 and writes 10 with parent 60. The result is [50,60,10], preserving the earlier prefix.

A separate diagnostic copy adds only public store.heads observations. Both Hosts then report A's visible head remains [50] while B sees [60], before the final append. The same ordering results remain. This diagnostic does not alter an assertion or the original script; both complete versions and receipts are retained.

## Input and grouping checks

JobRequested is still explicitly retained in AuthoritativeVocabulary for durable-convergence laws, with no in-tree business producer/consumer. The test is valid at that EventStore protocol boundary, not proof of job business semantics. Every real append returns ok with an empty cuts array. IDs are unique, every parent exists, and the graph is acyclic. Choosing a smaller opaque EventId is a valid ordering boundary; the protocol does not require monotonically increasing EventIds.

The physical grouping is not by business stream: every event's business stream is frontier/law, while merge inputs are separate actual writer files. In this small fixture each writer has exactly one 0000 segment, so file grouping equals logical-writer grouping. The helper must not be generalized to multiple segments without grouping all segments of one writer first. Writer labels only break duplicate ready ties; no duplicate event ID occurs here.

The program imports only the public EventStore Surface and registered MergeSurface. It reads documented canonical event_id fields to identify real stored events, then uses store.read JSON values. It does not inspect Fable union tags/fields, private Journal handles, maps or domain projections. MergeSurface calls the real EventKWayMerge owner, whose ready heap compares EventId and preserves each physical writer's natural order.

## Precise proof scope

This is a counterexample to assuming that an append to an already-known physical writer can always extend a previously materialized canonical prefix. It is expected k-way merge behavior under a newly available lower ready key, not evidence that the merge implementation violates its deterministic ordering contract.

The handles called cold here are newly opened handles within each experiment's OS process. They are not independent writer OS processes. The canonical sequence is obtained through the public MergeSurface over actual physical writer flows; this experiment does not directly observe a business Current fold, budget command correctness, persisted frontier/watermark performance, cross-process admission, Host send ownership or a B2 repair. B2 remains open.

All handles are disposed by the unchanged program. Actual files, stream grouping, parent arrays, append replies and raw receipts are retained. The complete consumed installation is hashed before/after, including its installed dependencies; all 2904 entries remain unchanged. Package 706 SHA-256 is `8572c309c3c5e64011e51972a70058c044b5cfd1478a650a460e64f2de4d2be2`.

## Replay

Install the included exact 706 tar privately, then run `node probe.mjs ABSOLUTE_PRODUCT_ROOT NEW_OUTPUT` or `bun probe.mjs ABSOLUTE_PRODUCT_ROOT NEW_OUTPUT` with a private HOME. heads-observation.mjs is the separate diagnostic. Neither script patches a product module. Only regenerable runtime caches are omitted; their hashes are listed in omissions.json. R12-U1 was not investigated.
