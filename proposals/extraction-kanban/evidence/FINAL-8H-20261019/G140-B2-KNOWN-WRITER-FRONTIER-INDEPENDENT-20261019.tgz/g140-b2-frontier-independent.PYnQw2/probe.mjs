import assert from 'node:assert/strict'
import { mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'
import { createHash } from 'node:crypto'

const [product, output] = process.argv.slice(2)
const store = await import(pathToFileURL(join(product, 'dist/Persistence/EventStore/Surface.js')))
const merge = await import(pathToFileURL(join(product, 'dist/Persistence/EventStore/MergeSurface.js')))
const id = value => value.toString(16).padStart(40, '0')
const event = (value, parents) => ({ id: id(value), stream: 'frontier/law', type: 'JobRequested', parents, payload: { marker: value }, payloadRefs: [] })
const hash = bytes => createHash('sha256').update(bytes).digest('hex')

function physicalStreams(directory, handle) {
  const events = join(directory, 'wanxiangshu/events')
  return readdirSync(events).sort().map(file => [file, readFileSync(join(events, file), 'utf8').trim().split('\n').map(line => {
    const physical = JSON.parse(line)
    const actual = store.read(handle, physical.event_id)
    assert.ok(actual)
    return actual
  })])
}

function observe(directory, reader) {
  const handle = store.create(directory, reader)
  try {
    const streams = physicalStreams(directory, handle)
    const result = merge.merge(streams)
    assert.equal(result.ok, true, JSON.stringify(result))
    return { streams, ids: result.events.map(item => item.id), heads: store.heads(handle, 'frontier/law') }
  } finally {
    store.dispose(handle)
  }
}

async function scenario(name, freshFrontier) {
  const directory = join(output, name)
  mkdirSync(directory, { recursive: true })
  const handles = []
  const first = store.create(directory, 'writer-a')
  handles.push(first)
  try {
    const a = await store.append(first, [event(0x50, [])])
    assert.deepEqual(a, { cuts: [], ok: true })
    const firstFile = join(directory, 'wanxiangshu/events/writer-a-0000.ndjson')
    const originalA = readFileSync(firstFile)
    const second = store.create(directory, 'writer-b')
    handles.push(second)
    const b = await store.append(second, [event(0x60, [id(0x50)])])
    assert.deepEqual(b, { cuts: [], ok: true })
    const before = observe(directory, 'reader-before')
    assert.deepEqual(before.ids, [id(0x50), id(0x60)])
    let writer = first
    let parents = [id(0x50)]
    if (freshFrontier) {
      writer = store.create(directory, 'writer-c')
      handles.push(writer)
      parents = store.heads(writer, 'frontier/law')
      assert.deepEqual(parents, [id(0x60)])
    }
    const appended = await store.append(writer, [event(0x10, parents)])
    assert.deepEqual(appended, { cuts: [], ok: true })
    const after = observe(directory, 'reader-after')
    const oldOrderIsPrefix = before.ids.every((value, index) => after.ids[index] === value)
    assert.equal(oldOrderIsPrefix, freshFrontier)
    assert.deepEqual(after.ids, freshFrontier ? [id(0x50), id(0x60), id(0x10)] : [id(0x50), id(0x10), id(0x60)])
    const finalA = readFileSync(firstFile)
    assert.deepEqual(finalA.subarray(0, originalA.length), originalA)
    if (freshFrontier) assert.deepEqual(finalA, originalA)
    return { name, freshFrontier, before, after, oldOrderIsPrefix, appended, originalAHash: hash(originalA), originalAPrefixUnchanged: true }
  } finally {
    for (const handle of handles) store.dispose(handle)
  }
}

mkdirSync(output, { recursive: true })
const results = [await scenario('known-writer-stale-parent', false), await scenario('fresh-frontier-parent', true)]
const receipt = { runtime: process.version, bun: process.versions.bun ?? null, pid: process.pid, product, boundary: 'real EventStore writers and cold handles; registered MergeSurface; no Journal domain command or Host send', results, handlesDisposed: true, physicalFilesRetained: true }
writeFileSync(join(output, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n')
console.log(JSON.stringify({ runtime: receipt.runtime, bun: receipt.bun, pid: receipt.pid, cases: results.map(item => ({ name: item.name, oldOrderIsPrefix: item.oldOrderIsPrefix, before: item.before.ids, after: item.after.ids })), handlesDisposed: true }))
