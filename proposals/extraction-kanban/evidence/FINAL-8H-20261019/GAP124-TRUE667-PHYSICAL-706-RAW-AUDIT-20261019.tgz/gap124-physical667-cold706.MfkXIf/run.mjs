import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
const root = path.dirname(fileURLToPath(import.meta.url))
const directory = path.join(root, 'physical-store')
const fixture = path.join(root, 'authority-root-v1-inspector.json')
const env = { ...process.env, HOME: path.join(root, 'home'), USERPROFILE: path.join(root, 'home') }
delete env.NODE_TEST_CONTEXT
delete env.NODE_OPTIONS
delete env.WANXIANGSHU_NO_FATAL_EXIT
fs.mkdirSync(directory)
fs.mkdirSync(env.HOME)
const commands = []
async function run(name, product) {
  const args = [path.join(root, 'worker.mjs'), name === '667-seed' ? 'seed' : 'cold', product, directory, fixture, path.join(root, name + '.json')]
  try {
    const actual = await promisify(execFile)(process.execPath, args, { env, cwd: root, timeout: 15000, maxBuffer: 8 * 1024 * 1024 })
    fs.writeFileSync(path.join(root, name + '.stdout.log'), actual.stdout)
    fs.writeFileSync(path.join(root, name + '.stderr.log'), actual.stderr)
    commands.push({ name, executable: process.execPath, args, code: 0 })
    return true
  } catch (error) {
    fs.writeFileSync(path.join(root, name + '.stdout.log'), error.stdout ?? '')
    fs.writeFileSync(path.join(root, name + '.stderr.log'), error.stderr ?? '')
    commands.push({ name, executable: process.execPath, args, code: error.code, signal: error.signal, killed: error.killed, message: error.message })
    return false
  } finally { fs.writeFileSync(path.join(root, 'commands.json'), JSON.stringify(commands, null, 2) + '\n') }
}
if (await run('667-seed', '/private/tmp/gap085-clean-install-667/node_modules/wanxiangshu')) {
  await run('706-cold', '/private/tmp/gap140-B1-surface-independent-706-portable/node_modules/wanxiangshu')
}
console.log(JSON.stringify(commands.map(({ name, code }) => ({ name, code }))))
if (commands.length !== 2 || commands.some(item => item.code !== 0)) process.exitCode = 1
