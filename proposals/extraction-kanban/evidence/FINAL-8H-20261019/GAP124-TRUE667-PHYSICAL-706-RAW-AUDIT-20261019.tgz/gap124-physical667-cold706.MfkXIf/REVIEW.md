# Historical raw audit: actual 667 write, 706 cold read

This experiment corrects an earlier review inference. I had described the interaction-authority/021 first-test failure too broadly as missing historical raw audit reading. The actual new evidence disproves that inference. Raw historical EventStore reading works; the pure legacy FactCodec decoding TODO is a different boundary and is not closed here.

## Actual independent OS operations

1. Fixed 667, Node PID 41177, calls the real EventStore Surface create/append/read/dispose with the exact existing test event. It successfully writes the historical Inspector event and a real Journal ProjectionCutTail. Its append reply explicitly reports that cut; the original historical event remains physically present. No event bytes were manually constructed after append or rewritten.
2. Fixed 706, a new Node process PID 41178, calls real store.create/read/dispose on the same physical directory. It reads the original event exactly, including Inspector, PeerAgent and its original JSON. All physical files and byte hashes remain identical before/after. No file is created for the new reader writer ID.
3. The same unchanged worker, asked to perform that live append with 706 in a separate empty owned directory, retains the original positive assertion and fails: AppendFailed because the Journal cut requires a decodable failed event. It writes no file. This raw red is preserved rather than reclassified as a read failure.

The original full first test also passes on 667; root's original pass log is retained. The prior same-input 697/700 failures remain in their separate baseline archive. The attribution is now precise: the first test's attempt to establish old history through the new live append boundary no longer has the old behavior after the GAP-159 decodable-cut hardening. The raw reader can still audit genuinely existing physical history. This evidence does not authorize an old identity, decode it into an active authority, or claim that the legacy FactCodec TODO passes.

## Immutable physical seed

File: `physical-store/wanxiangshu/events/history-writer-0000.ndjson`.
SHA-256: `2e2e8bd3ba8e30cba169da5b9b8236a6173e8474902ad814dde7051f1c40e6d0`.
It contains exactly two actual 667 records:

- `historical-authority`, JournalEnvelope, stream `authority-history`.
- `09bfb3d939db49c8b52bdd2ab0556855`, ProjectionCutTail, stream `integrator/cut-tail/Journal`, parent and failed_event_id `historical-authority`, rule Journal, reset_json `{}`.

The complete cut reason, original legacy fixture, raw seed bytes, append receipt, cold-read receipt and per-file base64/hash manifests are retained. The seed has no hand-edited timestamp or fabricated journal envelope. The producer directory is preserved after disposal and never deleted by the worker.

## Executable identity

667 tar SHA-256: `b0de9b9770139ae4aa977fae3d8b8d59f2d558cf4ff4a41cf4a1289419743297`.
706 tar SHA-256: `8572c309c3c5e64011e51972a70058c044b5cfd1478a650a460e64f2de4d2be2`.
All 2076 installed files of each consumed product are compared byte-for-byte with its original tar after execution. `package-verification.json` records every file. No source, installed module, fs function or test assertion was patched. Product input, old/new programs and original command arrays are retained. All three handles are disposed, processes exit, and there is no raw-reader write.

## Replay and scope

Install the two exact tars privately with explicit peers @opencode-ai/plugin 1.18.29 and smol-toml 1.8.0. Invoke worker.mjs with `seed OLD_PRODUCT EMPTY_COMMON_DIR FIXTURE RECEIPT`, then in a new OS process invoke it with `cold NEW_PRODUCT THE_SAME_COMMON_DIR FIXTURE OTHER_RECEIPT`. For the negative control, seed with NEW_PRODUCT in a different empty common directory; the unchanged assertion is expected to exit 1 without writing a file.

This is a raw EventStore audit proof only. It does not establish active Journal projection acceptance, current identity execution permission, historical FactCodec decoding, or all of WHAT[interaction-authority-021]. R12-U1 was not investigated. The broader source audit was stopped at root's request after this concrete attribution correction; it is not presented as a completed whole-system review.

Only the duplicate tar extraction directories are omitted from the compact archive. Their complete contents are reproducible from the included exact package tars and their hashes are already recorded in package-verification.json. No physical seed, cut, receipt, program, raw log, original red or pass log is omitted.
