import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
import { createHash } from 'node:crypto'
const [mode, product, directory, fixture, receipt] = process.argv.slice(2)
const store = await import(pathToFileURL(path.join(product, 'dist/Persistence/EventStore/Surface.js')).href)
const historical = fs.readFileSync(fixture, 'utf8').trim()
const event = { id: 'historical-authority', stream: 'authority-history', type: 'JournalEnvelope', parents: [],
  payload: { Fact: JSON.parse(historical) }, payloadRefs: [] }
const result = { mode, product, directory, pid: process.pid, runtime: process.version, event, historical }
function inventory() {
  const rows = []
  function visit(relative = '') {
    if (!fs.existsSync(path.join(directory, relative))) return
    for (const entry of fs.readdirSync(path.join(directory, relative), { withFileTypes: true })) {
      const next = path.join(relative, entry.name)
      if (entry.isDirectory()) visit(next)
      else if (entry.isFile()) {
        const bytes = fs.readFileSync(path.join(directory, next))
        rows.push({ file: next, bytes: bytes.toString('base64'), sha256: createHash('sha256').update(bytes).digest('hex') })
      }
    }
  }
  visit()
  return rows.sort((a, b) => a.file.localeCompare(b.file))
}
result.before = inventory()
let handle
try {
  handle = store.create(directory, mode === 'seed' ? 'history-writer' : '706-cold-raw-audit-reader')
  if (mode === 'seed') {
    result.appended = await store.append(handle, [event])
    assert.equal(result.appended.ok, true, JSON.stringify(result.appended))
  }
  result.actual = store.read(handle, event.id)
  assert.deepEqual(result.actual, event)
  assert.equal(JSON.stringify(result.actual.payload.Fact), historical)
  result.accepted = true
} catch (error) {
  result.accepted = false
  result.error = { name: error.name, message: error.message, stack: error.stack, text: String(error) }
  process.exitCode = 1
} finally {
  if (handle) {
    try { await store.dispose(handle); result.closed = true }
    catch (error) { result.cleanupError = error.message; process.exitCode = 1 }
  }
  result.after = inventory()
  result.originalBytesUnchanged = JSON.stringify(result.before) === JSON.stringify(result.after)
  if (mode === 'cold' && !result.originalBytesUnchanged) {
    result.unexpectedWrite = true
    process.exitCode = 1
  }
  fs.writeFileSync(receipt, JSON.stringify(result, null, 2) + '\n')
}
