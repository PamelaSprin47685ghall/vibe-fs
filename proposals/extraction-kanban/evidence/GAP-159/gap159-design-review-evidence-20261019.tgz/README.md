# GAP-159 read-only contract review

This is a non-author pre-implementation review. No shared source, tests, plan or Git state was edited. No full requirement suite, real Fission tool call, Host session creation or prompt dispatch was run here.

## Frozen baseline observations

`baseline.mjs` imports the actual clean 667 package, archive SHA256 `b0de9b9770139ae4aa977fae3d8b8d59f2d558cf4ff4a41cf4a1289419743297`. Node 26.6.0 and Bun 1.3.14 agree:

- resolveParticipantIdentityAtRoot('predictor') returns selected name predictor, public role engineer, persona Engineer, catalog version 1.
- ManagedAgentConfig generates primary mode, no hidden flag, fission allow, js-engineer allow and exactly the Engineer prompt. The caller's predictor model field is preserved.
- OfficeCapabilitySurface denies every public Predictor permission, and predictor is absent from public role labels.

This confirms an actual identity/configuration inconsistency. It is not proof of actual successful Fission misuse. The probe asserts the old observations to retain them, not as acceptance of the intended office contract.

## Actual source chain

`Participant/Persona/Identity.fs` parseKnownCanonicalName maps predictor to ManagedRole Engineer. `OpenCode/Tools/ManagedAgent.fs` admits any Some Role, so this becomes a Public managed agent. `ManagedAgentConfig.catalogBindings` skips only Bookkeeper, then its role projection selects engineerAgentConfig, which projects Engineer permissions from OfficeCapability. The configuration Surface filters predictor out of its reported bindingNames, but that does not stop the actual projection above.

The same identity owner supplies public HumanRoot seeds. AuthorityExecutionProfile's constructor rejects role=None, currently described as Bookkeeper, while this Predictor evidence has Some Engineer. ToolRuntimeScope.RoleFor reads the durable authority profile, not ctx.agent; its EnsureRoleFor fallback can recover from the actual Host user message. ToolRegistry's OfficeRole gate and the private FissionTool path both accept CanonicalRole Engineer with the static Engineer Fission capability.

Fission still requires a real subsession parent, active authority, an available runtime, valid prompts, no active lane/group, a nonempty canonical WorkRecord and remaining admission conditions. After those gates, CreateSiblingSession uses profile.SelectedAgent, then startLane sends the continuation. Consequently there is a potential ordinary-Predictor path to physical admission, but it must be proved by the real registered tool under ready prerequisites before calling it an executed permission violation.

The real Strength path is different. Strength/Replica/Runtime requires replicaAgent to equal the owner's canonical role label, derives an owner identity seed for that same role, and creates the resident child with that agent. It does not need an ordinary participant named predictor. Model routing purpose readonly-delegate selects the separate Predictor pool without changing identity. ToolRegistry.replicaStage permits only js-predictor for an actually registered replica before ordinary office admission.

## Root's proposed narrow contract

The root proposed a private Predictor ParticipantKind with role=None, label predictor and root persona Predictor. No public Role is added. Public ManagedAgent naturally rejects None; config inventory excludes both internal names, while the Predictor Host slot preserves model, is hidden and denies every tool. Public AuthorityExecutionProfile rejects internal identity. Ordinary readonly replicas continue to inherit owner identity and use the Predictor model pool by purpose.

This addresses the root cause. No necessary supported Strength path depending on a public Predictor-as-Engineer identity was found in the inspected production chain. Do not replace the identity correction with several separate special-case Fission denies.

The following contract edges need exact verification:

1. The existing generic inherited-identity rule should remain: an inherited internal identity, if supported, receives the owner's persona/provenance. Root persona Predictor must not rewrite the real replica's inherited identity.
2. Persona Surface rehydration currently recognizes only bookkeeper as a role=None label. New valid internal Predictor views must round-trip through the public data boundary, while old predictor+Engineer evidence must not be accepted as a new public alias.
3. Root deliberately proposes rejecting old catalog-v1 wrong Predictor Role=Engineer evidence with RoleMismatch, preserving raw bytes and making no inferred migration. That can reject a whole journal/workspace load, not merely one wrong run. A mixed normal-Engineer/old-Predictor cold-load receipt is needed to report the actual refusal grain and avoid claiming unaffected participants always continue.
4. PersonaCatalogVersion 1 and legacy AuthorityRootAccepted schema version 1 are different axes. The older root-upgrade path may fail as an internal-identity/public-authority rejection rather than RoleMismatch. Do not conflate their receipts or silently reinterpret old immutable evidence.
5. Existing identity tests 001/002/003/008 explicitly expect Predictor=Engineer. Those expectations must be intentionally revised with the contract, while valid ordinary v1 identities and immutable owner-derived identity behavior remain equivalent.

The root's explicit old-evidence rejection is a deliberate tightening, not transparent compatibility. It needs its own cold refusal and unchanged-byte evidence; it is not a reason to add an executable legacy Engineer facade.

## Minimal independent acceptance suggestion

- Configuration: real generated Predictor slot is hidden and denies all known tools and unknown tools via '*', with model untouched; legal Engineer retains Fission. Manager/DevOps/Bookkeeper remain denied. No public Predictor fork or office appears.
- Identity/authority: internal Predictor data round-trips, but public managed-agent and authority-root creation reject it; ordinary names and owner-derived replica evidence remain unchanged. Retain the wrong old Predictor payload and prove no activation/rewrite after restart.
- Actual positive Fission control: reuse intra-participant-parallelism-003's real Manager fork to Engineer child, then real fission. It supplies a physical parent, durable authority, canonical WorkRecord and ready admission, so the test can reach creation and prompt dispatch.
- Actual negative Predictor control: create a Host caller with a real parent and use the genuine public identity/root entry. Do not hand-install an Engineer profile and call it Predictor. Try forged ctx.agent, role parameters and Engineer WorkRecord claims. Compare effect counters before and after the attempt: no new lane session, prompt, abort or Fission-group fact.
- Pair Manager/DevOps/unknown/no-authority negatives with that ready Engineer positive. The present 017 negatives have no real physical parent; zero effects by itself could only prove the origin gate, so do not attribute every refusal to correct office authorization.
- Retain Engineer root InvalidOrigin and a genuine Strength replica Fission refusal with its narrow js-predictor positive surface. Do not represent a fake ctx.agent='predictor' as a real registered replica.
- Corresponding focused requirements include office 015/016, current identity mapping/rehydration tests, capability unknown/replica boundaries, intra-participant 003/013/017 and execution-model-routing 020's real Predictor-pool positive control.

These checks do not close GAP-158's full lane lifecycle, every Manager tenure, Sphinx eligibility or historical Manager Fission replay. They also do not reopen R12-U1. The root owns implementation, formal suite selection and final plan status.

Reproduce the baseline with node or bun and `baseline.mjs <installed-667-root> <667-tgz>`. No model provider is contacted by that probe.
