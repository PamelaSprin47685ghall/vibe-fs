import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const product = resolve(process.argv[2] ?? '/private/tmp/gap085-clean-install-667/node_modules/wanxiangshu')
const archive = resolve(process.argv[3] ?? '/private/tmp/gap085-candidate-667/wanxiangshu-0.9.0.tgz')
const identity = await import(pathToFileURL(join(product, 'dist/Participant/Persona/Surface.js')))
const office = await import(pathToFileURL(join(product, 'dist/Participant/Persona/OfficeCapabilitySurface.js')))
const config = await import(pathToFileURL(join(product, 'dist/OpenCode/Host/ManagedAgentConfigSurface.js')))
const hash = file => createHash('sha256').update(readFileSync(file)).digest('hex')
config.installDefaultResources()
const selected = identity.resolveParticipantIdentityAtRoot('predictor')
assert.equal(selected.ok, true)
assert.equal(selected.identity.name, 'predictor')
assert.equal(selected.identity.role, 'engineer')
assert.equal(selected.identity.persona, 'Engineer')
const input = { agent: Object.fromEntries(identity.requiredNames.map(name => [name, { model: `keep/${name}-model` }])) }
const projected = config.configure(input)
assert.equal(projected.ok, true)
assert.equal(input.agent.predictor.permission.fission, 'allow')
assert.equal(input.agent.predictor.permission['js-engineer'], 'allow')
assert.equal(input.agent.predictor.mode, 'primary')
assert.equal(input.agent.predictor.hidden, undefined)
assert.equal(input.agent.predictor.model, 'keep/predictor-model')
assert.equal(input.agent.predictor.prompt, input.agent.engineer.prompt)
assert.deepEqual(office.permissions('predictor'), [])
assert.equal(office.isAllowed('predictor', 'Fission'), false)
console.log(JSON.stringify({ runtime: process.versions.bun ? `Bun ${process.versions.bun}` : process.version,
  product, archive, archiveSha256: hash(archive), selected,
  config: { bindingNames: projected.bindingNames, mode: input.agent.predictor.mode,
    hidden: input.agent.predictor.hidden ?? null, fission: input.agent.predictor.permission.fission,
    jsEngineer: input.agent.predictor.permission['js-engineer'], model: input.agent.predictor.model,
    promptEqualsEngineer: input.agent.predictor.prompt === input.agent.engineer.prompt },
  publicOffice: { permissions: office.permissions('predictor'), fissionAllowed: office.isAllowed('predictor', 'Fission'),
    inPublicRoleLabels: identity.allPublicRoleLabels.includes('predictor') },
  scope: 'Actual fixed-package identity and config projection only. No authority root, real Fission admission, session creation or prompt dispatch was invoked, so this is not proof of actual Fission misuse.' }, null, 2))
