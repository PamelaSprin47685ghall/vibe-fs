import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const [productArg, destination, childDirectory] = process.argv.slice(2)
const product = resolve(productArg)
const load = name => import(pathToFileURL(join(product, 'dist', name)))
const [eventStore, journal, codec] = await Promise.all([
  load('Persistence/EventStore/Surface.js'), load('Persistence/Journal/Surface.js'),
  load('Persistence/Journal/CodecSurface.js'),
])
if (childDirectory) {
  const opened = await journal.JournalSurface_bootWithWriterId(childDirectory, 'cold-reader', 'cold-runtime', process.pid, '2026-10-19T00:00:00Z')
  assert.equal(opened.ok, true, JSON.stringify(opened.error))
  try {
    const snapshot = journal.JournalSurface_snapshot(opened.journal)
    const state = snapshot.sessionProjections['cut-session'].handles
    assert.equal(state.handleCount, 2)
    const first = state.handles.find(handle => handle.handle === 'agent:h-conflict')
    const last = state.handles.find(handle => handle.handle === 'agent:h-after')
    assert.equal(first.childSessionId, 'child-before')
    assert.equal(last.childSessionId, 'child-after')
    console.log(JSON.stringify({ pid: process.pid, snapshot }))
  } finally { journal.JournalSurface_dispose(opened.journal) }
} else {
  const directory = mkdtempSync('/private/tmp/gap159-decodable-cut-')
  let handle
  try {
    handle = eventStore.create(directory, 'decodable-conflict')
    const event = (n, child, handleId, parents = []) => {
      const id = n.toString(16).padStart(40, '0')
      const session = 'cut-session'
      return { id, stream: `journal/session/${session}`, type: 'JournalEnvelope', parents, payloadRefs: [],
        payload: { EventId: ['EventId', id], RuntimeId: ['RuntimeId', 'cut-runtime'],
          LocalSeq: ['LocalSeq', String(n)], ObservedAt: '2026-10-19T00:00:00.000+00:00',
          Stream: ['Session', ['SessionId', session]],
          Fact: ['Agent', ['Execution', ['HandleLinked', { Byname: 'Ada', CanonicalRole: 'Engineer',
            ChildSessionId: ['SessionId', child], Handle: ['Agent', ['AgentHandleId', handleId]],
            Ownership: 'DurableParentHandle', ParentSessionId: ['SessionId', session], TargetAgent: 'engineer' }]]] } }
    }
    const first = event(1, 'child-before', 'h-conflict')
    const bad = event(2, 'child-conflicting', 'h-conflict', [first.id])
    const after = event(3, 'child-after', 'h-after', [bad.id])
    for (const item of [first, bad, after]) {
      const decoded = codec.decode({ eventId: item.id, eventType: item.type, streamId: item.stream,
        parents: item.parents, payload: item.payload, payloadRefs: item.payloadRefs })
      assert.equal(decoded.ok, true, JSON.stringify(decoded.error))
    }
    const firstReceipt = await eventStore.append(handle, [first])
    assert.equal(firstReceipt.ok, true)
    assert.equal(firstReceipt.cuts.length, 0)
    const badReceipt = await eventStore.append(handle, [bad])
    assert.equal(badReceipt.ok, true, JSON.stringify(badReceipt.error))
    assert.equal(badReceipt.cuts.length, 1)
    assert.equal(badReceipt.cuts[0].rule, 'Journal')
    assert.equal(badReceipt.cuts[0].failedEventId, bad.id)
    const afterReceipt = await eventStore.append(handle, [after])
    assert.equal(afterReceipt.ok, true, JSON.stringify(afterReceipt.error))
    assert.equal(afterReceipt.cuts.length, 0)
    eventStore.dispose(handle)
    handle = null
    const raw = readFileSync(join(directory, 'wanxiangshu/events/decodable-conflict-0000.ndjson'), 'utf8')
    const events = raw.trim().split('\n').map(line => JSON.parse(line))
    assert.equal(events.length, 4)
    assert.deepEqual(events.map(item => item.event_type), ['JournalEnvelope', 'JournalEnvelope', 'ProjectionCutTail', 'JournalEnvelope'])
    assert.equal(events[2].payload.failed_event_id, bad.id)
    assert.deepEqual(events[2].payload.reset_json, '{}')
    const cold = JSON.parse(execFileSync(process.execPath, [process.argv[1], product, destination, directory],
      { encoding: 'utf8', timeout: 15000, env: { ...process.env, WANXIANGSHU_NO_FATAL_EXIT: '1' } }))
    assert.notEqual(cold.pid, process.pid)
    assert.equal(readFileSync(join(directory, 'wanxiangshu/events/decodable-conflict-0000.ndjson'), 'utf8'), raw)
    assert.deepEqual(readdirSync(join(directory, 'wanxiangshu/events')), ['decodable-conflict-0000.ndjson'])
    const report = { runtime: process.versions.bun ? `Bun ${process.versions.bun}` : process.version, product,
      firstReceipt, badReceipt, afterReceipt, events, cold,
      scope: 'A real decodable Journal fold conflict keeps the bad event and cut in one append, permits a later valid fact, and cold replay preserves the prior good binding. This is a low-level store proof, not a producing-process fatal ownership proof.' }
    writeFileSync(destination, JSON.stringify(report, null, 2) + '\n')
    console.log(JSON.stringify(report, null, 2))
  } finally {
    if (handle) eventStore.dispose(handle)
    rmSync(directory, { recursive: true, force: true })
  }
}
