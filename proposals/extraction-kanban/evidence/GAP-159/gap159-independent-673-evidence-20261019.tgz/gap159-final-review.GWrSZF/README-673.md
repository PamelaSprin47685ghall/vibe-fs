# GAP-159 non-author follow-up: fixed candidate 673

This is an addendum. The original 670 archive and `README-670.md` are not rewritten. The final report must distinguish the original identity/config defect, the recovery regression introduced during this repair, deliberate compatibility tightening, and reviewer fixture mistakes.

## Fixed input and results

- Archive: `/private/tmp/gap159-candidate-673/wanxiangshu-0.9.0.tgz`
- SHA-256 verified by an independent read: `991c149eb6e310e63db2ab799b0ab0f4573a930056be7855e171f1d333760dde`
- Actual clean installation: `/private/tmp/gap159-clean-install-673/node_modules/wanxiangshu`
- Both Node v26.6.0 and Bun 1.3.14 exited 0 for each of the three bounded scripts below.

1. `legacy.mjs ... strict`: all nine actual business-codec cases pass. Matching public Engineer/DevOps/Manager evidence remains supported; private Predictor/Bookkeeper roots and inconsistent SelectedAgent/CanonicalRole evidence are rejected. Legacy AgentOwnerRoot remains explicitly unprovable. Original inputs are unchanged. The 670 non-strict receipts and strict red logs remain separate.
2. `semantic-cut.mjs`: a genuine decodable Journal `HandleLinked` conflict retains the prior child binding, appends the bad event and its `ProjectionCutTail` together, accepts a later valid binding, and replays both good bindings in an independent process. The cold process changes no writer file and creates no new writer segment. This is actual store/cold-projection evidence; it does not substitute for the producing-process fatal ownership suite.
3. `review.mjs`: the full bounded 670 identity, config, ordinary-byte compatibility, owner-derived replica identity and real shared-journal cold-consumption checks were repeated against 673. All pass. The actual baseline-generated old Predictor event is rejected by 673 JournalCodec; an independent forced mixed-workspace snapshot preserves the healthy Engineer and omits the erroneous Predictor stream. Existing file paths and hashes remain identical after two cold consumers. No fresh root on the damaged stream is attempted by this script; the Host reviewer owns that counterexample and final correction verification.

The actual installed dist map contains 895 files on each side. From 670 to 673 exactly `Composition/Durable/JournalIntegration.js` and `Participant/Persona/Identity.js` changed. Other earlier identity/config generated files remain identical. The map is scoped to dist, not every archive member.

## Source review conclusion

The legacy upgrader now proves that a public role exists for SelectedAgent and that CanonicalRole agrees, using case-insensitive equality. It uses the existing LegacyRoleMismatch case. It does not infer an executable Engineer alias for private identities, mutate durable bytes, add a public Predictor Role, or change the real readonly replica identity.

Journal cut planning now uses the same production EventStoreJournalCodec as integration. It preserves the existing empty reset only when the failed event can be decoded. An undecodable event returns the actual decoder error; a reset cannot prove that an unknown prior run or physical obligation is released. No error-string classification, second identity parser, fallback alias, or temporary IntegrationRule flag was introduced.

The existing five public authority JSON surfaces still reject private Predictor labels. That is consistent with their public-authority contracts. The production business codec and actual cold-consumer path were checked separately; a fake private authority bypass was not added for surface symmetry.

No additional defect was found in the reviewed identity consumers or the normal decodable-cut path. This is not a claim of complete Fission lifecycle closure, nor final acceptance of a later archive.

## Deliberate behavior change and remaining cost

The new cut guard also applies to live malformed Journal payloads. Existing durable-events-024 malformed-payload fixtures formerly expected bad-event-plus-cut settlement and fatal. Those expectations must be retained as old evidence and replaced by explicit preparation rejection/no new physical append/no fabricated cut or fatal, while preserving real release-failure evidence. A valid, decodable business fold conflict still has the original cut behavior, as proved above. WHAT015/021/024 must state this boundary; it must not be called unchanged behavior.

A failed Journal cut inference enters the existing IntegratorEngine generic one-time full-history replay fallback before failing again. The failed event's decode is event-local, so replay cannot change this particular conclusion. This is a newly exposed rejection cost and consumes the shared generic fallback budget. The current patch does not solve WHAT017's absolute no-history-dependence claim on this exceptional path. Root explicitly retained this boundary rather than adding a temporary flag or exception escape. No large-history cost benchmark was performed by this reviewer.

An already durable ProjectionCutTail is still replayed by the existing ApplyCut protocol. This patch prevents generation of new unsafe reset facts; it is not new authentication or migration for arbitrary pre-existing cut records. An unshipped 670 candidate's generated bad history was not silently added to the supported compatibility domain.

## Evidence and attribution

- `legacy-673-{node,bun}.{log,json}`: strict codec receipts.
- `semantic-cut-673-{node,bun}.{log,json}`: physical bad/cut/good timeline and independent cold Current.
- `673-{node,bun}.log` and `673-{node,bun}-evidence/`: repeated actual-package ABI and cold-consumer evidence, including original NDJSON.
- `package-670-to-673.{json,log}`: exact generated-file map.
- Old `rejected-*-*` logs record review fixture errors about lazy acquire, not product regressions.
- The Host reviewer's 670 same-session fresh-Engineer counterexample is a repair-introduced recovery regression. These scripts neither claim authorship of that finding nor substitute for its corrected end-to-end test.

No shared source was edited. All owned temporary workspaces were removed. R12-U1 remains deferred.
