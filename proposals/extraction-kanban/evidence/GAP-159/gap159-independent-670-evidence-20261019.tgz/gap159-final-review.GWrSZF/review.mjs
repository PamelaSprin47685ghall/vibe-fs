import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { mkdirSync, mkdtempSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs'
import { join, relative, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const product = resolve(process.argv[2])
const baseline = '/private/tmp/gap085-clean-install-667/node_modules/wanxiangshu'
const archive = resolve(process.argv[4] ?? '/private/tmp/gap159-candidate-670/wanxiangshu-0.9.0.tgz')
const evidence = resolve(process.argv[3])
mkdirSync(evidence, { recursive: true })
const load = (root, path) => import(pathToFileURL(join(root, 'dist', path)))
const [identity, oldIdentity, config, office, authority, oldAuthority, strength, journal, oldJournal, dispatch, oldDispatch, factCodec, oldFactCodec, journalCodec, oldJournalCodec] = await Promise.all([
  load(product, 'Participant/Persona/Surface.js'), load(baseline, 'Participant/Persona/Surface.js'),
  load(product, 'OpenCode/Host/ManagedAgentConfigSurface.js'), load(product, 'Participant/Persona/OfficeCapabilitySurface.js'),
  load(product, 'Interaction/Authority/RuntimeSurface.js'), load(baseline, 'Interaction/Authority/RuntimeSurface.js'),
  load(product, 'Strength/Surface.js'), load(product, 'Persistence/Journal/Surface.js'),
  load(baseline, 'Persistence/Journal/Surface.js'), load(product, 'Interaction/Dispatch/DispatchSurface.js'),
  load(baseline, 'Interaction/Dispatch/DispatchSurface.js'), load(product, 'Persistence/Journal/FactCodecSurface.js'),
  load(baseline, 'Persistence/Journal/FactCodecSurface.js'),
  load(product, 'Persistence/Journal/CodecSurface.js'), load(baseline, 'Persistence/Journal/CodecSurface.js'),
])
const H = value => createHash('sha256').update(value).digest('hex')
const sha = file => H(readFileSync(file))
const observations = []
const record = (name, result = {}) => observations.push({ name, ...result })
const rootSeed = (module, name) => {
  const result = module.resolveParticipantIdentityAtRoot(name)
  assert.equal(result.ok, true, `${name}: ${result.error}`)
  const v = result.identity
  return { kind: 'RootSelection', ownerSession: null, ownerLogicalRun: null, ownerAuthorityRoot: null,
    participantIdentity: { participant: v.name, role: v.role, canonicalRole: v.role, selectedAgent: v.name,
      persona: v.persona, personaCatalogVersion: v.catalogVersion, origin: v.origin } }
}
const rootFor = (module, name) => module.createAuthorityRoot(H, 'review-runtime', `session-${name}`, 'HumanRoot', `physical-${name}`, rootSeed(identity, name))
const restore = (v, owner = '') => identity.rehydrateParticipantIdentity(owner, v.name, v.role, 'deep', '', v.persona, v.catalogVersion, v.origin)
const predictor = identity.resolveParticipantIdentityAtRoot('predictor').identity
assert.equal(predictor.role, 'predictor')
assert.equal(predictor.persona, 'Predictor')
assert.deepEqual(restore(predictor).identity, predictor)
const inherited = identity.inheritParticipantIdentityFromOwner('predictor', 'manager')
assert.equal(inherited.ok, true)
assert.equal(inherited.identity.persona, 'Lead')
assert.deepEqual(restore(inherited.identity, 'manager').identity, inherited.identity)
for (const name of ['bookkeeper', 'predictor', 'unknown-participant']) {
  assert.equal(authority.parseAgentName(name).ok, false)
  if (name !== 'unknown-participant') assert.equal(rootFor(authority, name).ok, false)
  assert.equal(office.isAllowed(name, 'Fission'), false)
}
for (const name of ['engineer', 'manager', 'orchestrator', 'devops', 'blogger', 'plan', 'bookkeeper']) {
  const before = oldIdentity.resolveParticipantIdentityAtRoot(name)
  const after = identity.resolveParticipantIdentityAtRoot(name)
  assert.deepEqual(after, before, `ordinary ${name}`)
  assert.deepEqual(restore(after.identity).identity, after.identity)
}
for (const ownerName of ['engineer', 'manager', 'devops']) {
  const seed = rootSeed(identity, ownerName)
  const oldOwner = oldAuthority.createAuthorityRoot(H, 'review-runtime', `session-${ownerName}`, 'HumanRoot', `physical-${ownerName}`, seed)
  const owner = rootFor(authority, ownerName)
  assert.equal(owner.ok, true)
  assert.deepEqual(owner, oldOwner)
  const replica = authority.issueInheritedIdentitySeed(ownerName, owner.value)
  assert.deepEqual(replica, oldAuthority.issueInheritedIdentitySeed(ownerName, oldOwner.value))
  assert.equal(replica.ok, true)
  assert.equal(replica.value.participantIdentity.participant, ownerName)
  assert.deepEqual(new Set(strength.readonlyCapabilities(ownerName, 'strength-replica')), new Set(['Read', 'Glob', 'Grep']))
}
const oldPredictor = oldIdentity.resolveParticipantIdentityAtRoot('predictor').identity
const oldBytes = JSON.stringify(oldPredictor)
const rejectedOld = restore(oldPredictor)
assert.equal(rejectedOld.ok, false)
assert.equal(rejectedOld.error, 'RoleMismatch')
assert.equal(JSON.stringify(oldPredictor), oldBytes)
record('identity-public-boundary-and-owner-derived-replica', { oldPredictor, predictor, rejectedOld })

config.installDefaultResources()
const configuration = { agent: Object.fromEntries(identity.requiredNames.map(name => [name, { model: `keep/${name}` }])) }
configuration.agent.predictor = { model: 'keep/predictor', prompt: 'stale Engineer prompt', hidden: false,
  permission: { '*': 'allow', fission: 'allow', 'js-engineer': 'allow' } }
const predictorSlot = configuration.agent.predictor
for (let pass = 0; pass < 2; pass += 1) {
  const result = config.configure(configuration)
  assert.equal(result.ok, true)
  assert.equal(result.bindingNames.includes('predictor'), false)
  assert.equal(result.bindingNames.includes('bookkeeper'), false)
  assert.equal(result.bindingNames.includes('engineer'), true)
  assert.equal(configuration.agent.predictor, predictorSlot)
  assert.equal(predictorSlot.model, 'keep/predictor')
  assert.equal(predictorSlot.hidden, true)
  assert.equal(predictorSlot.prompt, '')
  assert.equal(predictorSlot.permission['*'], 'deny')
  for (const [name, permission] of Object.entries(predictorSlot.permission)) {
    if (name !== 'external_directory') assert.equal(permission, 'deny', name)
  }
  assert.equal(configuration.agent.engineer.permission.fission, 'allow')
  assert.equal(configuration.agent.bookkeeper.permission.fission, 'deny')
}
record('stale-config-projection-repeat', { predictor: predictorSlot, engineerFission: configuration.agent.engineer.permission.fission })

const authorityFact = (profile) => ({ family: 'Prompt', case: 'AuthorityRootAccepted', payload: {
  SchemaVersion: 2, SessionId: profile.session, LogicalRunId: profile.logicalRun,
  AuthorityRootUserMessageId: profile.authorityRoot, AuthorityKind: profile.authorityKind, IdentitySeed: profile.identitySeed,
} })
for (const name of ['engineer', 'manager', 'devops']) {
  const profile = rootFor(authority, name).value
  const encoded = factCodec.encode(authorityFact(profile))
  assert.equal(encoded, oldFactCodec.encode(authorityFact(profile)))
  assert.equal(factCodec.decode(encoded).ok, true)
}
const actualOldPredictor = oldAuthority.createAuthorityRoot(H, 'review-old', 'old-predictor', 'HumanRoot', 'old-physical', rootSeed(oldIdentity, 'predictor'))
assert.equal(actualOldPredictor.ok, true)
const oldFactBytes = oldFactCodec.encode(authorityFact(actualOldPredictor.value))
const decodedOld = factCodec.decode(oldFactBytes)
assert.equal(decodedOld.ok, false)
assert.match(decodedOld.error, /Role mismatch: expected None, got engineer/)
writeFileSync(join(evidence, 'old-predictor-fact.json'), oldFactBytes)
record('business-codec-preserves-ordinary-bytes-rejects-old-predictor', { oldFactSha256: H(oldFactBytes), decodedOld })

const fileHashes = root => {
  const found = {}
  const visit = current => {
    for (const name of readdirSync(current)) {
      const file = join(current, name)
      if (statSync(file).isDirectory()) visit(file)
      else found[relative(root, file)] = sha(file)
    }
  }
  visit(root)
  return found
}
const worker = join(resolve(process.argv[1], '..'), 'cold-worker.mjs')
const coldWorker = (root, action, workspace, mode) => {
  const output = execFileSync(process.execPath, [worker, root, action, workspace, mode], { encoding: 'utf8', timeout: 15000, env: { ...process.env, WANXIANGSHU_NO_FATAL_EXIT: '1' } })
  return JSON.parse(output)
}
for (const mode of ['ordinary', 'mixed']) {
  const workspace = mkdtempSync('/private/tmp/gap159-cold-')
  try {
    execFileSync('git', ['init', '--quiet', workspace])
    const common = join(workspace, '.git')
    const seeded = coldWorker(baseline, 'seed', workspace, mode)
    const beforeCold = fileHashes(common)
    const oldRaw = readFileSync(join(common, 'wanxiangshu/events/old-seed-0000.ndjson'), 'utf8')
    writeFileSync(join(evidence, `${mode}-old-seed.ndjson`), oldRaw)
    if (mode === 'mixed') {
      const oldEvent = oldRaw.trim().split('\n').map(line => JSON.parse(line)).find(event => event.stream_id === 'journal/session/old-predictor')
      assert.ok(oldEvent)
      const wireEvent = { eventId: oldEvent.event_id, eventType: oldEvent.event_type, streamId: oldEvent.stream_id,
        parents: oldEvent.parents, payload: oldEvent.payload, payloadRefs: oldEvent.payload_refs, payloads: oldEvent.payloads }
      assert.equal(oldJournalCodec.decode(wireEvent).ok, true)
      const decodedActual = journalCodec.decode(wireEvent)
      assert.equal(decodedActual.ok, false)
      assert.match(decodedActual.error, /Role mismatch: expected None, got engineer/)
      record('actual-persisted-old-predictor-journal-codec-rejection', { decodedActual })
    }
    const cold = coldWorker(product, 'cold', workspace, mode)
    const afterCold = fileHashes(common)
    assert.deepEqual(afterCold, beforeCold, 'cold consumption and internal denial change no persisted file')
    let again
    if (mode === 'mixed') {
      again = coldWorker(product, 'cold', workspace, mode)
      const repeated = fileHashes(common)
      assert.deepEqual(repeated, beforeCold, 'repeated cold consumption changes no persisted file')
    }
    record(`independent-process-shared-cold-${mode}`, { seeded, cold, again, beforeCold, afterCold,
      newFiles: Object.keys(afterCold).filter(file => !(file in beforeCold)),
      scope: mode === 'mixed' ? 'Acquire remains lazy and successful. Forced snapshot preserves Engineer and refuses the old erroneous Predictor stream. Every persisted file remains unchanged; no fresh root on the damaged stream is exercised here.' : 'An ordinary Engineer journal replays and internal public admissions reject without installing sessions. No persisted file is changed.',
    })
  } finally {
    rmSync(workspace, { recursive: true, force: true })
  }
}
const report = { runtime: process.versions.bun ? `Bun ${process.versions.bun}` : process.version,
  product, archive, archiveSha256: sha(archive), observations,
  scope: 'Fixed actual package and real local EventStore/shared journal cold acquire. Replica checks are identity/capability owner-derived contracts, not full physical Strength execution. No shared source was edited.' }
writeFileSync(join(evidence, 'summary.json'), JSON.stringify(report, null, 2) + '\n')
console.log(JSON.stringify(report, null, 2))
