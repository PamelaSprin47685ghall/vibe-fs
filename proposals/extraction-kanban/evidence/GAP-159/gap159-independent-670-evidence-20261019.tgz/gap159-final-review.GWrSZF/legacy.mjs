import assert from 'node:assert/strict'
import { readFileSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const [productArg, destination, strict] = process.argv.slice(2)
const codec = await import(pathToFileURL(join(resolve(productArg), 'dist/Persistence/Journal/FactCodecSurface.js')))
const actualOldFact = JSON.parse(readFileSync(join(resolve(process.argv[1], '..'), 'node-evidence/old-predictor-fact.json'), 'utf8'))
const findAuthority = value => {
  if (Array.isArray(value)) {
    if (value[0] === 'AuthorityRootAccepted') return value
    for (const item of value) { const found = findAuthority(item); if (found) return found }
  } else if (value && typeof value === 'object') {
    for (const item of Object.values(value)) { const found = findAuthority(item); if (found) return found }
  }
}
const cases = [
  ['engineer', 'engineer', 'HumanRoot', true],
  ['devops', 'devops', 'HumanRoot', true],
  ['manager', 'manager', 'HumanRoot', true],
  ['predictor', 'engineer', 'HumanRoot', false],
  ['predictor', 'predictor', 'HumanRoot', false],
  ['bookkeeper', 'bookkeeper', 'HumanRoot', false],
  ['engineer', 'devops', 'HumanRoot', false],
  ['devops', 'engineer', 'HumanRoot', false],
  ['engineer', 'engineer', 'AgentOwnerRoot', false],
]
const observations = []
for (const [selectedAgent, canonicalRole, authorityKind, wanted] of cases) {
  const fact = structuredClone(actualOldFact)
  const payload = findAuthority(fact)[1]
  delete payload.SchemaVersion
  delete payload.IdentitySeed
  payload.AuthorityKind = authorityKind
  payload.SelectedAgent = selectedAgent
  payload.CanonicalRole = canonicalRole
  payload.PeerAgent = selectedAgent
  const bytes = JSON.stringify(fact)
  const result = codec.decode(bytes)
  assert.equal(JSON.stringify(fact), bytes)
  if (strict === 'strict') assert.equal(result.ok, wanted, `${selectedAgent}/${canonicalRole}/${authorityKind}: ${JSON.stringify(result)}`)
  if (result.ok) assert.equal(result.payload.IdentitySeed.participantIdentity.participant, selectedAgent)
  observations.push({ selectedAgent, canonicalRole, authorityKind, wanted, result })
}
const report = { runtime: process.versions.bun ? `Bun ${process.versions.bun}` : process.version,
  product: resolve(productArg), strict: strict === 'strict', observations,
  scope: 'Actual business FactCodec no-schema v1 decode only. This does not claim a decoded internal identity can install authority or run.' }
writeFileSync(destination, JSON.stringify(report, null, 2) + '\n')
console.log(JSON.stringify(report, null, 2))
