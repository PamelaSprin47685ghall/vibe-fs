# GAP-159 independent review of fixed candidate 670

Reviewer: non-author agent `/root/d1_review_git`. Shared production source was read only. Probes and all workspaces were private under `/private/tmp`; every owned workspace was removed in `finally`.

## Fixed input

- Candidate: `/private/tmp/gap159-candidate-670/wanxiangshu-0.9.0.tgz`
- SHA-256: `7e7a0edc6e37dd6ec1253162e73cdbf2ecbdc4c07ec4aff7a5bfb022e8bd4ebf`
- Actual clean install: `/private/tmp/gap159-clean-install-670/node_modules/wanxiangshu`
- Baseline 667: `/private/tmp/gap085-clean-install-667/node_modules/wanxiangshu`; archive SHA-256 `b0de9b9770139ae4aa977fae3d8b8d59f2d558cf4ff4a41cf4a1289419743297`.
- Node v26.6.0 and Bun 1.3.14, macOS arm64.

## Passed bounded actual-package checks

`review.mjs`, `cold-worker.mjs`, `node.log`, `bun.log`, and the two evidence directories are the original scripts and receipts. Both final script invocations exited 0.

1. Predictor resolves as its private identity and Persona, does not alias Engineer, and round-trips as root and owner-derived identity. Inherited Persona remains the owner Persona.
2. Ordinary Engineer, Manager, Orchestrator, DevOps, Blogger, Plan and Bookkeeper identity views are identical to 667. Ordinary authority profiles and owner-derived replica seeds are equal to 667; readonly capability checks remain Read/Glob/Grep. This is not a physical Strength-run proof.
3. Public role parsing and public authority construction refuse Predictor/Bookkeeper. Unknown participants cannot acquire a public office. No new public Role is introduced.
4. A caller-owned Predictor config object with stale Engineer prompt and permissive tools is projected twice in place: same model and object, hidden, empty prompt, wildcard and all named tools denied. The `external_directory` path permission is not a tool permission. Engineer retains Fission; Bookkeeper retains its denial.
5. Actual business FactCodec preserves ordinary fact bytes relative to 667 and explicitly rejects old schema-2/catalog-1 Predictor-as-Engineer with `Role mismatch: expected None, got engineer`.
6. Real baseline 667 Journal/Dispatch APIs seed private Git workspaces. Separate processes use 670 shared journal acquire and force canonical snapshot. Ordinary Engineer replays. In a mixed workspace the ordinary Engineer projection remains, while the old erroneous Predictor stream installs no authority. The actual persisted old event fails the actual 670 JournalCodec with RoleMismatch. Repeating forced cold consumption has the same result. All `.git` file paths and SHA-256 values are unchanged, with no new files. Original NDJSON is retained in each evidence directory.

Opening is lazy. `acquire.ok=true` alone says nothing about replay or authority acceptance. `JournalIntegration.FaultScope` and the existing integrator preserve healthy streams while faulting the erroneous stream. The exact observed boundary is neither global workspace rejection nor successful old authority restoration.

The dist map compares 895 actual installed generated files on both sides. Exactly nine changed, all in the declared identity, authority, config and ProviderFailureSurface paths. This map is scoped to `dist`; it is not a claim about every archive member.

## Confirmed remaining findings in 670

`legacy.mjs` records nine no-schema v1 business-codec cases on both runtimes. Matching Engineer/DevOps/Manager are accepted. Predictor/Engineer, Predictor/Predictor, Bookkeeper/Bookkeeper and inconsistent Engineer/DevOps pairs are also decoded successfully because the old legacy upgrader ignores CanonicalRole. Such decode success is not a proof of public authority installation. AgentOwnerRoot remains unprovable and rejected. Both strict invocations on 670 exited 1 at Predictor/Engineer; raw logs are preserved. Root is implementing the narrow validation fix, and a newer fixed package must be rechecked.

The Host reviewer separately confirmed a new recovery regression introduced by the identity tightening: on the faulted old Predictor session, a fresh public Engineer root can use the existing empty reset and install without the old exact closure. That evidence is owned by the Host reviewer, not by these scripts. The final mixed-workspace checks here intentionally do not submit a new root on the damaged stream. Root owns the correction and final independent recheck. Candidate 670 is not declared complete.

## Review fixture mistakes retained separately

`rejected-same-process-*` and `rejected-unforced-acquire-*` preserve earlier failed review assumptions. Both wrongly asserted that a lazy shared acquire must itself return `ok=false` for the mixed journal. The initial speculation about a process-local cache was withdrawn after source inspection and independent-process observation. The real cause of those failed expectations was that acquire does not force replay. These are reviewer fixture mistakes, not product defects. The final scripts force Snapshot and assert the real per-stream boundary.

No shared source was modified. Public-authority JSON surfaces that reject a private Predictor label before core construction were reviewed as public boundaries; no unnecessary private bypass was added. R12-U1 was not investigated. This review does not close GAP-158 or the complete Fission lifecycle.
