import { createHash } from 'node:crypto'
import { readFileSync, readdirSync, statSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

const [left, right, destination] = process.argv.slice(2)
const sha = file => createHash('sha256').update(readFileSync(file)).digest('hex')
const scan = root => {
  const files = {}
  const walk = (base, prefix = '') => {
    for (const entry of readdirSync(base)) {
      const name = prefix ? `${prefix}/${entry}` : entry
      const path = join(base, entry)
      if (statSync(path).isDirectory()) walk(path, name)
      else files[name] = sha(path)
    }
  }
  walk(root)
  return files
}
const before = scan(join(left, 'dist'))
const after = scan(join(right, 'dist'))
const paths = [...new Set([...Object.keys(before), ...Object.keys(after)])].sort()
const changed = paths.filter(path => before[path] !== after[path]).map(path => ({ path, before: before[path], after: after[path] }))
const report = { left, right, leftCount: Object.keys(before).length, rightCount: Object.keys(after).length, changed }
writeFileSync(destination, JSON.stringify(report, null, 2) + '\n')
console.log(JSON.stringify(report, null, 2))
