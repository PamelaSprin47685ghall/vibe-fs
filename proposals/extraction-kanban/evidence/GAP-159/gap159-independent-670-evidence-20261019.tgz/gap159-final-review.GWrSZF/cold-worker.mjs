import assert from 'node:assert/strict'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const [productArg, action, workspace, mode] = process.argv.slice(2)
const product = resolve(productArg)
const load = name => import(pathToFileURL(join(product, 'dist', name)))
const [journal, dispatch] = await Promise.all([
  load('Persistence/Journal/Surface.js'), load('Interaction/Dispatch/DispatchSurface.js'),
])
let handle
try {
  if (action === 'seed') {
    const opened = await journal.JournalSurface_bootWithWriterId(join(workspace, '.git'), 'old-seed', 'old-runtime', process.pid, '2026-10-19T00:00:00Z')
    assert.equal(opened.ok, true, JSON.stringify(opened.error))
    handle = opened.journal
    const engineer = await dispatch.acceptHumanRoot(handle, 'ordinary-engineer', 'ordinary-root', 'engineer')
    assert.equal(engineer.ok, true, JSON.stringify(engineer.error))
    if (mode === 'mixed') {
      const predictor = await dispatch.acceptHumanRoot(handle, 'old-predictor', 'old-predictor-root', 'predictor')
      assert.equal(predictor.ok, true, JSON.stringify(predictor.error))
    }
    console.log(JSON.stringify({ action, mode, seeded: mode === 'mixed' ? ['engineer', 'old-predictor-as-engineer'] : ['engineer'] }))
  } else {
    const opened = await journal.JournalSurface_acquireSharedForWorkspace(workspace, process.pid, '2026-10-19T00:00:00Z')
    if (opened.ok) {
      handle = opened.journal
      if (mode === 'mixed') {
        const snapshot = journal.JournalSurface_snapshot(handle)
        assert.equal(snapshot.sessions.includes('ordinary-engineer'), true)
        assert.equal(snapshot.sessions.includes('old-predictor'), false)
        assert.equal(journal.JournalSurface_hasSession(handle, 'old-predictor'), false)
        console.log(JSON.stringify({ action, mode, acquireOk: true, snapshot,
          scope: 'Forced canonical projection preserves Engineer and refuses the old erroneous Predictor stream. No fresh root was attempted on the damaged stream.' }))
      } else {
        assert.equal(journal.JournalSurface_hasSession(handle, 'ordinary-engineer'), true)
        const internalDenials = []
        for (const name of ['predictor', 'bookkeeper']) {
          const denied = await dispatch.acceptHumanRoot(handle, `rejected-${name}`, `root-${name}`, name)
          assert.equal(denied.ok, false)
          assert.equal(journal.JournalSurface_hasSession(handle, `rejected-${name}`), false)
          internalDenials.push({ name, denied })
        }
        console.log(JSON.stringify({ action, mode, ok: true, ordinaryEngineerReplayed: true, internalDenials }))
      }
    } else {
      assert.equal(mode, 'mixed')
      assert.match(opened.error, /Role mismatch: expected None, got engineer/)
      console.log(JSON.stringify({ action, mode, ...opened }))
    }
  }
} finally {
  if (handle) journal.JournalSurface_dispose(handle)
}
