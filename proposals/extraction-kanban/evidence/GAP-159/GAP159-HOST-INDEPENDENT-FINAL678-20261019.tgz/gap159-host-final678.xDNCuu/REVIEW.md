# Fixed678 independent Host regression verification

This is a read-only non-author review. No shared source or installed package bytes are edited. It verifies the actual npm public `wanxiangshu` Plugin server and registered tools with the existing controlled SDK Host; it does not claim a real model/provider network.

## Scope and the prior673 limitation

The complete673 archive remains untouched at `/private/tmp/GAP159-HOST-INDEPENDENT-FINAL673-20261019.tgz`, SHA256 `1ed4a1adcfd6358f34da8e61c1bc52c167fb6c491c04172a9e6ec34d93c9ee97`.

After the673 bounded matrix passed, another reviewer produced an additional real old667 history containing Predictor's bad root plus a later HandleLinked conflict and its existing semantic cut. The old cut names a different failed event from the new decoder failure;673 could clear that new earlier fault by stream scope. The673 public/portable matrix did not contain this existing-cut history and therefore did not prove that case. It must not be used to claim final acceptance of that newly discovered boundary.

The parent implemented the678 current-fault EventId guard; the tests reviewer owns independent exact-package execution of that new old-cut counterexample and typed consumers. This report independently inspects the product difference and reruns the prior public/portable/cold-restart consumer scope. It does not substitute the old matrix for the new counterexample proof or close all GAP-158/WHAT017 lifecycle clauses.

## Complete product difference

Both fixed tarballs contain2076 files;2074 are byte-identical. Only these emitted modules differ:

- `dist/Persistence/EventStore/IntegratorEngine.js`: if a current fault exists for the cut's rule/scope and its FailedEventId differs from the cut's failed_event_id, retain the original state. The cut cannot apply its reset or clear that different fault. Existing matching and no-current-fault paths are retained.
- `dist/Verification/JournalPortObservationSurface.js`: adds a real HandleLinked journal append observation port used by the new formal semantic-cut regression. Source search found no production `.fs` caller outside that verification module itself. This is not new Plugin/tool behavior.

The full tar comparison is `673-678-package-diff.json`. The installed678 product matches all2076 tar files and SHA256 `6d986c23419a4fdae8dae4bcd6bce64f1c2ce0eae87bf798d07ea96544913335`.

## Bounded actual678 results

Consumer and helper program files are copied byte-for-byte from the673 review. Only actual package bindings and fixture snapshot data paths change. Each consumer validates the npm public export's exact installed path. The fixture Date remains explicitly anchored in its own process; Date.now and no-argument new Date track fixture-day plus real performance.now elapsed, while physical timers and explicit Date arguments are unchanged. The same old8030-byte NDJSON remains untouched; refreshing mtime is not used.

- Public Node/Bun each3 tests: hidden Predictor slot/refused public identity, unknown and forged Engineer refusal, durable Manager/DevOps refusal, legitimate Manager → true registered fork → Engineer → two Fission lanes. Zero failure/skip/TODO. The positive makes three actual SDK session creations and prompts.
- Portable old670-red case Node/Bun each1 test: refuse same-session fresh Engineer root on unclosed old Predictor history. Zero failure/skip/TODO. Rejected calls create/send/abort no physical SDK effect.
- Healthy original Engineer/Manager journal: one fresh CLI process per Host preserves exact old profiles.
- Mixed original journal: one fresh CLI process per Host rejects the original same-session new-root probe, keeps old Predictor authority absent, emits no illegal ProjectionCutTail, and preserves the complete old writer bytes.
- Actual normally disposed post-rejection states are saved, then opened by another new OS process per Host. Both normal profiles remain; a real public Manager continuation succeeds in the independent healthy stream without changing its exact original logical run. Old Predictor remains without authority, and no illegal cut or SDK physical effect occurs.

`FINAL678-VERIFICATION.json` and `verify-final.mjs` assert these bounded outcomes. All11017 regular installed files/locks are identical before/after. Original full old snapshots and the minimal8030-byte event fixture match their original hashes. Sixteen actual temporary workspace paths are absent afterward; scoped process cleanup records no consumer or fixed678 Worker residue.

Only expected new RuntimeStarted/healthy continuation records and setup/diagnostic files may be added in the writable restored copies. Whole-directory immutability is not claimed. Old event-file bytes are checked exactly. No fabricated authority event, automatic migration, source fallback or suppressed assertion is used.

## Replay

Install the two included fixed packages in separate clean roots. Recreate final-public and final-new node_modules/dist links against the chosen678 clean install. Their package.json consumer labels remain unchanged from673; the runtime path assertion identifies678 itself. Generate private initial routing HOME with the unchanged helper before loading production.

Set GAP159_PRODUCT and GAP159_EVIDENCE explicitly. Public tests run `public-boundaries.test.mjs`; the portable case runs `anchored-clock-launch.test.mjs` with GAP159_CLOCK_TARGET=portable and GAP159_CLOCK_ANCHOR=2026-10-18T19:00:00Z. Cold scripts run through `clock-boot.mjs` with the declared target. The old snapshot restore scripts require their self-owned recorded original temporary path to be absent. Never restore over a live user workspace. The portable fixture overlays only its original event bytes on an already initialized new temporary Git repository.

This archive retains all domain evidence. Only the unrelated full local process inventory stays private; CLEANUP.json carries the scoped result. The original673 archive, its earlier667/670 red evidence and the new old-cut counterexample reviewer archive remain separate and are not overwritten here.
