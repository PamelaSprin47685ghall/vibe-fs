# Fixed678 bounded final Host rerun

Preserve the full fixed673 archive unchanged: `/private/tmp/GAP159-HOST-INDEPENDENT-FINAL673-20261019.tgz`, SHA256 `1ed4a1adcfd6358f34da8e61c1bc52c167fb6c491c04172a9e6ec34d93c9ee97`.

The parent found an additional old-cut identity mismatch counterexample after673; the tests reviewer owns that new failure and its exact678 verification. This work only independently checks the673→678 product change and reruns the original public/portable/cold restart consumer scope. Do not treat this original matrix as proof of the new old-cut failure itself.

One Node and one Bun public run, each three tests. One Node and one Bun portable regression run, each one test. One healthy cold CLI per Host. One mixed new-root refusal CLI per Host with actual disposed post-rejection state saved; one additional fresh OS restart per Host over that actual state, including a legal Manager continuation in the independent healthy stream. No consumer algorithm changes: only package bindings and data snapshot paths change. The declared process-local fixture Date anchor and actual timers/monotonic clock remain unchanged.

Compare the complete2076-file package payloads, verify installed678 bytes match its tar and before/after regular installation files, preserve all original NDJSON bytes, validate no illegal new cut and SDK effects on rejected calls, then check self-owned resources are gone. Retain every outcome without overriding673 history.
