import assert from 'node:assert/strict'
import fs from 'node:fs'
import { join, dirname, relative, resolve } from 'node:path'
import { createHash } from 'node:crypto'
import { spawn } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const [product, archive, expectedArchive, evidence] = process.argv.slice(2)
const prior = resolve(process.env.GAP159_PRIOR_678_EVIDENCE || '/private/tmp/gap159-independent-final-678-corrected')
const originals = resolve(process.env.GAP159_667_EVIDENCE || '/private/tmp/gap159-old-producer-cut')
const repository = resolve(process.env.GAP159_REPOSITORY || '/Users/yuanxi/Workwork/vibe-fs')
const own = dirname(fileURLToPath(import.meta.url))
const contract = join(own, 'cold-contract.mjs')
const hash = path => createHash('sha256').update(fs.readFileSync(path)).digest('hex')
const save = (name, value) => fs.writeFileSync(join(evidence, name), JSON.stringify(value, null, 2))
const files = root => {
  const result = {}
  const visit = dir => {
    for (const name of fs.readdirSync(dir).sort()) {
      const path = join(dir, name)
      const status = fs.lstatSync(path)
      assert.equal(status.isSymbolicLink(), false)
      if (status.isDirectory()) visit(path)
      else result[relative(root, path)] = hash(path)
    }
  }
  visit(root)
  return result
}
const execute = async (name, executable, args, cwd) => {
  const stdout = fs.openSync(join(evidence, `${name}.stdout`), 'w')
  const stderr = fs.openSync(join(evidence, `${name}.stderr`), 'w')
  const env = { ...process.env, HOME: join(cwd, 'home'), USERPROFILE: join(cwd, 'home') }
  fs.mkdirSync(env.HOME, { recursive: true })
  delete env.NODE_TEST_CONTEXT
  delete env.NODE_OPTIONS
  delete env.WANXIANGSHU_NO_FATAL_EXIT
  save(`${name}.command.json`, { executable, args, cwd, HOME: env.HOME, timeoutMs: 15000 })
  const child = spawn(executable, args, { cwd, env, detached: true, stdio: ['ignore', stdout, stderr] })
  let timedOut = false
  const timer = setTimeout(() => {
    timedOut = true
    try { process.kill(-child.pid, 'SIGKILL') } catch (error) { if (error.code !== 'ESRCH') throw error }
  }, 15000)
  const status = await new Promise((done, reject) => {
    child.once('error', reject)
    child.once('close', (code, signal) => done({ code, signal, pid: child.pid, timedOut }))
  })
  clearTimeout(timer)
  fs.closeSync(stdout)
  fs.closeSync(stderr)
  save(`${name}.status.json`, status)
  assert.equal(status.timedOut, false, name)
  assert.equal(status.code, 0, fs.readFileSync(join(evidence, `${name}.stderr`), 'utf8'))
  const observed = JSON.parse(fs.readFileSync(join(evidence, `${name}.stdout`)))
  assert.equal(observed.accepted, true)
  assert.equal(observed.requested.ok, false)
  assert.equal(observed.refusedRootWrites, 0)
  assert.equal(observed.originalBytesPreserved, true)
  return { ...status, sourceSHA256: observed.sourceSHA256 }
}

fs.mkdirSync(evidence, { recursive: true })
const scratch = fs.mkdtempSync('/private/tmp/gap159-680-private-')
console.log(JSON.stringify({ product, archive, expectedArchive, evidence, scratch }))
try {
  assert.equal(hash(archive), expectedArchive)
  assert.equal(hash(contract), hash(join(prior, 'cold-contract.mjs')), 'The original678 contract probe must be unchanged')
  fs.copyFileSync(contract, join(evidence, 'cold-contract.mjs'))
  const before = files(product)
  save('products-before.json', before)
  const priorProducts = JSON.parse(fs.readFileSync(join(prior, 'products-after.json')))
  const names = [...new Set([...Object.keys(before), ...Object.keys(priorProducts)])].sort()
  const changed = names.filter(name => before[name] !== priorProducts[name])
  save('678-to-680-product-map.json', { previousFiles: Object.keys(priorProducts).length,
    currentFiles: Object.keys(before).length,
    changed: changed.map(name => ({ path: name, from678: priorProducts[name] ?? null, to680: before[name] ?? null })),
    unchanged: names.filter(name => before[name] === priorProducts[name]).length })
  assert.deepEqual(changed, ['dist/Persistence/EventStore/IntegratorEngine.js'])
  const signatures = JSON.parse(fs.readFileSync(join(prior, 'unchanged-fsi.json')))
  for (const [name, expected] of Object.entries(signatures)) assert.equal(hash(join(repository, 'src/Wanxiangshu', name)), expected)
  save('unchanged-fsi.json', signatures)
  const emitted = join(prior, 'GAP159TypedConsumer.js')
  assert.equal(hash(emitted), '28ef5a606aa064225ae198a240a46e14ceddd9adf8311c3fdb0429521bb060dc')
  save('prior-consumer-evidence.json', { emittedSHA256: hash(emitted), newTypeCompilations: 0,
    newTypedConsumerRuntimeRuns: 0, newEMRStrengthRuns: 0, priorEvidence: prior,
    scope: 'The only installed product difference is the private IntegratorEngine helper extraction. All earlier typed consumer modules, signatures and other product bytes are identical. Prior678 typed and20-case Node/Bun passes are reused, not repeated or counted as680 executions.' })
  const results = []
  for (const [host, executable] of [['node', process.execPath], ['bun', 'bun']]) {
    const cwd = join(scratch, host)
    fs.mkdirSync(cwd)
    for (const mode of ['blocked', 'matching']) {
      const root = join(evidence, `${host}-${mode}`)
      fs.mkdirSync(root)
      const source = mode === 'blocked' ? 'evidence-667' : 'evidence-same-event-667'
      fs.cpSync(join(originals, source, '.git'), join(root, '.git'), { recursive: true })
      for (const phase of ['one', 'two']) {
        results.push({ host, mode, phase, status: await execute(`${host}-${mode}-${phase}`, executable,
          [contract, product, join(root, '.git'), mode, phase], cwd) })
      }
    }
  }
  assert.deepEqual(files(product), before)
  assert.equal(hash(archive), expectedArchive)
  save('products-after.json', files(product))
  save('summary.json', { accepted: true, expectedArchive, results, changedProductFiles: changed,
    originalContractSHA256: hash(contract), sameContractProgram: true,
    sourceOriginalsUnchanged: true, installedProductUnchanged: true,
    scope: 'Only changed IntegratorEngine680 acceptance: authentic667 blocked-scope and matching-event-cut histories, two independent sequential OS processes per mode and Node/Bun. Healthy scope works and refused roots append no bytes. No typed rerun,20-case rerun or type compilation is claimed.' })
} catch (error) {
  save('harness-error.json', { message: error.message, stack: error.stack })
  process.exitCode = 1
} finally {
  fs.copyFileSync(fileURLToPath(import.meta.url), join(evidence, 'run.mjs'))
  fs.rmSync(scratch, { recursive: true, force: true })
  save('cleanup.json', { scratchRemoved: !fs.existsSync(scratch), productPreserved: fs.existsSync(product),
    scope: 'CLI native close statuses retained; no watchdog or cleanup signal on accepted runs. Real historical/cold writer directories retained as evidence, runtime staging removed.' })
}
