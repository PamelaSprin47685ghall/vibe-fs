# GAP-159 generation680 independent supplemental acceptance

Exact final package SHA256: `7d218a541e0a3df334eaa34e1bf7018ca08906062d07e6fed22c68caae886ff6`.

Only the private IntegratorEngine helper extraction changed after generation678. This supplement does not overwrite the frozen678 evidence archive, SHA256 `9ae19b3b77f1a733fd0e9742acc57d0f9801a2256258968be31e583f10548c8b`.

## Scope and results

- All2904 installed files were hashed. Exactly one path differs from the prior accepted678 product: dist/Persistence/EventStore/IntegratorEngine.js, from `f885ae876be3f13d61a18e86dd7812f60573e7846ffa28fae110028f9a536654` to `2dc91b5cd9263e20597f2ecc8f1a6d3d03cdda0aec376bd3e38383c6156fd26d`. The other2903 files are byte-identical. The exact map is retained.
- The original corrected678 cold-contract.mjs was reused without edits, SHA256 `a9ba46264a702f29bd18f3f8e3650ce4e055e2a26f36918eff8d2812725c9a57`. Its writer label contains final678 because it is the unchanged fixture program; the product argument, archive hash and command receipts identify the actual680 consumption.
- Actual Node26.6 and Bun1.3.14 each consumed both real667 producer histories through two sequential independent OS processes: eight CLI executions total, all exit0, no signal, no timeout. No source history was manufactured or changed.
- For the scope-cut regression history, both OS processes refuse an unclosed replacement, while each accepts a healthy independent scope. The second OS process sees the first healthy root. The refused root appends no event, cut or writer byte. Original source SHA256 stays `7a6ca9b312e0bb1b38546b521dc06390a7716bd56c4adf71903318105a3f0008`.
- For the genuine old same-event cut history, both OS processes retain the earlier good Engineer identity and reject a replacement without closure. Healthy scopes continue to work. Original source SHA256 stays `51577bb621c510efd797db610b352071bb4aa00ddb8a40a8cb8d3cc8327d94fb`.
- The eight real .fsi contracts and prior emitted consumer SHA256 `28ef5a606aa064225ae198a240a46e14ceddd9adf8311c3fdb0429521bb060dc` are unchanged. All other runtime product bytes are unchanged. No type compilation, typed consumer runtime or EMR/Strength20-case run was repeated for680. Their earlier678 results are reused rather than renamed as new executions. The compiled F# contracts are internal, not npm d.ts.
- The actual680 tar hash and all installed product bytes are unchanged after execution. Each native child close status, command and raw stdout/stderr is retained. Private runtime staging was removed; the historical and cold writer directories remain intentionally as evidence. No additional product-descendant sampling is claimed.

No new product defect or review fixture failure appeared in this supplemental run. The earlier673 red and reviewer fixture mistakes remain in the immutable earlier archives. R12-U1 and unrelated lifecycle/supervision work remain outside this conclusion.

## Portable replay

Install the retained680 tarball with its declared dependencies in a fresh directory. Use the source repository only to compare the unchanged eight .fsi hashes; no source implementation is loaded at runtime. From this extracted directory run:

```sh
GAP159_PRIOR_678_EVIDENCE=/absolute/archive/prior678 \
GAP159_667_EVIDENCE=/absolute/archive/real667 \
GAP159_REPOSITORY=/absolute/source-repository \
node run.mjs /absolute/clean/node_modules/wanxiangshu /absolute/archive/wanxiangshu-0.9.0.tgz 7d218a541e0a3df334eaa34e1bf7018ca08906062d07e6fed22c68caae886ff6 /absolute/new-evidence
```

The runner uses the exact retained contract program and source fixtures. It asserts that the installed product differs from prior678 in exactly the one stated file before running. real667 includes the authentic old producers and original observations; do not regenerate these fixtures using the new identity policy. The source hashes are part of the acceptance inputs.

The parent/root's35-file supervised suite and its counts are separate acceptance evidence and are not claimed as executions by this reviewer.
