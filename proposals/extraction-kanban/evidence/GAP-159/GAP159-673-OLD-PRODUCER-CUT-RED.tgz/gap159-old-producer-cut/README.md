# GAP-159 supported-old-producer cut regression

This is a non-author, real-producer red witness. Shared source/dist were not edited. It uses fixed clean-installed generation667 and generation673, actual Node26.6, the real dispatcher, typed Journal append adapter, real EventStore and real process-fatal path. No event or cut was manually written, rewritten, manufactured as an expected receipt or injected into the integrator.

## Observed sequence

`producer.mjs` starts the actual667 Journal, calls the actual dispatcher AcceptHumanRoot for predictor and records the successful profile. It then appends two actual typed HandleLinked facts with the same handle but different children. The second is a real fold conflict. The production integrator appends the bad fact and its own ProjectionCutTail before the actual producer dies by SIGKILL. The driver has a15000ms guard; it did not fire. Producer pid20279, signal SIGKILL, timeoutfalse.

The retained source file contains exactly five canonical facts:

1. RuntimeStarted
2. accepted Predictor HumanRoot (old Engineer alias)
3. first valid HandleLinked
4. conflicting second HandleLinked
5. Journal ProjectionCutTail, whose failed_event_id names fact4 rather than fact2

Facts2/3/4 have the same journal/session scope. There is no AuthorityLogicalRunClosed fact.

Original source SHA256: `7a6ca9b312e0bb1b38546b521dc06390a7716bd56c4adf71903318105a3f0008`.

## Cold control and regression

`observe.mjs` uses the actual cold Journal boot and actual dispatcher. It attempts a new Engineer root in the same session with no prior closure.

- Fixed667: the original Predictor active run is retained. The new root is rejected with ActiveRunIdentityConflict. The original source bytes remain exact.
- Fixed673, on a byte-for-byte directory copy: the prior active run is null. The later cut, originally produced for a different failed event, has cleared the new earlier Predictor decoding fault by scope. The new Engineer root is accepted, adding a new reader writer with RuntimeStarted and root. The original source bytes remain exact.

This confirms a673 compatibility regression for a history a supported667 producer can create. It is not limited to an arbitrary hand-forged cut, and it is not an old claim that a Predictor root by itself failed decode under667. The failure appears when the new decoder changes the earlier failed event while replaying a valid later historical cut.

`evidence-667` retains the real original source, producer observations/stdout/stderr/status, exact rows and the667 cold control. `evidence-cold-673` retains the copied original source and new writer, package identity and actual observation. The cold CLI commands returned exit0; that is command success. Its returned requested.ok=true in673 is the unwanted product behavior, not a passing regression assertion. The original source hashes are equal in versions-and-packages.json.

No final repaired candidate is tested in this archive. Do not use this red evidence as green acceptance. The separate new malformed Journal fixture review remains in `/private/tmp/GAP159-673-JOURNAL-CUT-PRE-REVIEW.md`.

## Reproduce

Use the exact packages in versions-and-packages.json, independently installed. From a fresh evidence root:

```sh
node run.mjs /absolute/path/to/667/node_modules/wanxiangshu /absolute/path/to/new-original
node observe.mjs /absolute/path/to/667/node_modules/wanxiangshu /absolute/path/to/new-original/.git control-cold
```

Copy the resulting original `.git` directory byte-for-byte to a new directory, then run:

```sh
node observe.mjs /absolute/path/to/673/node_modules/wanxiangshu /absolute/path/to/new-copy/.git candidate-cold
```

The first cold control rejects replacement; the673 candidate accepts it. For a repaired candidate the desired result is rejection without new writer bytes, while retaining the original source exactly. The same supported667 source can be reused; do not regenerate it using the new identity policy.

All listeners/child CLI streams were closed on native exit. The driver did not request cleanup termination; no independent process-descendant sampling beyond the observed child termination is claimed.
