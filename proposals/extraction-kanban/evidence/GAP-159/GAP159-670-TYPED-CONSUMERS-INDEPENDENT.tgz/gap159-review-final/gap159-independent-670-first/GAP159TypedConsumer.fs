module GAP159TypedConsumer

open Fable.Core.JsInterop
open Wanxiangshu.Foundation
open Wanxiangshu.Participant.Persona

let private require condition message =
    if not condition then failwith message

let private resolved name =
    match ParticipantIdentity.resolveAtRoot name with
    | Ok identity -> identity
    | Error error -> failwithf "Identity %s failed: %A" name error

let private restored owner input =
    match ParticipantIdentity.rehydrate owner input with
    | Ok identity -> identity
    | Error error -> failwithf "Identity replay failed: %A" error

let private requireSame expected actual =
    require (ParticipantIdentity.toInput actual = ParticipantIdentity.toInput expected) "Identity fields changed"

let private rejectedAlias input =
    match ParticipantIdentity.fromInput input with
    | Error(ParticipantIdentityError.RoleMismatch(None, Some Role.Engineer)) -> ()
    | value -> failwithf "Old Predictor alias was not rejected exactly: %A" value

let exercise () : obj =
    let predictor = resolved "predictor"
    require (ParticipantIdentity.role predictor = None) "Predictor acquired a public Role"
    require (ParticipantIdentity.roleLabel predictor = "predictor") "Predictor label changed"
    require (ParticipantIdentity.persona predictor = "Predictor") "Predictor persona aliases Engineer"
    require (ParticipantIdentity.selectedAgent predictor = "predictor") "Predictor name changed"
    require (ParticipantIdentity.personaCatalogVersion predictor = 1) "Predictor version changed"
    require (ParticipantIdentity.origin predictor = PersonaOrigin.ResolvedAtRoot) "Predictor origin changed"
    require (Roles.tryParseRole "predictor" = None) "Public parser accepts Predictor"
    require (not (ManagedAgentCatalog.isRoleName "predictor")) "Predictor entered the office catalog"
    require (ManagedAgentCatalog.isRoleName "engineer") "Engineer left the office catalog"
    requireSame predictor (restored None (ParticipantIdentity.toInput predictor))

    match ParticipantIdentity.fromInput (ParticipantIdentity.toInput predictor) with
    | Ok replay -> requireSame predictor replay
    | Error error -> failwithf "Private Predictor roundtrip failed: %A" error

    let oldAlias =
        { ParticipantIdentity.toInput predictor with
            Role = Some Role.Engineer
            Persona = "Engineer" }

    rejectedAlias oldAlias
    require (oldAlias.Role = Some Role.Engineer && oldAlias.Persona = "Engineer") "Rejected old evidence was rewritten"

    let manager = resolved "manager"
    let inheritedPredictor =
        match ParticipantIdentity.inheritFromOwner "predictor" manager with
        | Ok value -> value
        | Error error -> failwithf "Internal inheritance failed: %A" error

    require (ParticipantIdentity.role inheritedPredictor = None) "Inherited Predictor acquired an office"
    require (ParticipantIdentity.persona inheritedPredictor = "Lead") "Inherited Predictor lost owner persona"
    require (ParticipantIdentity.origin inheritedPredictor = PersonaOrigin.InheritedFromOwner) "Inherited Predictor lost provenance"
    requireSame inheritedPredictor (restored (Some manager) (ParticipantIdentity.toInput inheritedPredictor))

    let engineer = resolved "engineer"
    require (ParticipantIdentity.role engineer = Some Role.Engineer) "Ordinary Engineer identity changed"
    require (ParticipantIdentity.persona engineer = "Engineer") "Ordinary Engineer persona changed"
    requireSame engineer (restored None (ParticipantIdentity.toInput engineer))

    let replicaIdentity =
        match ParticipantIdentity.inheritFromOwner (ParticipantIdentity.selectedAgent engineer) engineer with
        | Ok value -> value
        | Error error -> failwithf "Owner-derived identity failed: %A" error

    require (ParticipantIdentity.selectedAgent replicaIdentity = "engineer") "Readonly purpose changed participant"
    require (ParticipantIdentity.role replicaIdentity = Some Role.Engineer) "Readonly purpose changed role"
    require (ParticipantIdentity.persona replicaIdentity = "Engineer") "Readonly purpose changed persona"
    requireSame replicaIdentity (restored (Some engineer) (ParticipantIdentity.toInput replicaIdentity))

    require (OfficeCapability.isAllowed Role.Engineer ToolPermission.Fission) "Engineer lost Fission"
    require (not (OfficeCapability.isAllowed Role.Manager ToolPermission.Fission)) "Manager gained Fission"
    require (not (OfficeCapability.isAllowed Role.DevOps ToolPermission.Fission)) "DevOps gained Fission"
    require (OfficeCapabilitySurface.permissions "predictor" = [||]) "Predictor has office permissions"
    require (not (OfficeCapabilitySurface.isAllowed "predictor" "fission")) "Predictor passed the office gate"

    createObj
        [ "accepted", box true
          "predictorRoleIsNone", box true
          "oldVersionOneAliasRejected", box true
          "engineerPreserved", box true
          "ownerDerivedIdentityPreserved", box true
          "internalRoundtripPreserved", box true ]
