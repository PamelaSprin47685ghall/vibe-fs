import assert from 'node:assert/strict'
import { after } from 'node:test'
import { mkdirSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

const NativeDate = globalThis.Date
const base = NativeDate.parse(process.env.GAP159_CLOCK_ANCHOR)
assert.ok(Number.isFinite(base))
const started = performance.now()
const now = () => Math.floor(base + performance.now() - started)
function FixtureDate(...args) {
  if (!new.target) return new NativeDate(now()).toString()
  return Reflect.construct(NativeDate, args.length === 0 ? [now()] : args, new.target)
}
Object.setPrototypeOf(FixtureDate, NativeDate)
FixtureDate.prototype = NativeDate.prototype
Object.defineProperty(FixtureDate, 'now', { value: now })
globalThis.Date = FixtureDate
const first = Date.now()
await new Promise(resolve => setTimeout(resolve, 15))
assert.ok(Date.now() > first + 5)
assert.equal(new Date('2001-02-03T04:05:06Z').getTime(), NativeDate.parse('2001-02-03T04:05:06Z'))
assert.equal(Date.parse('2001-02-03T04:05:06Z'), NativeDate.parse('2001-02-03T04:05:06Z'))
assert.equal(Date.UTC(2001, 1, 3), NativeDate.UTC(2001, 1, 3))
assert.ok(new Date() instanceof NativeDate)
assert.equal(typeof Date(), 'string')
const evidence = process.env.GAP159_EVIDENCE
mkdirSync(evidence, { recursive: true })
const before = { nativeNow: NativeDate.now(), anchoredNow: Date.now(), anchor: base, constructorNow: new Date().getTime(), monotonic: performance.now() }
writeFileSync(join(evidence, 'clock-initial.json'), JSON.stringify(before, null, 2) + '\n')
after(() => writeFileSync(join(evidence, 'clock-after-tests.json'), JSON.stringify({ before, after: { nativeNow: NativeDate.now(), anchoredNow: Date.now(), constructorNow: new Date().getTime(), monotonic: performance.now() }, processExitCode: process.exitCode ?? null, restoredDuringPluginLifetime: false }, null, 2) + '\n'))
process.on('exit', code => writeFileSync(join(evidence, 'clock-control.json'), JSON.stringify({ before, after: { nativeNow: NativeDate.now(), anchoredNow: Date.now(), constructorNow: new Date().getTime(), monotonic: performance.now() }, exit: code, restoredDuringPluginLifetime: false, method: 'Process-local Date ambient boundary anchored to fixture date plus unchanged real performance.now elapsed; original explicit Date inputs and real timers retained' }, null, 2) + '\n'))
if (process.env.GAP159_CLOCK_TARGET === 'portable') await import('./portable-fixture-repro.test.mjs')
else await import('./clock-read-fixture.test.mjs')
