import assert from 'node:assert/strict'
import test from 'node:test'
import { createHash } from 'node:crypto'
import { cpSync, mkdirSync, readFileSync, realpathSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const base = dirname(dirname(fileURLToPath(import.meta.url)))
const evidence = process.env.GAP159_EVIDENCE
mkdirSync(evidence, { recursive: true })
assert.equal(realpathSync(fileURLToPath(import.meta.resolve('wanxiangshu'))), realpathSync(join(process.env.GAP159_PRODUCT, 'dist/OpenCode/Plugin/Plugin.js')))
const { default: plugin } = await import('wanxiangshu')
const { withExecutablePlugin, observeAuthority } = await import('./requirements/verification-system/tests/support/plugin-fixture.mjs')
const fixtureFile = '.git/wanxiangshu/events/6501f2cb85a44e099ae21008cb87f83f-0000.ndjson'
const expected = createHash('sha256').update(readFileSync(join(base, 'minimal-mixed', fixtureFile))).digest('hex')

test('actual Plugin retention observes declared anchored physical Date without editing old fixture bytes', async () => {
  await withExecutablePlugin(async (_hooks, directory, ids, runtime) => {
    const views = ['engineer', 'manager', 'predictor'].map(agent => ({ agent, view: observeAuthority(runtime, 'gap159-cold-mixed-predictor-' + agent) }))
    const hash = createHash('sha256').update(readFileSync(join(directory, fixtureFile))).digest('hex')
    writeFileSync(join(evidence, 'retention-result.json'), JSON.stringify({ directory, anchor: process.env.GAP159_CLOCK_ANCHOR, mode: process.env.GAP159_CLOCK_EXPECT, views, fixtureSha256: hash, ids, prompts: runtime.prompts, aborted: runtime.abortedIds }, null, 2) + '\n')
    assert.equal(hash, expected)
    if (process.env.GAP159_CLOCK_EXPECT === 'retained') {
      assert.equal(views[0].view.activeLogicalRun.participantIdentity.role, 'engineer')
      assert.equal(views[1].view.activeLogicalRun.participantIdentity.role, 'manager')
      assert.equal(views[2].view.activeLogicalRun, null)
    } else {
      assert.equal(process.env.GAP159_CLOCK_EXPECT, 'expired')
      for (const item of views) assert.equal(item.view.activeLogicalRun, null)
    }
    assert.deepEqual(ids, [])
    assert.deepEqual(runtime.prompts, [])
    assert.deepEqual(runtime.abortedIds, [])
  }, {}, async input => {
    cpSync(join(base, 'minimal-mixed/.git'), join(input.directory, '.git'), { recursive: true })
    return plugin.server(input)
  })
})
