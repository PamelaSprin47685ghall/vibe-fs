import assert from 'node:assert/strict'
import test from 'node:test'
import { cpSync, mkdirSync, readFileSync, readdirSync, realpathSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const base = dirname(dirname(fileURLToPath(import.meta.url)))
const evidence = process.env.GAP159_EVIDENCE
mkdirSync(evidence, { recursive: true })
const expected = realpathSync(join(process.env.GAP159_PRODUCT, 'dist/OpenCode/Plugin/Plugin.js'))
assert.equal(realpathSync(fileURLToPath(import.meta.resolve('wanxiangshu'))), expected)
const { default: plugin } = await import('wanxiangshu')
const { withExecutablePlugin, observeAuthority } = await import('./requirements/verification-system/tests/support/plugin-fixture.mjs')
const save = (name, value) => writeFileSync(join(evidence, name + '.json'), JSON.stringify(value, null, 2) + '\n')
const session = 'gap159-cold-mixed-predictor-predictor'
const rawEvents = directory => readdirSync(join(directory, '.git/wanxiangshu/events')).map(file => ({ file, text: readFileSync(join(directory, '.git/wanxiangshu/events', file), 'utf8') }))

test('portable old667 actual event fixture must block a fresh Engineer root on its unclosed Predictor session', async () => {
  await withExecutablePlugin(async (hooks, directory, ids, runtime) => {
    const before = rawEvents(directory)
    const views = ['engineer', 'manager', 'predictor'].map(agent => ({ agent, view: observeAuthority(runtime, 'gap159-cold-mixed-predictor-' + agent) }))
    assert.equal(views[0].view.activeLogicalRun.participantIdentity.role, 'engineer')
    assert.equal(views[1].view.activeLogicalRun.participantIdentity.role, 'manager')
    assert.equal(views[2].view.activeLogicalRun, null)
    const output = { message: { id: 'new-portable-engineer-root', sessionID: session, role: 'user', agent: 'engineer', model: { providerID: 'host', modelID: 'placeholder' } }, parts: [{ type: 'text', text: 'Attempt a new Engineer identity on the unclosed old Predictor session.' }] }
    let error = null
    try {
      await hooks['chat.message']({ sessionID: session, agent: 'engineer' }, output)
    } catch (failure) {
      error = { message: failure?.message ?? String(failure), stack: failure?.stack ?? null }
    }
    const fission = await hooks.tool.fission.execute({ prompts: ['lane alpha', 'lane beta'], estimated_readonly_rounds: 0 }, { sessionID: session, agent: 'engineer', callID: 'portable-fission', messageID: 'portable-provider' })
    const after = observeAuthority(runtime, session)
    save('portable-result', { directory, expectedProduct: expected, before, views, output, error, fission, after, afterEvents: rawEvents(directory), ids, prompts: runtime.prompts, aborted: runtime.abortedIds })
    assert.ok(error, 'A fresh Engineer root must be refused while the old Predictor run has no exact closure')
    assert.equal(after.activeLogicalRun, null)
    assert.deepEqual(ids, [])
    assert.deepEqual(runtime.prompts, [])
    assert.deepEqual(runtime.abortedIds, [])
  }, {}, async input => {
    cpSync(join(base, 'minimal-mixed/.git'), join(input.directory, '.git'), { recursive: true })
    return plugin.server(input)
  })
})
