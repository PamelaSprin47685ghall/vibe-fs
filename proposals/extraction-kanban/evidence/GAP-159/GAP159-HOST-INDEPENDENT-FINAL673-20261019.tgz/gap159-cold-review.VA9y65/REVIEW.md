# GAP-159 independent public-entry and cold-history review

This review does not edit shared source or installed product bytes. Production execution uses actual clean installed npm packages, never moving workspace dist. The SDK Host is controlled; no external provider or real model is claimed. The public consumer verifies resolution of npm `wanxiangshu` to the exact installed `dist/OpenCode/Plugin/Plugin.js` and executes that Plugin server and its registered tools.

## Packages and initial public acceptance

- Old667 package SHA256: `b0de9b9770139ae4aa977fae3d8b8d59f2d558cf4ff4a41cf4a1289419743297`.
- Candidate670 package SHA256: `7e7a0edc6e37dd6ec1253162e73cdbf2ecbdc4c07ec4aff7a5bfb022e8bd4ebf`.

The old public baseline is independently archived at `/private/tmp/GAP159-PUBLIC-BASELINE-667-20261019.tgz`. The current `public/public-boundaries.test.mjs` is copied from that exact consumer, changing only its test title, the intentional bad Predictor configuration expectation from allow to deny plus hidden, and placing Predictor in the existing unknown-identity refusal branch. Imports and the legitimate Manager → real fork → Engineer → real Fission path are unchanged. The precise source diff is `public-consumer.diff`.

Candidate670 Node and Bun each complete 3 tests, 0 failure/skip/TODO. Public Predictor selection cannot install authority; unknown and forged Engineer claims remain denied. Manager/DevOps retain their own durable identity. The true positive creates one delegated Engineer session and then two Fission lanes, with three actual session-create and prompt calls. This is an admission positive control, not full GAP-158 lifecycle or historical lane recovery proof.

## Actual old journals and cold boot

One old667 Node process generated two actual workspaces through public `chat.message`, with no codec injection. Healthy contains Engineer and Manager. Mixed contains those identities plus old Predictor-as-Engineer. Hooks were normally disposed before full workspace snapshots were made. The existing fixture then removed its original temporary directories. New probes restore only these self-owned snapshots to those original absolute paths and remove each restored copy afterward.

These are `AuthorityRootAccepted.SchemaVersion=2`, identity catalog version 1 journals. They are not the distinct legacy root-schema1 JSON fixtures. All original root event lines are preserved in `fixtures.json` and the complete snapshots.

One Node and one Bun process per fixture used real candidate670 Plugin boot and config, then read the actual shared journal projection. All four workspaces boot successfully. Healthy Engineer/Manager profiles retain their exact identity, logical run and authority root. Mixed normal profiles also survive, while the old Predictor profile is absent. No SDK method is called during these four boot-only probes.

The actual installed Journal codec separately reads the five original root events once per Host: four normal roots decode; the old Predictor root rejects with `participant identity Role mismatch: expected None, got engineer`. Input JSON bytes remain unchanged. The real Journal integration scopes this semantic failure by `EventStreamId`, so the observation is stream-level authority refusal rather than workspace boot rejection.

Old event-file hashes remain unchanged in boot-only and old-tool probes. Whole-workspace byte equality is intentionally not claimed: normal boot updates `.wanxiangshu/diagnostics/causal-waits.json`, and the mixed fixture also updates `.git/info/exclude`. Each before/after manifest preserves those differences. There are no SDK creates/prompts/aborts/deletes. Two additional finite mixed probes, one per Host, execute actual registered Fission on the old Predictor session using both old Predictor and forged Engineer claims. Both are unestablished; each Host makes two read-only `session.messages` calls and zero physical-effect calls.

## New regression discovered in candidate670

The parent requested one further fresh Node process over an independent restored mixed copy. It attempts a normal public Engineer root on the exact old Predictor SessionId, then Fission and actual projection observation. Candidate670 accepts the new root without a closure of the unknown old logical run. It appends `ProjectionCutTail` naming the old Predictor RoleMismatch, then a new Engineer `AuthorityRootAccepted` and accepted chat execution. The Fission call is stopped only by root origin. No SDK effect occurs, but the authority reuse invariant is red.

The observer intentionally captures this result without turning a process exit code into a green assertion. `new-root-670-red-assertion.log` is the separate explicit safety assertion, with exit 1 because the new Engineer root was not refused. All resulting event lines are saved in `cold-new-root-node/after-event-raw.json`; previous boot-only evidence and original snapshots are untouched.

One identical-source old667 Node run over the same original snapshot provides the before comparison. It rejects the new Engineer public message with `UnknownOriginWhileActive` and retains the exact old Predictor logical run `7948dccf6c8e6b6a24e8cb3e5f3362ff905d723002dfad39badf9a883bddfce8`. This distinguishes the new history-reuse regression caused by the identity tightening from the original wrong Predictor-to-Engineer mapping. It is not a fixture mismatch or review misjudgment.

The test-only fatal-exit switch is identical in both comparisons. Candidate670 records no fatal report and truly commits the new root: the writer tests semantic-cut receipts against the current event ID, while this preexisting cut names the old failed root ID. The failure is not a suppressed fatal that the harness accidentally continued past.

Candidate670 did not pass final acceptance. Its red proof remains. The parent repaired the boundary by refusing a semantic reset when the failed original Journal event cannot be decoded, preserving ordinary cuts for decoded business facts and stream isolation. Fixed673 is verified separately below.

## Fixed673 final verification

Package SHA256 `991c149eb6e310e63db2ab799b0ab0f4573a930056be7855e171f1d333760dde`, actual clean install. The 2076 distributed files match the tar bytes. All 11017 regular installation files and lock files are unchanged before/after this review.

- The same public consumer, with unchanged imports and test source from670, passes Node/Bun 3 tests each. The legal real fork → Engineer → two Fission lanes still succeeds.
- The same portable old-journal safety test that failed on670 passes Node/Bun 1 test each. Its source is byte-identical; only its actual installed product binding changes. It now receives the explicit non-decodable Journal cut refusal, leaves the old session without active authority, and sends zero SDK effects.
- Two original healthy cold journals preserve the full exact Engineer/Manager profiles, one fresh process per Host.
- Two fresh processes over the original mixed journal reject a same-session new Engineer root. The complete old writer NDJSON remains byte-identical. There is no `ProjectionCutTail` and no new authority on the old Predictor session. A normal new RuntimeStarted writer record and setup files may be added; this is not presented as whole-directory immutability.
- The actual normally disposed state after each rejection is retained separately. Another fresh OS process per Host opens that real post-rejection state. Both normal identities remain; an actual public Manager continuation succeeds in the independent healthy stream while preserving its exact old logical run. Old Predictor authority remains absent. No illegal cut and no SDK create/prompt/abort/delete effects occur.

`FINAL673-VERIFICATION.json` and `verify-final.mjs` mechanically check these bounded results, old bytes, original snapshot integrity and sixteen temporary workspace cleanups. The complete prior667 and670 proof, including both explicit red assertions, is not replaced by final green evidence. This accepts only GAP-159's demonstrated identity admission/history isolation scope, not all WHAT017 clauses, complete GAP-158 Fission lifecycle, historical lane replay, or real-model behavior. Legacy root-schema1 is intentionally separate from this real root-schema2 fixture; its broader codec verification belongs to the parent's other review evidence.

## Time-stable portable fixture

`minimal-fixture.tgz` contains only `.git/wanxiangshu/events/6501f2cb85a44e099ae21008cb87f83f-0000.ndjson`: the eight original events, 8030 bytes, SHA256 `a9709c18a6a1a6256f04f0acf384945d002b5904a90dc8f2c4577fc1a8c36ef5`. It overlays an already initialized Git directory before actual Plugin.server through the existing fixture createHooks argument. The archive omits config, hooks, ssh helper, routing HOME and diagnostics. A fresh temporary-directory reproduction on670 gives the exact real regression red; this fixture has not been rebuilt or normalized by the new codec.

ProcessEventLog retention derives last activity from the durable Journal ObservedAt tail and reads Date.now directly. Boot startedAt and the public IClockPort do not control this path. Refreshing mtime does not keep the fixture alive. The declared test control is therefore confined to an independent child before any production import: process-local Date is anchored to 2026-10-18T19:00Z plus unchanged real monotonic elapsed, while explicit Date inputs/parse/UTC and actual timers are preserved. The clock keeps advancing and is never restored during Plugin lifetime. Final adapters round Date.now to integer milliseconds. This is an explicit ambient clock test double, not full physical timing proof.

Node/Bun each verify a retained positive and a 2030 expiry negative on670 with the same unedited fixture bytes. The original normal profiles are present at the fixture-date anchor and absent at the future anchor. The anchored670 safety test remains red, proving the time boundary does not mask the authority defect. The ProcessEventLog implementation is unchanged by the final scope; final673 portable and cold checks retain the anchored clock.

Bun test does not publish its process exit event here. Its initial retention tests passed but final clock receipts were missing; those original outputs remain. Explicit before-import and node:test after observation hooks repaired receipt delivery in two distinct additional Bun runs. They do not change product behavior. The final tests have both clock observations. The clock prototype's original fractional milliseconds are preserved in old receipts; the final adapter's sole rounding correction is documented rather than retroactively editing them.

## Limits and integrity

The private identities and Model configuration slot are intentional; no public Predictor Role or executable compatibility alias is required. Production Strength replica preparation checks the owner's CanonicalRole and issues owner-derived identity, then chooses a model target separately. This review has not invented a historical migration or a full Strength/Fission lifecycle proof.

All 11017 regular candidate670 installation files and locks remain byte-identical across the public and cold probes, as do final673's independent installation files. Symlink paths are bound only in private consumer directories; installed package files are never patched. The archive preserves all raw outputs, scripts, source diffs, old snapshots, post-rejection states, package bytes, manifests and cleanup evidence. Routine full OS process inventory is retained privately and reduced to scoped cleanup results to avoid distributing unrelated local process details; no domain evidence is omitted.

To replay, install the included fixed packages into separate clean roots using the included manifest/lock or equivalent exact peer versions. Recreate each private consumer directory's node_modules/dist symlinks against its declared product. Generate the initial private routing HOME using the unchanged routing helper before importing production. `final-public/anchored-clock-launch.test.mjs` runs the portable test with `GAP159_CLOCK_TARGET=portable`; `final-new/clock-boot.mjs` runs the selected bounded boot probe. Set GAP159_PRODUCT and GAP159_EVIDENCE explicitly. Never extract a fixture over a live user workspace. Existing original absolute fixture directories must be absent before the recorded full-snapshot restore scripts run.
