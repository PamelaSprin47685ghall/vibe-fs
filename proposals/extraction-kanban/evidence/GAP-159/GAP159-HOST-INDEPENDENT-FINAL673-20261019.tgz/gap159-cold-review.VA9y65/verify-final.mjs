import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { existsSync, readFileSync, readdirSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const base = dirname(fileURLToPath(import.meta.url))
const read = path => JSON.parse(readFileSync(join(base, path), 'utf8'))
const sha = bytes => createHash('sha256').update(bytes).digest('hex')
const digest = root => {
  const files = {}
  const scan = (directory, prefix = '') => {
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
      const path = join(directory, entry.name)
      const key = prefix ? prefix + '/' + entry.name : entry.name
      if (entry.isDirectory()) scan(path, key)
      else if (entry.isFile()) files[key] = sha(readFileSync(path))
    }
  }
  scan(root)
  return files
}
const original = read('fixtures.json')
for (const fixture of original.fixtures) assert.deepEqual(digest(fixture.snapshot), fixture.hashes)
const installed = digest('/private/tmp/gap159-clean-install-673')
assert.deepEqual(installed, read('673-installed-before.json'))
writeFileSync(join(base, '673-installed-after.json'), JSON.stringify(installed, null, 2) + '\n')
const eventFile = '6501f2cb85a44e099ae21008cb87f83f-0000.ndjson'
const originalBytes = readFileSync(join(base, 'minimal-mixed/.git/wanxiangshu/events', eventFile), 'utf8')
const checked = []
const directories = new Set()
for (const host of ['node', 'bun']) {
  for (const agent of ['predictor', 'unknown-helper', 'engineer']) {
    const result = read('final673-public-' + host + '/root-' + agent + '.json')
    directories.add(result.directory)
    assert.deepEqual(result.before, result.after)
    assert.deepEqual(result.filesBefore, result.filesAfter)
    if (agent !== 'engineer') {
      assert.ok(result.message.error)
      assert.equal(result.authority.activeLogicalRun, null)
    }
  }
  for (const agent of ['manager', 'devops']) {
    const result = read('final673-public-' + host + '/forged-' + agent + '.json')
    directories.add(result.directory)
    assert.deepEqual(result.before, result.after)
    assert.deepEqual(result.filesBefore, result.filesAfter)
  }
  const legal = read('final673-public-' + host + '/legal-engineer.json')
  directories.add(legal.directory)
  assert.match(legal.result, /status\s*=\s*"fissioned"/)
  assert.equal(legal.effects.created, 3)
  assert.equal(legal.effects.prompts, 3)
  const portable = read('final673-portable-' + host + '/portable-result.json')
  directories.add(portable.directory)
  assert.ok(portable.error)
  assert.equal(portable.after.activeLogicalRun, null)
  assert.equal(portable.before.find(file => file.file === eventFile).text, originalBytes)
  assert.equal(portable.afterEvents.find(file => file.file === eventFile).text, originalBytes)
  assert.deepEqual(portable.ids, [])
  assert.deepEqual(portable.prompts, [])
  assert.deepEqual(portable.aborted, [])
  for (const group of ['cold-new-root', 'restart']) {
    const directory = 'final673-' + group + '-' + host
    const result = read(directory + '/result.json')
    directories.add(result.originalDirectory)
    assert.equal(result.error, null)
    assert.equal(result.disposeError, null)
    assert.deepEqual(result.effects, [])
    const raw = read(directory + '/after-event-raw.json')
    assert.equal(raw.find(file => file.file === eventFile).text, originalBytes)
    const events = raw.flatMap(file => file.text.trimEnd().split('\n').filter(Boolean).map(JSON.parse))
    assert.equal(events.some(event => event.event_type === 'ProjectionCutTail'), false)
    if (group === 'cold-new-root') {
      assert.ok(result.newRoot.chatError)
      assert.equal(result.newRoot.after.activeLogicalRun, null)
    } else {
      assert.equal(result.healthyContinuation.error, null)
      assert.equal(result.healthyContinuation.oldPredictor.activeLogicalRun, null)
      assert.equal(result.healthyContinuation.authority.activeLogicalRun.logicalRun, '44e961ac739c03bc67b3bb5c5e4916208cc3774664f4be2e137bb0321427dfef')
    }
    checked.push({ directory, originalEventUnchanged: true, noIllegalCut: true, sdkEffects: 0, error: null })
  }
  const healthy = read('final673-cold-healthy-' + host + '/result.json')
  directories.add(healthy.originalDirectory)
  assert.equal(healthy.error, null)
  assert.deepEqual(healthy.calls, [])
  for (const view of healthy.authority) {
    const old = original.fixtures.find(fixture => fixture.name === 'healthy').observations.find(item => item.agent === view.agent)
    assert.deepEqual(view.current.activeLogicalRun, old.authority.activeLogicalRun)
  }
}
const workspaces = [...directories].map(directory => ({ directory, exists: existsSync(directory) }))
assert.equal(workspaces.some(item => item.exists), false)
const summary = { fixedPackage: '673', publicTests: { node: 3, bun: 3, failure: 0, skip: 0, todo: 0 }, portableRegression: { node: 1, bun: 1, failure: 0, skip: 0, todo: 0 }, freshOsCases: { healthy: 2, rejectNewRoot: 2, restartHealthyContinuation: 2 }, checked, oldFixtureSha256: sha(originalBytes), originalSnapshotsUnchanged: true, installedRegularFiles: Object.keys(installed).length, installedFilesUnchanged: true, workspaces }
writeFileSync(join(base, 'FINAL673-VERIFICATION.json'), JSON.stringify(summary, null, 2) + '\n')
console.log(JSON.stringify({ ...summary, workspaces: workspaces.length, checked: checked.length }))
