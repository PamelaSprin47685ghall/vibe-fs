import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { cpSync, mkdirSync, readFileSync, readdirSync, realpathSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const base = dirname(dirname(fileURLToPath(import.meta.url)))
const expected = '/private/tmp/gap085-clean-install-667/node_modules/wanxiangshu'
assert.equal(realpathSync(fileURLToPath(import.meta.resolve('wanxiangshu'))), realpathSync(join(expected, 'dist/OpenCode/Plugin/Plugin.js')))
const { withRestartablePlugin, observeAuthority } = await import('./requirements/verification-system/tests/support/plugin-fixture.mjs')
const fixtures = []
const digest = directory => {
  const files = {}
  const visit = (parent, prefix = '') => {
    for (const entry of readdirSync(parent, { withFileTypes: true })) {
      const path = join(parent, entry.name)
      const key = prefix ? prefix + '/' + entry.name : entry.name
      if (entry.isDirectory()) visit(path, key)
      else if (entry.isFile()) files[key] = createHash('sha256').update(readFileSync(path)).digest('hex')
    }
  }
  visit(directory)
  return files
}
for (const [name, agents] of [['healthy', ['engineer', 'manager']], ['mixed-predictor', ['engineer', 'manager', 'predictor']]]) {
  await withRestartablePlugin(async (start, directory, runtime) => {
    const hooks = await start()
    const observations = []
    for (const agent of agents) {
      const sessionID = 'gap159-cold-' + name + '-' + agent
      const output = {
        message: { id: 'msg-' + sessionID, role: 'user', sessionID, agent, model: { providerID: 'host', modelID: 'placeholder' }, tools: { fission: true } },
        parts: [{ type: 'text', text: 'Retain this exact old identity journal for a cold-start review.' }],
      }
      await hooks['chat.message']({ sessionID, agent }, output)
      const authority = await runtime.withRuntime(inner => observeAuthority(inner, sessionID))
      assert.ok(authority.activeLogicalRun)
      assert.equal(authority.activeLogicalRun.participantIdentity.role, agent === 'predictor' ? 'engineer' : agent)
      observations.push({ agent, sessionID, output, authority })
    }
    assert.deepEqual(runtime.createdIds, [])
    assert.deepEqual(runtime.prompts, [])
    assert.deepEqual(runtime.abortedIds, [])
    await runtime.stop(hooks)
    const snapshot = join(base, 'snapshots', name)
    mkdirSync(dirname(snapshot), { recursive: true })
    cpSync(directory, snapshot, { recursive: true, preserveTimestamps: true })
    const eventsDirectory = join(snapshot, '.git/wanxiangshu/events')
    const roots = readdirSync(eventsDirectory).flatMap(file => readFileSync(join(eventsDirectory, file), 'utf8').split('\n').filter(Boolean).map(line => ({ file, line, event: JSON.parse(line) }))).filter(item => item.event.payload?.Fact?.[0] === 'Agent' && item.event.payload.Fact?.[1]?.[0] === 'Prompt' && item.event.payload.Fact?.[1]?.[1]?.[0] === 'AuthorityRootAccepted')
    assert.equal(roots.length, agents.length)
    for (const item of roots) assert.equal(item.event.payload.Fact[1][1][1].SchemaVersion, 2)
    fixtures.push({ name, originalDirectory: directory, snapshot, observations, rawAuthorityRoots: roots, hashes: digest(snapshot), effects: { created: runtime.createdIds, prompts: runtime.prompts, aborted: runtime.abortedIds } })
  })
}
writeFileSync(join(base, 'fixtures.json'), JSON.stringify({ oldProduct: expected, schema: 'AuthorityRootAccepted schema2, identity catalog1; not legacy root-schema1', fixtures }, null, 2) + '\n')
console.log(JSON.stringify({ generated: fixtures.map(({ name, originalDirectory, hashes }) => ({ name, originalDirectory, files: Object.keys(hashes).length })), publicExport: import.meta.resolve('wanxiangshu') }))
