import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { cpSync, existsSync, mkdirSync, readFileSync, readdirSync, realpathSync, rmSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const base = dirname(dirname(fileURLToPath(import.meta.url)))
const name = process.argv[2]
const evidence = process.env.GAP159_EVIDENCE
const fixtures = JSON.parse(readFileSync(join(base, 'fixtures.json'), 'utf8'))
const fixture = fixtures.fixtures.find(item => item.name === name)
assert.ok(fixture)
const directory = fixture.originalDirectory
assert.equal(existsSync(directory), false, 'Do not overwrite any live original workspace')
cpSync(fixture.snapshot, directory, { recursive: true, preserveTimestamps: true })
mkdirSync(evidence, { recursive: true })
const save = (file, value) => writeFileSync(join(evidence, file + '.json'), JSON.stringify(value, null, 2) + '\n')
const digest = root => {
  const files = {}
  const visit = (parent, prefix = '') => {
    for (const entry of readdirSync(parent, { withFileTypes: true })) {
      const path = join(parent, entry.name)
      const key = prefix ? prefix + '/' + entry.name : entry.name
      if (entry.isDirectory()) visit(path, key)
      else if (entry.isFile()) files[key] = createHash('sha256').update(readFileSync(path)).digest('hex')
    }
  }
  visit(root)
  return files
}
const calls = []
const method = (name, result) => async args => {
  calls.push({ name, args })
  return result(args)
}
const client = { session: {
  create: method('session.create', () => ({ data: { id: 'unexpected-boot-child' } })),
  get: method('session.get', args => ({ data: { id: args?.path?.id } })),
  list: method('session.list', () => ({ data: [] })),
  children: method('session.children', () => ({ data: [] })),
  messages: method('session.messages', () => ({ data: [] })),
  promptAsync: method('session.promptAsync', () => ({})),
  prompt: method('session.prompt', () => ({})),
  delete: method('session.delete', () => ({})),
  abort: method('session.abort', () => ({})),
} }
const before = digest(directory)
assert.deepEqual(before, fixture.hashes)
save('before', before)
process.env.HOME = join(directory, 'routing-home')
process.env.USERPROFILE = process.env.HOME
process.env.WANXIANGSHU_PROVIDER_LANGUAGE = 'en'
process.env.WANXIANGSHU_NO_FATAL_EXIT = '1'
let hooks = null
let stage = 'public-module-import'
let error = null
let authority = null
try {
  const publicExport = realpathSync(fileURLToPath(import.meta.resolve('wanxiangshu')))
  assert.equal(publicExport, realpathSync(join(process.env.GAP159_PRODUCT, 'dist/OpenCode/Plugin/Plugin.js')))
  save('public-export', { publicExport, host: process.execPath, product: process.env.GAP159_PRODUCT })
  const { default: plugin } = await import('wanxiangshu')
  stage = 'plugin.server-boot'
  hooks = await plugin.server({ client, directory, events: { listen: () => () => {} } })
  stage = 'plugin.config'
  await hooks.config({ agent: {} })
  stage = 'read-normal-authorities'
  const workspace = await import('./dist/OpenCode/Host/WorkspaceSharedJournal.js')
  const journal = await import('./dist/Persistence/Journal/Surface.js')
  const dispatch = await import('./dist/Interaction/Dispatch/DispatchSurface.js')
  const acquired = await workspace.acquireSharedForWorkspace(directory, process.pid, new Date().toISOString())
  assert.equal(acquired.ok, true)
  try {
    authority = fixture.observations.map(item => ({ agent: item.agent, sessionID: item.sessionID, current: dispatch.projectionObservation(acquired.journal, item.sessionID) }))
  } finally {
    journal.JournalSurface_dispose(acquired.journal)
  }
  stage = 'boot-and-config-complete'
} catch (failure) {
  error = { name: failure?.name, message: failure?.message ?? String(failure), stack: failure?.stack ?? null }
} finally {
  const afterBoot = digest(directory)
  save('after-boot', afterBoot)
  const changed = [...new Set([...Object.keys(before), ...Object.keys(afterBoot)])].filter(key => before[key] !== afterBoot[key])
  let disposeError = null
  try {
    if (hooks) await hooks.dispose()
  } catch (failure) {
    disposeError = { message: failure?.message ?? String(failure), stack: failure?.stack ?? null }
  }
  const afterDispose = digest(directory)
  save('after-dispose', afterDispose)
  const effects = calls.filter(call => ['session.create', 'session.promptAsync', 'session.prompt', 'session.delete', 'session.abort'].includes(call.name))
  save('result', { name, originalDirectory: directory, schema: fixtures.schema, stage, error, authority, calls, effects, changedDuringBoot: changed, changedAfterDispose: [...new Set([...Object.keys(before), ...Object.keys(afterDispose)])].filter(key => before[key] !== afterDispose[key]), disposeError })
  rmSync(directory, { recursive: true, force: true })
  save('cleanup', { directory, exists: existsSync(directory) })
}
console.log(JSON.stringify({ name, stage, error, sdkCalls: calls.length, effects: calls.filter(call => ['session.create', 'session.promptAsync', 'session.prompt', 'session.delete', 'session.abort'].includes(call.name)).length }))
