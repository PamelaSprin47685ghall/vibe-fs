import assert from 'node:assert/strict'
import { mkdirSync, readFileSync, realpathSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const base = dirname(dirname(fileURLToPath(import.meta.url)))
const evidence = process.env.GAP159_EVIDENCE
mkdirSync(evidence, { recursive: true })
const product = realpathSync(fileURLToPath(import.meta.resolve('wanxiangshu')))
assert.equal(product, realpathSync(join(process.env.GAP159_PRODUCT, 'dist/OpenCode/Plugin/Plugin.js')))
const codec = await import('./dist/Persistence/Journal/CodecSurface.js')
const fixtures = JSON.parse(readFileSync(join(base, 'fixtures.json'), 'utf8'))
const results = fixtures.fixtures.flatMap(fixture => fixture.rawAuthorityRoots.map(raw => {
  const event = raw.event
  const input = { eventId: event.event_id, streamId: event.stream_id, eventType: event.event_type, parents: event.parents, payload: event.payload, payloadRefs: event.payload_refs }
  const before = JSON.stringify(input)
  const result = codec.decode(input)
  assert.equal(JSON.stringify(input), before)
  const predictor = event.payload.Fact[1][1][1].IdentitySeed[1].SelectedAgent === 'predictor'
  assert.equal(result.ok, !predictor)
  if (predictor) assert.match(result.error, /Role mismatch: expected None, got engineer/)
  return { fixture: fixture.name, input, result }
}))
writeFileSync(join(evidence, 'raw-root-decode.json'), JSON.stringify({ product, host: process.execPath, results }, null, 2) + '\n')
console.log(JSON.stringify({ decoded: results.length, rejected: results.filter(item => !item.result.ok).length }))
