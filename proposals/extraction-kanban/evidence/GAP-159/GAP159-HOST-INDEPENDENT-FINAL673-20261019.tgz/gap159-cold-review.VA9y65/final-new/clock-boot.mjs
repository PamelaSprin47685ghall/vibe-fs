import assert from 'node:assert/strict'
import { mkdirSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

const NativeDate = globalThis.Date
const base = NativeDate.parse('2026-10-18T19:00:00Z')
const started = performance.now()
const now = () => Math.floor(base + performance.now() - started)
function FixtureDate(...args) {
  if (!new.target) return new NativeDate(now()).toString()
  return Reflect.construct(NativeDate, args.length === 0 ? [now()] : args, new.target)
}
Object.setPrototypeOf(FixtureDate, NativeDate)
FixtureDate.prototype = NativeDate.prototype
Object.defineProperty(FixtureDate, 'now', { value: now })
globalThis.Date = FixtureDate
const target = process.env.GAP159_BOOT_TARGET
assert.ok(['boot', 'boot-with-new-root', 'boot-after-rejection'].includes(target))
mkdirSync(process.env.GAP159_EVIDENCE, { recursive: true })
const before = { nativeNow: NativeDate.now(), wallNow: Date.now(), constructorNow: new Date().getTime(), monotonic: performance.now() }
try {
  await import('./' + target + '.mjs')
} finally {
  writeFileSync(join(process.env.GAP159_EVIDENCE, 'clock-control.json'), JSON.stringify({ before, after: { nativeNow: NativeDate.now(), wallNow: Date.now(), constructorNow: new Date().getTime(), monotonic: performance.now() }, base, restoredDuringPluginLifetime: false, method: 'Separate process, anchored integer wall milliseconds plus actual monotonic elapsed; real timers and explicit Date inputs retained' }, null, 2) + '\n')
}
