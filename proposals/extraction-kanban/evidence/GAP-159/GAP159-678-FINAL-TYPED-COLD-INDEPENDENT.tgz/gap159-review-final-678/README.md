# GAP-159 final678 independent acceptance

Final fixed clean-installed candidate: wanxiangshu0.9.0 generation678, library wanxiangli0.6.12 unchanged.

Package SHA256: `6d986c23419a4fdae8dae4bcd6bce64f1c2ce0eae87bf798d07ea96544913335`.

Actual runtimes: Node26.6.0 and Bun1.3.14. This reviewer did not implement the identity/config/kernel changes and did not edit shared source or tests.

## Final conclusions

- The exact real667 producer history that exposed the673 regression is now safely refused on Node and Bun. The unchanged673 observation program, rebound only to678, now returns requested.ok=false.
- For the stronger contract probe, each Host uses two sequential independent OS processes over the same retained source. Both cold boots refuse replacement in the blocked session. Each first admits an unrelated healthy scope through the actual dispatcher. The subsequent refused request adds no event, cut or writer bytes: every writer's before/after bytes are exactly equal. The next OS process observes the preceding healthy root, proving that preserving the blocked scope does not black out healthy scopes.
- A second genuine667 history is a same-event cut positive: two concurrently issued valid production HumanRoot requests, Engineer first and Predictor second, were serialized by the real writer. The second root failed the active-run invariant and received its own cut. Under678 on both Hosts and across two OS processes, the earlier good Engineer root is preserved, a replacement without closure remains denied, and unrelated healthy scopes work. This confirms that the guard keeps the existing same-event cut policy; it does not reject every legacy cut merely because decoding policy changed.
- Both original source files are byte-exact throughout. Their SHA256 hashes are `7a6ca9b312e0bb1b38546b521dc06390a7716bd56c4adf71903318105a3f0008` (accepted Predictor then later HandleLinked conflict/cut) and `51577bb621c510efd797db610b352071bb4aa00ddb8a40a8cb8d3cc8327d94fb` (earlier good Engineer, failed Predictor and matching cut). No fact or cut was manually written or modified.
- The unchanged670 Fable-emitted consumer, SHA256 `28ef5a606aa064225ae198a240a46e14ceddd9adf8311c3fdb0429521bb060dc`, runs successfully against678 under Node and Bun. Its eight real .fsi contracts match byte-for-byte. There are zero new compilations in this final step. The genuine670 positive compilation and three intended negative compilation results are retained under670-contract-evidence. No npm d.ts or new public npm export is claimed. Previously generated production implementations are absent from runtime staging; only the installed package supplies runtime production modules.
- The natural consumer still proves private Predictor identity, office denial, hidden Host model slot, preserved caller model fields, Engineer Fission, idempotent configuration and actual owner-issued Engineer lineage.
- The original EMR020 seven cases and Strength003 thirteen cases pass on Node20/20 and Bun20/20, with zero skip/TODO. Their bodies are unchanged, and dist/resources bind to this clean-installed package only. These finite native consumer tests do not replace the root's formal supervised related requirement suite or the separate public Host/journal review.
- All2904 installed product files match throughout initial and corrected runs; the archive hash is unchanged. Runtime/compiler staging directories were removed. Child close statuses show no timeout/cleanup signal on accepted probes; retained cold writer directories are evidence, not leaked running processes. No extra independent product-descendant sampling is claimed.

## Regression provenance

The original673 issue is a regression introduced during this uncommitted GAP159 repair, not an original module-extraction defect and not a hypothetical forged-history concern. PlanCut prevented new unreadable Journal cuts but cold replay applied an already-persisted cut by scope alone. A genuine later HandleLinked cut could remove a new earlier Predictor decode fault with a different event identity. The fixed kernel keeps the fault whenever its failed event does not equal the cut's failed_event_id.

`673-real-old-producer-red.tgz` is the previously frozen red archive, SHA256 `1eae021db8ad3c646a2ce0917d4e10507c677d32429d04e2b57bcbef16288ece`. It retains667's refusal and673's wrongful acceptance. The final green never overwrites that archive.

## Reviewer fixture errors retained

The initial670 natural probe passed lowercase fission to an interface requiring Fission. The Engineer positive correctly refused that unknown label. The corrected670 run uses canonical labels; both original and corrected evidence are available in the earlier full670 archive, SHA256 `bb46fbf2c819860f33e822cc16dcc01f93f47d9ae8caf4c53c2e9b53298ab0a7`.

During final678's first run, the same-event probe compared a whole session observation captured before a separate healthy-scope admission. That admission legitimately appends one lazy RuntimeStarted, changing the global runtimeStartCount from1 to2 without changing the earlier identity. The raw failure is retained under678-initial. The corrected probe captures the baseline after healthy admission, explicitly asserts the legitimate count increase is exactly one, then verifies the refused root changes no observation or bytes. This was a reviewer fixture error, not a product regression.

Already-passed Node typed/natural/20-case/blocked-two-OS runs were not repeated after that correction. Completion records point to those exact initial runs; only the affected same-event probe and previously unexecuted Bun/original-observer runs were executed. Counts are not added across attempts or treated as extra coverage.

## Portable replay

Install the retained exact final tarball in a fresh directory using normal declared dependencies/install permissions and its package lock. The source repository is needed only to verify that the eight actual F# signatures match the earlier real compilation. There is no source implementation runtime fallback.

The retained portable runner is the executed runner with only three evidence/repository directory defaults made configurable. It passes node --check; that path-parameter change is not counted as another product run. The actual executed scripts, raw commands and outputs remain under678-initial and678-completion.

From this extracted directory, with absolute paths:

```sh
GAP159_PRIOR_EVIDENCE=/absolute/archive/670-contract-evidence \
GAP159_PRODUCER_EVIDENCE=/absolute/archive/real667 \
GAP159_REPOSITORY=/absolute/source-repository \
node portable-runner.mjs /absolute/clean/node_modules/wanxiangshu /absolute/archive/wanxiangshu-0.9.0.tgz 6d986c23419a4fdae8dae4bcd6bce64f1c2ce0eae87bf798d07ea96544913335 /absolute/new-evidence
```

Do not set GAP159_COMPLETED_NODE_EVIDENCE for a fresh portable replay. That option only records the documented partial-run continuation used here. The original20 fixture hashes must match the repository; copies are retained. Both historical source fixtures and their real producer scripts are underreal667. To regenerate them, run its run.mjs/run-same-event.mjs with the exact667 package in versions-and-packages.json, never with the new identity policy. The source bytes retained here are the fixed acceptance inputs and can be reused without regeneration.

R12-U1, the whole GAP158 lifecycle, generic forged-cut authentication and Bun formal supervision are outside this conclusion. The original cut protocol is not promoted into a new authentication boundary.
