import assert from 'node:assert/strict'
import fs from 'node:fs'
import { join, relative, resolve, dirname } from 'node:path'
import { createHash } from 'node:crypto'
import { spawn } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const [product, archive, expectedArchive, evidence] = process.argv.slice(2)
const probes = dirname(fileURLToPath(import.meta.url))
const prior = resolve(process.env.GAP159_PRIOR_EVIDENCE || '/private/tmp/gap159-independent-670-corrected')
const red = resolve(process.env.GAP159_PRODUCER_EVIDENCE || '/private/tmp/gap159-old-producer-cut')
const repository = resolve(process.env.GAP159_REPOSITORY || '/Users/yuanxi/Workwork/vibe-fs')
const completedNodeEvidence = process.env.GAP159_COMPLETED_NODE_EVIDENCE
const scratch = fs.mkdtempSync('/private/tmp/gap159-final-678-work-')
const hash = file => createHash('sha256').update(fs.readFileSync(file)).digest('hex')
fs.mkdirSync(evidence, { recursive: true })
const save = (name, value) => fs.writeFileSync(join(evidence, name), JSON.stringify(value, null, 2))
const files = root => {
  const result = {}
  const visit = directory => {
    for (const name of fs.readdirSync(directory).sort()) {
      const path = join(directory, name)
      const status = fs.lstatSync(path)
      assert.equal(status.isSymbolicLink(), false, path)
      if (status.isDirectory()) visit(path)
      else result[relative(root, path)] = hash(path)
    }
  }
  visit(root)
  return result
}
const execute = async (name, executable, args, cwd, expectedCode = 0) => {
  const stdout = fs.openSync(join(evidence, `${name}.stdout`), 'w')
  const stderr = fs.openSync(join(evidence, `${name}.stderr`), 'w')
  const env = { ...process.env, HOME: join(cwd, 'home'), USERPROFILE: join(cwd, 'home') }
  fs.mkdirSync(env.HOME, { recursive: true })
  delete env.NODE_TEST_CONTEXT
  delete env.NODE_OPTIONS
  delete env.WANXIANGSHU_NO_FATAL_EXIT
  save(`${name}.command.json`, { executable, args, cwd, HOME: env.HOME, expectedCode })
  const child = spawn(executable, args, { cwd, env, detached: true, stdio: ['ignore', stdout, stderr] })
  let timedOut = false
  const timer = setTimeout(() => {
    timedOut = true
    try { process.kill(-child.pid, 'SIGKILL') } catch (error) { if (error.code !== 'ESRCH') throw error }
  }, 30000)
  const status = await new Promise((done, reject) => {
    child.once('error', reject)
    child.once('close', (code, signal) => done({ code, signal, pid: child.pid, timedOut }))
  })
  clearTimeout(timer)
  fs.closeSync(stdout)
  fs.closeSync(stderr)
  save(`${name}.status.json`, status)
  assert.equal(status.timedOut, false, name)
  assert.equal(status.code, expectedCode, fs.readFileSync(join(evidence, `${name}.stderr`), 'utf8'))
  return status
}
console.log(JSON.stringify({ product, archive, expectedArchive, evidence, scratch }))
try {
  assert.equal(hash(archive), expectedArchive)
  const before = files(product)
  if (completedNodeEvidence) assert.deepEqual(before, JSON.parse(fs.readFileSync(join(completedNodeEvidence, 'products-before.json'))))
  save('products-before.json', before)
  const originalInputs = JSON.parse(fs.readFileSync(join(prior, 'real-compile-inputs.json')))
  const signatures = Object.fromEntries(Object.entries(originalInputs).filter(([name]) => name.endsWith('.fsi')))
  for (const [name, expected] of Object.entries(signatures)) {
    const path = join(repository, 'src/Wanxiangshu', name)
    assert.equal(hash(path), expected, name)
    const target = join(evidence, 'same-fsi', name)
    fs.mkdirSync(dirname(target), { recursive: true })
    fs.copyFileSync(path, target)
  }
  save('unchanged-fsi.json', signatures)
  const runtime = join(scratch, 'runtime')
  fs.mkdirSync(runtime)
  fs.writeFileSync(join(runtime, 'package.json'), JSON.stringify({ name: 'gap159-final-typed-consumer', type: 'module' }))
  for (const name of ['GAP159TypedConsumer.js', 'typed-driver.mjs']) {
    fs.copyFileSync(join(prior, name), join(runtime, name))
    fs.copyFileSync(join(prior, name), join(evidence, name))
  }
  const emittedSHA = hash(join(runtime, 'GAP159TypedConsumer.js'))
  assert.equal(emittedSHA, '28ef5a606aa064225ae198a240a46e14ceddd9adf8311c3fdb0429521bb060dc')
  fs.symlinkSync(join(product, 'dist/Foundation'), join(runtime, 'Foundation'))
  fs.symlinkSync(join(product, 'dist/Participant'), join(runtime, 'Participant'))
  fs.symlinkSync(join(product, 'dist/fable_modules'), join(scratch, 'fable_modules'))
  const stage = join(scratch, 'stage')
  fs.mkdirSync(stage)
  fs.symlinkSync(join(product, 'dist'), join(stage, 'dist'))
  fs.symlinkSync(join(product, 'resources'), join(stage, 'resources'))
  const tests = ['requirements/execution-model-routing/tests/020.test.mjs', 'requirements/speculative-investigation/tests/003.test.mjs']
  for (const file of tests) {
    const path = join(stage, file)
    fs.mkdirSync(dirname(path), { recursive: true })
    fs.copyFileSync(join(prior, file), path)
    assert.equal(hash(path), hash(join(repository, file)))
    const retained = join(evidence, file)
    fs.mkdirSync(dirname(retained), { recursive: true })
    fs.copyFileSync(path, retained)
  }
  const results = []
  for (const [host, executable] of [['node', process.execPath], ['bun', 'bun']]) {
    const cwd = join(scratch, host)
    fs.mkdirSync(cwd)
    if (host === 'node' && completedNodeEvidence) {
      const completed = ['node-typed', 'node-natural', 'node-existing-consumers', 'node-blocked-one', 'node-blocked-two']
      for (const name of completed) {
        const status = JSON.parse(fs.readFileSync(join(completedNodeEvidence, `${name}.status.json`)))
        assert.equal(status.code, 0, name)
        assert.equal(status.timedOut, false, name)
      }
      results.push({ host, reusedCompletedRuns: completed, from: completedNodeEvidence, repeatedRuns: 0 })
    } else {
      results.push({ host, typed: await execute(`${host}-typed`, executable, [join(runtime, 'typed-driver.mjs')], cwd) })
      results.push({ host, natural: await execute(`${host}-natural`, executable, [join(prior, 'consumer-probe.mjs'), product], cwd) })
      const args = host === 'node' ? ['--test', ...tests.map(file => join(stage, file))]
        : ['test', ...tests.map(file => join(stage, file))]
      results.push({ host, existingTests: await execute(`${host}-existing-consumers`, executable, args, cwd) })
    }
    for (const mode of ['blocked', 'matching']) {
      if (host === 'node' && mode === 'blocked' && completedNodeEvidence) continue
      const name = `${host}-${mode}`
      const root = join(evidence, name)
      const original = mode === 'blocked' ? 'evidence-667' : 'evidence-same-event-667'
      fs.mkdirSync(root)
      fs.cpSync(join(red, original, '.git'), join(root, '.git'), { recursive: true })
      for (const phase of ['one', 'two']) {
        results.push({ host, mode, phase, contract: await execute(`${name}-${phase}`, executable,
          [join(probes, 'cold-contract.mjs'), product, join(root, '.git'), mode, phase], cwd) })
      }
    }
    const originalRoot = join(evidence, `${host}-original-observer`)
    fs.mkdirSync(originalRoot)
    fs.cpSync(join(red, 'evidence-667/.git'), join(originalRoot, '.git'), { recursive: true })
    results.push({ host, original673Program: await execute(`${host}-original-observer`, executable,
      [join(red, 'observe.mjs'), product, join(originalRoot, '.git'), 'final678-original-observer'], cwd) })
    const observed = JSON.parse(fs.readFileSync(join(evidence, `${host}-original-observer.stdout`)))
    assert.equal(observed.requested.ok, false, 'The unchanged673 observer must now report root refusal')
    assert.equal(observed.originalBytesPreserved, true)
  }
  assert.deepEqual(files(product), before)
  assert.equal(hash(archive), expectedArchive)
  save('products-after.json', files(product))
  save('summary.json', { accepted: true, expectedArchive, emittedSHA256: emittedSHA,
    newCompilations: 0, priorPositiveCompilation: 1, priorNegativeCompilations: 3,
    unchangedRealFsi: Object.keys(signatures), results, installedProductUnchanged: true,
    scope: 'Final fixed678 package only. Reuses the actual670 emitted consumer, does not count new type compilation. Original20 EMR/Strength bodies unchanged. Two real667 histories consumed through two sequential OS processes per mode and Host; authentic673 observer repeated unchanged. Healthy scope and same-event cut preserved. Runtime symlinks point only to installed product dist/resources.' })
} catch (error) {
  save('harness-error.json', { message: error.message, stack: error.stack })
  process.exitCode = 1
} finally {
  for (const path of [fileURLToPath(import.meta.url), join(probes, 'cold-contract.mjs')]) fs.copyFileSync(path, join(evidence, path.split('/').at(-1)))
  fs.copyFileSync(join(red, 'observe.mjs'), join(evidence, 'original-673-observe.mjs'))
  fs.copyFileSync(join(prior, 'consumer-probe.mjs'), join(evidence, 'consumer-probe.mjs'))
  fs.rmSync(scratch, { recursive: true, force: true })
  save('cleanup.json', { scratchRemoved: !fs.existsSync(scratch), productPreserved: fs.existsSync(product),
    scope: 'Native CLI child close status recorded; no timeout/cleanup signal on success. Private runtime staging removed; real historical/cold writer bytes retained as evidence.' })
}
