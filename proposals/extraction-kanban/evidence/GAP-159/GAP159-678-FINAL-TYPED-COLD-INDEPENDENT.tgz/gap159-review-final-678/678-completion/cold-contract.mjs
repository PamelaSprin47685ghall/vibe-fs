import assert from 'node:assert/strict'
import fs from 'node:fs'
import { join } from 'node:path'
import { createHash } from 'node:crypto'
import { pathToFileURL } from 'node:url'

const [product, commonDir, mode, phase] = process.argv.slice(2)
const load = path => import(pathToFileURL(join(product, 'dist', path)).href)
const [journal, dispatch] = await Promise.all([
  load('Persistence/Journal/Surface.js'), load('Interaction/Dispatch/DispatchSurface.js'),
])
const sourceName = mode === 'blocked' ? 'supported667-producer-0000.ndjson' : 'supported667-same-event-0000.ndjson'
const source = join(commonDir, 'wanxiangshu/events', sourceName)
const sourceBytes = fs.readFileSync(source)
const expectedSource = mode === 'blocked'
  ? '7a6ca9b312e0bb1b38546b521dc06390a7716bd56c4adf71903318105a3f0008'
  : '51577bb621c510efd797db610b352071bb4aa00ddb8a40a8cb8d3cc8327d94fb'
const hash = bytes => createHash('sha256').update(bytes).digest('hex')
assert.equal(hash(sourceBytes), expectedSource)
const session = mode === 'blocked' ? 'supported667-predictor-session' : 'supported667-same-event-session'
const writer = `final678-${mode}-${phase}`
const opened = await journal.JournalSurface_bootWithWriterId(commonDir, writer,
  `final678-runtime-${phase}`, process.pid, new Date().toISOString())
assert.equal(opened.ok, true, JSON.stringify(opened.error))
const snapshotFiles = () => Object.fromEntries(fs.readdirSync(join(commonDir, 'wanxiangshu/events')).sort()
  .map(name => [name, fs.readFileSync(join(commonDir, 'wanxiangshu/events', name)).toString('base64')]))
try {
  const prior = dispatch.projectionObservation(opened.journal, session)
  if (mode === 'blocked') assert.equal(prior.activeLogicalRun, null)
  else assert.equal(prior.activeLogicalRun.authorityRoot, 'supported667-good-engineer-root')

  if (phase === 'two') {
    const earlierHealthy = dispatch.projectionObservation(opened.journal, `healthy-${mode}-one`)
    assert.equal(earlierHealthy.activeLogicalRun.authorityRoot, `healthy-root-${mode}-one`)
  }

  const healthy = await dispatch.acceptHumanRoot(opened.journal, `healthy-${mode}-${phase}`,
    `healthy-root-${mode}-${phase}`, 'engineer')
  assert.equal(healthy.ok, true, JSON.stringify(healthy.error))
  const afterHealthy = dispatch.projectionObservation(opened.journal, session)
  assert.equal(afterHealthy.runtimeStartCount, prior.runtimeStartCount + 1)
  const beforeRefusedRoot = snapshotFiles()
  const requested = await dispatch.acceptHumanRoot(opened.journal, session,
    `replacement-without-close-${phase}`, 'engineer')
  assert.equal(requested.ok, false, 'A later cut must not authorize replacement without exact closure')
  if (mode === 'blocked') assert.match(JSON.stringify(requested.error), /decodable failed event|integration preparation failed/)
  else assert.equal(requested.error.kind, 'ActiveRunIdentityConflict')
  assert.deepEqual(snapshotFiles(), beforeRefusedRoot, 'The refused root must append no event or cut')
  assert.deepEqual(fs.readFileSync(source), sourceBytes)
  const after = dispatch.projectionObservation(opened.journal, session)
  const retainedHealthy = dispatch.projectionObservation(opened.journal, `healthy-${mode}-${phase}`)
  assert.equal(retainedHealthy.activeLogicalRun.authorityRoot, `healthy-root-${mode}-${phase}`)
  if (mode === 'blocked') assert.equal(after.activeLogicalRun, null)
  else assert.deepEqual(after, afterHealthy)
  console.log(JSON.stringify({ accepted: true, pid: process.pid, host: process.execPath, mode, phase,
    prior, requested, healthy, after, sourceSHA256: hash(fs.readFileSync(source)),
    allFilesBeforeRefusedRoot: beforeRefusedRoot, allFilesAfterRefusedRoot: snapshotFiles(),
    originalBytesPreserved: true, refusedRootWrites: 0,
    scope: 'Actual fixed package cold journal and dispatcher, over unchanged real667 producer history. Healthy scope is admitted before the blocked request; a second OS process observes its durable identity and repeats refusal. Matching-event historical cut preserves the earlier healthy Engineer root.' }))
} finally {
  journal.JournalSurface_dispose(opened.journal)
}
