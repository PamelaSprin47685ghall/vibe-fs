import assert from 'node:assert/strict'
import fs from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'

const [product, commonDir, writer] = process.argv.slice(2)
const load = path => import(pathToFileURL(join(product, 'dist', path)).href)
const [journal, dispatch] = await Promise.all([
  load('Persistence/Journal/Surface.js'), load('Interaction/Dispatch/DispatchSurface.js'),
])
const source = join(commonDir, 'wanxiangshu/events/supported667-producer-0000.ndjson')
const before = fs.readFileSync(source)
const opened = await journal.JournalSurface_bootWithWriterId(commonDir, writer,
  'independent-cold-reader', process.pid, new Date().toISOString())
assert.equal(opened.ok, true, JSON.stringify(opened.error))
try {
  const prior = dispatch.projectionObservation(opened.journal, 'supported667-predictor-session')
  const requested = await dispatch.acceptHumanRoot(opened.journal, 'supported667-predictor-session',
    'fresh-root-without-prior-close', 'engineer')
  const after = dispatch.projectionObservation(opened.journal, 'supported667-predictor-session')
  assert.deepEqual(fs.readFileSync(source), before)
  console.log(JSON.stringify({ pid: process.pid, prior, requested, after, originalBytesPreserved: true }))
} finally {
  journal.JournalSurface_dispose(opened.journal)
}
