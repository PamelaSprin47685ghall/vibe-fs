import assert from 'node:assert/strict'
import fs from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'

const [product, commonDir] = process.argv.slice(2)
const load = path => import(pathToFileURL(join(product, 'dist', path)).href)
const [journal, dispatch] = await Promise.all([
  load('Persistence/Journal/Surface.js'), load('Interaction/Dispatch/DispatchSurface.js'),
])
assert.equal(process.env.WANXIANGSHU_NO_FATAL_EXIT, undefined)
const opened = await journal.JournalSurface_bootWithWriterId(commonDir, 'supported667-producer',
  'supported667-runtime', process.pid, new Date().toISOString())
assert.equal(opened.ok, true, JSON.stringify(opened.error))
const handle = opened.journal
const session = 'supported667-predictor-session'
const record = value => fs.appendFileSync(join(commonDir, '..', 'producer-observations.ndjson'),
  JSON.stringify({ pid: process.pid, ...value }) + '\n')
try {
  const root = await dispatch.acceptHumanRoot(handle, session, 'supported667-original-root', 'predictor')
  assert.equal(root.ok, true, JSON.stringify(root.error))
  record({ stage: 'real-predictor-root-accepted', root,
    current: dispatch.projectionObservation(handle, session) })
  for (const child of ['supported667-child-before', 'supported667-child-conflict']) {
    const result = await journal.JournalSurface_appendAgent(handle, { kind: 'Session', session }, null, {
      family: 'Execution', case: 'HandleLinked', payload: {
        ParentSessionId: session, ChildSessionId: child, Handle: 'supported667-exact-handle',
        TargetAgent: 'engineer', Byname: 'review-real-link', CanonicalRole: 'engineer',
        Ownership: 'DurableParentHandle',
      },
    })
    assert.equal(result.ok, true, JSON.stringify(result.error))
    record({ stage: 'real-handle-accepted', child, result })
  }
  assert.fail('The real conflicting HandleLinked must settle cut and terminate its producer')
} finally {
  journal.JournalSurface_dispose(handle)
}
