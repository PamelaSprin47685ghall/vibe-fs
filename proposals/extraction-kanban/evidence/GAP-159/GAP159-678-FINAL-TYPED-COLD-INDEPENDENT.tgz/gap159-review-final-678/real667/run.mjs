import assert from 'node:assert/strict'
import fs from 'node:fs'
import { join, dirname } from 'node:path'
import { createHash } from 'node:crypto'
import { spawn } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const product = process.argv[2]
const root = process.argv[3]
const own = dirname(fileURLToPath(import.meta.url))
const commonDir = join(root, '.git')
fs.mkdirSync(commonDir, { recursive: true })
const env = { ...process.env }
delete env.NODE_TEST_CONTEXT
delete env.NODE_OPTIONS
delete env.WANXIANGSHU_NO_FATAL_EXIT
const stdout = fs.openSync(join(root, 'producer.stdout'), 'w')
const stderr = fs.openSync(join(root, 'producer.stderr'), 'w')
const child = spawn(process.execPath, [join(own, 'producer.mjs'), product, commonDir], {
  cwd: root, env, detached: true, stdio: ['ignore', stdout, stderr],
})
let timedOut = false
const timer = setTimeout(() => {
  timedOut = true
  try { process.kill(-child.pid, 'SIGKILL') } catch (error) { if (error.code !== 'ESRCH') throw error }
}, 15000)
const status = await new Promise((done, reject) => {
  child.once('error', reject)
  child.once('close', (code, signal) => done({ code, signal, pid: child.pid, timedOut }))
})
clearTimeout(timer)
fs.closeSync(stdout)
fs.closeSync(stderr)
fs.writeFileSync(join(root, 'producer.status.json'), JSON.stringify(status, null, 2))
assert.equal(timedOut, false)
assert.deepEqual({ code: status.code, signal: status.signal }, { code: null, signal: 'SIGKILL' },
  fs.readFileSync(join(root, 'producer.stderr'), 'utf8'))
const source = join(commonDir, 'wanxiangshu/events/supported667-producer-0000.ndjson')
const bytes = fs.readFileSync(source)
const facts = bytes.toString('utf8').trim().split('\n').map(JSON.parse)
assert.equal(facts.length, 5)
const [initialization, rootFact, firstHandle, failedHandle, cut] = facts
assert.equal(initialization.event_type, 'JournalEnvelope')
assert.ok(JSON.stringify(rootFact.payload).includes('predictor'))
assert.equal(cut.event_type, 'ProjectionCutTail')
assert.equal(cut.payload.rule, 'Journal')
assert.equal(cut.payload.failed_event_id, failedHandle.event_id)
assert.notEqual(cut.payload.failed_event_id, rootFact.event_id)
assert.equal(rootFact.stream_id, firstHandle.stream_id)
assert.equal(rootFact.stream_id, failedHandle.stream_id)
assert.deepEqual(cut.parents, [failedHandle.event_id])
const result = { accepted: true, product, status, source,
  sourceSHA256: createHash('sha256').update(bytes).digest('hex'), facts,
  scope: 'Actual fixed667 dispatcher accepted Predictor root, then actual typed Journal append produced a legal HandleLinked conflict and the production Integrator wrote its own cut before native fatal. No event or cut was manually written or modified.' }
fs.writeFileSync(join(root, 'result.json'), JSON.stringify(result, null, 2))
console.log(JSON.stringify({ ...result, facts: facts.map(fact => ({ id: fact.event_id, stream: fact.stream_id,
  type: fact.event_type, cutFor: fact.payload.failed_event_id })) }))
