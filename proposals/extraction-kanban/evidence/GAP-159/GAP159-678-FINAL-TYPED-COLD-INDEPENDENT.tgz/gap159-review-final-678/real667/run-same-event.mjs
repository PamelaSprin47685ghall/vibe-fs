import assert from 'node:assert/strict'
import fs from 'node:fs'
import { join, dirname } from 'node:path'
import { pathToFileURL, fileURLToPath } from 'node:url'
import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'

const [product, root] = process.argv.slice(2)
const commonDir = join(root, '.git')
fs.mkdirSync(commonDir, { recursive: true })
const env = { ...process.env }
delete env.NODE_TEST_CONTEXT
delete env.NODE_OPTIONS
delete env.WANXIANGSHU_NO_FATAL_EXIT
const script = join(dirname(fileURLToPath(import.meta.url)), 'producer-same-event.mjs')
const result = spawnSync(process.execPath, [script, product, commonDir], { env, cwd: root, encoding: 'utf8', timeout: 15000 })
fs.writeFileSync(join(root, 'producer.stdout'), result.stdout || '')
fs.writeFileSync(join(root, 'producer.stderr'), result.stderr || '')
fs.writeFileSync(join(root, 'producer.status.json'), JSON.stringify({ status: result.status, signal: result.signal,
  error: result.error ? { code: result.error.code, message: result.error.message } : null }, null, 2))
assert.ifError(result.error)
assert.deepEqual({ status: result.status, signal: result.signal }, { status: null, signal: 'SIGKILL' }, result.stderr)
const source = join(commonDir, 'wanxiangshu/events/supported667-same-event-0000.ndjson')
const bytes = fs.readFileSync(source)
const facts = bytes.toString('utf8').trim().split('\n').map(JSON.parse)
assert.equal(facts.length, 4)
const [, goodRoot, badRoot, cut] = facts
assert.ok(JSON.stringify(goodRoot.payload).includes('supported667-good-engineer-root'))
assert.ok(JSON.stringify(badRoot.payload).includes('supported667-conflicting-predictor-root'))
assert.equal(cut.event_type, 'ProjectionCutTail')
assert.equal(cut.payload.failed_event_id, badRoot.event_id)
assert.deepEqual(cut.parents, [badRoot.event_id])
const journal = await import(pathToFileURL(join(product, 'dist/Persistence/Journal/Surface.js')).href)
const dispatch = await import(pathToFileURL(join(product, 'dist/Interaction/Dispatch/DispatchSurface.js')).href)
const opened = await journal.JournalSurface_bootWithWriterId(commonDir, 'same-event-cold', 'same-event-cold-runtime',
  process.pid, new Date().toISOString())
assert.equal(opened.ok, true, JSON.stringify(opened.error))
const observed = dispatch.projectionObservation(opened.journal, 'supported667-same-event-session')
assert.equal(observed.activeLogicalRun.authorityRoot, 'supported667-good-engineer-root')
assert.deepEqual(fs.readFileSync(source), bytes)
journal.JournalSurface_dispose(opened.journal)
const summary = { accepted: true, product, source, facts,
  sourceSHA256: createHash('sha256').update(bytes).digest('hex'), observed,
  scope: 'Two concurrent valid production AcceptHumanRoot calls, serialized by the real journal writer. Engineer is accepted first; the Predictor root fails active-run registration during actual integration and receives a matching production cut. No direct root append or manufactured cut.' }
fs.writeFileSync(join(root, 'result.json'), JSON.stringify(summary, null, 2))
console.log(JSON.stringify({ ...summary, facts: facts.map(fact => ({ id: fact.event_id, type: fact.event_type,
  cutFor: fact.payload.failed_event_id })) }))
