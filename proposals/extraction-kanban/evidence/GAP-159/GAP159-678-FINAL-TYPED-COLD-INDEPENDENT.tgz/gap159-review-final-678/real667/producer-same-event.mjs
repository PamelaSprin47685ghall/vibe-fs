import assert from 'node:assert/strict'
import fs from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'

const [product, commonDir] = process.argv.slice(2)
const load = path => import(pathToFileURL(join(product, 'dist', path)).href)
const [journal, dispatch] = await Promise.all([
  load('Persistence/Journal/Surface.js'), load('Interaction/Dispatch/DispatchSurface.js'),
])
assert.equal(process.env.WANXIANGSHU_NO_FATAL_EXIT, undefined)
const opened = await journal.JournalSurface_bootWithWriterId(commonDir, 'supported667-same-event',
  'supported667-same-runtime', process.pid, new Date().toISOString())
assert.equal(opened.ok, true, JSON.stringify(opened.error))
const handle = opened.journal
const session = 'supported667-same-event-session'
const acceptedEngineer = dispatch.acceptHumanRoot(handle, session, 'supported667-good-engineer-root', 'engineer')
  .then(result => {
    assert.equal(result.ok, true, JSON.stringify(result.error))
    fs.writeFileSync(join(commonDir, '..', 'engineer-accepted.json'), JSON.stringify({ pid: process.pid, result }))
    return result
  })
const conflictingPredictor = dispatch.acceptHumanRoot(handle, session, 'supported667-conflicting-predictor-root', 'predictor')
await Promise.all([acceptedEngineer, conflictingPredictor])
assert.fail('A concurrently issued valid root must conflict at the actual serialized journal append')
