
import { equals, Exception } from "../fable_modules/fable-library-js.5.13.0/Util.js";
import { ParticipantIdentityModule_inheritFromOwner, ParticipantIdentityInput, PersonaOrigin, ParticipantIdentityModule_origin, ParticipantIdentityModule_personaCatalogVersion, ParticipantIdentityModule_selectedAgent, ParticipantIdentityModule_persona, ParticipantIdentityModule_roleLabel, ParticipantIdentityModule_role, ParticipantIdentityModule_fromInput, ParticipantIdentityModule_toInput, ParticipantIdentityModule_rehydrate, ParticipantIdentityModule_resolveAtRoot } from "./Participant/Persona/Identity.js";
import { printf, toFail } from "../fable_modules/fable-library-js.5.13.0/String.js";
import { Role as Role_1, Roles_tryParseRole } from "./Foundation/Roles.js";
import { isRoleName } from "./Participant/Persona/ManagedCatalog.js";
import { ToolPermission, OfficeCapability_isAllowed } from "./Foundation/OfficeCapability.js";
import { equalsWith } from "../fable_modules/fable-library-js.5.13.0/Array.js";
import { isAllowed, permissions } from "./Participant/Persona/OfficeCapabilitySurface.js";

function require(condition, message) {
    if (!condition) {
        throw new Exception(message);
    }
}

function resolved(name) {
    const matchValue = ParticipantIdentityModule_resolveAtRoot(name);
    if (matchValue.tag === 1) {
        const error = matchValue.fields[0];
        return toFail(printf("Identity %s failed: %A"))(name)(error);
    }
    else {
        const identity = matchValue.fields[0];
        return identity;
    }
}

function restored(owner, input) {
    const matchValue = ParticipantIdentityModule_rehydrate(owner, input);
    if (matchValue.tag === 1) {
        const error = matchValue.fields[0];
        return toFail(printf("Identity replay failed: %A"))(error);
    }
    else {
        const identity = matchValue.fields[0];
        return identity;
    }
}

function requireSame(expected, actual) {
    require(equals(ParticipantIdentityModule_toInput(actual), ParticipantIdentityModule_toInput(expected)), "Identity fields changed");
}

function rejectedAlias(input) {
    const matchValue = ParticipantIdentityModule_fromInput(input);
    let matchResult, value;
    if (matchValue.tag === 1) {
        if (matchValue.fields[0].tag === 5) {
            if (matchValue.fields[0].fields[0] == null) {
                if (matchValue.fields[0].fields[1] != null) {
                    if (matchValue.fields[0].fields[1].tag === 2) {
                        matchResult = 0;
                    }
                    else {
                        matchResult = 1;
                        value = matchValue;
                    }
                }
                else {
                    matchResult = 1;
                    value = matchValue;
                }
            }
            else {
                matchResult = 1;
                value = matchValue;
            }
        }
        else {
            matchResult = 1;
            value = matchValue;
        }
    }
    else {
        matchResult = 1;
        value = matchValue;
    }
    switch (matchResult) {
        case 0: {
            break;
        }
        case 1: {
            toFail(printf("Old Predictor alias was not rejected exactly: %A"))(value);
            break;
        }
    }
}

export function exercise() {
    const predictor = resolved("predictor");
    require(equals(ParticipantIdentityModule_role(predictor), undefined), "Predictor acquired a public Role");
    require(ParticipantIdentityModule_roleLabel(predictor) === "predictor", "Predictor label changed");
    require(ParticipantIdentityModule_persona(predictor) === "Predictor", "Predictor persona aliases Engineer");
    require(ParticipantIdentityModule_selectedAgent(predictor) === "predictor", "Predictor name changed");
    require(ParticipantIdentityModule_personaCatalogVersion(predictor) === 1, "Predictor version changed");
    require(equals(ParticipantIdentityModule_origin(predictor), PersonaOrigin.ResolvedAtRoot), "Predictor origin changed");
    require(equals(Roles_tryParseRole("predictor"), undefined), "Public parser accepts Predictor");
    require(!isRoleName("predictor"), "Predictor entered the office catalog");
    require(isRoleName("engineer"), "Engineer left the office catalog");
    requireSame(predictor, restored(undefined, ParticipantIdentityModule_toInput(predictor)));
    const matchValue = ParticipantIdentityModule_fromInput(ParticipantIdentityModule_toInput(predictor));
    if (matchValue.tag === 1) {
        const error = matchValue.fields[0];
        toFail(printf("Private Predictor roundtrip failed: %A"))(error);
    }
    else {
        const replay = matchValue.fields[0];
        requireSame(predictor, replay);
    }
    let oldAlias;
    const bind$0040 = ParticipantIdentityModule_toInput(predictor);
    oldAlias = (new ParticipantIdentityInput(bind$0040.SelectedAgent, Role_1.Engineer, "Engineer", bind$0040.PersonaCatalogVersion, bind$0040.Origin));
    rejectedAlias(oldAlias);
    require(equals(oldAlias.Role, Role_1.Engineer) && (oldAlias.Persona === "Engineer"), "Rejected old evidence was rewritten");
    const manager = resolved("manager");
    let inheritedPredictor;
    const matchValue_1 = ParticipantIdentityModule_inheritFromOwner("predictor", manager);
    if (matchValue_1.tag === 1) {
        const error_1 = matchValue_1.fields[0];
        inheritedPredictor = toFail(printf("Internal inheritance failed: %A"))(error_1);
    }
    else {
        const value = matchValue_1.fields[0];
        inheritedPredictor = value;
    }
    require(equals(ParticipantIdentityModule_role(inheritedPredictor), undefined), "Inherited Predictor acquired an office");
    require(ParticipantIdentityModule_persona(inheritedPredictor) === "Lead", "Inherited Predictor lost owner persona");
    require(equals(ParticipantIdentityModule_origin(inheritedPredictor), PersonaOrigin.InheritedFromOwner), "Inherited Predictor lost provenance");
    requireSame(inheritedPredictor, restored(manager, ParticipantIdentityModule_toInput(inheritedPredictor)));
    const engineer = resolved("engineer");
    require(equals(ParticipantIdentityModule_role(engineer), Role_1.Engineer), "Ordinary Engineer identity changed");
    require(ParticipantIdentityModule_persona(engineer) === "Engineer", "Ordinary Engineer persona changed");
    requireSame(engineer, restored(undefined, ParticipantIdentityModule_toInput(engineer)));
    let replicaIdentity;
    const matchValue_2 = ParticipantIdentityModule_inheritFromOwner(ParticipantIdentityModule_selectedAgent(engineer), engineer);
    if (matchValue_2.tag === 1) {
        const error_2 = matchValue_2.fields[0];
        replicaIdentity = toFail(printf("Owner-derived identity failed: %A"))(error_2);
    }
    else {
        const value_1 = matchValue_2.fields[0];
        replicaIdentity = value_1;
    }
    require(ParticipantIdentityModule_selectedAgent(replicaIdentity) === "engineer", "Readonly purpose changed participant");
    require(equals(ParticipantIdentityModule_role(replicaIdentity), Role_1.Engineer), "Readonly purpose changed role");
    require(ParticipantIdentityModule_persona(replicaIdentity) === "Engineer", "Readonly purpose changed persona");
    requireSame(replicaIdentity, restored(engineer, ParticipantIdentityModule_toInput(replicaIdentity)));
    require(OfficeCapability_isAllowed(Role_1.Engineer, ToolPermission.Fission), "Engineer lost Fission");
    require(!OfficeCapability_isAllowed(Role_1.Manager, ToolPermission.Fission), "Manager gained Fission");
    require(!OfficeCapability_isAllowed(Role_1.DevOps, ToolPermission.Fission), "DevOps gained Fission");
    require(equalsWith((x, y) => (x === y), permissions("predictor"), []), "Predictor has office permissions");
    require(!isAllowed("predictor", "Fission"), "Predictor passed the office gate");
    return {
        accepted: true,
        predictorRoleIsNone: true,
        oldVersionOneAliasRejected: true,
        engineerPreserved: true,
        ownerDerivedIdentityPreserved: true,
        internalRoundtripPreserved: true,
    };
}

