import assert from 'node:assert/strict'
import fs from 'node:fs'
import { join, resolve, relative, dirname } from 'node:path'
import { createHash } from 'node:crypto'
import { spawn } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const repository = resolve(process.argv[2])
const product = resolve(process.argv[3])
const archive = resolve(process.argv[4])
const expectedArchive = process.argv[5]
const evidence = resolve(process.argv[6])
const probes = dirname(fileURLToPath(import.meta.url))
const scratch = fs.mkdtempSync('/private/tmp/gap159-independent-work-')
const source = join(repository, 'src/Wanxiangshu')
const compileScratch = join(scratch, 'compile')
const digest = path => createHash('sha256').update(fs.readFileSync(path)).digest('hex')
const save = (name, value) => fs.writeFileSync(join(evidence, name), JSON.stringify(value, null, 2))
const files = root => {
  const result = {}
  const visit = directory => {
    for (const item of fs.readdirSync(directory).sort()) {
      const path = join(directory, item)
      const status = fs.lstatSync(path)
      assert.equal(status.isSymbolicLink(), false, path)
      if (status.isDirectory()) visit(path)
      else result[relative(root, path)] = digest(path)
    }
  }
  visit(root)
  return result
}
const run = async (name, executable, args, cwd, timeoutMs = 20000) => {
  const stdout = fs.openSync(join(evidence, `${name}.stdout`), 'w')
  const stderr = fs.openSync(join(evidence, `${name}.stderr`), 'w')
  const env = { ...process.env, HOME: join(cwd, 'home'), USERPROFILE: join(cwd, 'home') }
  delete env.NODE_TEST_CONTEXT
  fs.mkdirSync(env.HOME, { recursive: true })
  save(`${name}.command.json`, { executable, args, cwd, HOME: env.HOME, timeoutMs })
  const child = spawn(executable, args, { cwd, env, detached: true, stdio: ['ignore', stdout, stderr] })
  let timedOut = false
  const timeout = setTimeout(() => {
    timedOut = true
    try { process.kill(-child.pid, 'SIGKILL') } catch (error) { if (error.code !== 'ESRCH') throw error }
  }, timeoutMs)
  const status = await new Promise((done, reject) => {
    child.once('error', reject)
    child.once('close', (code, signal) => done({ code, signal, pid: child.pid, timedOut }))
  })
  clearTimeout(timeout)
  fs.closeSync(stdout)
  fs.closeSync(stderr)
  save(`${name}.status.json`, status)
  assert.equal(status.timedOut, false, name)
  assert.equal(status.code, 0, `${name}: ${fs.readFileSync(join(evidence, `${name}.stderr`), 'utf8')}`)
  return status
}

fs.mkdirSync(evidence, { recursive: true })
console.log(JSON.stringify({ evidence, product, archive, expectedArchive, scratch }))
try {
  assert.equal(digest(archive), expectedArchive)
  const before = files(product)
  save('products-before.json', before)
  const { planOwnerCompile, compileOwnerProject } = await import(join(repository, 'scripts/lib/owner-compile.mjs'))
  const project = join(source, 'Wanxiangshu.Owner.office-capability.foundation-officecapability.fsproj')
  const plan = planOwnerCompile({ projectPath: project })
  const realInputs = Object.fromEntries(plan.compileItems.map(path => [relative(source, path), digest(path)]))
  save('real-compile-inputs.json', realInputs)
  const inputs = plan.compileItems.map(path => {
    const target = join(compileScratch, 'source', relative(source, path))
    fs.mkdirSync(dirname(target), { recursive: true })
    fs.copyFileSync(path, target)
    return target
  })
  const names = ['GAP159TypedConsumer', 'GAP159NegativePublicPredictor', 'GAP159NegativeRoleOption', 'GAP159NegativeIdentityConstruction']
  let emitted
  for (const name of names) {
    const input = join(compileScratch, 'source', `${name}.fs`)
    fs.copyFileSync(join(probes, `${name}.fs`), input)
    fs.copyFileSync(input, join(evidence, `${name}.fs`))
    const compiled = await compileOwnerProject({ projectPath: project, scratchRoot: join(compileScratch, name), stdio: 'pipe',
      compilePlan: { ...plan, compileItems: [...inputs, input] } })
    fs.writeFileSync(join(evidence, `${name}.stdout`), compiled.stdout || '')
    fs.writeFileSync(join(evidence, `${name}.stderr`), compiled.stderr || '')
    save(`${name}.status.json`, { ok: compiled.ok, code: compiled.code, signal: compiled.signal, elapsedMs: compiled.elapsedMs })
    if (name === 'GAP159TypedConsumer') {
      assert.equal(compiled.ok, true, String(compiled.stdout) + String(compiled.stderr))
      const matches = Object.keys(files(compiled.outputPath)).filter(path => path.endsWith(`${name}.js`))
      assert.equal(matches.length, 1)
      emitted = fs.readFileSync(join(compiled.outputPath, matches[0]))
    } else {
      assert.equal(compiled.ok, false, `The invalid ${name} unexpectedly compiled`)
      assert.match(String(compiled.stdout) + String(compiled.stderr), new RegExp(`${name}.*\\.fs|${name}\\.fs`))
    }
  }
  fs.writeFileSync(join(evidence, 'GAP159TypedConsumer.js'), emitted)
  const runtime = join(scratch, 'runtime')
  fs.mkdirSync(runtime)
  fs.writeFileSync(join(runtime, 'package.json'), JSON.stringify({ name: 'gap159-independent-typed-consumer', type: 'module', private: true }))
  fs.writeFileSync(join(runtime, 'GAP159TypedConsumer.js'), emitted)
  const imports = [...emitted.toString().matchAll(/from\s+["']([^"']+)["']/g)].map(match => match[1])
  const links = new Map()
  for (const specifier of imports) {
    const component = specifier.startsWith('./') ? specifier.slice(2).split('/')[0]
      : specifier.startsWith('../fable_modules/') ? 'fable_modules' : null
    assert.ok(['Foundation', 'Participant', 'fable_modules'].includes(component), specifier)
    const from = component === 'fable_modules' ? join(scratch, component) : join(runtime, component)
    links.set(from, join(product, 'dist', component))
  }
  for (const [from, to] of links) fs.symlinkSync(to, from)
  save('runtime-imports.json', { imports, links: [...links], emittedSHA256: digest(join(runtime, 'GAP159TypedConsumer.js')), noImportRewrite: true })
  fs.rmSync(compileScratch, { recursive: true, force: true })
  assert.equal(fs.existsSync(compileScratch), false)
  const driver = join(runtime, 'typed-driver.mjs')
  fs.writeFileSync(driver, "import assert from 'node:assert/strict'\nimport { exercise } from './GAP159TypedConsumer.js'\nconst result = exercise()\nassert.equal(result.accepted,true)\nconsole.log(JSON.stringify(result))\n")
  fs.copyFileSync(driver, join(evidence, 'typed-driver.mjs'))

  const stage = join(scratch, 'stage')
  fs.mkdirSync(stage)
  fs.symlinkSync(join(product, 'dist'), join(stage, 'dist'))
  fs.symlinkSync(join(product, 'resources'), join(stage, 'resources'))
  const testFiles = ['requirements/execution-model-routing/tests/020.test.mjs', 'requirements/speculative-investigation/tests/003.test.mjs']
  for (const file of testFiles) {
    const target = join(stage, file)
    fs.mkdirSync(dirname(target), { recursive: true })
    fs.copyFileSync(join(repository, file), target)
    const retained = join(evidence, file)
    fs.mkdirSync(dirname(retained), { recursive: true })
    fs.copyFileSync(target, retained)
  }
  save('actual-test-inputs.json', Object.fromEntries(testFiles.map(file => [file, digest(join(stage, file))])))
  fs.copyFileSync(join(probes, 'consumer-probe.mjs'), join(evidence, 'consumer-probe.mjs'))
  const results = []
  for (const [host, executable] of [['node', process.execPath], ['bun', 'bun']]) {
    const cwd = join(scratch, host)
    fs.mkdirSync(cwd)
    results.push({ host, typed: await run(`${host}-typed`, executable, [driver], cwd) })
    results.push({ host, natural: await run(`${host}-natural`, executable, [join(probes, 'consumer-probe.mjs'), product], cwd) })
    const args = host === 'node' ? ['--test', ...testFiles.map(file => join(stage, file))]
      : ['test', ...testFiles.map(file => join(stage, file))]
    results.push({ host, existingConsumerTests: await run(`${host}-existing-consumers`, executable, args, cwd, 30000) })
  }
  assert.deepEqual(files(product), before)
  assert.equal(digest(archive), expectedArchive)
  assert.deepEqual(Object.fromEntries(plan.compileItems.map(path => [relative(source, path), digest(path)])), realInputs)
  save('products-after.json', files(product))
  save('summary.json', { accepted: true, expectedArchive, results, realFsi: Object.keys(realInputs).filter(path => path.endsWith('.fsi')),
    compilation: { positive: 1, negative: 3 }, sourceUnchanged: true, productUnchanged: true,
    generatedProductionJSRemovedBeforeExecution: true, sameConsumerJSUnmodified: true,
    scope: 'Internal F# contracts and fixed package consumption on Node/Bun. Existing test files are copied byte-for-byte with their relative imports bound by fixed package dist/resources symlinks. These native probes do not replace the formal supervised suite or the separate public Host/journal review.' })
} catch (error) {
  save('harness-error.json', { message: error.message, stack: error.stack })
  process.exitCode = 1
} finally {
  fs.copyFileSync(fileURLToPath(import.meta.url), join(evidence, 'run.mjs'))
  fs.rmSync(scratch, { recursive: true, force: true })
  save('cleanup.json', { scratchRemoved: !fs.existsSync(scratch), productPreserved: fs.existsSync(product),
    scope: 'Private compiler/runtime staging removed. Normal native test children return through their original test contracts; this file is not an independent per-PID product process sampling claim.' })
}
