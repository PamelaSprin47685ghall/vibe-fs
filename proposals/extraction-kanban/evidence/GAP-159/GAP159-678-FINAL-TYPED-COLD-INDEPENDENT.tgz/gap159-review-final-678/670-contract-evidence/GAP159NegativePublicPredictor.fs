module GAP159NegativePublicPredictor

open Wanxiangshu.Foundation

let forbiddenRole: Role = Role.Predictor
