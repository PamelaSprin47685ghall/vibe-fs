module GAP159NegativeRoleOption

open Wanxiangshu.Foundation
open Wanxiangshu.Participant.Persona

let forbiddenOffice (identity: ParticipantIdentityEvidence) =
    OfficeCapability.isAllowed (ParticipantIdentity.role identity) ToolPermission.Fission
