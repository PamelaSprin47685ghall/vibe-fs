# GAP-159 non-author type and consumer review

Candidate: clean-installed wanxiangshu 0.9.0 generation 670.

Archive SHA-256: `7e7a0edc6e37dd6ec1253162e73cdbf2ecbdc4c07ec4aff7a5bfb022e8bd4ebf`.

Runtime: Node 26.6.0 and Bun 1.3.14. Product: `/private/tmp/gap159-clean-install-670/node_modules/wanxiangshu`.

## Results

- One positive F# consumer compiled through the actual owner compiler against 16 real source inputs, including eight real .fsi files. Inputs and their SHA-256 digests are retained. The signatures are the internal F# contracts; no npm d.ts or new public npm export is claimed.
- Three independent negative compilation programs failed for the intended reasons: public Role has no Predictor case (code 39), Role option cannot be passed as Role to the office gate (code 1), and the private evidence Identity record label is not exposed (code 39). This is not a missing dependency or environment failure.
- All generated production JavaScript was removed before running the unchanged emitted consumer. Its imports were bound only to this installed package's Foundation, Participant and fable_modules directories. No source implementation or shared moving dist remained available as a fallback. Node and Bun both returned accepted.
- The typed program checks private Predictor role=None/persona=Predictor, internal root and inherited roundtrips, exact rejection of the old persona-catalog-version-1 Predictor=Engineer alias, ordinary Engineer and owner-derived Engineer identity preservation, and the typed office gate.
- A separate natural consumer exercises actual identity, office, managed Host configuration and authority owner-issued identity surfaces. Predictor remains a hidden model slot, all callable tool permissions remain denied, model fields survive, Engineer retains Fission, and the same configuration projection is idempotent. Actual owner-issued lineage stays Engineer. This is identity construction, not a complete Strength Host execution or journal replay proof; those have a separate reviewer.
- The original execution-model-routing 020 file (7 cases) and speculative-investigation 003 file (13 cases) were copied byte-for-byte. Their existing relative imports resolve through fixed package dist/resources links. Both full files passed on Node (20/20) and Bun (20/20), with no skip or TODO. Their bodies were not filtered, shortened or adapted to old JavaScript views. This covers real Predictor routing/configuration and finite Strength admission/terminal behavior through the existing production surfaces.
- All 2904 installed product files have identical before/after hashes; the tar hash is unchanged. Real compile inputs are unchanged. Private compile/runtime staging was removed after completion. Child CLI close statuses and the original tests' termination assertions are retained; no additional per-PID sampling or product descendant cleanup claim is made here.

## First failed attempt retained separately

`../gap159-independent-670-first` is archived beside this directory. Its positive compile, three intended negative compiles and Node emitted-consumer run had passed. Its natural consumer incorrectly called `OfficeCapabilitySurface.isAllowed` with lowercase `fission`; the real interface uses `Fission`. The Engineer positive correctly returned false for that unknown label and stopped the review fixture. This was a reviewer fixture error, not a product regression. The correction uses canonical permission labels, including in the private Predictor negative, then recompiles and repeats the finite matrix. The first raw outputs and original probe are not replaced.

The two attempts are not added together as extra coverage. Final accepted results are one corrected positive compile, three corrected negative compiles, one unchanged emitted consumer per Host, one natural consumer per Host and 20 original test cases per Host.

The old catalog-version-1 alias tested here is a complete ParticipantIdentity input. It is not a claim about the separate AuthorityRootAccepted event version 1 migration policy. Public Host/journal replay is outside this review's execution scope. R12-U1 remains deferred.

## Reproduce

Install the retained tarball into a fresh directory with the supplied package lock/declarations and normal required install permissions. Use the existing repository Fable toolchain, not dotnet build. The source repository must match the retained `real-compile-inputs.json` hashes for every one of the 16 listed files; compare these before replay. The helper uses the repository's genuine owner plan/compile entry and does not synthesize replacement signatures.

Place the retained F# inputs named GAP159TypedConsumer.fs and GAP159Negative*.fs, consumer-probe.mjs and run.mjs together. From any cwd run:

```sh
node run.mjs /absolute/path/to/source-repository /absolute/path/to/clean/node_modules/wanxiangshu /absolute/path/to/wanxiangshu-0.9.0.tgz 7e7a0edc6e37dd6ec1253162e73cdbf2ecbdc4c07ec4aff7a5bfb022e8bd4ebf /absolute/path/to/new-evidence
```

The original two numbered test files must also match `actual-test-inputs.json`. Copies are retained under requirements. The runner copies their bodies without editing imports and stages fixed package links. Compiler inputs and test source are used only for compilation or fixture definition, never as runtime production fallback.

For runtime-only replay, reuse the retained original GAP159TypedConsumer.js unchanged with Foundation/Participant links at its same directory level and fable_modules one level above, all pointing into the fixed installed package dist. Run typed-driver.mjs under Node and Bun. This runtime-only step does not count as another .fsi compilation.

Contract documents are copied under contract-documents; raw commands, stdout/stderr, actual close status, source snapshots, runtime import paths and before/after package hashes are retained. Native probes do not replace the formal supervised requirement run or the independent public Plugin/journal acceptance.
