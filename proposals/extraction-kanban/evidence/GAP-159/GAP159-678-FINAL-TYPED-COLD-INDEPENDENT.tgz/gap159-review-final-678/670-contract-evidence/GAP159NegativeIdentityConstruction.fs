module GAP159NegativeIdentityConstruction

open Wanxiangshu.Participant.Persona

let forbiddenIdentity: ParticipantIdentityEvidence =
    { Identity = Unchecked.defaultof<ParticipantIdentity> }
