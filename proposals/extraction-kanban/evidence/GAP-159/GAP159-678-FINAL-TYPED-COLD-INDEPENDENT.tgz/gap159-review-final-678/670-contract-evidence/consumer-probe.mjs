import assert from 'node:assert/strict'
import { pathToFileURL } from 'node:url'
import { join } from 'node:path'

const product = process.argv[2]
const load = path => import(pathToFileURL(join(product, 'dist', path)).href)
const [persona, office, config, authority] = await Promise.all([
  load('Participant/Persona/Surface.js'),
  load('Participant/Persona/OfficeCapabilitySurface.js'),
  load('OpenCode/Host/ManagedAgentConfigSurface.js'),
  load('Interaction/Authority/RuntimeSurface.js'),
])

const predictor = persona.resolveParticipantIdentityAtRoot('predictor')
assert.equal(predictor.ok, true)
assert.equal(predictor.identity.role, 'predictor')
assert.equal(predictor.identity.persona, 'Predictor')
assert.equal(persona.allPublicRoleLabels.includes('predictor'), false)
assert.equal(persona.allRoleLabels.includes('predictor'), false)
assert.deepEqual(office.permissions('predictor'), [])
for (const permission of ['Fission', 'Write', 'Exec', 'Fork']) assert.equal(office.isAllowed('predictor', permission), false)
assert.equal(office.isAllowed('engineer', 'Fission'), true)

config.installDefaultResources()
const configured = { agent: {
  predictor: { model: 'owner-preserved/predictor', prompt: 'obsolete engineer text', permission: { fission: 'allow', write: 'allow' } },
  engineer: { model: 'owner-preserved/engineer' },
} }
const result = config.configure(configured)
assert.equal(result.ok, true)
assert.equal(result.bindingNames.includes('predictor'), false)
assert.equal(result.bindingNames.includes('bookkeeper'), false)
assert.equal(result.bindingNames.includes('engineer'), true)
assert.equal(configured.agent.predictor.model, 'owner-preserved/predictor')
assert.equal(configured.agent.engineer.model, 'owner-preserved/engineer')
assert.equal(configured.agent.predictor.hidden, true)
assert.equal(configured.agent.predictor.mode, 'primary')
assert.equal(configured.agent.predictor.prompt, '')
for (const tool of ['*', 'fission', 'write', 'run', 'fork', 'js-engineer', 'js-predictor']) {
  assert.equal(configured.agent.predictor.permission[tool] ?? configured.agent.predictor.permission['*'], 'deny', tool)
}
assert.equal(configured.agent.engineer.permission.fission, 'allow')
for (const name of ['manager', 'orchestrator', 'devops', 'blogger', 'bookkeeper']) {
  assert.equal(configured.agent[name].permission.fission, 'deny', name)
}
const firstBytes = JSON.stringify(configured)
assert.equal(config.configure(configured).ok, true)
assert.equal(JSON.stringify(configured), firstBytes)

const ownerIdentity = persona.resolveParticipantIdentityAtRoot('engineer').identity
const created = authority.createAuthorityRoot(text => `H(${text})`, 'review-strength-runtime', 'review-strength-owner',
  'HumanRoot', 'review-strength-root', {
    kind: 'RootSelection', ownerSession: null, ownerLogicalRun: null, ownerAuthorityRoot: null,
    participantIdentity: {
      participant: ownerIdentity.name, role: ownerIdentity.role, persona: ownerIdentity.persona,
      personaCatalogVersion: ownerIdentity.catalogVersion, origin: ownerIdentity.origin,
    },
  })
assert.equal(created.ok, true, created.error)
const owner = created.value
const inherited = authority.issueInheritedIdentitySeed('engineer', owner)
assert.equal(inherited.ok, true, inherited.error)
assert.deepEqual(inherited.value, {
  kind: 'InheritedFromOwner', ownerSession: owner.session, ownerLogicalRun: owner.logicalRun,
  ownerAuthorityRoot: owner.authorityRoot,
  participantIdentity: {
    participant: 'engineer', role: 'engineer', persona: ownerIdentity.persona,
    personaCatalogVersion: ownerIdentity.catalogVersion, origin: 'InheritedFromOwner',
  },
})
assert.equal(authority.validateInheritedIdentitySeed(owner, inherited.value).ok, true)

console.log(JSON.stringify({ accepted: true, host: process.execPath,
  internalPredictor: predictor.identity, predictorConfig: configured.agent.predictor,
  bindingNames: result.bindingNames, inherited: inherited.value,
  scope: 'Actual fixed package identity, office, managed config and owner-issued Strength identity construction. No public Plugin or journal replay is claimed here.' }))
