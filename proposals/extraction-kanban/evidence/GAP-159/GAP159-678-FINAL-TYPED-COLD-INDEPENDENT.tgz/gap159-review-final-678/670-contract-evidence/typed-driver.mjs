import assert from 'node:assert/strict'
import { exercise } from './GAP159TypedConsumer.js'
const result = exercise()
assert.equal(result.accepted,true)
console.log(JSON.stringify(result))
