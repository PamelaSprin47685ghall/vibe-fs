# GAP-159 fixed667 public baseline

One Node invocation and one Bun invocation, each with the same three test bodies. No repeated stress loop. Production is the clean installed667 package; the consumer asserts the actual npm root export path. Existing SDK fixture is copied unchanged and all its product imports resolve to this installed package.

The baseline intentionally observes the known wrong Predictor configuration/identity and distinguishes it from actual Fission success. Public chat roots for Predictor/unknown/Engineer, Manager/DevOps forged Engineer calls, and a legal Manager fork to Engineer plus Fission are covered. Host SDK is controlled; no real model or provider network is claimed. Legal lifecycle setup uses the existing real EventStore seed only, not a new Fission state machine.

Every refusal records session-create/prompt/abort counts and ordinary workspace hashes. Expected Git-private durable evidence is kept separate. Tests must not manufacture Predictor HandleLinked facts and call that ordinary scheduling reachability. No shared source file is edited.
