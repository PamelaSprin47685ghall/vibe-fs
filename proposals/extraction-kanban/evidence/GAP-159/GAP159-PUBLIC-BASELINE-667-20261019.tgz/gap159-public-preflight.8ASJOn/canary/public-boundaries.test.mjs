import assert from 'node:assert/strict'
import test from 'node:test'
import { createHash } from 'node:crypto'
import { mkdirSync, readFileSync, readdirSync, realpathSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'

const product = realpathSync(process.env.GAP159_PRODUCT)
const publicExport = realpathSync(fileURLToPath(import.meta.resolve('wanxiangshu')))
assert.equal(publicExport, realpathSync(join(product, 'dist/OpenCode/Plugin/Plugin.js')))
const evidence = process.env.GAP159_EVIDENCE
mkdirSync(evidence, { recursive: true })
const save = (name, value) => writeFileSync(join(evidence, name + '.json'), JSON.stringify(value, null, 2) + '\n')
save('public-export', { product, publicExport, host: process.execPath })

const { withExecutablePlugin, observeAuthority, openIncumbency } = await import('./requirements/verification-system/tests/support/plugin-fixture.mjs')
const { configure, installDefaultResources } = await import('./dist/OpenCode/Host/ManagedAgentConfigSurface.js')
installDefaultResources()
const effects = (ids, runtime) => ({ created: ids.length, prompts: runtime.prompts.length, aborted: runtime.abortedIds.length })
const ordinaryFiles = directory => {
  const files = {}
  const visit = (parent, prefix = '') => {
    for (const entry of readdirSync(parent, { withFileTypes: true })) {
      if (entry.name === '.git') continue
      const path = join(parent, entry.name)
      const relative = prefix ? prefix + '/' + entry.name : entry.name
      if (entry.isDirectory()) visit(path, relative)
      else if (entry.isFile()) files[relative] = createHash('sha256').update(readFileSync(path)).digest('hex')
    }
  }
  visit(directory)
  return files
}
const chat = async (hooks, sessionID, agent) => {
  const output = {
    message: { id: 'msg-' + sessionID, role: 'user', sessionID, agent, model: { providerID: 'host', modelID: 'placeholder' }, tools: { fission: true } },
    parts: [{ type: 'text', text: 'Collect local evidence without executing commands.' }],
  }
  let error = null
  try {
    await hooks['chat.message']({ sessionID, agent }, output)
  } catch (failure) {
    error = { name: failure?.name, message: failure?.message ?? String(failure) }
  }
  return { output, error }
}
const forceFission = (hooks, sessionID, agent, suffix) => hooks.tool.fission.execute(
  { prompts: ['lane alpha exact\n', ' lane beta exact'], role: 'Engineer', work_record: 'I claim to be Engineer', estimated_readonly_rounds: 0 },
  { sessionID, agent, callID: 'call-' + sessionID + '-' + suffix, messageID: 'run-' + sessionID },
)

test('fixed667 baseline configuration and actual public roots distinguish identity acceptance from Fission origin rejection', async () => {
  const config = { agent: {} }
  assert.equal(configure(config).ok, true)
  save('configuration', { predictor: config.agent.predictor, engineer: config.agent.engineer })
  assert.equal(config.agent.predictor.permission.fission, 'allow')
  for (const agent of ['predictor', 'unknown-helper', 'engineer']) {
    await withExecutablePlugin(async (hooks, directory, ids, runtime) => {
      const sessionID = 'gap159-root-' + agent
      const before = effects(ids, runtime)
      const files = ordinaryFiles(directory)
      const message = await chat(hooks, sessionID, agent)
      const authority = observeAuthority(runtime, sessionID)
      const result = await forceFission(hooks, sessionID, agent, 'own')
      const forged = await forceFission(hooks, sessionID, 'engineer', 'forged')
      save('root-' + agent, { directory, before, after: effects(ids, runtime), message, authority, result, forged, filesBefore: files, filesAfter: ordinaryFiles(directory) })
      assert.deepEqual(effects(ids, runtime), before)
      assert.deepEqual(ordinaryFiles(directory), files)
      if (agent === 'unknown-helper') {
        assert.ok(message.error)
        assert.equal(authority.activeLogicalRun, null)
        assert.doesNotMatch(result, /status\s*=\s*"fissioned"/)
        assert.doesNotMatch(forged, /status\s*=\s*"fissioned"/)
      } else {
        assert.equal(message.error, null)
        assert.equal(authority.activeLogicalRun.participantIdentity.role, 'engineer')
        assert.match(result, /user-facing\/root/i)
        assert.match(forged, /user-facing\/root/i)
      }
    })
  }
})

test('actual public Manager and DevOps roots reject forged Engineer claims without SDK or ordinary file effects', async () => {
  for (const agent of ['manager', 'devops']) {
    await withExecutablePlugin(async (hooks, directory, ids, runtime) => {
      const sessionID = 'gap159-forged-' + agent
      const message = await chat(hooks, sessionID, agent)
      assert.equal(message.error, null)
      const before = effects(ids, runtime)
      const files = ordinaryFiles(directory)
      const own = await forceFission(hooks, sessionID, agent, 'own')
      const forged = await forceFission(hooks, sessionID, 'engineer', 'forged')
      const authority = observeAuthority(runtime, sessionID)
      save('forged-' + agent, { directory, message, authority, before, after: effects(ids, runtime), own, forged, filesBefore: files, filesAfter: ordinaryFiles(directory) })
      assert.match(own, /only available to Engineer|仅 Engineer 允许|denied/i)
      assert.match(forged, /only available to Engineer|仅 Engineer 允许|denied/i)
      assert.deepEqual(effects(ids, runtime), before)
      assert.deepEqual(ordinaryFiles(directory), files)
    })
  }
})

test('actual public Manager fork supplies a legal Engineer subsession that can enter Fission', async () => {
  await withExecutablePlugin(async (hooks, directory, ids, runtime) => {
    const manager = 'gap159-legal-manager'
    const message = await chat(hooks, manager, 'manager')
    assert.equal(message.error, null)
    await openIncumbency(runtime, manager)
    const forked = await hooks.tool.fork.execute(
      { name: 'Ada', charge: 'Collect local evidence in two independent lanes.', estimated_readonly_rounds: 0 },
      { sessionID: manager, agent: 'manager', callID: 'call-legal-fork', messageID: 'run-legal-manager' },
    )
    save('legal-fork-intermediate', { directory, message, forked, ids, effects: effects(ids, runtime), prompts: runtime.prompts })
    assert.match(forked, /carries this charge now|现已接下这项托付/i)
    assert.equal(ids.length, 1)
    const child = ids[0]
    const result = await forceFission(hooks, child, 'engineer', 'legal')
    save('legal-engineer', { directory, child, result, ids, effects: effects(ids, runtime), prompts: runtime.prompts, authority: observeAuthority(runtime, child) })
    assert.match(result, /status\s*=\s*"fissioned"/)
    assert.equal(ids.length, 3)
    assert.equal(runtime.prompts.length, 3)
  })
})
