# GAP-159 public-entry baseline on fixed667

This is a non-author read-only review. The consumer has not edited shared source or installed product bytes. It runs the actual npm root `wanxiangshu` export and registered Plugin server/tools. The existing SDK Host fixture is copied unchanged; it creates controlled physical Host session records and accepts real production prompt calls, but no real external model or provider network is claimed.

## Results

One Node run and one Bun run each complete all three registered test bodies: 3 pass, 0 failure, 0 skip, 0 TODO. The seven semantic flows per Host are the three root identities, two forged-role identities, Manager fork, and its Engineer Fission call. The test runs do not prove all office combinations or the GAP-158 lifecycle.

- Public `chat.message` with `agent=predictor` installs an actual HumanRoot with participant `predictor`, role `engineer`, persona `Engineer`, catalog version 1. It routes the actual request output to `provider/engineer-model`. Both own and forged Engineer Fission calls are then rejected by the independent root-origin condition. This is real identity admission outside the internal model slot, but is not proof of successful Fission privilege escape.
- Public unknown identity rejects with `InvalidExplicitAgent`; no active authority is installed. Its own and forged Engineer Fission calls remain unestablished.
- Public Manager and DevOps install their actual durable roles. Each own-role and forged Engineer Fission call rejects. Refusals have zero SDK session creation, prompt sends and abort calls; ordinary file hashes remain identical. Expected Git-private authority/evidence writes are not mistaken for an absence of all durable effects.
- The positive control uses the registered production route: public Manager chat, existing lifecycle seed, registered `fork` that creates a real Engineer child, then registered Fission. It returns `status="fissioned"` and creates two lanes: three total Host session creations and three real prompt calls. This is a scope-limited admission positive control, not complete lane convergence or historical recovery proof.

The current wrong Predictor identity is intentional baseline evidence. A future version that rejects this identity is the planned correction, not a compatibility regression. Ordinary Engineer v1 identity remains the legitimate compatibility positive control.

## Design review

The defect is shared by the identity parser and real admission path: the old private parser maps `predictor` to the public Engineer kind. `ChatAdmissionIntent.tryRootIdentity` accepts any identity with a public role. `ToolRuntimeScope` snapshot/command recovery uses the same resolver. Host permissions then project the wrong role, while Fission independently checks physical parent and active authority.

The production Strength replica preparation does not require a Predictor-selected participant. `Strength/Replica/Runtime.fs` `PrepareReplicaStartCore` checks `replicaAgent = Roles.roleLabel ownerProfile.CanonicalRole`, issues owner-derived identity, and records the owner role. Predictor is a model target pool for this execution. Private internal identity and a denied/hidden model configuration slot can therefore be separated without adding a public Predictor Role or an executable alias.

## Reproduction and evidence

The archive includes this consumer, the three unchanged fixture files, all raw JSON results, logs, before/after regular installed-file hashes, cleanup summary, fixed667 package and its install manifest/lock. The copied helpers import only `canary/dist`, a symlink to the exact installed product. `canary/node_modules` resolves the actual installed package. Recreate those two symlinks when replaying elsewhere; no production JS rewrite or main-repository import is needed.

Set initial HOME/USERPROFILE to a private routing directory generated with copied `routing-home.mjs` before loading production modules. Then run once with Node `--test` and once with `bun test`. Set `GAP159_PRODUCT` to the exact installed product and `GAP159_EVIDENCE` to separate output directories. The baseline asserts the old wrong Predictor mapping and is not the post-fix expected suite.

All 11017 regular installation files and lock files are byte-identical before and after. Twelve actual temporary Plugin workspaces are independently checked absent after hooks/journal disposal. The process cleanup observation is scoped to this consumer and fixed667 workers. No raw success bytes are omitted. A raw full process inventory remains private and is summarized in the archive to avoid distributing unrelated local process details.
