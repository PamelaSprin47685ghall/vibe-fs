import assert from 'node:assert/strict'
import { spawn } from 'node:child_process'
import { writeFileSync, readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { createFiniteWaitChannel } from './fixed-support/finite-wait-channel.mjs'

const directory = dirname(fileURLToPath(import.meta.url))
const entryFile = join(directory, 'fixture.test.mjs')
const allModes = ['positive', 'refused', 'lost', 'deadline-late', 'context-closed-late', 'end-lost',
  'late-delivered', 'bad-run-id', 'bad-entry-file']
const modes = process.argv.length > 2 ? process.argv.slice(2) : allModes
for (const mode of modes) assert.ok(allModes.includes(mode), `Unknown probe ${mode}`)
const results = []
for (const mode of modes) {
  const frames = []
  const errors = []
  const lateReplies = []
  const marker = join(directory, `${mode}.begin-seen`)
  let channel
  let child
  let stdout = ''
  let stderr = ''
  try {
    channel = await createFiniteWaitChannel({ entryFile,
      onError(error) { errors.push({ message: error.message, code: error.code }) },
      onRequest(request) {
        frames.push({ ...request, observedAt: performance.now() })
        if (request.phase === 'cancel') return
        if (request.phase === 'begin') {
          writeFileSync(marker, JSON.stringify({ phase: request.phase, observedAt: performance.now() }))
          if (mode === 'refused') {
            channel.reply({ ...request, ok: false, reason: 'controlled refusal' })
          } else if (mode === 'bad-run-id') {
            channel.reply({ ...request, ok: true, runId: request.runId === 'f'.repeat(32) ? 'a'.repeat(32) : 'f'.repeat(32) })
          } else if (mode === 'bad-entry-file') {
            channel.reply({ ...request, ok: true, entryFile: `${request.entryFile}.other` })
          } else if (mode === 'lost') {
            // Deliberately leave the one real request without an ACK.
          } else if (['deadline-late', 'context-closed-late', 'late-delivered'].includes(mode)) {
            lateReplies.push(new Promise(accept => {
              setTimeout(() => {
                frames.push({ phase: 'late-reply-attempt', requestId: request.requestId,
                  contextToken: request.contextToken, observedAt: performance.now() })
                channel.reply({ ...request, ok: true })
                accept()
              }, mode === 'context-closed-late' ? 250 : 1200)
            }))
          } else channel.reply({ ...request, ok: true })
        } else if (mode !== 'end-lost') channel.reply({ ...request, ok: true })
      },
    })
    const descriptor = { ...channel.descriptor, runId: channel.runId }
    const env = { ...process.env, R1_ACK_MODE: mode, R1_ACK_DESCRIPTOR: JSON.stringify(descriptor),
      R1_ACK_EVIDENCE: join(directory, `${mode}.child.json`), R1_ACK_MARKER: marker }
    delete env.NODE_TEST_CONTEXT
    child = spawn(process.execPath, [`--import=${pathToFileURL(join(directory, 'preload.mjs')).href}`,
      '--test', entryFile], { env, stdio: ['ignore', 'pipe', 'pipe'] })
    child.stdout.setEncoding('utf8')
    child.stderr.setEncoding('utf8')
    child.stdout.on('data', value => { stdout += value })
    child.stderr.on('data', value => { stderr += value })
    const timer = setTimeout(() => child.kill('SIGKILL'), 7000)
    const outcome = await new Promise((accept, reject) => {
      child.once('error', reject)
      child.once('close', (code, signal) => accept({ code, signal }))
    }).finally(() => clearTimeout(timer))
    await Promise.all(lateReplies)
    writeFileSync(join(directory, `${mode}.stdout.raw`), stdout)
    writeFileSync(join(directory, `${mode}.stderr.raw`), stderr)
    writeFileSync(join(directory, `${mode}.frames.json`), JSON.stringify(frames, null, 2))
    writeFileSync(join(directory, `${mode}.status.json`), JSON.stringify(outcome))
    assert.deepEqual(outcome, { code: 0, signal: null }, `${mode}: ${stdout}\n${stderr}`)
    assert.deepEqual(errors, [], mode)
    const begins = frames.filter(frame => frame.phase === 'begin')
    const ends = frames.filter(frame => frame.phase === 'end')
    assert.equal(begins.length, 1, `${mode}: begin must never be resent`)
    assert.equal(ends.length, ['positive', 'end-lost'].includes(mode) ? 1 : 0,
      `${mode}: end must never be resent`)
    const observation = JSON.parse(readFileSync(env.R1_ACK_EVIDENCE, 'utf8'))
    assert.equal(observation.callbacks, ['positive', 'end-lost'].includes(mode) ? 1 : 0)
    results.push({ mode, outcome, begins: begins.length, ends: ends.length,
      callbacks: observation.callbacks, lateReplyAttempts: frames.filter(frame => frame.phase === 'late-reply-attempt').length,
      clientCancellations: frames.filter(frame => frame.phase === 'cancel').length, observation })
  } finally {
    if (channel) await channel.close()
  }
}
writeFileSync(join(directory, process.argv.length > 2 ? `summary.${modes.join('-')}.json` : 'summary.json'),
  JSON.stringify({ runtime: process.version, results }, null, 2))
console.log(JSON.stringify({ runtime: process.version, cases: results.length,
  callbacks: results.map(({ mode, callbacks }) => ({ mode, callbacks })), passed: true }))
