import assert from 'node:assert/strict'
import { existsSync, readFileSync, readdirSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const directory = dirname(fileURLToPath(import.meta.url))
const rows = []
for (const file of readdirSync(directory).filter(value => value.endsWith('.child.json'))) {
  const child = JSON.parse(readFileSync(join(directory, file), 'utf8'))
  const frames = JSON.parse(readFileSync(join(directory, file.replace('.child.json', '.frames.json')), 'utf8'))
  const begin = frames.find(frame => frame.phase === 'begin')
  const processes = [child.pid, child.parentPid].map(pid => {
    try {
      process.kill(pid, 0)
      return { pid, status: 'still present' }
    } catch (error) {
      return { pid, status: error.code }
    }
  })
  const socket = `/tmp/wxs-finite-${begin.runId}.sock`
  const socketPresent = existsSync(socket)
  rows.push({ mode: child.mode, processes, socket, socketPresent })
  assert.ok(processes.every(value => value.status === 'ESRCH'), JSON.stringify(rows))
  assert.equal(socketPresent, false, socket)
}
writeFileSync(join(directory, 'cleanup.json'), JSON.stringify(rows, null, 2))
console.log(JSON.stringify({ cases: rows.length, allProcessesExited: true, allSocketsRemoved: true }))
