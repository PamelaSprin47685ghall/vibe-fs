# CUT-00-R1 independent helper ACK review, final snapshot

Read-only non-author review. Actual runtime Node v26.6.0. No repository source was edited. These private scripts exercise the unmodified captured helper and production Unix-socket channel with actual node:test TestContext objects pre-registered by a private preload. The peer deliberately controls ACKs through the existing private channel API; no production hook, fake context or copied helper algorithm is introduced.

The original seven scenarios ran once together against this final copied closure. Only two new instance-identity negatives ran afterward; the seven were not repeated. Each scenario exited zero without a signal, skip or TODO. Across nine scenarios there are ten actual native tests because context-closed-late uses two sequential contexts.

| Scenario | Callback | Actual begin / end | Assertion |
| --- | ---: | --- | --- |
| positive | 1 | 1 / 1 | Value 41 preserved |
| refused | 0 | 1 / 0 | Controlled refusal preserved |
| lost | 0 | 1 / 0 | Real reply deadline; no resend |
| deadline-late | 0 | 1 / 0 | Pending request already canceled before later ACK attempt |
| context-closed-late | 0 | 1 / 0 | Begin reaches server before real context ends; late grant cannot execute it |
| end-lost | 1 | 1 / 1 | Original action exception and end exception both retained, no resend |
| late-delivered | 0 | 1 / 0 | Actual delivered ACK is rejected by independent elapsed check |
| bad-run-id | 0 | 1 / 0 | `reply identity mismatch` |
| bad-entry-file | 0 | 1 / 0 | `reply identity mismatch` |

All ordinary scenarios use real request timers and sockets. For late-delivered only, actual TestContext.mock.timers freezes child setTimeout callback dispatch. performance.now and socket I/O are not mocked. The server sends after 1200ms and helper rejects with `Physical wait reply arrived after its deadline`. This distinguishes its elapsed check from relying on an already dispatched timeout callback. It is a controlled timer-dispatch experiment, not an uncontrolled physical-scheduling proof.

For end-lost the fixture checks Error object identity: AggregateError.errors[0] and cause are exactly the thrown action Error, and errors[1] is the reply deadline failure. Frames show precisely one begin and one end. A second helper call with the same real context is rejected locally and does not create another request.

The two late-attempt scenarios are separate from late-delivered: production channel has already processed client cancellation, so its later reply attempt does not deliver another frame. Context closure is observed through actual signal abort after the body waits for the socket begin marker. No closure is inferred from hand-made context fields.

This is helper/transport acceptance only. It does not replace outer absolute-P arbitration, owned process group supervision, formal 006 / 003 / 025, or minimum Node 22.13 execution. The copied owner supplies the normal shared validate function dependency. The prior initial-helper evidence remains immutable in CUT-00-R1-ACK-INITIAL-20261019.tgz, SHA256 ab96a71ac2d1ae6ae06459810205baa1d753d2ca29093f8f71bdd56b34d854b7.

## Replay

```
node runner.mjs
node cleanup.mjs
```

This portable directory uses only relative imports into fixed-support. It needs local Unix socket and process-query permission. The runner can also select scenarios explicitly, for example `node runner.mjs bad-run-id bad-entry-file`. All scripts, copied closure, raw TAP, received frames, exact exits, callback/error observations and cleanup are retained. No source or dist fallback exists.

summary.json contains the first seven; summary.bad-run-id-bad-entry-file.json contains the two additional negatives. cleanup.json verifies exact worker and parent PIDs are ESRCH and every actual channel socket is absent. snapshot-sha256.txt identifies copied bytes; source-correspondence.json compares that closure with the shared source after execution.
