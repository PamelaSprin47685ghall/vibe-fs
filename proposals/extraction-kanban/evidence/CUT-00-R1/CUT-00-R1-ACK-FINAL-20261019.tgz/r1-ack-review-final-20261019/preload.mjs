import { installFinitePhysicalWait } from './fixed-support/finite-physical-wait.mjs'

installFinitePhysicalWait(JSON.parse(process.env.R1_ACK_DESCRIPTOR))
