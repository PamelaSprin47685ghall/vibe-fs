import assert from 'node:assert/strict'
import test from 'node:test'
import { existsSync, writeFileSync } from 'node:fs'
import { setTimeout as delay } from 'node:timers/promises'
import { withFinitePhysicalWait } from './fixed-support/finite-physical-wait.mjs'

const mode = process.env.R1_ACK_MODE
const evidence = process.env.R1_ACK_EVIDENCE
const marker = process.env.R1_ACK_MARKER
const options = { operation: `ACK boundary ${mode}`, limitMs: 3000 }
let callbacks = 0

async function markerAppeared() {
  const deadline = performance.now() + 800
  while (!existsSync(marker)) {
    assert.ok(performance.now() < deadline, 'the real begin frame must reach the real socket')
    await delay(5)
  }
}

if (mode === 'context-closed-late') {
  let oldOperation
  test('WHAT[verification-system-006] close the real context after its real begin is sent', async context => {
    oldOperation = withFinitePhysicalWait(context, options, () => { callbacks += 1 })
      .then(() => ({ fulfilled: true }), error => ({ error }))
    await markerAppeared()
  })
  test('WHAT[verification-system-006] a late grant cannot run an already closed context', async () => {
    const outcome = await oldOperation
    assert.equal(outcome.fulfilled, undefined)
    assert.match(outcome.error.message, /context closed/)
    await delay(400)
    assert.equal(callbacks, 0)
    writeFileSync(evidence, JSON.stringify({ mode, callbacks, error: outcome.error.message,
      pid: process.pid, parentPid: process.ppid }))
  })
} else {
  test(`WHAT[verification-system-006] actual helper ACK boundary ${mode}`, async context => {
    let failure
    if (mode === 'positive') {
      const value = await withFinitePhysicalWait(context, options, () => {
        callbacks += 1
        return 41
      })
      assert.equal(value, 41)
      assert.equal(callbacks, 1)
    } else if (mode === 'end-lost') {
      const original = new Error('original action exception identity')
      try {
        await withFinitePhysicalWait(context, options, () => {
          callbacks += 1
          throw original
        })
        assert.fail('the two failures must reject')
      } catch (error) {
        assert.ok(error instanceof AggregateError)
        assert.equal(error.cause, original)
        assert.equal(error.errors[0], original)
        assert.equal(error.errors.length, 2)
        assert.match(error.errors[1].message, /reply deadline expired/)
        failure = { message: error.message, errors: error.errors.map(value => value.message),
          originalCauseRetained: error.cause === original }
      }
      assert.equal(callbacks, 1)
    } else {
      if (mode === 'late-delivered') context.mock.timers.enable({ apis: ['setTimeout'] })
      try {
        await assert.rejects(withFinitePhysicalWait(context, options, () => { callbacks += 1 }), error => {
          assert.match(error.message, mode === 'refused' ? /controlled refusal/
            : ['bad-run-id', 'bad-entry-file'].includes(mode) ? /reply identity mismatch/
            : mode === 'late-delivered' ? /reply arrived after its deadline/ : /reply deadline expired/)
          failure = { message: error.message }
          return true
        })
      } finally {
        if (mode === 'late-delivered') context.mock.timers.reset()
      }
      if (mode === 'deadline-late') await delay(400)
      assert.equal(callbacks, 0)
    }
    await assert.rejects(withFinitePhysicalWait(context,
      { operation: 'no retry after the first exchange', limitMs: 3000 }, () => { callbacks += 1 }),
    /already declared/)
    assert.equal(callbacks, ['positive', 'end-lost'].includes(mode) ? 1 : 0)
    writeFileSync(evidence, JSON.stringify({ mode, callbacks, failure,
      pid: process.pid, parentPid: process.ppid }))
  })
}
