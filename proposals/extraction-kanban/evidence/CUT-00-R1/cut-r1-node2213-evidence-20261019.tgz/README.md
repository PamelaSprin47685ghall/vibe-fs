# CUT-00-R1: actual Node 22.13.0 identity and native-event probe

Non-author contract validation only. No shared source, requirement or test was edited. No R1 production implementation was installed. The previous Node 26 socket/diagnostic prototype was not rerun.

## Fixed runtime

The available normal Node was v26.6.0 on darwin arm64. No 22.13 distribution was found in the inspected `/private/tmp` paths or conventional nvm/fnm/volta/node-cache/Homebrew node@22 locations. This is a bounded cache inspection, not a claim about every file on the computer.

The sandboxed archive and manifest fetch both returned curl error 6, `Could not resolve host: nodejs.org`, before downloading anything. One authorized execution outside that network restriction downloaded the fixed official archive and manifest successfully. `download-archive.log` and `download-shasums.log` preserve those successful requests. There were no repeated version guesses or alternate download sites.

- Official archive: `https://nodejs.org/dist/v22.13.0/node-v22.13.0-darwin-arm64.tar.gz`
- Official manifest: `https://nodejs.org/dist/v22.13.0/SHASUMS256.txt`
- Archive SHA-256 from that manifest and independent local computation: `bc1e374e7393e2f4b20e5bbc157d02e9b1fb2c634b2f992136b38fb8ca2023b7`.
- Executable: `/private/tmp/cut-r1-node2213-review.VKeI2I/node-v22.13.0-darwin-arm64/bin/node`
- Executable SHA-256: `5c79f8e198fd2456ea6660aaa6be218f9f44747f2306c7d0f5f97b087b2f2dfc`.
- The actual parent and every test-worker body recorded version `v22.13.0` and this executable path. Runtime component versions and local macOS version are preserved in `runtime.json` and `platform.log`.

The digest comparison uses the official HTTPS manifest. It is not a separate GPG-signature verification claim. Nothing was installed into the system, and the normal Node executable was not changed. The downloaded archive and extracted distribution remain in this private temporary directory for the next authorized tests. The small evidence archive excludes those distribution bytes; their fixed official URL and hashes are retained.

## One bounded native execution

`probe.mjs` ran once under the actual 22.13 binary, using real process-isolated `node:test.run`, a single owned test file and a 3-second abort backstop. It exited 0. Its worker declared 13 ordinary test invocations, including parent invocations, and emitted 82 native events. `analyse.mjs` then checked the preserved observations under the same actual binary and exited 0; it did not rerun the tests.

Raw receipts:

- `native-events.ndjson`: every TestsStream event, its parent-side observation time and complete JSON data, including file wrapper and summaries.
- `worker-records.ndjson`: real beforeEach/body/afterEach/signal observations, object-token identity, context names and actual worker runtime.
- `probe.log` / `summary.json`: runtime/hash and first assertions.
- `analysis.log` / `analysis.json`: exact terminal-event pairs, wrapper completion and cross-invocation checks.

## Observed facts

1. All 13 invocations used the exact same TestContext object in beforeEach, body and afterEach, proved by the same private WeakMap key. A new context was registered once per invocation. Their observed worker sequences are beforeEach → body → afterEach → signal-abort. The next body observes the prior saved context's signal already aborted and its recorded closed flag set. In particular the first repeated-name context aborts before the second repeated-name beforeEach.
2. Actual dequeue data contains `nesting`, `name`, `line`, `column`, `file`. It contains neither testId nor testNumber. Two top-level same-name declarations generated at the same source location have completely equal dequeue data. Their later terminal testNumbers are 3 and 4, but those numbers are unavailable at dequeue.
3. Repeated nested child declarations likewise have equal dequeue data. More strongly, two concurrently executing same-name children at the same source location both dequeue before either complete; both bodies enter before either finishes. Their entire dequeue data is equal. Their worker fullName is also equal. Matching by name, fullName, location or nesting cannot uniquely bind them.
4. All 13 ordinary invocations generate both complete and pass, with the same terminal testNumber/location/name for that invocation. Complete precedes pass. Complete additionally reports `details.passed`; pass is a later report observation of the same end. The unmatched fourteenth complete is the real file wrapper and is retained separately. No second renewal should be inferred from the later pass.
5. A top-level test literally named `a > b` and a child `b` under parent `a` both expose fullName `a > b`. A fullName string must not be parsed as an unambiguous ancestry encoding.

These results support pre-registering helper context state in beforeEach, sealing it on the real signal, retaining consumed/closed tombstones and refusing ambiguous native attribution. They support the proposed restriction to provably attributable invocations rather than guessing concurrent name matches. The probe does not implement that policy.

## Limits

Parent and worker performance clocks have different origins. Their absolute timestamps are not treated as interchangeable. Lifecycle order is asserted within the worker trace; native-event order is asserted within the parent trace. This probe does not claim a new cross-process clock authority.

This is an actual minimum-version execution for the stated context/event facts on the current macOS arm64 platform. It is not full R1 acceptance or a claim about all Node versions/platforms. It does not prove control ACK transport, per-file deadline arbitration, expiry/late-message behavior, physical long-wait permission, stream/final-summary/exit enforcement, owned-descendant cleanup, complete formal 003/025, Bun R2 or isolated-PTY R3. R12-U1 remains deferred.

## Reproduce with the retained runtime

```sh
/private/tmp/cut-r1-node2213-review.VKeI2I/node-v22.13.0-darwin-arm64/bin/node probe.mjs
/private/tmp/cut-r1-node2213-review.VKeI2I/node-v22.13.0-darwin-arm64/bin/node analyse.mjs
```

The two scripts write only into this private evidence directory. Keep the original receipt files before a deliberate reproduction; do not overwrite a red result and call it the same run.
