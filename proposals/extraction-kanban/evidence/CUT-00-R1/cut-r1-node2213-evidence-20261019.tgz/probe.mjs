import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { appendFileSync, readFileSync, writeFileSync } from 'node:fs'
import { run } from 'node:test'
import { fileURLToPath } from 'node:url'

assert.equal(process.version, 'v22.13.0')
const file = fileURLToPath(new URL('./invocations.test.mjs', import.meta.url))
const output = new URL('./native-events.ndjson', import.meta.url)
const workerOutput = new URL('./worker-records.ndjson', import.meta.url)
writeFileSync(output, '')
writeFileSync(workerOutput, '')
const observations = []
const controller = new AbortController()
const timer = setTimeout(() => controller.abort(new Error('Native identity probe exceeded 3 seconds')), 3000)
const replacer = (_key, value) => value instanceof Error
  ? { ...value, name: value.name, message: value.message, stack: value.stack }
  : typeof value === 'bigint' ? value.toString() : value
try {
  const stream = run({ files: [file], concurrency: 1, signal: controller.signal })
  for await (const event of stream) {
    const observation = { at: performance.now(), type: event.type, data: event.data }
    observations.push(observation)
    appendFileSync(output, JSON.stringify(observation, replacer) + '\n')
  }
} finally { clearTimeout(timer) }
assert.equal(observations.filter(event => event.type === 'test:fail').length, 0)
const workers = readFileSync(workerOutput, 'utf8').trim().split('\n').map(line => JSON.parse(line))
assert.ok(workers.length > 0)
assert.ok(workers.every(record => record.runtime === 'v22.13.0' && record.executable === process.execPath))
const bodies = workers.filter(record => record.type === 'body')
for (const item of bodies) {
  const lifecycle = workers.filter(record => record.token === item.token)
  assert.equal(lifecycle.filter(record => record.type === 'beforeEach').length, 1)
  assert.equal(lifecycle.filter(record => record.type === 'afterEach').length, 1)
  assert.equal(lifecycle.filter(record => record.type === 'signal-abort').length, 1)
  assert.ok(lifecycle.findIndex(record => record.type === 'beforeEach') < lifecycle.findIndex(record => record.type === 'body'))
  assert.ok(lifecycle.findIndex(record => record.type === 'body') < lifecycle.findIndex(record => record.type === 'afterEach'))
  assert.ok(lifecycle.findIndex(record => record.type === 'afterEach') < lifecycle.findIndex(record => record.type === 'signal-abort'))
}
const leaves = name => observations.filter(event => event.data?.name === name)
const sequential = leaves('sequential repeated')
const sequentialDequeues = sequential.filter(event => event.type === 'test:dequeue')
assert.equal(sequentialDequeues.length, 2)
assert.deepEqual(sequentialDequeues[0].data, sequentialDequeues[1].data)
const concurrent = leaves('same concurrent')
const concurrentDequeues = concurrent.filter(event => event.type === 'test:dequeue')
assert.equal(concurrentDequeues.length, 2)
assert.deepEqual(concurrentDequeues[0].data, concurrentDequeues[1].data)
assert.equal('testId' in concurrentDequeues[0].data, false)
assert.equal('testNumber' in concurrentDequeues[0].data, false)
const firstConcurrentComplete = observations.findIndex(event => event.type === 'test:complete' && event.data?.name === 'same concurrent')
const lastConcurrentDequeue = observations.findLastIndex(event => event.type === 'test:dequeue' && event.data?.name === 'same concurrent')
assert.ok(lastConcurrentDequeue < firstConcurrentComplete)
const sameFullName = bodies.filter(record => record.fullName === 'a > b')
assert.equal(sameFullName.length, 2)
assert.deepEqual(new Set(sameFullName.map(record => record.name)), new Set(['a > b', 'b']))
const summary = {
  runtime: process.version, executable: process.execPath, arch: process.arch, platform: process.platform,
  binarySha256: createHash('sha256').update(readFileSync(process.execPath)).digest('hex'),
  rawEventCount: observations.length, bodyCount: bodies.length,
  actualContextLifecycle: bodies.map(item => ({ token: item.token, name: item.name, fullName: item.fullName,
    sequence: workers.filter(record => record.token === item.token).map(record => record.type) })),
  sequential: sequential.map(event => ({ type: event.type, data: event.data })),
  concurrent: concurrent.map(event => ({ type: event.type, data: event.data })),
  concurrentAmbiguityProven: true,
  fullNameCollision: sameFullName,
  scope: 'Actual official Node 22.13.0 darwin arm64 process-isolated node:test. Native fields and real context lifecycle only; no production allowance, socket, watchdog, owned descendant cleanup or R1 acceptance is implemented.',
}
writeFileSync(new URL('./summary.json', import.meta.url), JSON.stringify(summary, replacer, 2) + '\n')
console.log(JSON.stringify(summary, replacer, 2))
