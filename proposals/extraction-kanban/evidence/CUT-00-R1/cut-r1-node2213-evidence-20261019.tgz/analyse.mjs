import assert from 'node:assert/strict'
import { readFileSync, writeFileSync } from 'node:fs'

assert.equal(process.version, 'v22.13.0')
const lines = name => readFileSync(new URL(name, import.meta.url), 'utf8').trim().split('\n').map(line => JSON.parse(line))
const events = lines('native-events.ndjson')
const workers = lines('worker-records.ndjson')
const key = data => JSON.stringify([data.file, data.line, data.column, data.nesting, data.name, data.testNumber])
const completes = events.map((event, index) => ({ ...event, index })).filter(event => event.type === 'test:complete')
const passes = events.map((event, index) => ({ ...event, index })).filter(event => event.type === 'test:pass')
const terminalPairs = passes.map(pass => {
  const matches = completes.filter(complete => key(complete.data) === key(pass.data))
  assert.equal(matches.length, 1)
  assert.ok(matches[0].index < pass.index)
  assert.equal('testId' in pass.data, false)
  return { name: pass.data.name, nesting: pass.data.nesting, testNumber: pass.data.testNumber,
    completeIndex: matches[0].index, passIndex: pass.index,
    completeFields: Object.keys(matches[0].data), passFields: Object.keys(pass.data) }
})
assert.equal(terminalPairs.length, 13)
const wrapperComplete = completes.filter(complete => !passes.some(pass => key(pass.data) === key(complete.data)))
assert.equal(wrapperComplete.length, 1)
assert.equal(wrapperComplete[0].data.name, wrapperComplete[0].data.file)
const nested = events.filter(event => event.type === 'test:dequeue' && event.data.name === 'repeated child')
assert.equal(nested.length, 2)
assert.deepEqual(nested[0].data, nested[1].data)
const sequentialBodies = workers.filter(record => record.type === 'body' && record.name === 'sequential repeated')
assert.equal(sequentialBodies.length, 2)
assert.ok(workers.findIndex(record => record.type === 'signal-abort' && record.token === sequentialBodies[0].token)
  < workers.findIndex(record => record.type === 'beforeEach' && record.token === sequentialBodies[1].token))
const concurrentWorkers = workers.filter(record => record.name === 'same concurrent')
assert.ok(concurrentWorkers.findLastIndex(record => record.type === 'body')
  < concurrentWorkers.findIndex(record => record.type === 'concurrent-body-finished'))
const analysis = { runtime: process.version, terminalPairs, wrapperComplete,
  nestedIdenticalDequeueData: nested[0].data,
  sequentialOldContextAbortedBeforeNextBeforeEach: true,
  concurrentBothBodiesEnteredBeforeEitherFinished: true,
  scope: 'Assertions over preserved actual raw observations. No invocation matching or watchdog implementation is installed.' }
writeFileSync(new URL('./analysis.json', import.meta.url), JSON.stringify(analysis, null, 2) + '\n')
console.log(JSON.stringify(analysis, null, 2))
