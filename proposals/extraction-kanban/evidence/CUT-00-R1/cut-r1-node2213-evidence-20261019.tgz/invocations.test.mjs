import assert from 'node:assert/strict'
import { appendFileSync } from 'node:fs'
import { beforeEach, afterEach, test } from 'node:test'

const path = new URL('./worker-records.ndjson', import.meta.url)
const contexts = new WeakMap()
let nextToken = 0
let oldContext
const record = (type, context, extra = {}) => appendFileSync(path, JSON.stringify({
  type, at: performance.now(), runtime: process.version, executable: process.execPath,
  token: contexts.get(context)?.token, name: context.name, fullName: context.fullName,
  filePath: context.filePath, aborted: context.signal.aborted, ...extra,
}) + '\n')
beforeEach(context => {
  assert.equal(contexts.has(context), false)
  const state = { token: ++nextToken, closed: false }
  contexts.set(context, state)
  record('beforeEach', context)
  context.signal.addEventListener('abort', () => {
    state.closed = true
    record('signal-abort', context)
  }, { once: true })
})
afterEach(context => {
  assert.ok(contexts.has(context), 'afterEach receives the registered context')
  record('afterEach', context)
})
const body = (context, extra = {}) => {
  assert.ok(contexts.has(context), 'body receives exactly the beforeEach context')
  assert.equal(contexts.get(context).closed, false)
  record('body', context, extra)
}

test('context identity', context => {
  body(context)
  oldContext = context
})
test('context closure observed by the next body', context => {
  body(context)
  assert.equal(oldContext.signal.aborted, true)
  assert.equal(contexts.get(oldContext).closed, true)
  record('old-context-closed', context, { oldToken: contexts.get(oldContext).token })
})
for (let index = 0; index < 2; index += 1) {
  test('sequential repeated', context => body(context, { index }))
}
test('nested parent', async context => {
  body(context)
  for (let index = 0; index < 2; index += 1) {
    await context.test('repeated child', child => body(child, { index }))
  }
})
test('concurrent parent', { concurrency: true, timeout: 1000 }, async context => {
  body(context)
  let arrived = 0
  let release
  const barrier = new Promise(resolve => { release = resolve })
  await Promise.all(Array.from({ length: 2 }, (_, index) => context.test('same concurrent', async child => {
    body(child, { index })
    arrived += 1
    if (arrived === 2) release()
    await barrier
    record('concurrent-body-finished', child, { index })
  })))
})
test('a > b', context => body(context))
test('a', async context => {
  body(context)
  await context.test('b', child => body(child))
})
