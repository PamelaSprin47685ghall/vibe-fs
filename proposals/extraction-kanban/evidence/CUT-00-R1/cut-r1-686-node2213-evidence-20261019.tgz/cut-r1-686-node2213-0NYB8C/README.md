# CUT-00-R1 build 686: final independent Node 22.13 check

Reviewer: d1_review_git. This review edited no shared file. The candidate was identified by root as frozen build 686.

The real official Node v22.13.0 darwin-arm64 executable was used, not a newer runtime with removed fields:

- Executable: `/private/tmp/cut-r1-node2213-review.VKeI2I/node-v22.13.0-darwin-arm64/bin/node`
- Executable SHA-256: `5c79f8e198fd2456ea6660aaa6be218f9f44747f2306c7d0f5f97b087b2f2dfc`
- Official distribution SHA-256: `bc1e374e7393e2f4b20e5bbc157d02e9b1fb2c634b2f992136b38fb8ca2023b7`
- Distribution URL: `https://nodejs.org/dist/v22.13.0/node-v22.13.0-darwin-arm64.tar.gz`
- Official checksum verification and runtime identity receipts: `/private/tmp/cut-r1-node2213-evidence-20261019.tgz`, SHA-256 `440ad94586069ebaf9d8e15a70903182763d68bdcbfe0436c80bed235d5ce5f9`.

Command, from `/Users/yuanxi/Workwork/vibe-fs`:

```sh
/private/tmp/cut-r1-node2213-review.VKeI2I/node-v22.13.0-darwin-arm64/bin/node /private/tmp/cut-r1-686-node2213-0NYB8C/run-006.mjs
```

`run-006.mjs` invokes the actual full current `requirements/verification-system/tests/006.test.mjs` using native node:test.run(), with no name filter. One authorized execution outside sandbox restrictions was performed because build 684 had already demonstrated that the sandbox denies required Unix sockets and ps observation. There was no failed 686 sandbox retry. The same driver's earlier 684 evidence remains separate and unchanged.

The process exited 0 after 38.28 seconds. Both actual native summaries report success, 79 passed, 0 failed, 0 cancelled, 0 skipped and 0 TODO. The raw stream contains 80 dequeue and complete events including the file wrapper, plus 79 pass events. All eight ACK boundary modes and the added nested-test refusal have actual test:pass records. Every raw event is in `native-events.ndjson`, with native error fields preserved by the driver if present. `result.json` and stdout/stderr are retained.

The 14 staged input files had identical pre/post SHA-256 values. `input-manifest.json` records hashes, executable identity, base commit and execution scope. `source-snapshot.tgz` contains the exact source copies taken before execution, indexed by `candidate-files.txt`; `frozen-staged.patch` preserves the complete staged patch. This is a pre/post comparison, not continuous proof against a transient input change. No package installation or release SHA is claimed. Existing fixture commands explicitly named node use inherited PATH; descendants spawned through process.execPath use the real Node 22.13 executable.

## Limited final source review

No new semantic blocker was found in the changed client, context or backstop boundary. The client now checks ACK contextToken, phase, runId and entryFile. A declared operation is consumed before the first exchange; timeout/refusal/malformed or wrong-instance ACKs cannot run the action or resend begin. The context-closed-late fixture sends a real begin, lets the actual TestContext end, then receives the late reply; the action count stays zero. The end-lost fixture retains the original action error identity and cause alongside the end acknowledgement error. The nested test is refused by the ordinary-top-level binding rule, and a later ordinary leaf still finishes. These observations do not claim that the isolated ACK fixture itself exercises the entire outer deadline owner; the remaining full 006 tests exercise that actual formal owner.

The physical backstop stops the deadline owner and clears its timer before deferred diagnostics/termination. New control requests cannot obtain a grant after stop. The prior semicolon-separated multi-action generated fixture was expanded manually. The scope remains verification support, WHAT/BOARD and corresponding PTY test call sites; no unrelated product source or library modification appeared. Requirement-numbered tests and WHAT anchors remain intact. `git diff --cached --check` exited 0 during this review.

This is the final minimum-Node full-006 receipt and limited source review. Root owns the final formal seven-file acceptance, including complete Process 003 and Lifecycle 025, plan closure and commit/push. This receipt alone does not close all R1 obligations, the separate Bun supervision card, or R12-U1. R12-U1 was not investigated.
