# CUT-00-R1 final bounded-preload gate, independent replay

Non-author read-only review of the final frozen current source during candidate689 acceptance. No shared file was edited. Node v26.6.0. This directory copies the same 12-file actual verification closure and the five original private fixture/runner files. All five fixture files are byte-identical to the first review. Only the fixed implementation closure changed. There is no repository or dist fallback.

The original exact stdout assertion was replayed once, without weakening or replacing it. Result: 3 native tests pass, 0 fail; exit0 with no signal; actual file completes and drains; owned process group cleanup accepted. Seven body diagnostic routes remain on stderr and absent from outer stdout. The ordinary fork inherits the bound preload but retains fd1/2 and its exact two stdout lines. Its stderr is empty, with no worker-cost or zero-test native frames added. The later actual finite action executes once, waits900ms across the ordinary600ms window and completes through genuine native dequeue/ACK.

The first review's 2pass/1fail and the HEAD old/new inheritance comparison remain immutable in CUT-00-R1-OUTPUT-REVIEW-FIRST-20261019.tgz, SHA256 6a1a469729d74cb87af3973d2117cd7aa4518d3ac2bc11dd028c45b84c6b652d. That failure was an old unscoped preload side effect; this narrow bound-preload gate now fixes it. The old assertion was not relabeled as pass.

## Source review

Bound verdict transport checks actual main-thread status, exact argv entry and actual process.ppid before dynamically importing node:test or the helper. Outer assigns the inner PID; inner strictly verifies descriptor.workerParentPid equals its actual process.pid. A same-entry fork has the wrong actual parent, and a different-entry fork has the wrong entry. Worker threads fail the main-thread test. The captured native reporter exists before replacing the public stdout getter and canonical Console methods; syncBuiltinESMExports updates named process/console bindings.

This is an execution-instance gate, not a claim that PID text authenticates arbitrary remote clients. The random channel capability and owner-native binding remain separate. Legacy unbound direct transport preserves its prior behavior; this replay concerns the bound formal path. Child source that independently imports node:test can still create its own test harness; the gate only prevents this preload from adding one.

The author also changed the closed diagnostic sink fixture to close fd2, which is now the real worker-cost sink. fd1 remains a separately named protocol-closed positive control. This review checked those source preconditions; it does not recount the author's twelve-case execution as an independent runtime.

## Evidence and limits

actual.stdout.raw / actual.stderr.raw and actual.status.json retain the full real run. Ordinary child raw stdout/stderr bytes and its actual fd/parent/preload observation are saved. cleanup.json, first-cleanup.json and final-cleanup.raw check exact launcher, inner, worker and ordinary-fork PIDs are ESRCH, the actual socket is absent and owned HOME is removed. The inherited first-cleanup filename comes from the unchanged original cleanup script and contains this final run's actual identities.

correspondence.json proves all12 copied source files match shared source after execution and all5 original fixtures match their first-review bytes. It also lists the exact implementation changes between snapshots. The six collector and real idempotent-close checks remain in the first archive; unchanged modules were not blindly rerun. Same-entry-fork and minimum22 runtime evidence belongs to the author's/host reviewer's separate runs, not this one. Full formal7-file acceptance remains separate.

Replay after extraction:

```
node run.mjs
node cleanup.mjs
```

Requires local Unix socket, process inspection and owned process termination permissions. The copied package.json only reproduces the repository's ESM setting for the private snapshot. R12-U1 and unrelated product work are excluded.
