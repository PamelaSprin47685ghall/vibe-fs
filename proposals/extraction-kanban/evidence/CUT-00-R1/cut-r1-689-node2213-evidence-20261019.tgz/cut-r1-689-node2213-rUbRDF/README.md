# CUT-00-R1 build 689: final independent Node 22.13 verification

Reviewer: d1_review_git. Root identified the frozen source candidate as build 689. This reviewer edited no shared source and performed one full-006 execution on this candidate. No further run was added after its green result.

## Actual execution and inputs

The real official Node v22.13.0 darwin-arm64 executable was used:

- Executable: `/private/tmp/cut-r1-node2213-review.VKeI2I/node-v22.13.0-darwin-arm64/bin/node`
- Executable SHA-256: `5c79f8e198fd2456ea6660aaa6be218f9f44747f2306c7d0f5f97b087b2f2dfc`
- Official distribution SHA-256: `bc1e374e7393e2f4b20e5bbc157d02e9b1fb2c634b2f992136b38fb8ca2023b7`
- Distribution URL: `https://nodejs.org/dist/v22.13.0/node-v22.13.0-darwin-arm64.tar.gz`
- Official checksum/runtime receipts: `/private/tmp/cut-r1-node2213-evidence-20261019.tgz`, SHA-256 `440ad94586069ebaf9d8e15a70903182763d68bdcbfe0436c80bed235d5ce5f9`.

Command, from `/Users/yuanxi/Workwork/vibe-fs`:

```sh
/private/tmp/cut-r1-node2213-review.VKeI2I/node-v22.13.0-darwin-arm64/bin/node /private/tmp/cut-r1-689-node2213-rUbRDF/run-006.mjs
```

The driver invokes native node:test.run() on the actual entire current 006.test.mjs with no name filter. The process exited 0 after 40.66 seconds. Both native summaries report success: 84 passed, 0 failed, 0 cancelled, 0 skipped and 0 TODO. There were 85 dequeue/complete observations including the file wrapper and 84 pass observations. Complete native events, actual summaries and stdout/stderr are retained. This is actual minimum-version execution, not Node 26 with deleted fields.

The exact sixteen staged input files have equal pre/post SHA-256 values in input-manifest.json. source-snapshot.tgz contains the pre-run source copies indexed by candidate-files.txt; frozen-staged.patch preserves the patch against the recorded base commit. snapshot-verification.json compares each declared source copy with the runtime manifest. This is an endpoint hash check rather than a continuous watcher. Root's build number identifies the frozen source candidate; no independently installed package SHA is claimed. Existing fixture commands explicitly named node resolve from inherited PATH, while process.execPath descendants use actual Node 22.13.

## Confirmed focused boundaries

The complete file includes actual passes for:

- Allocated preload isolation for ordinary fork of the same entry and another entry: exact child stdout and stderr stay on their original channels.
- The closed-sink matrix: actual diagnostic fd2 closure yields a missing exit receipt, while fd1 closure is a strict complete-receipt positive control. Original pass/failure result, real worker identity, no uncaught stream error and owned cleanup assertions remain.
- Independent stdout/stderr fragment buffers, shared actual body/cost PID validation and mismatched body-PID rejection.
- Six real body diagnostic forms kept observable on stderr without entering the native reporter stream.
- Real drained-file socket release before the next entry.
- Synchronous burst followed by four real finite admissions, all eight ACK modes, stale/closed context and nested refusal, ordinary positive finite wait and original synchronous/verdict timing cases.

These are actual registered requirement cases within the full 84-test file, not private replacements. The isolated ACK cases prove the actual helper exchange boundary; the actual formal-entry cases separately exercise the supervisor/deadline owner. A diagnostic line is never treated as a verdict or renewal.

## Limited final source and AGENTS review

No new semantic blocker was found in the inspected R1 algorithm. NativeTestSupervision is the formal deadline/invocation owner. Each active file retains its own earliest bound; a pending begin grants no provisional time; accepted operation deadlines are absolute and non-renewable; end does not release its allowance; only the genuine matching complete clears the ended operation. Pass/fail are not another renewal. Every transition checks expiry before processing; stop/backstop cannot be revived by a late control or verdict. Real contexts are registered before body entry and sealed at lifecycle end. Reuse and ambiguous/nested/concurrent binding are refused. Final verdict, file completion/drain, authoritative summary, child exit and owned cleanup remain separate acceptance gates.

The final allocated preload checks main thread, exact entry and actual ppid against the outer's known inner PID before dynamically importing node:test or the finite helper. The inner independently requires workerParentPid to equal its own PID. Thus an inherited same-entry ordinary fork cannot start the test transport or redirect its streams merely by sharing argv[1]. Cost/body fragment buffers are separate per channel; identity and the pre-import/exit facts have one owner. Output redirection is restricted to the actual allocated test entry and updates canonical/named process/console exports. File drain releases its listener; final cleanup retains resource ownership.

Scope remains verification requirements/support/tests, corresponding Process 003 and Lifecycle 025 test call sites and BOARD. No product src, library, persistent business semantics or global default silence value was changed. Requirement-numbered filenames and WHAT anchors are preserved. The reported generated-fixture multi-action line was manually expanded. git diff --cached --check exited 0. This reviewer did not run a build or edit shared files; root owns Fable/check and the required report/status updates.

## Preserved failures and final limits

The old 686 formal ACK failures, the 687 marker-to-observer wiring regression and the 688 closed-sink fixture mismatch remain separate receipts. This final green does not overwrite them or retroactively change their inputs. In particular, 688 actually had 82 pass/1 fail; its fixture closed fd1 after diagnostics moved to fd2. The final repair migrates the missing-receipt premise and adds the old-fd positive control rather than relaxing the assertion. The 687 actual observer stderr omission was a new verification regression introduced by the marker move; the final two-channel path restores its identity check.

This receipt proves complete 006 on actual Node 22.13 and the limited non-author source review. Root owns final complete seven-file acceptance, including Process 003/Lifecycle 025, the final report, commit and push. It does not independently certify a package release, every OS or the separate Bun-supervision card. R12-U1 remains deferred and was not investigated.
