import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync, existsSync } from 'node:fs'
import { connect } from 'node:net'
import { once } from 'node:events'
import { pathToFileURL } from 'node:url'

const modulePath = process.argv[2]
const prefix = process.argv[3]
const { createFiniteWaitChannel } = await import(pathToFileURL(modulePath).href)
const sourceSha256 = createHash('sha256').update(readFileSync(modulePath)).digest('hex')
const result = { node: process.version, modulePath, sourceSha256, cases: [] }

async function runNullFrame() {
  const observed = { case: 'actual-null-frame', requests: [], onErrors: [], uncaught: [], closeObserved: false }
  const channel = await createFiniteWaitChannel({
    entryFile: '/private/tmp/r1-protocol-entry.test.mjs',
    onRequest: request => observed.requests.push(request),
    onError: error => observed.onErrors.push({ name: error.name, message: error.message }),
  })
  const socket = connect(channel.descriptor.path)
  socket.on('error', error => { observed.clientError = { name: error.name, message: error.message } })
  const uncaught = error => observed.uncaught.push({ name: error.name, message: error.message })
  process.on('uncaughtException', uncaught)
  try {
    await once(socket, 'connect')
    socket.write('null\n')
    await new Promise(resolve => setTimeout(resolve, 75))
  } finally {
    socket.destroy()
    await channel.close()
    process.removeListener('uncaughtException', uncaught)
    observed.closeObserved = !existsSync(channel.descriptor.path)
  }
  result.cases.push(observed)
}

async function runSplitUtf8() {
  const observed = { case: 'actual-split-utf8', expectedName: 'probe界', requests: [], onErrors: [] }
  let channel
  channel = await createFiniteWaitChannel({
    entryFile: '/private/tmp/r1-protocol-entry.test.mjs',
    onRequest(request) {
      observed.requests.push(request)
      if (request.phase !== 'cancel') channel.reply({ ...request, ok: true })
    },
    onError: error => observed.onErrors.push({ name: error.name, message: error.message }),
  })
  const socket = connect(channel.descriptor.path)
  socket.on('error', error => { observed.clientError = { name: error.name, message: error.message } })
  const payload = Buffer.from(JSON.stringify({ capability: channel.descriptor.capability,
    contextToken: 'a'.repeat(32), name: observed.expectedName, fullName: observed.expectedName,
    phase: 'begin', operation: 'split UTF8', limitMs: 1000 }) + '\n')
  const boundary = payload.indexOf(Buffer.from('界')) + 1
  observed.fragmentLengths = [boundary, payload.length - boundary]
  try {
    await once(socket, 'connect')
    socket.write(payload.subarray(0, boundary))
    await new Promise(resolve => setTimeout(resolve, 25))
    socket.write(payload.subarray(boundary))
    await Promise.race([once(socket, 'data'), new Promise((_, reject) => setTimeout(() => reject(new Error('No UTF8 reply')), 1000))])
  } finally {
    socket.destroy()
    await channel.close()
    observed.socketRemoved = !existsSync(channel.descriptor.path)
  }
  observed.namePreserved = observed.requests[0]?.name === observed.expectedName
  result.cases.push(observed)
}

await runNullFrame()
await runSplitUtf8()
writeFileSync(prefix + '.json', JSON.stringify(result, null, 2) + '\n')
console.log(JSON.stringify(result))
