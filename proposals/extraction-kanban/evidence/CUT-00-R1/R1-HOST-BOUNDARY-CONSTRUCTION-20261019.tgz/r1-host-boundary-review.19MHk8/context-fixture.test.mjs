import assert from 'node:assert/strict'
import test from 'node:test'

const url = process.execArgv.find(value => value.startsWith('--import=')).slice('--import='.length)
const { inspectContext } = await import(url)
let previous
test('first top-level', ctx => {
  assert.deepEqual(inspectContext(ctx), { serial: 1, sealed: false })
  previous = ctx
})
test('second top-level rejects previous identity', ctx => {
  assert.equal(inspectContext(previous).sealed, true)
  assert.equal(inspectContext(ctx).sealed, false)
  assert.equal(inspectContext({ name: ctx.name, fullName: ctx.fullName, signal: ctx.signal }), null)
})
test('parent with nested leaf', async ctx => {
  assert.equal(inspectContext(ctx).sealed, false)
  await ctx.test('nested leaf', nested => {
    assert.equal(inspectContext(nested).sealed, false)
    assert.notEqual(inspectContext(ctx).serial, inspectContext(nested).serial)
  })
})
