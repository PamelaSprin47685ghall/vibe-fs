import assert from 'node:assert/strict'
import test from 'node:test'
import { existsSync } from 'node:fs'
import { setTimeout } from 'node:timers/promises'

test('pending top-level native invocation', async () => {
  process.stdout.write('R1-BODY-IS-PENDING\n')
  while (!existsSync(process.env.R1_PRIVATE_GATE)) await setTimeout(5)
  assert.ok(existsSync(process.env.R1_PRIVATE_GATE))
})
