import assert from 'node:assert/strict'
import { run } from 'node:test'
import { rmSync, writeFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'

const gate = fileURLToPath(new URL('./live-dequeue-gate', import.meta.url))
rmSync(gate, { force: true })
process.env.R1_PRIVATE_GATE = gate
const fixture = fileURLToPath(new URL('./live-dequeue-fixture.test.mjs', import.meta.url))
const events = []
let releasedBy = null
const release = reason => {
  if (releasedBy !== null) return
  releasedBy = reason
  writeFileSync(gate, reason)
}
const fallback = setTimeout(() => release('finite-probe-fallback-without-native-dequeue'), 1500)
const stream = run({ files: [fixture], concurrency: 1, execArgv: [] })
stream.on('test:dequeue', data => {
  if (data.name === 'pending top-level native invocation') release('actual-native-dequeue-before-body-completion')
})
for await (const event of stream) events.push(event)
clearTimeout(fallback)
rmSync(gate, { force: true })
writeFileSync(fileURLToPath(new URL('./native-live-dequeue.json', import.meta.url)), JSON.stringify({ node: process.version, releasedBy, events }, null, 2) + '\n')
console.log(JSON.stringify({ releasedBy, failures: events.filter(event => event.type === 'test:fail').length }))
assert.equal(releasedBy, 'actual-native-dequeue-before-body-completion')
