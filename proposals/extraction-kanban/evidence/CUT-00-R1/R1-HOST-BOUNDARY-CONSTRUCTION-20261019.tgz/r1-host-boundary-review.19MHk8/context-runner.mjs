import { run } from 'node:test'
import { writeFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'

const fixture = fileURLToPath(new URL('./context-fixture.test.mjs', import.meta.url))
const preload = new URL('./context-preload.mjs?entry=exact', import.meta.url).href
const events = []
const stream = run({ files: [fixture], concurrency: 1, execArgv: ['--import=' + preload] })
for await (const event of stream) events.push(event)
writeFileSync(fileURLToPath(new URL('./native-context-events.json', import.meta.url)), JSON.stringify({ node: process.version, execPath: process.execPath, preload, events }, null, 2) + '\n')
const failures = events.filter(event => event.type === 'test:fail')
console.log(JSON.stringify({ events: events.length, failures: failures.length, dequeue: events.filter(event => event.type === 'test:dequeue').map(event => event.data) }))
if (failures.length) process.exitCode = 1
