import { beforeEach, afterEach } from 'node:test'

const tokens = new WeakMap()
let serial = 0
const observe = (kind, ctx, token) => process.stdout.write('R1-CONTEXT ' + JSON.stringify({ kind, name: ctx.name, fullName: ctx.fullName, token: token?.serial ?? null, sealed: token?.sealed ?? null, aborted: ctx.signal.aborted }) + '\n')
beforeEach(ctx => {
  const token = { serial: ++serial, sealed: false }
  tokens.set(ctx, token)
  observe('beforeEach', ctx, token)
  ctx.signal.addEventListener('abort', () => {
    token.sealed = true
    observe('abort', ctx, token)
  }, { once: true })
})
afterEach(ctx => {
  const token = tokens.get(ctx)
  observe('afterEach-same-context', ctx, token)
  if (token) token.sealed = true
})
export const inspectContext = ctx => tokens.has(ctx) ? { ...tokens.get(ctx) } : null
