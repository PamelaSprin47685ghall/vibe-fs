import { isMainThread, parentPort, threadId } from 'node:worker_threads'
const record = { kind: 'file-child', pid: process.pid, isMainThread, threadId, argv: process.argv,
  nodeTestContext: process.env.NODE_TEST_CONTEXT ?? null }
if (parentPort) parentPort.postMessage(record)
else if (process.send) process.send(record)
