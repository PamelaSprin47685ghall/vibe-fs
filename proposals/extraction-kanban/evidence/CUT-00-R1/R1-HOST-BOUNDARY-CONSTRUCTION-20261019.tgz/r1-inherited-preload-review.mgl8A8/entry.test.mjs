import test from 'node:test'
import assert from 'node:assert/strict'
import { Worker } from 'node:worker_threads'
import { fork } from 'node:child_process'
import { once } from 'node:events'
import { fileURLToPath } from 'node:url'

test('R1 real entry creates three inherited preload children', { timeout: 10000 }, async () => {
  const fileWorker = new Worker(new URL('./child.mjs', import.meta.url))
  const fileRecord = await once(fileWorker, 'message')
  assert.equal(fileRecord[0].isMainThread, false)
  await once(fileWorker, 'exit')
  const evalWorker = new Worker(`const {parentPort,isMainThread,threadId}=require('node:worker_threads'); parentPort.postMessage({kind:'eval-child',pid:process.pid,isMainThread,threadId,argv:process.argv,nodeTestContext:process.env.NODE_TEST_CONTEXT??null})`, { eval: true })
  const evalRecord = await once(evalWorker, 'message')
  assert.equal(evalRecord[0].isMainThread, false)
  await once(evalWorker, 'exit')
  const forked = fork(fileURLToPath(new URL('./child.mjs', import.meta.url)))
  const forkRecord = await once(forked, 'message')
  assert.equal(forkRecord[0].isMainThread, true)
  await once(forked, 'exit')
  console.log('R1-INHERITED-RESULT ' + JSON.stringify({ parent: { pid: process.pid, argv: process.argv }, fileWorker: fileRecord[0], evalWorker: evalRecord[0], fork: forkRecord[0] }))
})
