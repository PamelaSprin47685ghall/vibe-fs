import { isMainThread, threadId } from 'node:worker_threads'
console.log('R1-INHERITED-PRELOAD ' + JSON.stringify({
  node: process.version, pid: process.pid, parentPid: process.ppid,
  isMainThread, threadId, argv: process.argv, execArgv: process.execArgv,
  nodeTestContext: process.env.NODE_TEST_CONTEXT ?? null,
}))
