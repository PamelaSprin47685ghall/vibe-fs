import test from 'node:test'
import assert from 'node:assert/strict'
import { once } from 'node:events'
import { Worker } from 'node:worker_threads'
import { fork } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import { withFinitePhysicalWait } from '/Users/yuanxi/Workwork/vibe-fs/requirements/verification-system/tests/support/finite-physical-wait.mjs'

test('R1 actual granted operation keeps inherited Worker and fork available', { timeout: 8000 }, async context => {
  let executions = 0
  const children = []
  await withFinitePhysicalWait(context, { operation: 'real inherited preload child startup', limitMs: 3000 }, async () => {
    executions += 1
    const worker = new Worker(new URL('./child.mjs', import.meta.url))
    const workerExit = once(worker, 'exit')
    const [workerRecord] = await once(worker, 'message')
    assert.equal((await workerExit)[0], 0)
    assert.equal(workerRecord.isMainThread, false)
    children.push(workerRecord)
    const child = fork(fileURLToPath(new URL('./child.mjs', import.meta.url)))
    const childExit = once(child, 'exit')
    const [childRecord] = await once(child, 'message')
    assert.equal((await childExit)[0], 0)
    assert.equal(childRecord.isMainThread, true)
    children.push(childRecord)
  })
  assert.equal(executions, 1)
  assert.equal(children.length, 2)
  console.log('R1-REAL-INHERITANCE ' + JSON.stringify({ executions, children }))
})
