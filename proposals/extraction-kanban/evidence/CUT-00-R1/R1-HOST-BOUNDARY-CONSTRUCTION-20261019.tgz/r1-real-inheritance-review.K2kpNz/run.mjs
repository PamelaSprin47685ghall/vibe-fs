import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync } from 'node:fs'
import { superviseNodeTest } from '/Users/yuanxi/Workwork/vibe-fs/requirements/verification-system/tests/e2e/support/supervise-node-test.mjs'
const root = '/Users/yuanxi/Workwork/vibe-fs/requirements/verification-system/tests/'
const sources = [ 'support/finite-physical-wait.mjs', 'support/finite-wait-channel.mjs', 'support/native-test-supervision.mjs', 'support/verdict-transport.mjs', 'support/run-inner.mjs', 'e2e/support/supervise-node-test.mjs' ]
const hashes = () => Object.fromEntries(sources.map(path => [path, createHash('sha256').update(readFileSync(root + path)).digest('hex')]))
const result = { node: process.version, before: hashes(), plannedRuns: 1,
  scope: 'real source supervised one native entry; one finite callback spawning one inherited file Worker and one inherited fork' }
delete process.env.NODE_TEST_CONTEXT
try {
  result.outcome = await superviseNodeTest({ files: [new URL('./entry.test.mjs', import.meta.url).pathname], label: 'R1 real inheritance review', silenceMs: 5000 })
  result.accepted = true
} catch (error) {
  result.accepted = false
  result.error = { name: error.name, message: error.message, stack: error.stack }
  process.exitCode = 1
} finally {
  result.after = hashes()
  result.sourceStable = JSON.stringify(result.before) === JSON.stringify(result.after)
  writeFileSync(new URL('./result.json', import.meta.url), JSON.stringify(result, null, 2) + '\n')
}
