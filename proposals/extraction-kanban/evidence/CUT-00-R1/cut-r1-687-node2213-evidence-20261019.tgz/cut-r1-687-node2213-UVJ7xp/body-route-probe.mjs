import assert from 'node:assert/strict'
import { writeFileSync } from 'node:fs'
import { createWorkerCostObserver, encodeWorkerCostRecord } from '/Users/yuanxi/Workwork/vibe-fs/requirements/verification-system/tests/support/worker-cost-observation.mjs'

assert.equal(process.version, 'v22.13.0')
const entryFile = '/private/tmp/controlled-worker.test.mjs'
const preImport = { version: 1, phase: 'pre-import', sequence: 0, entryFile,
  pid: 501, parentPid: 500, monotonicMs: 10, cpuUserMicros: 100, cpuSystemMicros: 30 }
const exit = { ...preImport, phase: 'exit', sequence: 1,
  monotonicMs: 20, cpuUserMicros: 140, cpuSystemMicros: 42, exitCode: 0 }
const body = `[verification-test-start] ${JSON.stringify({ entryFile, pid: 502, parentPid: 500 })}\n`
function observed(bodyChannel) {
  const observer = createWorkerCostObserver({ entryFile, parentPid: 500 })
  for (const [type, message] of [
    ['test:stdout', encodeWorkerCostRecord(preImport)],
    [bodyChannel, body],
    ['test:stdout', encodeWorkerCostRecord(exit)],
  ]) observer.observe({ type, data: { entryFile, file: entryFile, message } })
  return observer.finish()
}
const stdoutControl = observed('test:stdout')
const newStderrRoute = observed('test:stderr')
assert.equal(stdoutControl.status, 'invalid')
assert.equal(newStderrRoute.status, 'complete')
const result = { runtime: process.version, stdoutControl, newStderrRoute,
  counterexample: 'The actual cost observer rejects mismatched body PID on the old stdout route but ignores the identical record on the new stderr route and reports complete.',
  scope: 'Controlled diagnostic records through the real observer. Not a forged OS failure or an actual mismatched worker process. Real inner additionally forwards only stdout to this observer.' }
writeFileSync(new URL('./body-route-result.json', import.meta.url), JSON.stringify(result, null, 2) + '\n')
console.log(JSON.stringify(result, null, 2))
