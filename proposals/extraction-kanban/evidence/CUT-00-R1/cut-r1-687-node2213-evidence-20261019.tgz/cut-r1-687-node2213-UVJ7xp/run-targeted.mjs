import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { appendFileSync, readFileSync, writeFileSync } from 'node:fs'
import { run } from 'node:test'
import { spawnSync } from 'node:child_process'

assert.equal(process.version, 'v22.13.0')
const root = '/Users/yuanxi/Workwork/vibe-fs'
const file = `${root}/requirements/verification-system/tests/006.test.mjs`
const patterns = [
  'the actual physical wait ACK boundary',
  'a synchronous verdict burst cannot block',
  'synchronous work and microtasks deliver',
  'transport scheduling cannot renew',
  'transport scheduling preserves after-hook',
  'the real verdict transport records body entry',
  'a closed unused context cannot claim',
  'nested tests remain ordinary',
  'a real finite operation may outlast',
]
const output = new URL('./native-events.ndjson', import.meta.url)
const inputFiles = spawnSync('git', ['diff', '--cached', '--name-only'], { cwd: root, encoding: 'utf8' })
assert.equal(inputFiles.status, 0)
const hash = path => createHash('sha256').update(readFileSync(path)).digest('hex')
const inputs = () => Object.fromEntries(inputFiles.stdout.trim().split('\n').filter(Boolean).map(path => [path, hash(`${root}/${path}`)]))
const before = inputs()
const manifest = {
  runtime: process.version, executable: process.execPath, platform: process.platform, arch: process.arch,
  binarySha256: hash(process.execPath), files: [file], cwd: process.cwd(), inputsBefore: before,
  head: spawnSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).stdout.trim(),
  scope: 'Targeted current 006.test.mjs under actual official Node 22.13.0 native run(): new synchronous burst, existing synchronous timing, actual client ACK, ordinary and nested context boundaries. Unselected tests are not claimed as passed. Explicit child commands named node remain resolved by inherited PATH.',
  testNamePatterns: patterns,
}
writeFileSync(new URL('./input-manifest.json', import.meta.url), JSON.stringify(manifest, null, 2) + '\n')
writeFileSync(output, '')
const replacer = (_key, value) => value instanceof Error
  ? { ...value, name: value.name, message: value.message, stack: value.stack, cause: value.cause }
  : typeof value === 'bigint' ? value.toString() : value
const controller = new AbortController()
const startedAt = performance.now()
const timer = setTimeout(() => controller.abort(new Error('Independent complete 006 exceeded 240 seconds')), 240000)
const counts = {}
const failures = []
let thrown = null
try {
  for await (const event of run({ files: [file], concurrency: 1, testNamePatterns: patterns, signal: controller.signal })) {
    counts[event.type] = (counts[event.type] ?? 0) + 1
    appendFileSync(output, JSON.stringify({ at: performance.now(), type: event.type, data: event.data }, replacer) + '\n')
    if (event.type === 'test:fail') failures.push(event.data)
  }
} catch (error) { thrown = error }
finally { clearTimeout(timer) }
const after = inputs()
const result = { ...manifest, elapsedMs: performance.now() - startedAt, counts, failures, thrown,
  aborted: controller.signal.aborted, inputsAfter: after, inputsEqualBeforeAfter: JSON.stringify(before) === JSON.stringify(after) }
writeFileSync(new URL('./result.json', import.meta.url), JSON.stringify(result, replacer, 2) + '\n')
console.log(JSON.stringify({ runtime: process.version, counts, failures: failures.length, thrown, elapsedMs: result.elapsedMs, inputsEqualBeforeAfter: result.inputsEqualBeforeAfter }, replacer))
process.exitCode = failures.length || thrown || controller.signal.aborted || !result.inputsEqualBeforeAfter ? 1 : 0
