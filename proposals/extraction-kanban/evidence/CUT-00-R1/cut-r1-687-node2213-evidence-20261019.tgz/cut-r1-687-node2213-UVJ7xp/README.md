# CUT-00-R1 build 687: targeted minimum-Node check and diagnosis regression

Reviewer: d1_review_git. No shared source was edited. Root identified the frozen candidate as build 687. Root separately owns its formal seven-file run; these receipts cannot substitute for that result.

## Targeted actual execution

The actual official Node v22.13.0 darwin-arm64 binary was used:

- Executable: `/private/tmp/cut-r1-node2213-review.VKeI2I/node-v22.13.0-darwin-arm64/bin/node`
- Executable SHA-256: `5c79f8e198fd2456ea6660aaa6be218f9f44747f2306c7d0f5f97b087b2f2dfc`
- Official archive SHA-256: `bc1e374e7393e2f4b20e5bbc157d02e9b1fb2c634b2f992136b38fb8ca2023b7`
- Official archive/checksum verification evidence remains `/private/tmp/cut-r1-node2213-evidence-20261019.tgz`, SHA-256 `440ad94586069ebaf9d8e15a70903182763d68bdcbfe0436c80bed235d5ce5f9`.

Command, from `/Users/yuanxi/Workwork/vibe-fs`:

```sh
/private/tmp/cut-r1-node2213-review.VKeI2I/node-v22.13.0-darwin-arm64/bin/node /private/tmp/cut-r1-687-node2213-UVJ7xp/run-targeted.mjs
```

Native node:test.run() selected the actual registered 006 cases through the name patterns recorded in input-manifest.json. Exactly 16 selected tests passed: ACK eight modes, the new synchronous burst admission case, three existing synchronous/scheduling cases, actual parent/child transport identity, stale closed context, nested refusal and ordinary finite-operation positive control. Native events contain 17 dequeue/complete observations including the file wrapper and 16 pass observations. The process exited 0 after 15.01 seconds. Both actual native summaries report success and 16 passed, 0 failed/cancelled/skipped/TODO. Unselected tests were not delivered as skip events by this runtime; they are not counted as tested or passed.

The new burst case ran the actual formal entry with twelve synchronous ordinary tests followed by four real finite admissions. ACK timeout was not increased. This receipt is a green observation on 687, not an independently reproduced old-candidate red or proof of the root's earlier parsing diagnosis. Root retains the original 686 formal failures and spy trace separately.

Fifteen staged source files have equal pre/post SHA-256 values. The exact pre-run source copies are in source-snapshot.tgz, indexed by candidate-files.txt; frozen-staged.patch preserves their patch against the base commit. The manifest records actual runtime/hash, patterns, input hashes and base commit. This endpoint comparison is not a continuous watcher or an installed package identity claim. Explicit child commands named node continue to use inherited PATH, while process.execPath children use actual Node 22.13.

## Confirmed regression introduced by the marker move

The new verdict-transport writes BODY_PREFIX (`[verification-test-start]`) to stderr. The unchanged run-inner forwards only test:stdout to the worker cost observer, and createWorkerCostObserver.observe itself accepts only test:stdout. Consequently, the actual body identity no longer reaches the existing pre-import/exit PID cross-check. The existing forged-body matrix only submits stdout and stays green.

body-route-probe.mjs runs actual Node 22.13 and the real current createWorkerCostObserver with controlled diagnostic records. Both lanes use matching pre-import/exit PID 501 and a mismatched body PID 502. The old stdout control reports invalid, while the identical new stderr record is ignored and the snapshot incorrectly reports complete. body-route-result.json and body-route.log preserve the exact result. This is a controlled diagnostic counterexample, not a claim that an actual OS worker had a wrong PID or that native verdicts were forged. The probe exits 0 because it explicitly demonstrates the current incorrect behavior; it is not a production acceptance pass.

Root acknowledged this as a regression introduced by this round's stderr move. At this snapshot it was not fixed. The agreed next correction is to route actual cost/body records on stderr, accept both observation channels with independent fragment state, forward both types from the actual inner, and add interleaved-channel plus wrong-body-PID counterexamples. No shared edit or further broad run was made by this reviewer.

## Scope

No new deadline, ACK or TestContext defect was found in the targeted cases. The scope remains verification support, its requirements/tests and actual PTY test call sites; no product src or library change is present. git diff --cached --check exited 0. However, the confirmed diagnostic regression prevents this review from declaring 687 wholly acceptable. The 16 actual passes, the diagnostic red, old 686 evidence and the root's formal suite result must remain distinct. R12-U1 was not investigated.
