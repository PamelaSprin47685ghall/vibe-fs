import assert from 'node:assert/strict'
import { NativeTestSupervision } from '/Users/yuanxi/Workwork/vibe-fs/requirements/verification-system/tests/support/native-test-supervision.mjs'

const file = '/private/tmp/r1-owner-review-20261019/native.mjs'
let time = 0
const owner = new NativeTestSupervision({ files: [file], silenceMs: 100, now: () => time })
const event = (type, nativeSequence, extra = {}) => ({ type, data: {
  entryFile: file, file, name: 'ordinary', line: 1, column: 1, nesting: 0, nativeSequence, ...extra,
} })
owner.observe(event('runner:file-start', undefined, { runId: 'test-run' }))
owner.observe(event('test:dequeue', 1))
time = 10
let firstError
try { owner.observe(event('test:dequeue', 1)) } catch (error) { firstError = error.message }
assert.match(firstError, /repeated or out of order/)
const reply = owner.control({ entryFile: file, runId: 'test-run', requestId: 1,
  phase: 'begin', contextToken: 'a'.repeat(32), name: 'ordinary', fullName: 'ordinary',
  operation: 'operation after protocol rejection', limitMs: 1000 })
console.log(JSON.stringify({ probe: 'protocol-rejection-is-not-latched', firstError, reply,
  deadline: owner.nextDeadline() }))

time = 0
const repeated = new NativeTestSupervision({ files: [file], silenceMs: 100, now: () => time })
repeated.observe(event('runner:file-start'))
repeated.observe(event('test:dequeue', 1))
time = 90
repeated.observe(event('test:complete', 2))
const firstDeadline = repeated.nextDeadline()
time = 180
repeated.observe(event('test:complete', 3))
console.log(JSON.stringify({ probe: 'complete-without-an-active-occurrence', firstDeadline,
  repeatedDeadline: repeated.nextDeadline(), active: repeated.currentWait(file) }))
