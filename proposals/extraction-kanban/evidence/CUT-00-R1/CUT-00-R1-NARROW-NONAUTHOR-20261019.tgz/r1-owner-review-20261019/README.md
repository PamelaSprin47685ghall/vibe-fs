# CUT-00-R1 non-author narrow review

Read-only review of the shared implementation. No repository file was edited by this reviewer. This is a narrow supplement, not the formal 006 / 003 / 025 acceptance or a minimum-Node-version runtime claim. Runtime was Node v26.6.0.

## Observations and limits

1. `owner-probes.raw` preserves the initial state-owner observations. An invalid repeated native sequence throws, but the standalone owner can still grant before its caller calls `stop()`. The original outer socket path did not check termination and the termination entry did not stop the owner. The root author fixed both: `requestTermination()` now calls `fileWaits.stop()` and clears the silence timer before physical cleanup; socket requests also have a termination guard. The standalone diagnostic is not expected to become green because the outer supervisor owns protocol-failure policy. `stopped-owner-probe.raw` proves the existing stopped state refuses a new begin and has no future deadline. Current wiring was checked read-only.

2. The artificial complete-with-new-sequence probe remains only a trust-boundary observation. It manually invents a fresh sequence for an event without an active occurrence. Actual run-inner assigns each sequence at the unique native event emission, and duplicate same-sequence events are rejected. Real skip / abort terminals can lack a dequeue and must remain supported. This probe is not recorded as a confirmed product regression or acceptance failure.

3. `nested.unsandboxed.raw` is an actual supervisor run with an ordinary parent, two children and a later ordinary test. The nested helper request is explicitly rejected; its callback must not execute. All four native tests pass, one planned stream completes and drains, exit is zero, and owned group verification is accepted. This confirms the new exception does not forbid ordinary nesting. It does not cover arbitrary nested grants, which are intentionally unsupported.

The initial sandbox run (`nested.raw`) failed before executing tests: Unix socket listen and ps were forbidden. It is retained as an environment failure. The authorized actual run succeeded. `cleanup.ps.raw` is empty and ps exit status was 1 for exact PIDs 39815, 40010, 40011 and 40012, meaning none remained at that observation. The accepted run additionally performed the supervisor's own complete group verification.

## Replay

With the reviewed checkout available at `/Users/yuanxi/Workwork/vibe-fs`:

```
node owner-probes.mjs
node stopped-owner-probe.mjs
node launch.mjs
```

The scripts use explicit absolute checkout imports to prevent accidental self-resolution into another product. On another machine, manually rebind those import paths and the private fixture path in `launch.mjs`; preserve all assertion bodies. The actual launcher requires permission for local Unix sockets, process inspection and owned process termination.

The baseline native owner is intentionally a mutable owner with an injected clock. These probes call that actual module; they do not implement a parallel expected algorithm. Source snapshots and the staged diff identify what was reviewed. Root's formal suite and later fixed candidate evidence remain separate.
