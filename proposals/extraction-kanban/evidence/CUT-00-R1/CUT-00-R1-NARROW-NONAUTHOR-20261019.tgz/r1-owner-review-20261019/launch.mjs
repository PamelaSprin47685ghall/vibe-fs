import { superviseNodeTest } from '/Users/yuanxi/Workwork/vibe-fs/requirements/verification-system/tests/e2e/support/supervise-node-test.mjs'

await superviseNodeTest({ files: ['/private/tmp/r1-owner-review-20261019/nested.mjs'],
  label: 'independent-r1-normal-nested', silenceMs: 2000 })
