import test from 'node:test'
import assert from 'node:assert/strict'
import { withFinitePhysicalWait } from '/Users/yuanxi/Workwork/vibe-fs/requirements/verification-system/tests/support/finite-physical-wait.mjs'

test('ordinary parent', async t => {
  await t.test('nested child', async child => {
    await assert.rejects(withFinitePhysicalWait(child,
      { operation: 'nested refusal', limitMs: 1000 }, () => assert.fail('must not execute')),
    /unique ordinary top-level/)
  })
  await t.test('another child', () => assert.equal(2 + 2, 4))
})
test('ordinary later', () => assert.equal(1 + 1, 2))
