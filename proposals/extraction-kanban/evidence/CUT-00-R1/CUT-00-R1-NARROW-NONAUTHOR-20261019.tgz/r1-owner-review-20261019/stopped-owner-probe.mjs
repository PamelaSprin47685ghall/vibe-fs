import assert from 'node:assert/strict'
import { NativeTestSupervision } from '/Users/yuanxi/Workwork/vibe-fs/requirements/verification-system/tests/support/native-test-supervision.mjs'

const file = '/private/tmp/r1-owner-review-20261019/native.mjs'
const owner = new NativeTestSupervision({ files: [file], silenceMs: 100, now: () => 0 })
owner.observe({ type: 'runner:file-start', data: { entryFile: file, runId: 'test-run' } })
owner.observe({ type: 'test:dequeue', data: { entryFile: file, file, name: 'ordinary',
  nesting: 0, nativeSequence: 1 } })
owner.stop()
const reply = owner.control({ entryFile: file, runId: 'test-run', requestId: 1,
  phase: 'begin', contextToken: 'a'.repeat(32), name: 'ordinary', fullName: 'ordinary',
  operation: 'operation after supervisor termination', limitMs: 1000 })
assert.equal(reply[0].ok, false)
assert.equal(owner.nextDeadline(), null)
console.log(JSON.stringify({ probe: 'stopped owner refuses grants', reply, deadline: owner.nextDeadline() }))
