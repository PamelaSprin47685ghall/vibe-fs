# CUT-00-R1 final output-boundary review, first snapshot

Non-author read-only review of actual verification support. Node v26.6.0. No shared file was edited. The 12-file source closure in snapshot preserves original relative imports and the actual supervisor, inner runner, native event stream, helper, socket, cost observer and owned cleanup. It has no repository or dist fallback.

## First actual run

`node run.mjs` ran once, expecting three native tests to pass. It instead recorded two passes and one assertion failure. Keep this original result: actual.status.json is exit1 / no signal; original exact-stdout assertion is fully printed; native file completed/drained and owned group cleanup accepted. It was not a watchdog or lost original exception.

- Seven actual body routes (process.stdout string/Buffer, node:process named stdout, global/default/named/CommonJS Console) all reached stderr and none reached outer stdout.
- The later real helper obtained permission from actual native dequeue, executed its callback once, waited 900ms across the ordinary 600ms window and completed. This is an ordinary physical run, not the separate coalescing experiment.
- The ordinary fork correctly retained stdout.fd=1, stderr.fd=2 and distinct streams despite inheriting the bound preload. Both original stdout lines survived.
- Its exact-stdout assertion failed because the ordinary fork also inherited NODE_TEST_CONTEXT=child-v8 and the preload's static node:test import appended native zero-test summary bytes. Do not call this a new getter-routing regression.

## Bounded old/new attribution

`ordinary-inheritance-compare.mjs` ran one actual fork with HEAD's old unbound preload and one actual fork with the new preload bound to a different entry. Both kept fd1/2 and ordinary stdout lines, and both appended native zero-test summary. Old source was read unchanged with git show HEAD; HEAD at capture was c385b8fab. This establishes the inherited-preload side effect existed before the new router. It does not prove arbitrary child stdio inheritance is safe, nor claim raw fd1 writes are routed by a JavaScript getter.

The exact assertion was not relaxed or rerun to manufacture a green result. If the author narrows the preload before importing node:test/helper for nonmatching entries, replay this original fixture against a new fixed closure. Otherwise disclose the old inheritance limitation separately.

## Collector and close checks

`cost-and-close.mjs` passed six cases using the actual copied cost owner: independent partial buffers in either direction; no cross-channel record assembly; one channel's newline cannot terminate another's record; oversized body diagnostics rejected; large ordinary noise does not invalidate a later valid record. These are direct collector inputs, not a native parser proof.

The same script opened a real authenticated socket with a pending begin, then called channel.close three times. It returned the same promise, removed the socket and produced no duplicate callback/error. The actual outer source was checked to close the channel on file-drained and aggregate final resource cleanup failures.

## Test target finding

The reviewed 006 closed-exit-diagnostic-sink fixture still closes fd1. New worker-cost diagnostics use preimport fd2 and process.stderr at exit. That fixture no longer reaches the intended diagnostic sink; author was asked to close fd2 and rerun the relevant small matrix, while keeping native-protocol-sink tests separately named if needed. This is a confirmed test-target mismatch from source inspection, not another executed product failure.

## Scope and replay

The host reviewer independently preserved actual coalesced-byte native parser red/green evidence on Node22.13 and26.6. This reviewer read that evidence and checked the formal six-output case hits the default/named Console leak; it is not counted again as this reviewer's runtime.

Replay after extraction:

```
node run.mjs
node ordinary-inheritance-compare.mjs
node cost-and-close.mjs
node cleanup.mjs
```

The first command intentionally preserves the original failing expectation on this snapshot. Local socket and process-query permissions are required. first-cleanup.json verifies exact launcher/inner/worker/fork PIDs absent, socket absent and owned HOME removed. Other comparison children were individually observed exited. Raw stdout/stderr, binary child outputs, statuses, source closure and original scripts are retained.
