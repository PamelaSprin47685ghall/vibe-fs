import { setImmediate } from 'node:timers/promises'
import { beforeEach } from 'node:test'
import nativeConsole, { Console } from 'node:console'
import { syncBuiltinESMExports } from 'node:module'
import { installWorkerCostObservation } from './worker-cost-observation.mjs'
import { installFinitePhysicalWait } from './finite-physical-wait.mjs'

installWorkerCostObservation()
const control = new URL(import.meta.url).searchParams
if (control.has('entryFile')) {
  if (installFinitePhysicalWait(Object.fromEntries(control))) {
    // The native reporter has already captured its own stdout stream.
    Object.defineProperty(process, 'stdout', { configurable: true, get: () => process.stderr })
    Object.assign(nativeConsole, new Console({ stdout: process.stderr, stderr: process.stderr }))
    globalThis.console = nativeConsole
    syncBuiltinESMExports()
  }
}

// The previous verdict exists only after its afterEach hooks have finished.
// Yield before starting the next leaf so synchronous work cannot hold that verdict.
beforeEach(context => {
  process.stderr.write(`[verification-test-start] ${JSON.stringify({
    pid: process.pid, parentPid: process.ppid,
    entryFile: process.argv[1], name: context.name, fullName: context.fullName,
  })}\n`)
  return setImmediate()
})
