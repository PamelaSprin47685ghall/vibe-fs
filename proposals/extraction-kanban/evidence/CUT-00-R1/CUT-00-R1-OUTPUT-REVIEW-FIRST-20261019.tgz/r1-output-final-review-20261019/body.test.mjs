import test from 'node:test'
import assert from 'node:assert/strict'
import { stdout } from 'node:process'
import nativeConsole, { log } from 'node:console'
import { createRequire } from 'node:module'
import { fork } from 'node:child_process'
import { writeFileSync, readFileSync } from 'node:fs'
import { setTimeout as delay } from 'node:timers/promises'
import { withFinitePhysicalWait } from './snapshot/requirements/verification-system/tests/support/finite-physical-wait.mjs'

const commonJSConsole = createRequire(import.meta.url)('node:console')
test('ordinary output paths preserve native framing', () => {
  assert.equal(process.stdout, process.stderr)
  assert.equal(stdout, process.stderr)
  process.stdout.write('review-body-stream-string\n')
  process.stdout.write(Buffer.from('review-body-stream-buffer\n'))
  stdout.write('review-body-named-stream\n')
  console.log('review-body-global-console')
  nativeConsole.log('review-body-default-console')
  log('review-body-named-console')
  commonJSConsole.log('review-body-commonjs-console')
  writeFileSync(new URL('./body-observation.json', import.meta.url), JSON.stringify({ pid: process.pid,
    parentPid: process.ppid, home: process.env.HOME }))
})
test('ordinary fork inherits preload without inheriting output redirection', async () => {
  const child = fork(new URL('./ordinary-child.mjs', import.meta.url), [], { silent: true,
    env: { ...process.env, R1_CHILD_OBSERVATION: new URL('./child-observation.json', import.meta.url).pathname } })
  const out = []
  const err = []
  child.stdout.on('data', value => out.push(value))
  child.stderr.on('data', value => err.push(value))
  const outcome = await new Promise((accept, reject) => {
    child.once('error', reject)
    child.once('close', (code, signal) => accept({ code, signal }))
  })
  writeFileSync(new URL('./ordinary-child.stdout.bin', import.meta.url), Buffer.concat(out))
  writeFileSync(new URL('./ordinary-child.stderr.bin', import.meta.url), Buffer.concat(err))
  assert.deepEqual(outcome, { code: 0, signal: null })
  const observation = JSON.parse(readFileSync(new URL('./child-observation.json', import.meta.url), 'utf8'))
  assert.equal(observation.sameStream, false)
  assert.equal(observation.stdoutFd, 1)
  assert.equal(observation.stderrFd, 2)
  assert.ok(observation.execArgv.some(value => value.includes('verdict-transport.mjs?')))
  assert.equal(Buffer.concat(out).toString('utf8'), 'ordinary-child-stream-output\nordinary-child-console-output\n')
})
test('a finite permit still follows native dequeue after body diagnostics', async context => {
  let calls = 0
  await withFinitePhysicalWait(context, { operation: 'private physical proof after diagnostic burst', limitMs: 2000 },
    async () => {
      calls += 1
      await delay(900)
    })
  assert.equal(calls, 1)
})
