import assert from 'node:assert/strict'
import { spawn } from 'node:child_process'
import { writeFileSync, readFileSync, existsSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const directory = dirname(fileURLToPath(import.meta.url))
const env = { ...process.env, NODE_TEST_CONCURRENCY: '1' }
delete env.NODE_TEST_CONTEXT
const child = spawn(process.execPath, [join(directory, 'launch.mjs')], { env, stdio: ['ignore', 'pipe', 'pipe'] })
let stdout = ''
let stderr = ''
child.stdout.setEncoding('utf8')
child.stderr.setEncoding('utf8')
child.stdout.on('data', value => { stdout += value })
child.stderr.on('data', value => { stderr += value })
const timer = setTimeout(() => child.kill('SIGKILL'), 10000)
const outcome = await new Promise((accept, reject) => {
  child.once('error', reject)
  child.once('close', (code, signal) => accept({ code, signal }))
}).finally(() => clearTimeout(timer))
writeFileSync(join(directory, 'actual.stdout.raw'), stdout)
writeFileSync(join(directory, 'actual.stderr.raw'), stderr)
writeFileSync(join(directory, 'actual.status.json'), JSON.stringify(outcome))
assert.deepEqual(outcome, { code: 0, signal: null }, stdout + stderr)
for (const kind of ['stream-string', 'stream-buffer', 'named-stream', 'global-console', 'default-console', 'named-console', 'commonjs-console']) {
  const marker = `review-body-${kind}`
  assert.equal(stdout.includes(marker), false, marker)
  assert.ok(stderr.includes(marker), marker)
}
assert.match(stderr, /3 passed, 0 failed; 1\/1 planned file\(s\) completed/)
assert.match(stderr, /accepted=true/)
assert.doesNotMatch(stderr, /WATCHDOG|reply deadline expired|stream error/)
const body = JSON.parse(readFileSync(join(directory, 'body-observation.json'), 'utf8'))
const ordinary = JSON.parse(readFileSync(join(directory, 'child-observation.json'), 'utf8'))
const pids = [child.pid, body.pid, body.parentPid, ordinary.pid]
const cleanup = pids.map(pid => {
  try {
    process.kill(pid, 0)
    return { pid, status: 'still present' }
  }
  catch (error) { return { pid, status: error.code } }
})
assert.ok(cleanup.every(row => row.status === 'ESRCH'), JSON.stringify(cleanup))
assert.equal(existsSync(body.home), false)
writeFileSync(join(directory, 'cleanup.json'), JSON.stringify({ cleanup, homeRemoved: true }, null, 2))
console.log(JSON.stringify({ passed: true, nativeTests: 3, diagnosticRoutes: 7,
  ordinaryChildExactStdout: true, finiteActionCalls: 1 }))
