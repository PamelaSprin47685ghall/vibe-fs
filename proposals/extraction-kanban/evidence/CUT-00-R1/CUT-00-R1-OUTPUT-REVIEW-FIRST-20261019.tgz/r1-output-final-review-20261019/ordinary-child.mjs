import { writeFileSync } from 'node:fs'

writeFileSync(process.env.R1_CHILD_OBSERVATION, JSON.stringify({ pid: process.pid, parentPid: process.ppid,
  stdoutFd: process.stdout.fd, stderrFd: process.stderr.fd, sameStream: process.stdout === process.stderr,
  execArgv: process.execArgv }))
process.stdout.write('ordinary-child-stream-output\n')
console.log('ordinary-child-console-output')
