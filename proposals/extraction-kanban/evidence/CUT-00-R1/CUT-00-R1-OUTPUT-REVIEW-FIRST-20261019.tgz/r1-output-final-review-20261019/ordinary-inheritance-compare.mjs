import assert from 'node:assert/strict'
import { fork } from 'node:child_process'
import { readFileSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const directory = dirname(fileURLToPath(import.meta.url))
const childFile = join(directory, 'ordinary-child.mjs')
const observations = []
for (const mode of ['old-unbound', 'new-bound-other-entry']) {
  const preload = pathToFileURL(join(directory, mode === 'old-unbound' ? 'old-support/verdict-transport.mjs'
    : 'snapshot/requirements/verification-system/tests/support/verdict-transport.mjs'))
  if (mode === 'new-bound-other-entry') {
    preload.searchParams.set('entryFile', join(directory, 'body.test.mjs'))
    preload.searchParams.set('path', '/tmp/intentionally-unused-review-channel.sock')
    preload.searchParams.set('runId', 'a'.repeat(32))
    preload.searchParams.set('capability', 'b'.repeat(64))
  }
  const observation = join(directory, `${mode}.child.json`)
  const child = fork(childFile, [], { silent: true, execArgv: [`--import=${preload.href}`],
    env: { ...process.env, NODE_TEST_CONTEXT: 'child-v8', R1_CHILD_OBSERVATION: observation } })
  const out = []
  const err = []
  child.stdout.on('data', value => out.push(value))
  child.stderr.on('data', value => err.push(value))
  const outcome = await new Promise((accept, reject) => {
    child.once('error', reject)
    child.once('close', (code, signal) => accept({ code, signal }))
  })
  const stdout = Buffer.concat(out)
  const stderr = Buffer.concat(err)
  writeFileSync(join(directory, `${mode}.stdout.bin`), stdout)
  writeFileSync(join(directory, `${mode}.stderr.bin`), stderr)
  const fields = JSON.parse(readFileSync(observation, 'utf8'))
  assert.deepEqual(outcome, { code: 0, signal: null })
  assert.equal(fields.sameStream, false)
  assert.equal(fields.stdoutFd, 1)
  assert.ok(stdout.includes(Buffer.from('ordinary-child-stream-output\nordinary-child-console-output\n')))
  assert.ok(stdout.includes(Buffer.from('test:summary')))
  assert.throws(() => process.kill(child.pid, 0), { code: 'ESRCH' })
  observations.push({ mode, outcome, fields, stdoutBytes: stdout.length, stderrBytes: stderr.length,
    ordinaryMarkersPresent: true, appendedNativeSummary: true, childExited: true })
}
writeFileSync(join(directory, 'ordinary-inheritance-comparison.json'), JSON.stringify(observations, null, 2))
console.log(JSON.stringify({ comparisonComplete: true, bothAppendNativeSummary: true,
  newOutputGetterGuardPreserved: true }))
