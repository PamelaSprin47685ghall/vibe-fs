import assert from 'node:assert/strict'
import { readFileSync, existsSync, writeFileSync } from 'node:fs'

const body = JSON.parse(readFileSync(new URL('./body-observation.json', import.meta.url), 'utf8'))
const child = JSON.parse(readFileSync(new URL('./child-observation.json', import.meta.url), 'utf8'))
const stderr = readFileSync(new URL('./actual.stderr.raw', import.meta.url), 'utf8')
const start = JSON.parse(stderr.split('\n').find(line => line.startsWith('runner: file lifecycle '))
  .slice('runner: file lifecycle '.length))
const pids = [...new Set([start.parentPid, body.parentPid, body.pid, child.pid])]
const processes = pids.map(pid => {
  try {
    process.kill(pid, 0)
    return { pid, status: 'still present' }
  } catch (error) { return { pid, status: error.code } }
})
const socket = `/tmp/wxs-finite-${start.runId}.sock`
const result = { processes, socket, socketRemoved: !existsSync(socket), homeRemoved: !existsSync(body.home) }
writeFileSync(new URL('./first-cleanup.json', import.meta.url), JSON.stringify(result, null, 2))
assert.ok(processes.every(row => row.status === 'ESRCH'), JSON.stringify(processes))
assert.equal(result.socketRemoved, true)
assert.equal(result.homeRemoved, true)
console.log(JSON.stringify({ allExactProcessesExited: true, socketRemoved: true, homeRemoved: true }))
