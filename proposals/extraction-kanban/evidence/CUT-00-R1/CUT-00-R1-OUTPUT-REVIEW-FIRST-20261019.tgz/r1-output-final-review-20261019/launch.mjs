import { fileURLToPath } from 'node:url'
import { superviseNodeTest } from './snapshot/requirements/verification-system/tests/e2e/support/supervise-node-test.mjs'

await superviseNodeTest({ files: [fileURLToPath(new URL('./body.test.mjs', import.meta.url))],
  label: 'independent-final-output-review', silenceMs: 600 })
