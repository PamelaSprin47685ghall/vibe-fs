import assert from 'node:assert/strict'
import { connect } from 'node:net'
import { existsSync, writeFileSync } from 'node:fs'
import { createWorkerCostObserver, encodeWorkerCostRecord, MAX_WORKER_COST_BYTES } from './snapshot/requirements/verification-system/tests/support/worker-cost-observation.mjs'
import { createFiniteWaitChannel } from './snapshot/requirements/verification-system/tests/support/finite-wait-channel.mjs'

const file = '/private/tmp/r1-cost-private-file.mjs'
const pre = { version: 1, phase: 'pre-import', sequence: 0, entryFile: file,
  pid: 222, parentPid: 111, monotonicMs: 1, cpuUserMicros: 10, cpuSystemMicros: 2 }
const end = { ...pre, phase: 'exit', sequence: 1, monotonicMs: 2, cpuUserMicros: 12,
  cpuSystemMicros: 3, exitCode: 0 }
const line = encodeWorkerCostRecord(pre)
const event = (type, message) => ({ type, data: { entryFile: file, file, message } })
const outcomes = []
for (const [cost, noise] of [['test:stderr', 'test:stdout'], ['test:stdout', 'test:stderr']]) {
  const owner = createWorkerCostObserver({ entryFile: file, parentPid: 111 })
  owner.observe(event(noise, 'ordinary partial line without newline'))
  owner.observe(event(cost, line.slice(0, 20)))
  owner.observe(event(noise, '\nordinary complete line\n'))
  owner.observe(event(cost, line.slice(20)))
  owner.observe(event(cost, encodeWorkerCostRecord(end)))
  const result = owner.finish()
  assert.equal(result.status, 'complete')
  assert.equal(result.preImport.pid, 222)
  assert.equal(result.interval.wallMs, 1)
  outcomes.push({ case: `independent partial buffers ${cost}`, result })
}
{
  const owner = createWorkerCostObserver({ entryFile: file, parentPid: 111 })
  owner.observe(event('test:stdout', line.slice(0, 20)))
  owner.observe(event('test:stderr', line.slice(20)))
  const result = owner.finish()
  assert.notEqual(result.status, 'complete')
  outcomes.push({ case: 'a record cannot be assembled across channels', result })
}
{
  const owner = createWorkerCostObserver({ entryFile: file, parentPid: 111 })
  owner.observe(event('test:stdout', '[verification-test-start] {"pid":222'))
  owner.observe(event('test:stderr', '\n'))
  const result = owner.finish()
  assert.equal(result.status, 'invalid')
  assert.match(result.reason, /ended before its newline/)
  outcomes.push({ case: 'other channel newline cannot terminate an incomplete body record', result })
}
{
  const owner = createWorkerCostObserver({ entryFile: file, parentPid: 111 })
  owner.observe(event('test:stderr', '[verification-test-start] ' + 'x'.repeat(MAX_WORKER_COST_BYTES) + '\n'))
  const result = owner.finish()
  assert.equal(result.status, 'invalid')
  assert.match(result.reason, /exceeds its byte boundary/)
  outcomes.push({ case: 'bounded body diagnostic', result })
}
{
  const owner = createWorkerCostObserver({ entryFile: file, parentPid: 111 })
  owner.observe(event('test:stdout', 'ordinary-noise'.repeat(MAX_WORKER_COST_BYTES) + '\n'))
  owner.observe(event('test:stderr', line))
  owner.observe(event('test:stderr', encodeWorkerCostRecord(end)))
  const result = owner.finish()
  assert.equal(result.status, 'complete')
  outcomes.push({ case: 'large ordinary noise is not a diagnostic record', result })
}

const frames = []
const errors = []
let accepted
const entered = new Promise(accept => { accepted = accept })
const channel = await createFiniteWaitChannel({ entryFile: file,
  onRequest(request) {
    frames.push(request)
    accepted()
  },
  onError(error) { errors.push({ message: error.message, code: error.code }) },
})
const socket = connect(channel.descriptor.path)
socket.on('error', error => { errors.push({ message: error.message, code: error.code }) })
const socketClosed = new Promise(accept => socket.once('close', accept))
socket.once('connect', () => socket.write(JSON.stringify({ capability: channel.descriptor.capability,
  phase: 'begin', contextToken: 'a'.repeat(32), name: 'ordinary', fullName: 'ordinary',
  operation: 'pending during close', limitMs: 1000 }) + '\n'))
await entered
const firstClose = channel.close()
const secondClose = channel.close()
assert.equal(firstClose, secondClose)
await firstClose
await socketClosed
assert.equal(channel.close(), firstClose)
assert.equal(existsSync(channel.descriptor.path), false)
assert.deepEqual(frames.map(frame => frame.phase), ['begin'])
assert.deepEqual(errors, [])
writeFileSync(new URL('./cost-and-close.json', import.meta.url), JSON.stringify({ outcomes,
  close: { frames: frames.map(frame => frame.phase), samePromise: true, socketRemoved: true, errors } }, null, 2))
console.log(JSON.stringify({ collectorCases: outcomes.length, passed: true, idempotentCloseWithPendingSocket: true }))
