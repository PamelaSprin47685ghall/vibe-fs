# CUT-00-R1 build 684: independent Node 22.13 verification

Reviewer: d1_review_git. Shared source was read only. Evidence directory and probe driver were private; no production or test source was edited by this reviewer.

## Actual execution

The official darwin-arm64 Node v22.13.0 binary was used:

- Binary: `/private/tmp/cut-r1-node2213-review.VKeI2I/node-v22.13.0-darwin-arm64/bin/node`
- Binary SHA-256: `5c79f8e198fd2456ea6660aaa6be218f9f44747f2306c7d0f5f97b087b2f2dfc`
- Official archive: `https://nodejs.org/dist/v22.13.0/node-v22.13.0-darwin-arm64.tar.gz`
- Archive SHA-256, checked against official SHASUMS256.txt: `bc1e374e7393e2f4b20e5bbc157d02e9b1fb2c634b2f992136b38fb8ca2023b7`
- Prior download/runtime identity evidence: `/private/tmp/cut-r1-node2213-evidence-20261019.tgz`, SHA-256 `440ad94586069ebaf9d8e15a70903182763d68bdcbfe0436c80bed235d5ce5f9`.

Command, from `/Users/yuanxi/Workwork/vibe-fs`:

```sh
/private/tmp/cut-r1-node2213-review.VKeI2I/node-v22.13.0-darwin-arm64/bin/node /private/tmp/cut-r1-684-node2213-pVuMO5/run-006.mjs
```

The driver invokes native `node:test.run()` on the real current `006.test.mjs`, without test-name filtering. It records every native event, including original error fields, and uses a 240-second abort bound. The complete successful execution took 33.60 seconds and exited 0. Native summaries report 70 passed, 0 failed, 0 cancelled, 0 skipped and 0 TODO. There were 71 dequeue and complete events, including the file wrapper, and 70 pass events. The 11 new finite-wait tests ran as part of that complete file; they were not substituted by a private imitation.

The exact executable and 13 staged input file hashes are in `input-manifest.json`. Pre/post input hashes were equal. `frozen-staged.patch` and `git-status.txt` preserve the inspected candidate. This is an endpoint hash comparison, not a continuous input watcher. The root identified this frozen source candidate as build 684; this evidence does not claim an independently installed package hash.

`process.execPath` descendants use the same Node 22.13 binary. Existing fixtures that explicitly invoke a command named `node` still use inherited PATH; that distinction is stated in the manifest. No field-deletion emulation of Node 22 was used.

## Preserved first attempt

The first exact script ran in the restrictive sandbox and exited 1, with 38 pass and 32 fail. `sandbox-attempt/` preserves its complete native events and results. Twenty-nine failure receipts explicitly contain EPERM from local socket or `ps` operations. Three other failures were downstream readiness or assertion failures; their precise individual cause was not separately established. They are not reported as 32 independently diagnosed product defects. A single authorized execution outside those sandbox restrictions then produced the complete green result above. The first red receipts are not overwritten by that result.

## Limited source review

No correctness defect was found in the inspected R1 boundary. NativeTestSupervision owns the actual per-file deadline and invocation state. The formal path no longer runs the replaced createFileWaitTracker and Watchdog deadline owners in parallel. Only native complete advances; pass/fail are diagnostic observations. A pending begin has no provisional allowance. An allowance has one absolute deadline, end does not release it, and the matching complete requires end. Another invocation during an allowance fails safely. Every transition checks expiry before processing, including delayed event dispatch and actual exit. BeforeEach registers the real context; afterEach and the context signal seal it; reuse and ambiguous nested/concurrent binding are refused. The private authenticated socket is separate from node:test IPC and stdout.

The staged scope is 13 files: verification WHAT, the formal supervisor/inner/transport and new private helpers/tests, 006 registration/model assertions, the actual PTY test call sites in Process 003 and Lifecycle 025, and BOARD status. No `src/`, library, product runtime, global default silence value, persistent data policy or PTY business assertion changed in this candidate. Existing owned process termination and final verdict/summary/drain/exit gates remain distinct from the physical allowance. The retained generic Watchdog still has other consumers and tests; its existence is not a second owner of the migrated formal path.

AGENTS alignment: requirement-numbered tests and WHAT anchors are preserved, scope is local, no facade or second business state was added, and this reviewer did not build or edit the workspace. One small source-style follow-up was reported to root: the generated unallowed-file fixture at finite-wait-tests.mjs:191 puts setInterval and await on one semicolon-separated line; AGENTS requires these actions to be written on separate lines. This is not a semantic failure. The root owns its correction and any resulting candidate update.

## Remaining acceptance boundary

This proves complete 006 on the declared minimum Node version and the limited source review. It does not independently prove complete Process 003 or Lifecycle 025 under the final formal entry, the root's final commit/push, a package release, every supported OS, or the separate Bun verification card. Root is running the actual related consumer suites. R12-U1 was not investigated. Do not close the full R1 card from this receipt alone.
