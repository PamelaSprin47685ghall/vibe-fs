# CUT-00-R1 build 688: independent full Node 22.13 result (not green)

Reviewer: d1_review_git. No shared source was edited. Root identified the frozen candidate as build 688. Its formal seven-file result remains separate.

## Actual full execution

The real official Node v22.13.0 darwin-arm64 binary was used:

- Executable: `/private/tmp/cut-r1-node2213-review.VKeI2I/node-v22.13.0-darwin-arm64/bin/node`
- Executable SHA-256: `5c79f8e198fd2456ea6660aaa6be218f9f44747f2306c7d0f5f97b087b2f2dfc`
- Official distribution SHA-256: `bc1e374e7393e2f4b20e5bbc157d02e9b1fb2c634b2f992136b38fb8ca2023b7`
- Prior official checksum/runtime receipts: `/private/tmp/cut-r1-node2213-evidence-20261019.tgz`, SHA-256 `440ad94586069ebaf9d8e15a70903182763d68bdcbfe0436c80bed235d5ce5f9`.

Command from `/Users/yuanxi/Workwork/vibe-fs`:

```sh
/private/tmp/cut-r1-node2213-review.VKeI2I/node-v22.13.0-darwin-arm64/bin/node /private/tmp/cut-r1-688-node2213-EeIx8n/run-006.mjs
```

The driver executes the actual complete current 006.test.mjs through native node:test.run(), with no name filter. It exited 1 after 39.27 seconds. Both native summaries report 83 tests: 82 passed, 1 failed, 0 cancelled, 0 skipped and 0 TODO. There were 84 dequeue/complete observations including the file wrapper, 82 pass and one fail. This is not an acceptance pass.

The exact 16 staged inputs had equal pre/post SHA-256 values. input-manifest.json records executable identity, base commit and input hashes. source-snapshot.tgz contains the pre-run source copies indexed by candidate-files.txt; frozen-staged.patch retains the entire staged patch. The comparison does not continuously watch for transient source changes and does not claim an installed package hash. Existing fixture commands explicitly named node use inherited PATH; process.execPath descendants use real Node 22.13.

## Exact failure and cause boundary

The single failure is `worker cost diagnostics preserve actual success and assertion failure with a closed exit sink`, at current 006.test.mjs:376. It expected status missing but observed complete. The preserved native fail includes the complete original child output: the pre-import and exit diagnostics both arrived with matching real PID; the worker's original result and owned process-group cleanup completed normally.

The fixture at 006.test.mjs:322 still calls fs.closeSync(1), which previously closed the stdout diagnostic sink. The candidate moved cost diagnostics to stderr/fd2, so this fixture no longer closes the actual diagnostic sink. Reporting complete when both real receipts are present is correct; changing that result to missing or merely accepting either value would hide the failed premise. This is a test fixture adaptation omitted during the current channel migration, not evidence of an actual lost exit receipt or a deadline/PTY business failure.

Root was notified to test closing the actual stderr sink and preserve a stdout-close positive control rather than weakening the missing-receipt assertion. That next candidate and any fix result are not part of this archive. This original red must remain distinct from later green results.

## Related source review and passed cases

The prior 687 diagnostic regression is repaired structurally: run-inner forwards both stdout and stderr to the actual observer; each channel owns a separate fragment/drop state, while process identity and pre-import/exit facts have one shared owner. The new cross-channel fragmented-cost/wrong-body-PID case passed. The six actual output forms, synchronous burst, all ACK modes, nested/context restrictions, drained-file socket release and prior synchronous timing cases also passed as part of this complete file. Their green results do not cancel the single failed case.

Formal-worker output redirection is gated by successful installation for the actual target entry. It updates process.stdout and canonical/named console/process exports; native reporter stream ownership remains separate. The real six-form case observes diagnostics on stderr and excludes their markers from stdout. No product src/library change or global silence increase was introduced. Deadline/permit ownership remains in NativeTestSupervision, and diagnostics do not advance native progress. No further semantic blocker was found in this limited source review. git diff --cached --check exited 0.

Root owns the fixture repair, affected revalidation, complete Process 003/Lifecycle 025 and final report/commit/push. This reviewer performed no further broad run after the new failure. R12-U1 was not investigated.
