import { writeFileSync, readFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
const directory = new URL('.', import.meta.url).pathname
const natives = process.binding('natives')
for (const key of ['internal/test_runner/test', 'internal/test_runner/tests_stream', 'internal/test_runner/runner', 'internal/test_runner/harness', 'internal/test_runner/utils', 'internal/test_runner/reporter/v8-serializer', 'internal/child_process']) {
  writeFileSync(directory + process.version + '_' + key.replaceAll('/', '_') + '.js', natives[key])
}
writeFileSync(directory + process.version + '_runtime.json', JSON.stringify({ version: process.version,
  executable: process.execPath, binarySha256: createHash('sha256').update(readFileSync(process.execPath)).digest('hex'),
  release: process.release, versions: process.versions }, null, 2) + '\n')
