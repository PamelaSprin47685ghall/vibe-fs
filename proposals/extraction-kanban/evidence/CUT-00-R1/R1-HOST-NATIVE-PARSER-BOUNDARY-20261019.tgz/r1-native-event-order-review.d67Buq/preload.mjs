import { beforeEach } from 'node:test'
import { setImmediate } from 'node:timers/promises'
import canonicalConsole, { Console } from 'node:console'
import { syncBuiltinESMExports } from 'node:module'
import { stdout as namedStdout } from 'node:process'
import { isMainThread } from 'node:worker_threads'
import { resolve } from 'node:path'
import { installFinitePhysicalWait } from '/Users/yuanxi/Workwork/vibe-fs/requirements/verification-system/tests/support/finite-physical-wait.mjs'
const params = new URL(import.meta.url).searchParams
installFinitePhysicalWait(Object.fromEntries(params))
canonicalConsole.log('R1-PRIME-DEFAULT-CONSOLE')
if (['isolated', 'canonical'].includes(params.get('marker')) && isMainThread && typeof process.argv[1] === 'string' && resolve(process.argv[1]) === params.get('entryFile')) {
  const original = process.stdout
  const diagnostics = process.stderr
  Object.defineProperty(process, 'stdout', { configurable: true, enumerable: true, get: () => diagnostics })
  if (params.get('marker') === 'canonical') {
    Object.assign(canonicalConsole, new Console({ stdout: diagnostics, stderr: diagnostics }))
    globalThis.console = canonicalConsole
  } else globalThis.console = new Console(diagnostics, diagnostics)
  syncBuiltinESMExports()
  if (process.stdout === original || namedStdout !== diagnostics) throw new Error('Private stdout route did not take effect')
}
beforeEach(async context => {
  const line = 'R1-RAW-HOOK ' + context.name + '\n'
  if (['raw', 'isolated', 'canonical'].includes(params.get('marker'))) process.stdout.write(line)
  if (params.get('marker') === 'flush') await new Promise(resolve => process.stdout.write(line, resolve))
  if (params.get('marker') === 'stderr') process.stderr.write(line)
  await setImmediate()
})
