import { run } from 'node:test'
import { channel as diagnosticsChannel } from 'node:diagnostics_channel'
import { existsSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { DefaultSerializer, DefaultDeserializer } from 'node:v8'
import { NativeTestSupervision } from '/Users/yuanxi/Workwork/vibe-fs/requirements/verification-system/tests/support/native-test-supervision.mjs'
import { createFiniteWaitChannel } from '/Users/yuanxi/Workwork/vibe-fs/requirements/verification-system/tests/support/finite-wait-channel.mjs'

const directory = new URL('.', import.meta.url).pathname
const file = new URL('./entry.test.mjs', import.meta.url).pathname
const root = '/Users/yuanxi/Workwork/vibe-fs/requirements/verification-system/tests/support/'
const hashes = () => Object.fromEntries(['finite-physical-wait.mjs', 'native-test-supervision.mjs', 'finite-wait-channel.mjs'].map(path => [path, createHash('sha256').update(readFileSync(root + path)).digest('hex')]))
const results = { runtime: process.version, preregistered: [ ['isolated','raw'], ['canonical','raw'] ], before: hashes(), cases: [] }
results.transportFixture = 'Only coalesces real child stdout bytes into one data event; retains real producer, Node builtin parser, native event stream, helper and socket'
delete process.env.NODE_TEST_CONTEXT
const serializer = new DefaultSerializer()
serializer.writeHeader()
const header = serializer.releaseBuffer()
function containsNativeTarget(bytes) {
  for (let offset = bytes.indexOf(header); offset >= 0; offset = bytes.indexOf(header, offset + 1)) {
    if (bytes.length < offset + header.length + 4) continue
    const size = bytes.readUInt32BE(offset + header.length)
    const start = offset + header.length + 4
    if (bytes.length < start + size) continue
    try {
      const decoder = new DefaultDeserializer(bytes.subarray(start, start + size))
      decoder.readHeader()
      const item = decoder.readValue()
      if (item.type === 'test:dequeue' && item.data.name === 'native dequeue must authorize this finite callback') return true
    } catch {}
  }
  return false
}

async function one(marker, previous) {
  const key = marker + '-' + previous + '-' + process.version
  const ready = directory + key + '.ready.json'
  const executed = directory + key + '.executed.json'
  rmSync(ready, { force: true })
  rmSync(executed, { force: true })
  const started = performance.now()
  const result = { marker, previous, events: [], controls: [], chunks: [], dataGateReleased: false }
  result.diagnostics = []
  const owner = new NativeTestSupervision({ files: [file], silenceMs: 5000 })
  let flushHeld = () => {}
  let channel
  channel = await createFiniteWaitChannel({ entryFile: file,
    onRequest(request) {
      result.controls.push({ at: performance.now() - started, phase: request.phase, name: request.name })
      for (const reply of owner.control(request)) channel.reply(reply)
      if (request.phase === 'begin') flushHeld()
    }, onError(error) { result.channelError = { name: error.name, message: error.message } } })
  owner.allocate(file, channel.runId)
  owner.observe({ type: 'runner:file-start', data: { entryFile: file, runId: channel.runId } })
  const preload = new URL('./preload.mjs', import.meta.url)
  for (const [name, value] of Object.entries({ ...channel.descriptor, runId: channel.runId, marker, previous, ready, executed })) preload.searchParams.set(name, value)
  const childSpawn = diagnosticsChannel('child_process')
  let child
  let polling
  const raw = []
  const observeChild = ({ process: observed }) => {
    queueMicrotask(() => {
      child = observed
      const emit = observed.stdout.emit
      const held = []
      let released = false
      flushHeld = () => {
        if (released || !result.controls.some(value => value.phase === 'begin')) return
        const combined = Buffer.concat(held)
        if (!containsNativeTarget(combined)) return
        released = true
        result.dataGateReleased = true
        result.dataGateAt = performance.now() - started
        result.dataGateReason = 'real serialized native target dequeue and real helper begin both observed'
        result.heldChunks = held.map(bytes => bytes.length)
        result.heldBytes = combined.length
        observed.stdout.emit = emit
        emit.call(observed.stdout, 'data', combined)
      }
      observed.stdout.emit = function(type, ...args) {
        if (type !== 'data' || released) return emit.call(this, type, ...args)
        held.push(Buffer.from(args[0]))
        flushHeld()
        return true
      }
      observed.stdout.on('data', bytes => {
        raw.push(Buffer.from(bytes))
        result.chunks.push({ at: performance.now() - started, bytes: bytes.length })
      })
      polling = setInterval(() => {
        if (!existsSync(ready)) return
        clearInterval(polling)
        result.ready = JSON.parse(readFileSync(ready, 'utf8'))
        flushHeld()
      }, 2)
    })
  }
  childSpawn.subscribe(observeChild)
  const controller = new AbortController()
  const hardStop = setTimeout(() => controller.abort(new Error('Private native probe deadline')), 8000)
  try {
    const stream = run({ files: [file], concurrency: 1, execArgv: ['--import=' + preload.href], signal: controller.signal })
    let sequence = 0
    for (const type of ['test:dequeue', 'test:complete']) stream.on(type, data => {
      sequence += 1
      const event = { type, data: { ...data, entryFile: file, nativeSequence: sequence } }
      result.events.push({ at: performance.now() - started, type, name: data.name, passed: data.details?.passed })
      try { for (const reply of owner.observe(event)) channel.reply(reply) }
      catch (error) { result.ownerError = { name: error.name, message: error.message } }
    })
    for await (const event of stream) {
      if (event.type === 'test:pass' || event.type === 'test:fail') result.events.push({ at: performance.now() - started, type: event.type, name: event.data.name, error: event.data.details?.error?.message })
      if (event.type === 'test:stdout' || event.type === 'test:stderr') result.diagnostics.push({ type: event.type, message: event.data.message })
    }
    result.executed = existsSync(executed)
    const stderr = result.diagnostics.filter(value => value.type === 'test:stderr').map(value => value.message).join('')
    result.bodyOutputsAllOnStderr = ['R1-PREVIOUS-RAW', 'R1-PREVIOUS-BUFFER', 'R1-PREVIOUS-NAMED', 'R1-PREVIOUS-CONSOLE', 'R1-PREVIOUS-DEFAULT-CONSOLE', 'R1-PREVIOUS-NAMED-CONSOLE'].every(value => stderr.includes(value))
    result.childPid = child?.pid
  } finally {
    clearTimeout(hardStop)
    clearInterval(polling)
    childSpawn.unsubscribe(observeChild)
    await channel.close()
    result.socketRemoved = !existsSync(channel.descriptor.path)
    writeFileSync(directory + key + '.' + process.version + '.isolated-stdout.bin', Buffer.concat(raw))
  }
  results.cases.push(result)
}

for (const [marker, previous] of results.preregistered) await one(marker, previous)
results.after = hashes()
results.sourceStable = JSON.stringify(results.before) === JSON.stringify(results.after)
writeFileSync(directory + 'canonical-' + process.version + '-result.json', JSON.stringify(results, null, 2) + '\n')
console.log(JSON.stringify(results))
