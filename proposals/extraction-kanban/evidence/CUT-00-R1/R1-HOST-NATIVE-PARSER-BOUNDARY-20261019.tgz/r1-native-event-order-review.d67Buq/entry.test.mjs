import test from 'node:test'
import { writeFileSync } from 'node:fs'
import { stdout as namedStdout } from 'node:process'
import defaultConsole, { log as namedLog } from 'node:console'
import { withFinitePhysicalWait } from '/Users/yuanxi/Workwork/vibe-fs/requirements/verification-system/tests/support/finite-physical-wait.mjs'
const imported = process.execArgv.find(argument => argument.startsWith('--import='))
const params = new URL(imported.slice(9)).searchParams
test('ordinary predecessor', () => {
  if (params.get('previous') === 'raw') {
    process.stdout.write('R1-PREVIOUS-RAW\n')
    process.stdout.write(Buffer.from('R1-PREVIOUS-BUFFER\n'))
    namedStdout.write('R1-PREVIOUS-NAMED\n')
    console.log('R1-PREVIOUS-CONSOLE')
    defaultConsole.log('R1-PREVIOUS-DEFAULT-CONSOLE')
    namedLog('R1-PREVIOUS-NAMED-CONSOLE')
  }
})
test('native dequeue must authorize this finite callback', { timeout: 5000 }, async context => {
  writeFileSync(params.get('ready'), JSON.stringify({ pid: process.pid, at: performance.now() }))
  await withFinitePhysicalWait(context, { operation: 'native dequeue physical boundary', limitMs: 2000 }, () => {
    writeFileSync(params.get('executed'), JSON.stringify({ pid: process.pid, at: performance.now() }))
  })
})
