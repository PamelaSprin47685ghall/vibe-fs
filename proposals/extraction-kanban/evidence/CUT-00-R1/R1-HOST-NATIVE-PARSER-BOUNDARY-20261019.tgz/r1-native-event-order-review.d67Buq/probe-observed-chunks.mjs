import { run } from 'node:test'
import { tracingChannel } from 'node:diagnostics_channel'
import { existsSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { NativeTestSupervision } from '/Users/yuanxi/Workwork/vibe-fs/requirements/verification-system/tests/support/native-test-supervision.mjs'
import { createFiniteWaitChannel } from '/Users/yuanxi/Workwork/vibe-fs/requirements/verification-system/tests/support/finite-wait-channel.mjs'

const directory = new URL('.', import.meta.url).pathname
const file = new URL('./entry.test.mjs', import.meta.url).pathname
const root = '/Users/yuanxi/Workwork/vibe-fs/requirements/verification-system/tests/support/'
const hashes = () => Object.fromEntries(['finite-physical-wait.mjs', 'native-test-supervision.mjs', 'finite-wait-channel.mjs'].map(path => [path, createHash('sha256').update(readFileSync(root + path)).digest('hex')]))
const results = { runtime: process.version, preregistered: [ ['raw','none'], ['flush','none'], ['stderr','none'], ['stderr','raw'] ], before: hashes(), cases: [] }
delete process.env.NODE_TEST_CONTEXT

async function one(marker, previous) {
  const key = marker + '-' + previous
  const ready = directory + key + '.ready.json'
  const executed = directory + key + '.executed.json'
  rmSync(ready, { force: true })
  rmSync(executed, { force: true })
  const started = performance.now()
  const result = { marker, previous, events: [], controls: [], chunks: [], dataGateReleased: false }
  const owner = new NativeTestSupervision({ files: [file], silenceMs: 5000 })
  let channel
  channel = await createFiniteWaitChannel({ entryFile: file,
    onRequest(request) {
      result.controls.push({ at: performance.now() - started, phase: request.phase, name: request.name })
      for (const reply of owner.control(request)) channel.reply(reply)
    }, onError(error) { result.channelError = { name: error.name, message: error.message } } })
  owner.allocate(file, channel.runId)
  owner.observe({ type: 'runner:file-start', data: { entryFile: file, runId: channel.runId } })
  const preload = new URL('./preload.mjs', import.meta.url)
  for (const [name, value] of Object.entries({ ...channel.descriptor, runId: channel.runId, marker, previous, ready, executed })) preload.searchParams.set(name, value)
  const tracing = tracingChannel('child_process.spawn')
  let child
  let polling
  const raw = []
  const observeChild = ({ process: observed }) => {
    queueMicrotask(() => {
      child = observed
      observed.stdout.pause()
      observed.stdout.on('data', bytes => {
        raw.push(Buffer.from(bytes))
        result.chunks.push({ at: performance.now() - started, bytes: bytes.length })
      })
      observed.stdout.pause()
      polling = setInterval(() => {
        if (!existsSync(ready)) return
        clearInterval(polling)
        result.ready = JSON.parse(readFileSync(ready, 'utf8'))
        result.dataGateReleased = true
        result.dataGateAt = performance.now() - started
        observed.stdout.resume()
      }, 2)
    })
  }
  tracing.end.subscribe(observeChild)
  const controller = new AbortController()
  const hardStop = setTimeout(() => controller.abort(new Error('Private native probe deadline')), 8000)
  try {
    const stream = run({ files: [file], concurrency: 1, execArgv: ['--import=' + preload.href], signal: controller.signal })
    let sequence = 0
    for (const type of ['test:dequeue', 'test:complete']) stream.on(type, data => {
      sequence += 1
      const event = { type, data: { ...data, entryFile: file, nativeSequence: sequence } }
      result.events.push({ at: performance.now() - started, type, name: data.name, passed: data.details?.passed })
      try { for (const reply of owner.observe(event)) channel.reply(reply) }
      catch (error) { result.ownerError = { name: error.name, message: error.message } }
    })
    for await (const event of stream) {
      if (event.type === 'test:pass' || event.type === 'test:fail') result.events.push({ at: performance.now() - started, type: event.type, name: event.data.name, error: event.data.details?.error?.message })
    }
    result.executed = existsSync(executed)
    result.childPid = child?.pid
  } finally {
    clearTimeout(hardStop)
    clearInterval(polling)
    tracing.end.unsubscribe(observeChild)
    await channel.close()
    result.socketRemoved = !existsSync(channel.descriptor.path)
    writeFileSync(directory + key + '.stdout.bin', Buffer.concat(raw))
  }
  results.cases.push(result)
}

for (const [marker, previous] of results.preregistered) await one(marker, previous)
results.after = hashes()
results.sourceStable = JSON.stringify(results.before) === JSON.stringify(results.after)
writeFileSync(directory + 'result.json', JSON.stringify(results, null, 2) + '\n')
console.log(JSON.stringify(results))
