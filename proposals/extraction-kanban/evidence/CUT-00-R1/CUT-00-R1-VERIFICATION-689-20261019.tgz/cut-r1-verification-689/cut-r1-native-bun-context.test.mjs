import test from 'node:test'
import assert from 'node:assert/strict'
import { withFinitePhysicalWait } from '/Users/yuanxi/Workwork/vibe-fs/requirements/verification-system/tests/support/finite-physical-wait.mjs'

test('native Bun preserves the uninstrumented physical callback', async context => {
  let calls = 0
  await withFinitePhysicalWait(context, { operation: 'native context', limitMs: 1000 }, () => {
    calls += 1
  })
  assert.equal(calls, 1)
  console.error(JSON.stringify({ signal: typeof context.signal, aborted: context.signal?.aborted }))
})
