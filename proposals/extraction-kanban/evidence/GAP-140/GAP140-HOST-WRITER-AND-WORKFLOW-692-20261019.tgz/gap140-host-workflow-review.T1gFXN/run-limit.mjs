import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import { createHash } from 'node:crypto'
const [host] = process.argv.slice(2)
const root = path.dirname(fileURLToPath(import.meta.url))
const product = path.join(root, 'node_modules', 'wanxiangshu')
const output = path.join(root, host + '-limit-v1')
if (fs.existsSync(output)) throw new Error('Refuse to overwrite evidence')
const home = path.join(output, 'home')
const store = path.join(output, 'store')
fs.mkdirSync(path.join(home, '.config', 'opencode'), { recursive: true })
fs.mkdirSync(store, { recursive: true })
fs.writeFileSync(path.join(home, '.config', 'opencode', 'wanxiangshu.mjs'), `export const routingProtocol = 2
export default function route(role) { return { model: 'provider/' + role + '-model', reasoning: 'none' } }
export const predictorConfiguration = () => ({state:'unconfigured',reason:null})
`)
const env = { ...process.env, HOME: home, USERPROFILE: home }
delete env.NODE_TEST_CONTEXT
delete env.WANXIANGSHU_NO_FATAL_EXIT
const executable = host === 'node' ? process.execPath : host
const run = promisify(execFile)
const outcomes = []
async function child(name, args) {
  try {
    const value = await run(executable, args, { env, cwd: output, timeout: 30000, maxBuffer: 8 * 1024 * 1024 })
    fs.writeFileSync(path.join(output, name + '.stdout.log'), value.stdout)
    fs.writeFileSync(path.join(output, name + '.stderr.log'), value.stderr)
    outcomes.push({ name, code: 0 })
    return true
  } catch (error) {
    fs.writeFileSync(path.join(output, name + '.stdout.log'), error.stdout ?? '')
    fs.writeFileSync(path.join(output, name + '.stderr.log'), error.stderr ?? '')
    outcomes.push({ name, code: error.code, signal: error.signal, killed: error.killed, message: error.message })
    return false
  }
}
const physical = path.join(output, 'physical.json')
if (await child('physical', [path.join(root, 'limit-child.mjs'), product, store, physical])) {
  await child('cold', [path.join(root, 'cold-limit-child.mjs'), product, physical, path.join(output, 'cold.json')])
}
const tgz = '/private/tmp/gap140-candidate-692/wanxiangshu-0.9.0.tgz'
const result = { host, product, tgz, sha256: createHash('sha256').update(fs.readFileSync(tgz)).digest('hex'), outcomes,
  accepted: outcomes.length === 2 && outcomes.every(item => item.code === 0) }
fs.writeFileSync(path.join(output, 'result.json'), JSON.stringify(result, null, 2) + '\n')
console.log(JSON.stringify(result))
if (!result.accepted) process.exitCode = 1
