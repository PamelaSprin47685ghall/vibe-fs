# GAP-140 actual writer and recovery consumer review

This is an independent consumer experiment against fixed package generation 692.
Package SHA-256: `e4d0f606efba582592695da298010c152b8294ea63e071ddc5de34e83c5b89ac`.
No shared source or installed package file was changed. Package contents are checked against the original tar in `package-file-verification.json`.

## Completed evidence

`node-*-reentry-v2` and `bun-*-reentry-v2` use the real SyncDelegate, ProviderRecoveryWorkflow, ledger, AgentJournal, ProcessEventLog, lock and native fs. The controlled Host port records actual SendPrompt calls; this is not a real external provider request. The known-stop prerequisite comes from the real process-local Host stop fence.

| Scenario | Native append | Product result | New SendPrompt | Cold failures |
| --- | --- | --- | --- | --- |
| closed | not called | NotAttempted / writer closing | 0 | 0 |
| before-physical | wrapper throws before native append | CommitUnknown / PhysicalAppend | 0 | 0 |
| after-release | actual append, fsync and owned lock release; wrapper then throws | CommitUnknown / StoreRelease | 0 | 1 |
| valid | actual append succeeds | recovery proceeds | 1 | 1 |

The same runtime receives the exact failed identity again after each refusal: additional append calls and actual sends remain zero. The call is already terminal and its handler returns false. This is not evidence that an active handler can safely replay a poisoned ledger.

Cold children have new OS PIDs, read the same event bytes, retain their hashes, and create no file for their reader writer ID. This proves projection durability only. It does not prove a cold workflow has Host-stop authority.

The injected Error has an explicit code and message, saved in each receipt. The formatted SyncDelegate completion preserves the message and physical phase. That consumer exposes no typed original cause identity or code, so this evidence does not claim their end-to-end preservation.

`node-limit-v1` and `bun-limit-v1` use the existing default limit 12 without changing product code. Each follows actual physical successors in one owner root: failures 1 through 11 each cause exactly one SendPrompt; failure 12 causes none. There are 12 actual FailureRecorded facts and one RetryExhausted, 12 total prompts including the initial prompt, and cold state remains count 12 / exhausted true.

## Negative controls and limits

The initial Bun fault probes are preserved at `bun-before-physical`, `bun-after-release`, `bun-valid`, with the exact initial source `physical-child.initial-import-gap.mjs`. Importing product modules before changing native fs exports did not bind the wrappers on Bun. Before/after probes therefore never injected a failure and waited for an unreturned actual retry receipt; the healthy probe sent and committed but its wrapper-call assertion failed. These are invalid fault-injection observations, not product regressions. Final Bun probes install only native fs wrappers with Bun's public mock.module before importing the product. All nonfault fs calls delegate to the original physical functions. Node uses syncBuiltinESMExports.

`node-concurrent-v1` and `bun-concurrent-v1` are the initial bounded concurrent probes; their failure receipt omitted live send state. The one diagnostic variant is preserved in `*-concurrent-v2`. Two simultaneous calls of the callable SyncDelegate HandleTurn surface intentionally bypass the ordinary per-session production Scheduler. Both hosts produce two identical failure facts, projection count 1 and two actual recovery SendPrompt calls (three total including initial). The second call waits for the unreturned third prompt receipt; cleanup releases it. This is a confirmed application-consumer concurrency gap. It is not yet evidence of reachability through ordinary serialized public Host scheduling, nor proof that this change introduced it. Root has independently reported the raw-ledger duplicate is also present before this repair; that alone does not classify the old physical send boundary.

The ordinary production Scheduler serializes per-session ReconcilePass/onTurn work. EventStoreJournalWriter serializes individual append calls, not the preceding ledger CurrentState read. These are separate boundaries.

The permanent test migration initially carried the private `/private/tmp/` assertion into a fixture whose parent uses the platform tmpdir. This is a test setup error. Root has removed that private-only prefix constraint and retained its first failure.

## Reproduction

Install the archived exact package with the included lock and peer versions. Each runner refuses to overwrite its output directory. Use a fresh copy or change the explicit evidence suffix before replay.

```
node run.mjs node closed new-run
node run.mjs node before-physical new-run
node run.mjs node after-release new-run
node run.mjs node valid new-run
node run.mjs bun closed new-run
node run.mjs bun before-physical new-run
node run.mjs bun after-release new-run
node run.mjs bun valid new-run
node run-limit.mjs node
node run-limit.mjs bun
```

The final physical-child source adds explicit terminal phase assertions after reentry-v2 execution. All stored completion strings already meet these assertions; permanent tests include them. This source-only assertion addition does not replace any raw receipt.

All owned runtimes, pending sends, writer descriptors and owned locks were released. Native-process stdout and stderr, complete receipts and actual event files are preserved. Only installed dependencies, a duplicate extracted tar tree, and Bun generated caches are omitted; `omissions.json` inventories those files. The exact package, dependency lock and installation log are retained. R12-U1 was not investigated.
