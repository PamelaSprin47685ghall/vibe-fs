import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
import { createHash, randomUUID } from 'node:crypto'

const [packageRoot, directory, receiptPath] = process.argv.slice(2)
const imported = relative => import(pathToFileURL(path.join(packageRoot, 'dist', relative)).href)
const sync = await imported('Execution/Delegation/SyncDelegate/Surface.js')
const dispatch = await imported('Interaction/Dispatch/DispatchSurface.js')
const failure = await imported('Participant/Provider/Attempt/Fallback/ProviderFailureSurface.js')
const limit = failure.budget.defaultBudget
assert.ok(Number.isSafeInteger(limit) && limit > 1)
const owner = 'gap140-limit-owner-' + randomUUID()
const result = { pid: process.pid, runtime: process.version, bun: process.versions.bun ?? null, packageRoot, directory, limit, rounds: [] }
let runtime
async function bounded(action, label) {
  let timer
  try { return await Promise.race([action, new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(label + ' did not settle')), 8000) })]) }
  finally { clearTimeout(timer) }
}
try {
  runtime = await sync.createForProviderRecovery(directory, [{ sessionId: owner, agent: 'manager' }])
  const execution = sync.startObserved(runtime, owner, 'GAP140 actual finite recovery exhaustion')
  const completion = sync.observedCompletion(execution)
  await bounded(sync.awaitPromptCount(runtime, owner, 'Engineer', 1), 'initial real send')
  assert.equal(sync.returnPromptOutcome(runtime, owner, 'Engineer', 0, dispatch.admittedWithReceipt('limit-initial-receipt')), true)
  let current = await sync.confirmManagedPromptPhysical(runtime, owner, 'Engineer', 0, 'limit-physical-0')
  assert.equal(current.ok, true)
  result.initial = current
  await bounded(sync.observedAdmission(execution), 'initial admission')
  for (let count = 1; count <= limit; count += 1) {
    const failedRun = 'limit-provider-' + count + '-' + randomUUID()
    const reason = 'GAP140_ACTUAL_LIMIT_' + count
    const beforePrompts = sync.promptCount(runtime, owner, 'Engineer')
    assert.equal(sync.observeProviderFailureStop(runtime, current.sessionId, failedRun), true)
    const attempted = sync.observeExactProviderFailure(runtime, current.sessionId, current.physicalUserMessageId,
      current.authorityRootUserMessageId, failedRun, reason)
    if (count < limit) {
      await bounded(sync.awaitPromptCount(runtime, owner, 'Engineer', beforePrompts + 1), 'real recovery send below persisted limit')
      assert.equal(sync.returnPromptOutcome(runtime, owner, 'Engineer', beforePrompts, dispatch.admittedWithReceipt('limit-receipt-' + count)), true)
    }
    const handled = await bounded(attempted, 'recovery at count ' + count)
    const afterPrompts = sync.promptCount(runtime, owner, 'Engineer')
    const state = await sync.withJournal(runtime, async journal => failure.snapshot(journal, current.sessionId))
    result.rounds.push({ count, failedRun, reason, handled, beforePrompts, afterPrompts, sendDelta: afterPrompts - beforePrompts, state })
    assert.equal(state.failures, count)
    assert.deepEqual(state.budgetSpec, { version: 1, limit })
    assert.equal(state.exhausted, count === limit)
    assert.equal(afterPrompts - beforePrompts, count < limit ? 1 : 0)
    if (count < limit) {
      current = await sync.confirmManagedPromptPhysical(runtime, owner, 'Engineer', beforePrompts, 'limit-physical-' + count)
      assert.equal(current.ok, true, JSON.stringify(current))
    }
  }
  result.completion = await bounded(completion, 'exhaustion completion')
  assert.equal(result.completion.ok, false)
  result.final = await sync.withJournal(runtime, async journal => failure.snapshot(journal, result.initial.sessionId))
  result.totalPrompts = sync.promptCount(runtime, owner, 'Engineer')
  assert.equal(result.totalPrompts, limit)
  const eventDirectory = path.join(directory, 'wanxiangshu', 'events')
  result.files = fs.readdirSync(eventDirectory).filter(name => name.endsWith('.ndjson')).sort().map(name => {
    const bytes = fs.readFileSync(path.join(eventDirectory, name))
    return { name, bytes: bytes.toString('base64'), sha256: createHash('sha256').update(bytes).digest('hex') }
  })
  const facts = result.files.flatMap(file => Buffer.from(file.bytes, 'base64').toString('utf8').trimEnd().split('\n').filter(Boolean).map(JSON.parse))
  result.failureFacts = facts.filter(fact => JSON.stringify(fact).includes('GAP140_ACTUAL_LIMIT_'))
  result.exhaustedFacts = facts.filter(fact => JSON.stringify(fact).includes('RetryExhausted'))
  assert.equal(result.failureFacts.length, limit)
  assert.equal(result.exhaustedFacts.length, 1)
  result.accepted = true
} catch (error) {
  result.accepted = false
  result.error = { name: error.name, message: error.message, stack: error.stack }
  process.exitCode = 1
} finally {
  if (runtime) {
    try { await bounded(sync.closeRecovery(runtime), 'owned close'); result.closed = true }
    catch (error) { result.cleanupError = error.message; process.exitCode = 1 }
  }
  fs.writeFileSync(receiptPath, JSON.stringify(result, null, 2) + '\n')
}
