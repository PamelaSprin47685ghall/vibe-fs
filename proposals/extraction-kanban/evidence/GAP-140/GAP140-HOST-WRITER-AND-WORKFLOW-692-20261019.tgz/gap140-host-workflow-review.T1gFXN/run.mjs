import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import { createHash } from 'node:crypto'

const [host, scenario, suffix = 'reentry-v2'] = process.argv.slice(2)
const directory = path.dirname(fileURLToPath(import.meta.url))
const packageRoot = path.join(directory, 'node_modules', 'wanxiangshu')
const output = path.join(directory, host + '-' + scenario + '-' + suffix)
if (fs.existsSync(output)) throw new Error('Refuse to overwrite prior evidence: ' + output)
fs.mkdirSync(output, { recursive: true })
const commonDir = path.join(output, 'store')
const home = path.join(output, 'home')
fs.mkdirSync(commonDir, { recursive: true })
fs.mkdirSync(path.join(home, '.config', 'opencode'), { recursive: true })
fs.writeFileSync(path.join(home, '.config', 'opencode', 'wanxiangshu.mjs'), `export const routingProtocol = 2
export default function route(role) { return { model: 'provider/' + role + '-model', reasoning: 'none' } }
export const predictorConfiguration = () => ({state:'unconfigured',reason:null})
`)
const env = { ...process.env, HOME: home, USERPROFILE: home }
delete env.NODE_TEST_CONTEXT
delete env.WANXIANGSHU_NO_FATAL_EXIT
const executable = host === 'node' ? process.execPath : host
const hash = file => createHash('sha256').update(fs.readFileSync(file)).digest('hex')
const watched = ['Participant/Provider/Attempt/Fallback/Ledger.js', 'Participant/Provider/Attempt/Fallback/Projection.js',
  'Participant/Provider/Attempt/Fallback/Retry.js', 'Participant/Provider/Attempt/Fallback/Workflow.js',
  'Composition/Durable/AgentJournalPortAdapter.js', 'Persistence/Journal/EventStoreJournalWriter.js']
const digest = () => Object.fromEntries(watched.map(file => [file, hash(path.join(packageRoot, 'dist', file))]))
const result = { host, scenario, executable, packageRoot, commonDir,
  tgz: '/private/tmp/gap140-candidate-692/wanxiangshu-0.9.0.tgz',
  tgzSha256: hash('/private/tmp/gap140-candidate-692/wanxiangshu-0.9.0.tgz'), before: digest(), outcomes: [] }
const run = promisify(execFile)
async function child(name, args) {
  const started = performance.now()
  try {
    const value = await run(executable, args, { env, cwd: output, timeout: 20000, maxBuffer: 8 * 1024 * 1024 })
    fs.writeFileSync(path.join(output, name + '.stdout.log'), value.stdout)
    fs.writeFileSync(path.join(output, name + '.stderr.log'), value.stderr)
    result.outcomes.push({ name, code: 0, elapsedMs: performance.now() - started })
    return true
  } catch (error) {
    fs.writeFileSync(path.join(output, name + '.stdout.log'), error.stdout ?? '')
    fs.writeFileSync(path.join(output, name + '.stderr.log'), error.stderr ?? '')
    result.outcomes.push({ name, code: error.code, signal: error.signal, killed: error.killed,
      elapsedMs: performance.now() - started, message: error.message })
    return false
  }
}
const receipt = path.join(output, 'physical.json')
const physical = await child('physical', [path.join(directory, 'physical-child.mjs'), packageRoot, commonDir, scenario, receipt])
if (physical) await child('cold', [path.join(directory, 'cold-child.mjs'), packageRoot, receipt, path.join(output, 'cold.json')])
result.after = digest()
result.sourceStable = JSON.stringify(result.before) === JSON.stringify(result.after)
result.accepted = result.sourceStable && result.outcomes.length === 2 && result.outcomes.every(item => item.code === 0)
fs.writeFileSync(path.join(output, 'result.json'), JSON.stringify(result, null, 2) + '\n')
console.log(JSON.stringify({ host, scenario, accepted: result.accepted, outcomes: result.outcomes }))
if (!result.accepted) process.exitCode = 1
