import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
const [host] = process.argv.slice(2)
const root = path.dirname(fileURLToPath(import.meta.url))
const output = path.join(root, host + '-concurrent-v2')
if (fs.existsSync(output)) throw new Error('Refuse to overwrite evidence')
const home = path.join(output, 'home')
const store = path.join(output, 'store')
fs.mkdirSync(path.join(home, '.config', 'opencode'), { recursive: true })
fs.mkdirSync(store, { recursive: true })
fs.copyFileSync(path.join(root, host + '-limit-v1', 'home', '.config', 'opencode', 'wanxiangshu.mjs'),
  path.join(home, '.config', 'opencode', 'wanxiangshu.mjs'))
const env = { ...process.env, HOME: home, USERPROFILE: home }
delete env.NODE_TEST_CONTEXT
delete env.WANXIANGSHU_NO_FATAL_EXIT
let result
try {
  const actual = await promisify(execFile)(host === 'node' ? process.execPath : host,
    [path.join(root, 'concurrent-child.mjs'), path.join(root, 'node_modules', 'wanxiangshu'), store, path.join(output, 'physical.json')],
    { env, cwd: output, timeout: 20000, maxBuffer: 8 * 1024 * 1024 })
  fs.writeFileSync(path.join(output, 'stdout.log'), actual.stdout)
  fs.writeFileSync(path.join(output, 'stderr.log'), actual.stderr)
  result = { host, code: 0 }
} catch (error) {
  fs.writeFileSync(path.join(output, 'stdout.log'), error.stdout ?? '')
  fs.writeFileSync(path.join(output, 'stderr.log'), error.stderr ?? '')
  result = { host, code: error.code, signal: error.signal, message: error.message }
  process.exitCode = 1
}
fs.writeFileSync(path.join(output, 'result.json'), JSON.stringify(result, null, 2) + '\n')
console.log(JSON.stringify(result))
