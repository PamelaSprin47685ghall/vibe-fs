import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
import { createHash, randomUUID } from 'node:crypto'
const [packageRoot, receiptPath, resultPath] = process.argv.slice(2)
const source = JSON.parse(fs.readFileSync(receiptPath, 'utf8'))
const imported = relative => import(pathToFileURL(path.join(packageRoot, 'dist', relative)).href)
const journals = await imported('Persistence/Journal/Surface.js')
const failure = await imported('Participant/Provider/Attempt/Fallback/ProviderFailureSurface.js')
const writerId = 'cold-limit-' + randomUUID()
const opened = await journals.JournalSurface_bootWithWriterId(source.directory, writerId, 'cold-limit-runtime', process.pid, new Date().toISOString())
assert.equal(opened.ok, true, JSON.stringify(opened))
try {
  const actual = failure.snapshot(opened.journal, source.initial.sessionId)
  assert.deepEqual(actual, source.final)
  assert.deepEqual(actual, { budgetSpec: { version: 1, limit: source.limit }, exhausted: true, failures: source.limit })
  for (const file of source.files) {
    const bytes = fs.readFileSync(path.join(source.directory, 'wanxiangshu', 'events', file.name))
    assert.equal(bytes.toString('base64'), file.bytes)
    assert.equal(createHash('sha256').update(bytes).digest('hex'), file.sha256)
  }
  const writerCreated = fs.readdirSync(path.join(source.directory, 'wanxiangshu', 'events')).some(name => name.startsWith(writerId))
  assert.equal(writerCreated, false)
  fs.writeFileSync(resultPath, JSON.stringify({ pid: process.pid, sourcePid: source.pid, writerId, writerCreated,
    actual, originalBytesPreserved: true, scope: 'Actual cold journal fold only; no cold workflow or Host-stop authority is inferred' }, null, 2) + '\n')
} finally { journals.JournalSurface_dispose(opened.journal) }
