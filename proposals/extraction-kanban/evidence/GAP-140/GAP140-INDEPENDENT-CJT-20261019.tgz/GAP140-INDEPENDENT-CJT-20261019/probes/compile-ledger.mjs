import assert from 'node:assert/strict'
import fs from 'node:fs'
import { join, dirname, relative, resolve } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { createHash } from 'node:crypto'

const [repositoryArg, productArg, evidenceArg] = process.argv.slice(2)
const repository = resolve(repositoryArg)
const product = resolve(productArg)
const evidence = resolve(evidenceArg)
const probes = dirname(fileURLToPath(import.meta.url))
const staging = join(evidence, 'compile-staging')
const source = join(repository, 'src/Wanxiangshu')
const hash = path => createHash('sha256').update(fs.readFileSync(path)).digest('hex')
const save = (name, value) => fs.writeFileSync(join(evidence, name), JSON.stringify(value, null, 2) + '\n')
fs.mkdirSync(evidence, { recursive: true })
const { planOwnerCompile, compileOwnerProject } = await import(pathToFileURL(join(repository, 'scripts/lib/owner-compile.mjs')).href)
const project = join(source, 'Wanxiangshu.Owner.provider-attempt-recovery.participant-provider-attempt-fallback-ledger.fsproj')
const plan = planOwnerCompile({ projectPath: project })
const inputs = plan.compileItems.map(path => {
  const name = relative(source, path)
  const staged = join(staging, 'source', name)
  const archived = join(evidence, 'source-contracts', name)
  fs.mkdirSync(dirname(staged), { recursive: true })
  fs.mkdirSync(dirname(archived), { recursive: true })
  fs.copyFileSync(path, staged)
  fs.copyFileSync(path, archived)
  return staged
})
const snapshots = Object.fromEntries(plan.compileItems.map(path => [relative(source, path), hash(path)]))
save('source-inputs.json', snapshots)
const results = []
let emitted
for (const name of ['GAP140LedgerConsumer', 'GAP140NegativeLedgerMissingRoot']) {
  const file = join(staging, 'source', `${name}.fs`)
  fs.copyFileSync(join(probes, `${name}.fs`), file)
  fs.copyFileSync(file, join(evidence, `${name}.fs`))
  const compiled = await compileOwnerProject({ projectPath: project, scratchRoot: join(staging, name), stdio: 'pipe',
    compilePlan: { ...plan, compileItems: [...inputs, file] } })
  fs.writeFileSync(join(evidence, `${name}.stdout`), compiled.stdout || '')
  fs.writeFileSync(join(evidence, `${name}.stderr`), compiled.stderr || '')
  const result = { name, ok: compiled.ok, code: compiled.code, signal: compiled.signal }
  results.push(result)
  save(`${name}.status.json`, result)
  if (name === 'GAP140LedgerConsumer') {
    assert.equal(compiled.ok, true, String(compiled.stdout) + String(compiled.stderr))
    const find = directory => fs.readdirSync(directory).flatMap(value => {
      const path = join(directory, value)
      return fs.statSync(path).isDirectory() ? find(path) : path.endsWith(`${name}.js`) ? [path] : []
    })
    const matches = find(compiled.outputPath)
    assert.equal(matches.length, 1)
    emitted = fs.readFileSync(matches[0])
  } else {
    assert.equal(compiled.ok, false)
    assert.match(String(compiled.stdout), /AuthorityRootUserMessageId/)
  }
}
const runtime = join(evidence, 'typed-runtime')
fs.mkdirSync(runtime)
fs.writeFileSync(join(runtime, 'package.json'), JSON.stringify({ type: 'module', private: true }))
fs.writeFileSync(join(runtime, 'GAP140LedgerConsumer.js'), emitted)
const imports = [...emitted.toString().matchAll(/from\s+["']([^"']+)["']/g)].map(value => value[1])
const components = new Set(imports.map(value => value.slice(2).split('/')[0]))
for (const component of components) {
  assert.ok(['Foundation', 'Participant'].includes(component), component)
  fs.symlinkSync(join(product, 'dist', component), join(runtime, component))
}
fs.rmSync(staging, { recursive: true, force: true })
assert.equal(fs.existsSync(staging), false)
assert.deepEqual(Object.fromEntries(plan.compileItems.map(path => [relative(source, path), hash(path)])), snapshots)
save('runtime-bindings.json', { imports, product, emittedSha256: hash(join(runtime, 'GAP140LedgerConsumer.js')),
  allGeneratedProductionJsRemovedBeforeRuntime: true, noImportRewrite: true })
save('summary.json', { results, sourceFiles: inputs.length, fsiFiles: inputs.filter(path => path.endsWith('.fsi')).length,
  sourceUnchanged: true, productionGeneratedJsRemoved: true, runtimeIsSeparateStep: true,
  scope: 'Internal F# Ledger.fsi contract, not npm d.ts. Runtime must bind only the fixed package.' })
console.log(JSON.stringify({ positive: 1, negative: 1, actualFsi: true }))
