import assert from 'node:assert/strict'
import { mkdirSync, readFileSync, readdirSync, statSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { createHash } from 'node:crypto'

const [mode, packageRoot, evidenceRoot, typedModule, ledgerModule] = process.argv.slice(2)
const load = path => import(pathToFileURL(join(packageRoot, 'dist', path)).href)
const journal = await load('Persistence/Journal/Surface.js')
const owner = await load('Participant/Provider/Attempt/Fallback/ProviderFailureSurface.js')
const common = join(evidenceRoot, 'journal')
mkdirSync(common, { recursive: true })
const digest = value => createHash('sha256').update(value).digest('hex')
function files(directory = common) {
  return readdirSync(directory).sort().flatMap(name => {
    const path = join(directory, name)
    return statSync(path).isDirectory() ? files(path) : [path]
  })
}
function bytes() {
  return files().map(path => ({ path: path.slice(common.length + 1), bytes: statSync(path).size, sha256: digest(readFileSync(path)) }))
}
const before = bytes()
const opened = await journal.JournalSurface_bootWithWriterId(common, `writer-${mode}-pid${process.pid}`, `runtime-${mode}-${process.pid}`, process.pid, new Date().toISOString())
assert.equal(opened.ok, true, JSON.stringify(opened))
const handle = opened.journal
const results = []
let expected
try {
  if (mode === 'produce') {
    const typed = await import(pathToFileURL(resolve(typedModule)).href)
    const ledger = await import(pathToFileURL(resolve(ledgerModule)).href)
    const { AgentFact } = await load('Composition/Durable/Fact.js')
    const { StreamId } = await load('Persistence/Journal/Envelope.js')
    const identity = await load('Foundation/Identity.js')
    const { AgentJournalModule_appendAgent } = await load('Persistence/Journal/AgentJournal.js')
    const journalValue = journal.JournalHandle__get_Journal(handle)
    const { forProviderFailure } = await load('Composition/Durable/AgentJournalPortAdapter.js')
    const port = forProviderFailure(journalValue)
    const success = async (session, root, provider) => {
      const value = await ledger.recordSuccess(port, session, root, provider)
      return value.tag === 0 ? { ok: true } : { ok: false, error: value.fields[0] }
    }
    for (const limit of [3, 15]) {
      const session = `journal-limit-${limit}`
      assert.equal((await owner.acceptHumanRoot(handle, session, `physical-${limit}`, 'engineer')).ok, true)
      const profile = journal.JournalSurface_snapshot(handle).sessionProjections[session].promptAuthority.activeLogicalRun
      assert.ok(profile.logicalRun)
      assert.ok(profile.authorityRoot)
      const zeroSuccess = `zero-success-${limit}`
      assert.deepEqual(await success(session, profile.authorityRoot, zeroSuccess), { ok: true })
      const provider = `failure-${limit}-1`
      const failure = typed.failureFact(session, profile.logicalRun, profile.authorityRoot, provider, limit, 1)
      const stream = new StreamId(new StreamId(0, []).cases().indexOf('Session'), [identity.SessionIdModule_create(session)])
      const fact = new AgentFact(new AgentFact(0, []).cases().indexOf('ProviderFailure'), [failure])
      const appended = await AgentJournalModule_appendAgent(stream, identity.ProviderRunIdentityModule_create(provider), fact, journalValue)
      assert.equal(appended.tag, 0, JSON.stringify(appended))
      assert.deepEqual(owner.snapshot(handle, session), { failures: 1, budgetSpec: { version: 1, limit }, exhausted: false })
      const afterFirst = bytes()
      assert.deepEqual(await success(session, profile.authorityRoot, zeroSuccess), { ok: true })
      assert.deepEqual(bytes(), afterFirst, 'old zero-success cannot append or clear a later failure')
      const wrongRoot = await success(session, 'unrelated-authority-root', `unseen-${limit}`)
      assert.equal(wrongRoot.ok, false)
      assert.match(wrongRoot.error, /different authority root/)
      assert.deepEqual(bytes(), afterFirst, 'wrong authority root must not append a success fact')
      const conflict = await success(session, profile.authorityRoot, provider)
      assert.equal(conflict.ok, false, JSON.stringify(conflict))
      assert.deepEqual(bytes(), afterFirst, 'failure identity cannot later become success')
      const actual = []
      for (let count = 2; count <= limit; count++) {
        const outcome = await owner.recordConfirmedFailure(handle, session, `failure-${limit}-${count}`, `confirmed failure ${count}`)
        assert.deepEqual(outcome, { ok: true, outcome: count === limit ? 'RetryExhausted' : 'RetryAuthorized' })
        const state = owner.snapshot(handle, session)
        assert.deepEqual(state, { failures: count, budgetSpec: { version: 1, limit }, exhausted: count === limit })
        actual.push({ count, outcome, state })
      }
      const exhausted = bytes()
      assert.deepEqual(await owner.recordConfirmedFailure(handle, session, `late-${limit}`, 'exhausted attempt'), { ok: true, outcome: 'RetryExhausted' })
      assert.deepEqual(bytes(), exhausted, 'exhaustion must reject a later failure without a new fact')
      assert.deepEqual(await success(session, profile.authorityRoot, `success-after-limit-${limit}`), { ok: true })
      assert.deepEqual(owner.snapshot(handle, session), { failures: limit, budgetSpec: { version: 1, limit }, exhausted: true })
      const rememberedSuccess = bytes()
      assert.notDeepEqual(rememberedSuccess, exhausted, 'new success identity remains durable even after exhaustion')
      assert.deepEqual(await success(session, profile.authorityRoot, `success-after-limit-${limit}`), { ok: true })
      assert.deepEqual(bytes(), rememberedSuccess, 'duplicate success cannot append or reopen an exhausted run')
      results.push({ session, limit, profile, zeroSuccess, conflict, actual, state: owner.snapshot(handle, session) })
    }
    expected = { pid: process.pid, execPath: process.execPath, results, bytes: bytes() }
    writeFileSync(join(evidenceRoot, 'producer.json'), JSON.stringify(expected, null, 2) + '\n')
  } else {
    expected = JSON.parse(readFileSync(join(evidenceRoot, 'producer.json'), 'utf8'))
    assert.notEqual(process.pid, expected.pid)
    assert.deepEqual(before, expected.bytes, 'saved durable originals must match producer bytes')
    for (const item of expected.results) {
      const actual = owner.snapshot(handle, item.session)
      assert.deepEqual(actual, item.state)
      assert.equal(actual.budgetSpec.limit, item.limit)
      const slices = journal.JournalSurface_snapshot(handle).sessionProjections[item.session]
      assert.equal(slices.promptAuthority.activeLogicalRun.logicalRun, item.profile.logicalRun)
      results.push({ session: item.session, limit: item.limit, actual })
    }
    assert.deepEqual(bytes(), before, 'read-only cold boot cannot create a writer or alter originals')
    writeFileSync(join(evidenceRoot, `cold-${process.versions.bun ? 'bun' : 'node'}.json`), JSON.stringify({ pid: process.pid, producerPid: expected.pid, execPath: process.execPath, results, originalBytesPreserved: true, writerCreated: false, bytes: bytes() }, null, 2) + '\n')
  }
} finally {
  journal.JournalSurface_dispose(handle)
}
console.log(JSON.stringify({ mode, pid: process.pid, cases: results.length, passed: true }))
