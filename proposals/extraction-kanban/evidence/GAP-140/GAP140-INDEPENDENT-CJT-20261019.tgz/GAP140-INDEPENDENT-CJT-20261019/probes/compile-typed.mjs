import assert from 'node:assert/strict'
import fs from 'node:fs'
import { join, dirname, relative, resolve } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { createHash } from 'node:crypto'
import { spawn } from 'node:child_process'

const [repositoryArg, productArg, evidenceArg] = process.argv.slice(2)
const repository = resolve(repositoryArg)
const product = resolve(productArg)
const evidence = resolve(evidenceArg)
const probes = dirname(fileURLToPath(import.meta.url))
const staging = join(evidence, 'compile-staging')
const source = join(repository, 'src/Wanxiangshu')
const hash = path => createHash('sha256').update(fs.readFileSync(path)).digest('hex')
const save = (name, value) => fs.writeFileSync(join(evidence, name), JSON.stringify(value, null, 2))
fs.mkdirSync(evidence, { recursive: true })
const { planOwnerCompile, compileOwnerProject } = await import(pathToFileURL(join(repository, 'scripts/lib/owner-compile.mjs')).href)
const project = join(source, 'Wanxiangshu.Owner.provider-attempt-recovery.participant-provider-attempt-fallback-fact.fsproj')
const plan = planOwnerCompile({ projectPath: project })
const inputs = plan.compileItems.map(path => {
  const target = join(staging, 'source', relative(source, path))
  fs.mkdirSync(dirname(target), { recursive: true })
  fs.copyFileSync(path, target)
  return target
})
const snapshots = Object.fromEntries(plan.compileItems.map(path => [relative(source, path), hash(path)]))
save('source-inputs.json', snapshots)
const names = ['GAP140TypedConsumer', 'GAP140NegativeMissingSpec', 'GAP140NegativeOldLimit', 'GAP140NegativeMissingIdentity']
const results = []
let emitted
for (const name of names) {
  const file = join(staging, 'source', `${name}.fs`)
  fs.copyFileSync(join(probes, `${name}.fs`), file)
  fs.copyFileSync(file, join(evidence, `${name}.fs`))
  const compiled = await compileOwnerProject({ projectPath: project, scratchRoot: join(staging, name),
    stdio: 'pipe', compilePlan: { ...plan, compileItems: [...inputs, file] } })
  fs.writeFileSync(join(evidence, `${name}.stdout`), compiled.stdout || '')
  fs.writeFileSync(join(evidence, `${name}.stderr`), compiled.stderr || '')
  const result = { name, ok: compiled.ok, code: compiled.code, signal: compiled.signal }
  results.push(result)
  save(`${name}.status.json`, result)
  if (name === 'GAP140TypedConsumer') {
    assert.equal(compiled.ok, true, String(compiled.stdout) + String(compiled.stderr))
    const find = directory => fs.readdirSync(directory).flatMap(value => {
      const path = join(directory, value)
      return fs.statSync(path).isDirectory() ? find(path) : path.endsWith(`${name}.js`) ? [path] : []
    })
    const matches = find(compiled.outputPath)
    assert.equal(matches.length, 1)
    emitted = fs.readFileSync(matches[0])
  } else {
    assert.equal(compiled.ok, false, `${name} unexpectedly compiled`)
    assert.match(String(compiled.stdout) + String(compiled.stderr), new RegExp(name))
  }
}
const runtime = join(evidence, 'typed-runtime')
fs.mkdirSync(runtime)
fs.writeFileSync(join(runtime, 'package.json'), JSON.stringify({ type: 'module', private: true }))
fs.writeFileSync(join(runtime, 'GAP140TypedConsumer.js'), emitted)
const imports = [...emitted.toString().matchAll(/from\s+["']([^"']+)["']/g)].map(value => value[1])
const links = new Map()
for (const specifier of imports) {
  const component = specifier.startsWith('./') ? specifier.slice(2).split('/')[0]
    : specifier.startsWith('../fable_modules/') ? 'fable_modules' : null
  assert.ok(['Foundation', 'Participant', 'fable_modules'].includes(component), specifier)
  links.set(component === 'fable_modules' ? join(evidence, component) : join(runtime, component), join(product, 'dist', component))
}
for (const [from, to] of links) fs.symlinkSync(to, from)
fs.rmSync(staging, { recursive: true, force: true })
assert.equal(fs.existsSync(staging), false)
save('runtime-bindings.json', { imports, links: [...links], originalEmittedSha256: hash(join(runtime, 'GAP140TypedConsumer.js')),
  allGeneratedProductionJsRemovedBeforeRuntime: true, noImportRewrite: true })
const driver = join(runtime, 'driver.mjs')
fs.writeFileSync(driver, "import assert from 'node:assert/strict'\nimport { exercise } from './GAP140TypedConsumer.js'\nconst value=exercise()\nassert.equal(value.accepted,true)\nassert.equal(value.factLimit,3)\nconsole.log(JSON.stringify(value))\n")
for (const executable of [process.execPath, 'bun']) {
  const host = executable === 'bun' ? 'bun' : 'node'
  const child = spawn(executable, [driver], { stdio: ['ignore', 'pipe', 'pipe'] })
  let stdout = ''
  let stderr = ''
  child.stdout.on('data', value => { stdout += value })
  child.stderr.on('data', value => { stderr += value })
  const outcome = await new Promise((accept, reject) => {
    child.once('error', reject)
    child.once('close', (code, signal) => accept({ code, signal, pid: child.pid }))
  })
  fs.writeFileSync(join(evidence, `${host}.stdout`), stdout)
  fs.writeFileSync(join(evidence, `${host}.stderr`), stderr)
  save(`${host}.status.json`, outcome)
  assert.equal(outcome.code, 0, stderr)
  assert.equal(outcome.signal, null)
}
assert.deepEqual(Object.fromEntries(plan.compileItems.map(path => [relative(source, path), hash(path)])), snapshots)
save('summary.json', { positive: 1, expectedNegativeCompiles: 3, results, realSourceFiles: inputs.length,
  realFsiFiles: inputs.filter(path => path.endsWith('.fsi')).length, sameEmittedJsNodeBun: true,
  generatedProductionJsRemoved: true, sourceUnchanged: true,
  scope: 'Internal F# declarations, not new npm d.ts. Runtime only uses fixed installed package dist.' })
console.log(JSON.stringify({ accepted: true, positive: 1, negative: 3, sameEmittedJsNodeBun: true }))
