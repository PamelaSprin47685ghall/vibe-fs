import assert from 'node:assert/strict'
import fs from 'node:fs'
import { join, resolve } from 'node:path'
import { createHash } from 'node:crypto'
import { spawnSync } from 'node:child_process'

const [archiveArg, outputArg] = process.argv.slice(2)
const archive = resolve(archiveArg)
const output = resolve(outputArg)
assert.equal(fs.existsSync(output), false, 'Replay requires a new output directory')
fs.mkdirSync(output, { recursive: true })
const probes = join(archive, 'probes')
const tar = join(archive, 'packages', '697.tgz')
assert.equal(createHash('sha256').update(fs.readFileSync(tar)).digest('hex'), '21a3409fe09a626976189b47349122c2e94b405b941d4536a5ad7e837817346f')
const env = { ...process.env }
delete env.NODE_OPTIONS
delete env.NODE_TEST_CONTEXT
const commands = []
function run(name, executable, args) {
  const result = spawnSync(executable, args, { cwd: output, env, encoding: 'utf8', timeout: 60000 })
  fs.writeFileSync(join(output, `${name}.stdout`), result.stdout || '')
  fs.writeFileSync(join(output, `${name}.stderr`), result.stderr || '')
  commands.push({ name, executable, args, status: result.status, signal: result.signal, error: result.error?.message || null })
  fs.writeFileSync(join(output, 'commands-status.json'), JSON.stringify(commands, null, 2) + '\n')
  assert.equal(result.status, 0, `${name}: ${result.stderr}`)
  assert.equal(result.signal, null)
}
run('install', 'npm', ['install', '--ignore-scripts', '--no-audit', '--no-fund', tar])
const product = join(output, 'node_modules/wanxiangshu')
function restoreTyped(name, source, file) {
  const runtime = join(output, name)
  fs.mkdirSync(runtime)
  fs.copyFileSync(join(archive, source, file), join(runtime, file))
  fs.writeFileSync(join(runtime, 'package.json'), JSON.stringify({ type: 'module', private: true }))
  for (const component of ['Foundation', 'Participant']) fs.symlinkSync(join(product, 'dist', component), join(runtime, component))
  return join(runtime, file)
}
const fact = restoreTyped('typed-fact', 'evidence-695/typed/typed-runtime', 'GAP140TypedConsumer.js')
const ledger = restoreTyped('typed-ledger', 'evidence-697/typed-ledger/typed-runtime', 'GAP140LedgerConsumer.js')
fs.symlinkSync(join(product, 'dist/fable_modules'), join(output, 'fable_modules'))
fs.copyFileSync(join(archive, 'evidence-695/typed/typed-runtime/driver.mjs'), join(output, 'typed-fact/driver.mjs'))
for (const host of ['node', 'bun']) {
  run(`contracts-${host}`, host, [join(probes, 'contracts.mjs'), product, join(output, `contracts-${host}.json`)])
  run(`typed-fact-${host}`, host, [join(output, 'typed-fact/driver.mjs')])
  run(`produce-${host}`, host, [join(probes, 'journal-697.mjs'), 'produce', product, join(output, `journal-${host}`), fact, ledger])
  run(`legal-${host}`, host, [join(probes, 'legal-root.mjs'), '697', product, join(output, `legal-${host}`), ledger])
}
for (const source of ['node', 'bun']) {
  for (const host of ['node', 'bun']) run(`cold-${source}-${host}`, host, [join(probes, 'journal-697.mjs'), 'cold', product, join(output, `journal-${source}`), fact, ledger])
}
fs.writeFileSync(join(output, 'summary.json'), JSON.stringify({ accepted: true, fixed697: true, actualTypeRecompiles: 0,
  retainedJournals: true, scope: 'C/J01 and same compiled F# Ledger consumer; not full Host/workflow acceptance.' }, null, 2) + '\n')
console.log(JSON.stringify({ accepted: true, output }))
