# GAP-140 independent fixed-695 evidence

Fixed tar SHA256: `80d2392e5ea301f984a36d64c9162bbc4948e9bfe11d460d0a3b5ccf831c4418`.
Real npm installation: `gap140-independent-695/node_modules/wanxiangshu` (124 installed packages).
Node 26.6.0 and Bun 1.3.14. No shared source or tests edited.

## Scope and results

- C: `contracts.mjs`, nine grouped scenarios per Host, both exit 0. Actual fixed product pure owner and raw envelope codec; not a model replacement. Covers persistent limits 1/3/15, all-run identity retention, duplicate/conflicting observations, zero-count success, mutual failure/success identity, exhausted success stability, exhausted marker validation, malformed/missing persisted spec and legacy fallback rejection.
- T: 24 real project source inputs, 12 real `.fsi`; one Fable compile accepted, three negative compiles rejected for the intended type error. Actual source bytes archived. All generated production JS deleted before the *same* emitted consumer JS ran using only the fixed installed package `dist` via explicit symlinks. Node/Bun accepted. These are internal F# contracts, not npm `d.ts` additions.
- J01: Node/Bun each produced two actual Journal sessions with persistent limit 3 and 15. First versioned failure is made by the compiled F# consumer and committed through actual AgentJournal; later failures use the production ledger boundary. Limit 15 crosses the current default 12 and exhausts only at 15. Zero-count success stays durable; replaying it after failure does not reset; failure/success conflict is rejected; exhaustion stays closed. New success after exhaustion records its identity, but never resets/reopens; its duplicate writes nothing.
- Four separate cold OS consumers: Node/Bun each read both producer originals. Different PIDs, persisted limits/count/exhaustion preserved, all original file byte counts/SHA256 unchanged, no cold writer created.

This does **not** close GAP-140 or prove full Host/workflow retry authority. Fixed695 lacks the later expected-authority-root success command parameter. Full workflow/concurrency/COMMIT findings are reported separately by the parent.

## Preserved initial failures and corrections

1. `journal-*-produce.raw`: invalid private fixture writer name ended `-NNNN`; product correctly rejected its reserved suffix. No product defect.
2. `journal-*-produce-second.raw` and retained `journal-node`/`journal-bun` originals: my overstrict assertion demanded *no* fact after new success at exhaustion. Product correctly persisted new success identity while preserving count/exhaustion. Corrected to check that late failure writes nothing, new success remains durable, its duplicate writes nothing, and exhausted state never reopens. The successful runs use fresh `*-v3` directories; original failures were not overwritten.

## Portable replay

Use exact tar, `npm install --ignore-scripts --no-audit --no-fund /absolute/wanxiangshu-0.9.0.tgz` in a fresh private project. Set `PRODUCT` to the installed `node_modules/wanxiangshu`, `OUT` to a fresh directory, `PROBES` to the extracted probes, and `REPO` to a checkout with exact archived F# input bytes and declared build dependencies.

```sh
node "$PROBES/contracts.mjs" "$PRODUCT" "$OUT/contracts-node.json"
bun "$PROBES/contracts.mjs" "$PRODUCT" "$OUT/contracts-bun.json"
node "$PROBES/compile-typed.mjs" "$REPO" "$PRODUCT" "$OUT/typed"
node "$PROBES/journal.mjs" produce "$PRODUCT" "$OUT/journal-node" "$OUT/typed/typed-runtime/GAP140TypedConsumer.js"
bun "$PROBES/journal.mjs" produce "$PRODUCT" "$OUT/journal-bun" "$OUT/typed/typed-runtime/GAP140TypedConsumer.js"
node "$PROBES/journal.mjs" cold "$PRODUCT" "$OUT/journal-node" "$OUT/typed/typed-runtime/GAP140TypedConsumer.js"
bun "$PROBES/journal.mjs" cold "$PRODUCT" "$OUT/journal-node" "$OUT/typed/typed-runtime/GAP140TypedConsumer.js"
node "$PROBES/journal.mjs" cold "$PRODUCT" "$OUT/journal-bun" "$OUT/typed/typed-runtime/GAP140TypedConsumer.js"
bun "$PROBES/journal.mjs" cold "$PRODUCT" "$OUT/journal-bun" "$OUT/typed/typed-runtime/GAP140TypedConsumer.js"
```

Do not rerun producers over the preserved originals. Runtime symlinks in original typed evidence are recorded in `runtime-bindings.json`; recreate them for a moved fixed installation, without changing emitted consumer JS. No package implementation fallback is allowed.
