import assert from 'node:assert/strict'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { writeFileSync } from 'node:fs'

const product = resolve(process.argv[2])
const output = resolve(process.argv[3])
const owner = await import(pathToFileURL(join(product, 'dist/Participant/Provider/Attempt/Fallback/ProviderFailureSurface.js')).href)
const codec = await import(pathToFileURL(join(product, 'dist/Persistence/Journal/CodecSurface.js')).href)
const p = owner.providerFailureProjection
const session = 'independent-contract-session'
const run = 'independent-contract-run'
const root = 'independent-contract-root'
const spec = limit => ({ version: 1, limit })
const identity = attempt => owner.budget.attemptIdentity(session, run, root, attempt)
const rootFact = () => owner.authorityRootAccepted({ session, logicalRun: run, authorityRoot: root,
  authorityKind: 'HumanRoot', identitySeed: { kind: 'RootSelection', participantIdentity: {
    selectedAgent: 'engineer', canonicalRole: 'engineer', persona: 'Engineer',
    personaCatalogVersion: 1, origin: 'ResolvedAtRoot' } } })
const failure = (attempt, count, limit = 3, reason = 'confirmed-failure') => owner.providerFailureRecorded({
  session, logicalRun: run, authorityRoot: root, providerRun: attempt, budgetSpec: spec(limit),
  consecutiveFailureCount: count, reason })
const success = attempt => owner.providerSuccessRecorded({ session, logicalRun: run, authorityRoot: root, providerRun: attempt })
const exhausted = count => owner.providerRetryExhausted({ session, logicalRun: run, authorityRoot: root,
  finalConsecutiveFailureCount: count })
const fold = facts => owner.fold(facts.map((fact, index) => owner.envelope({ session, seq: index + 1, fact })))
const state = folded => {
  assert.equal(folded.ok, true, JSON.stringify(folded.error))
  return p.read(folded.value)
}
const cases = []
function check(name, action) {
  try {
    const evidence = action()
    cases.push({ name, passed: true, evidence })
  } catch (error) {
    cases.push({ name, passed: false, error: { name: error.name, message: error.message, stack: error.stack } })
  }
}
check('new run with no spec admits first accounting, and zero success remains deduplicated', () => {
  const initial = p.forAuthority(run, root)
  assert.equal(p.mayRetry(initial), true)
  assert.equal(p.read(initial).budgetSpec, null)
  const result = state(fold([rootFact(), success('zero'), failure('new', 1), success('zero')]))
  assert.equal(result.failures, 1)
  assert.deepEqual(result.budgetSpec, spec(3))
  return result
})
check('persisted limits 1, 3 and 15 exhaust without an exhaustion marker', () => {
  return [1, 3, 15].map(limit => {
    const facts = Array.from({ length: limit }, (_, index) => failure(`f-${index}`, index + 1, limit))
    const result = state(fold([rootFact(), ...facts]))
    assert.equal(result.failures, limit)
    assert.equal(result.exhausted, true)
    assert.deepEqual(result.budgetSpec, spec(limit))
    assert.equal(fold([rootFact(), ...facts, failure('over', limit + 1, limit)]).ok, false)
    assert.equal(fold([rootFact(), ...facts, facts.at(-1)]).ok, true)
    return result
  })
})
check('canonical duplicate is idempotent and count reason or spec changes conflict', () => {
  const first = failure('first', 1)
  assert.equal(state(fold([rootFact(), first, first])).failures, 1)
  for (const conflict of [failure('first', 2), failure('first', 1, 4), failure('first', 1, 3, 'changed'), failure('next', 2, 4)]) {
    assert.equal(fold([rootFact(), first, conflict]).ok, false)
  }
})
check('full-run identities survive forty successful reset cycles and old observations', () => {
  const facts = [rootFact()]
  for (let index = 0; index < 40; index += 1) facts.push(failure(`f-${index}`, 1, 2), success(`s-${index}`))
  facts.push(failure('last', 1, 2), failure('f-0', 1, 2), success('s-0'))
  const result = state(fold(facts))
  assert.equal(result.failures, 1)
  assert.equal(result.dedupeKeys, 41)
  assert.deepEqual(result.budgetSpec, spec(2))
  return result
})
check('same provider attempt cannot become both failure and success', () => {
  assert.equal(fold([rootFact(), failure('conflict', 1), success('conflict')]).ok, false)
  assert.equal(fold([rootFact(), success('conflict'), failure('conflict', 1)]).ok, false)
})
check('success after exhaustion cannot reopen, and repeats remain inert', () => {
  const result = state(fold([rootFact(), failure('last', 1, 1), success('late'), success('late')]))
  assert.equal(result.failures, 1)
  assert.equal(result.exhausted, true)
  return result
})
check('exhaustion marker only confirms an already derived exact boundary', () => {
  assert.equal(fold([rootFact(), exhausted(1)]).ok, false)
  assert.equal(fold([rootFact(), failure('first', 1), exhausted(1)]).ok, false)
  assert.equal(fold([rootFact(), failure('last', 1, 1), exhausted(2)]).ok, false)
  assert.equal(fold([rootFact(), failure('last', 1, 1), exhausted(1), exhausted(1)]).ok, true)
})
check('pure failure owner rejects invalid spec versions and limits', () => {
  for (const value of [{ version: 0, limit: 3 }, { version: 2, limit: 3 }, spec(0), spec(-1)]) {
    const result = p.applyFailure(identity('bad'), 1, p.forAuthority(run, root), value, 'confirmed-failure')
    assert.equal(result.ok, false)
    assert.equal(result.error, 'InvalidBudget')
  }
})
check('raw codec rejects old evidence and invalid spec without throwing', () => {
  const payload = { SessionId: ['SessionId', session], LogicalRunId: ['LogicalRunId', run],
    AuthorityRootUserMessageId: ['AuthorityRootUserMessageId', root], ProviderRun: ['ProviderRunIdentity', 'raw'],
    ConsecutiveFailureCount: 1, Reason: 'raw-confirmed-failure' }
  const envelope = (family, name, body) => JSON.stringify({ RuntimeId: ['RuntimeId', 'raw-runtime'],
    LocalSeq: ['LocalSeq', '1'], ObservedAt: '2026-01-01T00:00:00.000+00:00', EventId: ['EventId', 'raw-event'],
    Stream: ['Session', ['SessionId', session]], ProviderRun: ['ProviderRunIdentity', 'raw'],
    Fact: ['Agent', [family, [name, body]]] })
  const old = codec.deserialize(envelope('ProviderFailure', 'FailureRecorded', payload))
  assert.equal(old.ok, false)
  for (const budgetSpec of [{ Version: 0, Limit: 3 }, { Version: 2, Limit: 3 }, { Version: 1, Limit: 0 }, { Version: 1, Limit: -1 }]) {
    assert.equal(codec.deserialize(envelope('ProviderFailure', 'FailureRecorded', { ...payload, BudgetSpec: budgetSpec })).ok, false)
  }
  for (const name of ['FallbackCursorAdvanced', 'FallbackExhausted', 'FallbackSucceeded']) {
    const legacy = codec.deserialize(envelope('Fallback', name, { ...payload, PreviousOffset: 0, NextOffset: 1,
      FinalConsecutiveFailureCount: 12, FinalOffset: 3 }))
    assert.equal(legacy.ok, false)
  }
  const valid = codec.deserialize(envelope('ProviderFailure', 'FailureRecorded', { ...payload, BudgetSpec: { Version: 1, Limit: 3 } }))
  assert.equal(valid.ok, true, JSON.stringify(valid))
  return { oldFailureError: old.error, validEncoded: valid.value.line }
})
writeFileSync(output, JSON.stringify({ runtime: process.version, product, cases, passed: cases.every(value => value.passed) }, null, 2))
console.log(JSON.stringify({ runtime: process.version, cases: cases.length, failed: cases.filter(value => !value.passed).map(value => value.name) }))
assert.ok(cases.every(value => value.passed), JSON.stringify(cases.filter(value => !value.passed)))
