import assert from 'node:assert/strict'
import { mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { createHash, randomUUID } from 'node:crypto'

const [version, packageRoot, directory, typedModule] = process.argv.slice(2)
mkdirSync(directory, { recursive: true })
const load = path => import(pathToFileURL(join(packageRoot, 'dist', path)).href)
const journal = await load('Persistence/Journal/Surface.js')
const owner = await load('Participant/Provider/Attempt/Fallback/ProviderFailureSurface.js')
const store = await load('Persistence/EventStore/Surface.js')
const session = 'legal-root-scope'
const eventsDirectory = join(directory, 'wanxiangshu/events')
const bytes = () => readdirSync(eventsDirectory).filter(name => name.endsWith('.ndjson')).sort().map(name => {
  const value = readFileSync(join(eventsDirectory, name))
  return { name, bytes: value.length, sha256: createHash('sha256').update(value).digest('hex') }
})
const events = () => readdirSync(eventsDirectory).filter(name => name.endsWith('.ndjson')).flatMap(name =>
  readFileSync(join(eventsDirectory, name), 'utf8').trimEnd().split('\n').filter(Boolean).map(JSON.parse))
let opened = await journal.JournalSurface_bootWithWriterId(directory, 'writer-old-root', `runtime-a-${process.pid}`, process.pid, new Date().toISOString())
const measured = { version, pid: process.pid, execPath: process.execPath }
try {
  assert.equal(opened.ok, true)
  measured.rootA = await owner.acceptHumanRoot(opened.journal, session, 'root-a', 'engineer')
  assert.equal(measured.rootA.ok, true)
  const original = events().find(event => event.payload?.Fact?.[1]?.[1]?.[0] === 'AuthorityRootAccepted')
  assert.ok(original)
  const root = original.payload.Fact[1][1][1]
  journal.JournalSurface_dispose(opened.journal)
  opened = null
  const closer = store.create(directory, 'writer-legal-closure')
  try {
    const id = randomUUID().replaceAll('-', '')
    measured.close = await store.append(closer, [{
      id, stream: original.stream_id, type: 'JournalEnvelope', parents: [original.event_id], payloadRefs: [],
      payload: {
        ...original.payload, EventId: ['EventId', id], RuntimeId: ['RuntimeId', 'runtime-legal-closure'], LocalSeq: ['LocalSeq', '1'],
        Fact: ['Agent', ['Prompt', ['AuthorityLogicalRunClosed', {
          SessionId: root.SessionId, LogicalRunId: root.LogicalRunId,
          AuthorityRootUserMessageId: root.AuthorityRootUserMessageId,
          RootKind: 'HumanRoot', ClosureWitness: 'independent-a-legally-closed',
        }]]],
      },
    }])
    assert.deepEqual(measured.close, { ok: true, cuts: [] })
  } finally {
    store.dispose(closer)
  }
  opened = await journal.JournalSurface_bootWithWriterId(directory, 'writer-new-root', `runtime-b-${process.pid}`, process.pid, new Date().toISOString())
  assert.equal(opened.ok, true)
  measured.rootB = await owner.acceptHumanRoot(opened.journal, session, 'root-b', 'engineer')
  assert.equal(measured.rootB.ok, true)
  measured.failure = await owner.recordConfirmedFailure(opened.journal, session, 'new-root-failure', 'confirmed failure')
  assert.deepEqual(measured.failure, { ok: true, outcome: 'RetryAuthorized' })
  measured.before = owner.snapshot(opened.journal, session)
  assert.equal(measured.before.failures, 1)
  measured.bytesBeforeLate = bytes()
  if (version === '695') {
    measured.late = await owner.recordConfirmedSuccess(opened.journal, session, 'old-root-late-success')
    assert.deepEqual(measured.late, { ok: true })
    assert.equal(owner.snapshot(opened.journal, session).failures, 0)
    measured.expectedOldContractVulnerability = true
  } else {
    const typed = await import(pathToFileURL(resolve(typedModule)).href)
    const { forProviderFailure } = await load('Composition/Durable/AgentJournalPortAdapter.js')
    const port = forProviderFailure(journal.JournalHandle__get_Journal(opened.journal))
    const rejected = await typed.recordSuccess(port, session, 'root-a', 'old-root-late-success')
    assert.equal(rejected.tag, 1)
    assert.match(rejected.fields[0], /different authority root/)
    measured.late = { ok: false, error: rejected.fields[0] }
    assert.deepEqual(owner.snapshot(opened.journal, session), measured.before)
    assert.deepEqual(bytes(), measured.bytesBeforeLate)
    measured.originalBytesPreservedAfterReject = true
    const current = await typed.recordSuccess(port, session, 'root-b', 'new-root-success')
    assert.equal(current.tag, 0)
    assert.equal(owner.snapshot(opened.journal, session).failures, 0)
    measured.currentSuccessAccepted = true
  }
  measured.after = owner.snapshot(opened.journal, session)
  measured.bytesAfter = bytes()
  measured.scope = 'Actual Journal/store and ledger commands after accepted durable logical-run closure; no Host completion measured.'
  writeFileSync(join(directory, 'result.json'), JSON.stringify(measured, null, 2) + '\n')
} finally {
  if (opened?.ok) journal.JournalSurface_dispose(opened.journal)
}
console.log(JSON.stringify({ version, pid: process.pid, accepted: true }))
