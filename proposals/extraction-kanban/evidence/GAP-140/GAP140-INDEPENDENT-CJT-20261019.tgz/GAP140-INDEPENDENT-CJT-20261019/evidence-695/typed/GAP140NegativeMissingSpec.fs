module GAP140NegativeMissingSpec

open Wanxiangshu.Foundation.Identity
open Wanxiangshu.Participant.Provider.Attempt.Fallback

let invalid =
    ProviderFailureFactCases.FailureRecorded
        {| SessionId = SessionId.create "s"
           LogicalRunId = LogicalRunId.create "l"
           AuthorityRootUserMessageId = AuthorityRootUserMessageId.create "r"
           ProviderRun = ProviderRunIdentity.create "p"
           ConsecutiveFailureCount = 1
           Reason = "missing persistent budget" |}
