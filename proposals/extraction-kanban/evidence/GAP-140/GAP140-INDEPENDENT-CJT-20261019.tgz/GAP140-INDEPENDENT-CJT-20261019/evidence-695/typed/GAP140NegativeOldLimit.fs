module GAP140NegativeOldLimit

open Wanxiangshu.Participant.Provider.Attempt.Fallback

let invalid (current: ProviderFailureProjection) =
    ProviderFailureProjection.mayRetry 99 current
