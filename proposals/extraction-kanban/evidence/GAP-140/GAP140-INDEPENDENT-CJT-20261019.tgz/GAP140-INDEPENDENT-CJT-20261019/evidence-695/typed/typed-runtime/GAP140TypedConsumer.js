
import { ProviderFailureBudget_attemptIdentity } from "./Participant/Provider/Attempt/FailureBudget.js";
import { ProviderRunIdentityModule_create, AuthorityRootUserMessageIdModule_create, LogicalRunIdModule_create, SessionIdModule_create } from "./Foundation/Identity.js";
import { ProviderFailureFactCases, ProviderFailureBudgetSpec } from "./Participant/Provider/Attempt/Fallback/Facts.js";
import { ProviderFailureAdvanceRejection, ProviderFailureProjectionModule_mayRetry, ProviderFailureProjectionModule_applyFailure, ProviderFailureProjectionModule_recordSuccess, ProviderFailureProjectionModule_forAuthority } from "./Participant/Provider/Attempt/Fallback/Projection.js";
import { FSharpResult$2, Result_DefaultWith } from "../fable_modules/fable-library-js.5.13.0/Result.js";
import { printf, toFail } from "../fable_modules/fable-library-js.5.13.0/String.js";
import { equals, Exception } from "../fable_modules/fable-library-js.5.13.0/Util.js";

function identity(session, logical, root, provider) {
    return ProviderFailureBudget_attemptIdentity(SessionIdModule_create(session), LogicalRunIdModule_create(logical), AuthorityRootUserMessageIdModule_create(root), ProviderRunIdentityModule_create(provider));
}

export function failureFact(session, logical, root, provider, limit, count) {
    let SessionId, LogicalRunId;
    return new ProviderFailureFactCases(/* FailureRecorded */ 0, [(SessionId = SessionIdModule_create(session), (LogicalRunId = LogicalRunIdModule_create(logical), {
        AuthorityRootUserMessageId: AuthorityRootUserMessageIdModule_create(root),
        BudgetSpec: new ProviderFailureBudgetSpec(1, limit),
        ConsecutiveFailureCount: count,
        LogicalRunId: LogicalRunId,
        ProviderRun: ProviderRunIdentityModule_create(provider),
        Reason: "independent typed committed failure",
        SessionId: SessionId,
    }))]);
}

export function exercise() {
    const spec = new ProviderFailureBudgetSpec(1, 3);
    const initial = ProviderFailureProjectionModule_forAuthority(LogicalRunIdModule_create("typed-run"), AuthorityRootUserMessageIdModule_create("typed-root"));
    const successId = identity("typed-session", "typed-run", "typed-root", "success-zero");
    const failureId = identity("typed-session", "typed-run", "typed-root", "failed");
    const zero = Result_DefaultWith((error) => toFail(printf("%A"))(error), ProviderFailureProjectionModule_recordSuccess(successId, initial));
    const first = Result_DefaultWith((error_1) => toFail(printf("%A"))(error_1), ProviderFailureProjectionModule_applyFailure(failureId, spec, 1, "confirmed", zero));
    const oldSuccess = ProviderFailureProjectionModule_recordSuccess(successId, first);
    const duplicate = ProviderFailureProjectionModule_applyFailure(failureId, spec, 1, "confirmed", first);
    const validFact = failureFact("typed-session", "typed-run", "typed-root", "failed", 3, 1);
    let factLimit;
    if (validFact.tag === 0) {
        const payload = validFact.fields[0];
        factLimit = payload.BudgetSpec.Limit;
    }
    else {
        throw new Exception("Expected a failure fact");
    }
    return {
        accepted: ((((ProviderFailureProjectionModule_mayRetry(initial) && ProviderFailureProjectionModule_mayRetry(first)) && (first.Budget.ConsecutiveFailureCount === 1)) && equals(first.BudgetSpec, spec)) && equals(oldSuccess, new FSharpResult$2(/* Error */ 1, [ProviderFailureAdvanceRejection.AlreadyObserved]))) && equals(duplicate, new FSharpResult$2(/* Error */ 1, [ProviderFailureAdvanceRejection.AlreadyObserved])),
        factLimit: factLimit,
        failures: first.Budget.ConsecutiveFailureCount,
    };
}

