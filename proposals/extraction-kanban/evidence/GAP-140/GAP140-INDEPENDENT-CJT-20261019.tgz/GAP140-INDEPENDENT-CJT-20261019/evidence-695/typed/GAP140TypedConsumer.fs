module GAP140TypedConsumer

open Wanxiangshu.Foundation.Identity
open Wanxiangshu.Participant.Provider.Attempt
open Wanxiangshu.Participant.Provider.Attempt.Fallback

let private identity session logical root provider =
    ProviderFailureBudget.attemptIdentity
        (SessionId.create session)
        (LogicalRunId.create logical)
        (AuthorityRootUserMessageId.create root)
        (ProviderRunIdentity.create provider)

let failureFact session logical root provider limit count =
    ProviderFailureFactCases.FailureRecorded
        {| SessionId = SessionId.create session
           LogicalRunId = LogicalRunId.create logical
           AuthorityRootUserMessageId = AuthorityRootUserMessageId.create root
           ProviderRun = ProviderRunIdentity.create provider
           BudgetSpec = { Version = 1; Limit = limit }
           ConsecutiveFailureCount = count
           Reason = "independent typed committed failure" |}

let exercise () =
    let spec: ProviderFailureBudgetSpec = { Version = 1; Limit = 3 }
    let initial = ProviderFailureProjection.forAuthority (LogicalRunId.create "typed-run") (AuthorityRootUserMessageId.create "typed-root")
    let successId = identity "typed-session" "typed-run" "typed-root" "success-zero"
    let failureId = identity "typed-session" "typed-run" "typed-root" "failed"
    let zero = ProviderFailureProjection.recordSuccess successId initial |> Result.defaultWith (fun error -> failwithf "%A" error)
    let first = ProviderFailureProjection.applyFailure failureId spec 1 "confirmed" zero |> Result.defaultWith (fun error -> failwithf "%A" error)
    let oldSuccess = ProviderFailureProjection.recordSuccess successId first
    let duplicate = ProviderFailureProjection.applyFailure failureId spec 1 "confirmed" first
    let validFact = failureFact "typed-session" "typed-run" "typed-root" "failed" 3 1
    let factLimit =
        match validFact with
        | ProviderFailureFactCases.FailureRecorded payload -> payload.BudgetSpec.Limit
        | _ -> failwith "Expected a failure fact"
    {| accepted =
        ProviderFailureProjection.mayRetry initial
        && ProviderFailureProjection.mayRetry first
        && first.Budget.ConsecutiveFailureCount = 1
        && first.BudgetSpec = Some spec
        && oldSuccess = Error AlreadyObserved
        && duplicate = Error AlreadyObserved
       factLimit = factLimit
       failures = first.Budget.ConsecutiveFailureCount |}
