module GAP140NegativeMissingIdentity

open Wanxiangshu.Participant.Provider.Attempt.Fallback

let invalid (current: ProviderFailureProjection) =
    ProviderFailureProjection.recordSuccess current
