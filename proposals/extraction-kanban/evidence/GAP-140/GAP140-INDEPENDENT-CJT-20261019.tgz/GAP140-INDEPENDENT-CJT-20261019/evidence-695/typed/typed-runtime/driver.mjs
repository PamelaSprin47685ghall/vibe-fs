import assert from 'node:assert/strict'
import { exercise } from './GAP140TypedConsumer.js'
const value=exercise()
assert.equal(value.accepted,true)
assert.equal(value.factLimit,3)
console.log(JSON.stringify(value))
