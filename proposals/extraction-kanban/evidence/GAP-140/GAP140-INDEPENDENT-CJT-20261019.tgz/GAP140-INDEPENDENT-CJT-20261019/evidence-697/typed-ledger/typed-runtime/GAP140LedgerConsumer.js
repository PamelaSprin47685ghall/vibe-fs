
import { ProviderFailureLedger_recordConfirmedSuccess } from "./Participant/Provider/Attempt/Fallback/Ledger.js";
import { ProviderRunIdentityModule_create, AuthorityRootUserMessageIdModule_create, SessionIdModule_create } from "./Foundation/Identity.js";

export function recordSuccess(port, session, root, provider) {
    return ProviderFailureLedger_recordConfirmedSuccess(port, SessionIdModule_create(session), AuthorityRootUserMessageIdModule_create(root), ProviderRunIdentityModule_create(provider));
}

