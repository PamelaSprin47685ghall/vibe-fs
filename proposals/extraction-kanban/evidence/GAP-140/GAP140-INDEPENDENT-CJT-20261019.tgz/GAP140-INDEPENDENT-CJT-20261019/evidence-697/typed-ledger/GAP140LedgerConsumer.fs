module GAP140LedgerConsumer

open Wanxiangshu.Foundation.Identity
open Wanxiangshu.Participant.Provider.Attempt.Fallback

let recordSuccess (port: ProviderFailureJournalPort) session root provider =
    ProviderFailureLedger.recordConfirmedSuccess
        port
        (SessionId.create session)
        (AuthorityRootUserMessageId.create root)
        (ProviderRunIdentity.create provider)
