module GAP140NegativeLedgerMissingRoot

open System.Threading.Tasks
open Wanxiangshu.Foundation.Identity
open Wanxiangshu.Participant.Provider.Attempt.Fallback

let recordSuccess (port: ProviderFailureJournalPort) session provider : Task<Result<unit, string>> =
    ProviderFailureLedger.recordConfirmedSuccess
        port
        (SessionId.create session)
        (ProviderRunIdentity.create provider)
