# GAP-140 independent C / J01 / T acceptance

Non-author review, 2026-10-19. No shared repository source/test edits. Node 26.6.0, Bun 1.3.14.

## Fixed products

- 695: SHA256 `80d2392e5ea301f984a36d64c9162bbc4948e9bfe11d460d0a3b5ccf831c4418`.
- Final 697: SHA256 `21a3409fe09a626976189b47349122c2e94b405b941d4536a5ad7e837817346f`.
- Both actually installed by npm, 124 packages. All 2076 packaged files matched the fixed tar. 697 before/after file hashes are retained. The only 695→697 differences are seven production JS files listed in `evidence-697/product-695-697-diff.json`.

## Results

1. C9 grouped scenarios ran on both Node/Bun for both products: accepted. Persistent limits 1/3/15; zero-count success identity; all-run dedupe through 40 success-ended episodes; conflicting identity/count/reason/spec; mutual failure/success; exhausted success never reopens; exhausted marker validation; missing/invalid BudgetSpec and old fallback raw decode rejection.
2. T base: actual 24 source files/12 `.fsi`, one positive Fable compilation and three intended failures. Missing BudgetSpec fails for the missing field; external-limit `mayRetry` fails as not-a-function; missing success identity fails by expected identity type. All production generated JS removed before runtime. The same unmodified emitted consumer ran against clean 695 and rebound clean 697 on Node/Bun. No additional compile count is claimed for the rebound.
3. T697 Ledger: actual 28 source files/14 `.fsi`, positive compilation plus a negative old signature missing authority root. Negative fails because ProviderRunIdentity is not AuthorityRootUserMessageId. Production generated JS removed before runtime. The same emitted `recordSuccess` program runs against the actual JournalPort and fixed697 Ledger on both Hosts. These are internal F# protocols, **not npm d.ts additions**.
4. J01 final: Node/Bun each wrote real Journal sessions with persisted limits 3 and 15. First versioned failure comes from the original compiled F# fact producer and actual AgentJournal; subsequent failures use the production ledger. Limit15 crosses default12 and only exhausts at15. Zero-count old success does not clear a later failure; mutually conflicting outcomes are rejected; wrong authority root writes no bytes; exhausted late failure writes nothing; success remains durably identified without reopening exhaustion. Four new OS cold readers (each Host reads both originals) preserve original byte counts/hashes, recover exact limit/count/exhaustion, and create no writer.
5. Actual legal closure counterexample: A accepted → A durably closed through real EventStore → B accepted → B failure. On695, the old success command, lacking source root, accepts late A success and clears B. On697, the same compiled F# Ledger consumer passes A root; rejection leaves every original byte unchanged. Legitimate B-root success clears the count. Both Node/Bun measured; all original NDJSON retained.

The 695 producer's first two fixture failures are retained, described in `README-695.md`. They are **review fixture mistakes**, not product defects: an invalid writer suffix, then an overstrict assumption that a new success after exhaustion must not persist its identity. Successful corrected runs used fresh `-v3` directories.

## Limits

This proves the stated contract, actual Journal/ledger operations, cold OS reads, and fixed-package F# consumption. It does **not** prove that every Host/workflow completion reaches the ledger with the right authority, nor concurrency arbitration or full COMMIT/Host recovery. The parent keeps GAP-140 DOING. No unknown investigation was resumed.

697 source review also confirmed Wire passes its frozen plan root and OrdinaryTurnWorkflow passes its reconciled turn root. Runtime rejection demonstrated here is a **ledger command** boundary; it is not represented as an observed Host incident.

The old endpoint in this independent comparison is fixed695, an earlier candidate from this work package. This comparison alone cannot classify the missing-root defect as introduced in this work package or already present before it. The parent retains that attribution separately.

## Portable replay

Extract the archive, then run with Node and Bun installed:

```sh
node probes/replay-runtime.mjs /absolute/extracted/archive /absolute/fresh/replay-directory
```

The runner installs the exact archived 697 tar in the fresh directory, checks its SHA, reconstructs only declared fixed-package runtime links, and runs C, the same archived emitted F# consumers, real Journal writes, four cold OS reads, and legal-root checks. It writes raw stdout/stderr, commands and child status. It never compiles a production implementation or falls back to repository dist.

This portable runner was itself actually executed once in a new directory and accepted. Its raw/status, original Journals and cold records are archived under `portable-replay`; no additional type compile is counted.

For actual type recompilation, the archive includes all exact F# inputs under each `typed*/source-contracts`, their SHA mapping, compiler outputs/errors, consumer source, and the portable compile scripts. Those scripts require a repository checkout with the declared Fable build dependencies and the matching owner project plan; check input bytes against archived mappings before reproducing. They use the repo's official Fable `compileOwnerProject`, never `dotnet build`. Do not count runtime replays as new type compilations.

Original final byte-preservation proofs live in each cold reader JSON and legal-root result. The archive manifest hashes every regular file. Runtime symlinks from original `/private/tmp` locations are omitted from the archive and reconstructed by the portable runner; `runtime-bindings.json` records the original bindings.
