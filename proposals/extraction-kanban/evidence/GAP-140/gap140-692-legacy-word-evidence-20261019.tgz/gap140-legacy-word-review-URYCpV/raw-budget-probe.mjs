import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { mkdirSync, readdirSync, readFileSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const [productArg, outputArg, childDirectory, childSession] = process.argv.slice(2)
const product = resolve(productArg)
const load = path => import(pathToFileURL(join(product, 'dist', path)))
const [store, journal, owner, envelopeCodec, factCodec] = await Promise.all([
  load('Persistence/EventStore/Surface.js'), load('Persistence/Journal/Surface.js'),
  load('Participant/Provider/Attempt/Fallback/ProviderFailureSurface.js'),
  load('Persistence/Journal/CodecSurface.js'), load('Persistence/Journal/FactCodecSurface.js'),
])

if (childDirectory) {
  const opened = await journal.JournalSurface_bootWithWriterId(childDirectory,
    'cold-reader', 'cold-runtime', process.pid, '2026-10-19T02:00:00Z')
  const result = { runtime: process.version, pid: process.pid, opened }
  if (opened.ok) {
    result.snapshot = owner.snapshot(opened.journal, childSession)
    result.hasSession = journal.JournalSurface_hasSession(opened.journal, childSession)
    journal.JournalSurface_dispose(opened.journal)
    delete result.opened.journal
  }
  console.log(JSON.stringify(result))
} else {
  const output = resolve(outputArg)
  mkdirSync(output, { recursive: true })
  const cases = [
    { name: 'missing-plain', reason: 'ordinary provider failure' },
    { name: 'missing-tip-word', reason: 'TipRuleId' },
    { name: 'missing-guideline-word', reason: 'PairProgrammingGuidelineAppended' },
    { name: 'unsupported-version-tip-word', reason: 'TipRuleId', spec: { Version: 2, Limit: 3 } },
    { name: 'zero-limit-plain', reason: 'ordinary provider failure', spec: { Version: 1, Limit: 0 } },
    { name: 'valid-three', reason: 'ordinary provider failure', spec: { Version: 1, Limit: 3 }, wantedValid: true },
  ]
  const observations = []
  const fileHashes = directory => {
    const path = join(directory, 'wanxiangshu', 'events')
    return Object.fromEntries(readdirSync(path).filter(name => name.endsWith('.ndjson'))
      .map(name => [name, createHash('sha256').update(readFileSync(join(path, name))).digest('hex')]))
  }
  for (const [index, scenario] of cases.entries()) {
    const directory = join(output, scenario.name)
    mkdirSync(directory)
    const session = `budget-${index}`
    let opened = await journal.JournalSurface_bootWithWriterId(directory,
      'seed', `runtime-${index}`, process.pid, '2026-10-19T00:00:00Z')
    assert.equal(opened.ok, true, JSON.stringify(opened.error))
    const accepted = await owner.acceptHumanRoot(opened.journal, session, 'root-message', 'engineer')
    assert.equal(accepted.ok, true, JSON.stringify(accepted))
    const identity = journal.JournalSurface_snapshot(opened.journal).sessionProjections[session].providerFailures
    assert.equal(identity.consecutiveFailureCount, 0)
    journal.JournalSurface_dispose(opened.journal)
    opened = null
    const eventId = createHash('sha1').update(`raw-budget-${index}`).digest('hex')
    const payload = {
      SessionId: ['SessionId', session], LogicalRunId: ['LogicalRunId', identity.logicalRun],
      AuthorityRootUserMessageId: ['AuthorityRootUserMessageId', identity.authorityRoot],
      ProviderRun: ['ProviderRunIdentity', 'raw-failed-run'], ConsecutiveFailureCount: 1,
      Reason: scenario.reason, ...(scenario.spec ? { BudgetSpec: scenario.spec } : {}),
    }
    const envelope = {
      RuntimeId: ['RuntimeId', `raw-runtime-${index}`], LocalSeq: ['LocalSeq', '1'],
      ObservedAt: '2026-10-19T01:00:00.000+00:00', EventId: ['EventId', eventId],
      Stream: ['Session', ['SessionId', session]], ProviderRun: ['ProviderRunIdentity', 'raw-failed-run'],
      Fact: ['Agent', ['ProviderFailure', ['FailureRecorded', payload]]],
    }
    const rawFact = JSON.stringify(envelope.Fact)
    const rawEnvelope = JSON.stringify(envelope)
    writeFileSync(join(directory, 'raw-fact.json'), rawFact + '\n')
    writeFileSync(join(directory, 'raw-envelope.json'), rawEnvelope + '\n')
    const directFact = factCodec.decode(rawFact)
    const directEnvelope = envelopeCodec.deserialize(rawEnvelope)
    let handle = store.create(directory, 'raw-writer')
    const parents = store.heads(handle, `journal/session/${session}`)
    const input = { id: eventId, stream: `journal/session/${session}`, type: 'JournalEnvelope',
      parents, payloadRefs: [], payload: envelope }
    const decodedEvent = envelopeCodec.decode({ eventId, eventType: input.type,
      streamId: input.stream, parents, payloadRefs: [], payload: envelope })
    const before = fileHashes(directory)
    const receipt = await store.append(handle, [input])
    const physicalEvent = store.read(handle, eventId)
    const after = fileHashes(directory)
    store.dispose(handle)
    handle = null
    const cold = JSON.parse(execFileSync(process.execPath,
      [process.argv[1], product, output, directory, session],
      { encoding: 'utf8', timeout: 15000, env: { ...process.env, WANXIANGSHU_NO_FATAL_EXIT: '1' } }))
    assert.notEqual(cold.pid, process.pid)
    observations.push({ scenario, directFact, directEnvelope, decodedEvent, input, receipt,
      physicalEvent, before, after, appendBytesUnchanged: JSON.stringify(before) === JSON.stringify(after), cold,
      unexpectedRawAcceptance: !scenario.wantedValid && receipt.ok === true })
    writeFileSync(join(output, 'partial-result.json'), JSON.stringify(observations, null, 2) + '\n')
  }
  const report = { runtime: process.version, executable: process.execPath, product, observations,
    scope: 'Actual fixed-pack codec plus real Journal authority seed, raw EventStore append and independent OS reader. Missing-spec/legacy-word outcomes are observations, not presupposed bugs. Direct Fact validation may differ from Envelope in this intermediate candidate.' }
  writeFileSync(join(output, 'result.json'), JSON.stringify(report, null, 2) + '\n')
  console.log(JSON.stringify(report, null, 2))
}
