# GAP-140 candidate 692: raw missing-budget and legacy-word investigation

Reviewer: d1_review_git. This is a limited non-author fixed-package investigation. No shared source or active dist was edited or consumed. GAP-140 remains under construction.

## Candidate and runtime

Actual package: `/private/tmp/gap140-candidate-692/wanxiangshu-0.9.0.tgz`.

SHA-256: `e4d0f606efba582592695da298010c152b8294ea63e071ddc5de34e83c5b89ac`.

The package's 2076 regular files were extracted privately and compared byte-for-byte with the actual tarball, including its bundled library. package-verification.json reports zero mismatches. The original old main package was removed from the private copied dependency directory before extracting 692, so no old main implementation was retained. The runtime dependency closure was copied from the previous independent gap159-clean-install-680 installation; its origin lock is retained. This is an exact actual 692 package consumed with a prior complete runtime dependency closure, not a newly resolved clean npm install. Initial offline install attempts were blocked by default-cache write permission and then missing registry cache metadata; both logs are preserved. No cache permission or system installation was changed, and active workspace dist was not a fallback.

Runtime: actual official Node v22.13.0 darwin-arm64, binary SHA-256 `5c79f8e198fd2456ea6660aaa6be218f9f44747f2306c7d0f5f97b087b2f2dfc`. Official archive SHA-256 `bc1e374e7393e2f4b20e5bbc157d02e9b1fb2c634b2f992136b38fb8ca2023b7`. Prior distribution/checksum receipts: `/private/tmp/cut-r1-node2213-evidence-20261019.tgz`, SHA-256 `440ad94586069ebaf9d8e15a70903182763d68bdcbfe0436c80bed235d5ce5f9`.

Command:

```sh
/private/tmp/cut-r1-node2213-review.VKeI2I/node-v22.13.0-darwin-arm64/bin/node /private/tmp/gap140-legacy-word-review-URYCpV/raw-budget-probe.mjs /private/tmp/gap140-legacy-word-review-URYCpV/runtime/node_modules/wanxiangshu /private/tmp/gap140-legacy-word-review-URYCpV/node-evidence
```

The probe exited 0 and preserved observations. It does not infer product acceptance from that exit. analyse.mjs separately checks the actual recorded outcomes, including the known incomplete direct-Fact validation, without rerunning any producer.

## Actual chain and outcome

Each case booted the real Journal, accepted an Engineer HumanRoot through the production PromptDispatcher owner, read its actual LogicalRun/root identity, disposed the writer, then submitted one raw JournalEnvelope through the real filesystem EventStore. The inputs bypass no-spec test builders: raw canonical Fact/Envelope JSON is retained in each case directory. Direct Fact decode, canonical Envelope decode and EventEnvelope decode were observed separately. A new OS process then booted the same actual package and read the durable result.

| Input | Direct Fact | Envelope/Event | Actual append | Cold budget |
|---|---|---|---|---|
| Missing spec, ordinary Reason | reject | reject | preparation failure, no write | 0 / no spec |
| Missing spec, Reason=TipRuleId | reject | reject | preparation failure, no write | 0 / no spec |
| Missing spec, Reason=PairProgrammingGuidelineAppended | reject | reject | preparation failure, no write | 0 / no spec |
| Version=2, Limit=3, Reason=TipRuleId | accepts (known intermediate gap) | reject | preparation failure, no write | 0 / no spec |
| Version=1, Limit=0 | accepts (known intermediate gap) | reject | preparation failure, no write | 0 / no spec |
| Version=1, Limit=3 | accepts | accepts | commits one event, zero cuts | 1 / version1 limit3 |

All five invalid raw appends returned failure, published no event at their exact ID and left existing NDJSON file hashes unchanged. All six independent cold readers opened successfully and observed the intended committed prefix. The valid positive control records the exact durable spec and failure. Complete inputs, codec errors, append receipts, byte hashes, physical read observations and cold PID/results are in node-evidence/result.json, with partial-result.json retained as a progressive receipt.

## Rejected hypothesis and remaining gap

The suspected legacy-word bypass was not reproduced. Thoth's missing-field error is restricted to the BudgetSpec path and undefined value; it does not echo Reason=TipRuleId or the guideline marker into the error. JournalIntegration therefore does not ignore that missing-spec error. PlanCut rejects the undecodable failure. This is a falsified hypothesis for these inputs, not a confirmed defect or a repaired issue.

Candidate 692 does confirm the root's pre-declared unfinished path: FactCodec.deserializeFact invokes validateFact, whose current branch validates ChatExecution schema only and lacks ProviderFailure BudgetSpec Version/positive-Limit validation. Thus the two well-shaped but invalid specs are accepted by direct FactCodecSurface.decode, while Envelope's new explicit validation and actual Journal reject them. Root already planned the corresponding validateFact branch. This archive must not be relabelled as a fully green codec matrix or whole GAP-140 acceptance.

The first rejected append uses the existing one-full-replay inference fallback; later cases in that producer process report that the generic replay budget is unavailable. The exact receipts retain this distinction. It does not create an ignored record or a write. That pre-existing exceptional fallback cost was already recorded during GAP-159 and is not solved by this investigation.

## Limits

The proof is actual Journal/raw EventStore admission and independent cold reading on Node 22.13. It does not prove the actual Host retry/physical-send chain, append-unknown behavior, final requirements, final FactCodec fix, release installation, or all operating systems. Those remain with the root's GAP-140 work package. R12-U1 was not investigated. The archive omits the 140 MB dependency/runtime tree and private npm cache but includes the exact package SHA, origin lock, probe and all small raw evidence needed to reproduce against the fixed package.
