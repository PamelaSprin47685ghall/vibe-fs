import assert from 'node:assert/strict'
import { readFileSync, writeFileSync } from 'node:fs'

const report = JSON.parse(readFileSync(new URL('./node-evidence/result.json', import.meta.url)))
assert.equal(report.runtime, 'v22.13.0')
assert.equal(report.observations.length, 6)
for (const observation of report.observations) {
  const valid = observation.scenario.wantedValid === true
  assert.equal(observation.directEnvelope.ok, valid)
  assert.equal(observation.decodedEvent.ok, valid)
  assert.equal(observation.receipt.ok, valid)
  assert.equal(observation.physicalEvent !== null, valid)
  assert.equal(observation.appendBytesUnchanged, !valid)
  assert.equal(observation.cold.opened.ok, true)
  assert.equal(observation.cold.snapshot.failures, valid ? 1 : 0)
  assert.deepEqual(observation.cold.snapshot.budgetSpec, valid ? { version: 1, limit: 3 } : null)
  if (observation.scenario.name.startsWith('missing-')) assert.equal(observation.directFact.ok, false)
}
const directFactGaps = report.observations.filter(item => !item.scenario.wantedValid && item.directFact.ok)
assert.deepEqual(directFactGaps.map(item => item.scenario.name), ['unsupported-version-tip-word', 'zero-limit-plain'])
const result = { runtime: report.runtime, journalNegativeControls: 5, journalPositiveControls: 1,
  independentColdReaders: 6, legacyWordBypassReproduced: false,
  knownIntermediateDirectFactValidationGaps: directFactGaps.map(item => item.scenario.name),
  note: 'Analysis of preserved observations only. No test rerun. This is not whole GAP-140 acceptance.' }
writeFileSync(new URL('./analysis.json', import.meta.url), JSON.stringify(result, null, 2) + '\n')
console.log(JSON.stringify(result, null, 2))
