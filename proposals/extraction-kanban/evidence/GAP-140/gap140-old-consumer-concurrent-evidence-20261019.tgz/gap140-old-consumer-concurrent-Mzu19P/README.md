# GAP-140 old actual consumer concurrency attribution

Reviewer: d1_review_git. Exactly one bounded old-package consumer run was performed. No shared source, original child probe or installed package file was modified. No repeat or broad test was added.

## Fixed comparison inputs

Old product: `/private/tmp/gap159-clean-install-680/node_modules/wanxiangshu`.

Its actual tarball SHA-256 is `7d218a541e0a3df334eaa34e1bf7018ca08906062d07e6fed22c68caae886ff6`; the prior independent 2076-file package equality receipt is copied as old-package-verification.json. The seven actual consumer/ledger/writer modules watched by this run have identical pre/post hashes in driver-result.json.

The child is an exact unmodified copy of `/private/tmp/gap140-host-workflow-review.T1gFXN/concurrent-child.mjs`, SHA-256 `a1003011132a42f914098e878fd6d46659518830ffc2f1f34684d3c6a4090709`. That same source drove the candidate 692 observation. It calls the actual SyncDelegate HandleTurn recovery consumer, establishes one real initial managed admission, observes exact Host-stop evidence, then presents two simultaneous identical provider failures. The ordinary production per-session Scheduler is deliberately bypassed.

Both the supplied 692 receipt and this old-package execution use actual Node v26.6.0. This runtime was chosen to preserve the comparison, not substituted for the separate Node22 minimum-version proofs. Executable SHA-256: `1ef99ea25fe70c9b67e7efe768ef8ee22148d3cabc703db6131b57aeb617d040`.

run-once.mjs creates a private owned store and routing HOME, clears inherited test/fatal opt-out state, then executes the exact child with a 22-second outer kill bound. The child has the same 8-second diagnostic wait as the supplied probe. The routing module is retained under home/.config/opencode and is independent of the user's configuration.

Command:

```sh
node /private/tmp/gap140-old-consumer-concurrent-Mzu19P/run-once.mjs
```

## Actual observed result

The old-package child and driver exited 1, signal null, not killed. Total elapsed time including initialization and cleanup was 9.64 seconds. The intended one-send condition was not met:

- Actual recovery SendPrompt call delta: 2 (3 prompts including the initial send).
- Actual physically persisted FailureRecorded facts containing the exact reason: 2.
- Folded failure count: 1, not exhausted.
- First observation handled true; the second waited for the third prompt's receipt. The bounded wait rejected after 8 seconds. Owned close released the pending test Host call, and the second observation then recorded that release error.
- closeRecovery completed: closed=true, no cleanupError.

physical.json retains the exact live prompt counts, observations, state and canonical failure events. stdout.log, stderr.log and driver-result.json retain the actual exit and diagnostic output. stderr contains the fixture's incidental `fatal: not a git repository` diagnostic; it is preserved and is not the reported cause of the bounded recovery refusal. There was no repeated run to hide that output.

original-692-physical.json is an unmodified copy of the supplied newer receipt. It likewise reports actual recovery send delta 2, two FailureRecorded facts, count 1 and successful owned close. The old consumer reproduction adds the missing attribution evidence: the same callable-consumer duplicate SendPrompt behavior existed before the GAP-140 persisted-budget repair. It is not merely inferred from the earlier raw-ledger duplicate-fact example.

## Interpretation and limits

This is a real application-consumer recovery path invoking its actual observable SendPrompt port, backed by the real Journal and writer. It proves duplicated consumer send calls under the probe's two concurrent HandleTurn observations. It is not an observation of two remote provider responses or a user external service; no such claim is made.

The probe intentionally bypasses ordinary production Scheduler serialization. Therefore it does not establish reachability through normally serialized public Host events. PromptDispatcher and exact physical-acceptance boundaries also remain distinct from this call-count observation. The residual should remain a concrete concurrent-consumer atomic-admission boundary; fold count 1 must not be presented as proof of a unique physical fact or send.

No fix is implemented or accepted by this archive. The existing queue/NoNewWrite capability investigation remains in `/private/tmp/gap140-concurrent-old-evidence-20261019.tgz` (SHA-256 `c01010f93b5cc5d045387ddc18a3f448095898c68ba22fb248632c27a482a450`). Whole GAP-140, the final FactCodec candidate and full-scope cold workflow remain with the root. R12-U1 was not investigated.
