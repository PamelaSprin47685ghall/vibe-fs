import { createHash } from 'node:crypto'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const output = dirname(fileURLToPath(import.meta.url))
const product = '/private/tmp/gap159-clean-install-680/node_modules/wanxiangshu'
const child = join(output, 'concurrent-child.mjs')
const home = join(output, 'home')
const store = join(output, 'store')
mkdirSync(join(home, '.config', 'opencode'), { recursive: true })
mkdirSync(store)
writeFileSync(join(home, '.config', 'opencode', 'wanxiangshu.mjs'), `export const routingProtocol = 2
export default function route(role) { return { model: 'provider/' + role + '-model', reasoning: 'none' } }
export const predictorConfiguration = () => ({state:'unconfigured',reason:null})
`)
const env = { ...process.env, HOME: home, USERPROFILE: home }
delete env.NODE_TEST_CONTEXT
delete env.WANXIANGSHU_NO_FATAL_EXIT
const sha = path => createHash('sha256').update(readFileSync(path)).digest('hex')
const watched = ['Participant/Provider/Attempt/Fallback/Ledger.js',
  'Participant/Provider/Attempt/Fallback/Projection.js', 'Participant/Provider/Attempt/Fallback/Retry.js',
  'Participant/Provider/Attempt/Fallback/Workflow.js', 'Composition/Durable/AgentJournalPortAdapter.js',
  'Persistence/Journal/EventStoreJournalWriter.js', 'Execution/Delegation/SyncDelegate/Surface.js']
const digest = () => Object.fromEntries(watched.map(path => [path, sha(join(product, 'dist', path))]))
const result = { runtime: process.version, executable: process.execPath, executableSha256: sha(process.execPath),
  product, home, store, childSha256: sha(child), before: digest(),
  scope: 'Exactly one old-680 consumer reproduction, same concurrent-child script as 692 and Node26 runtime. Intentionally bypasses ordinary per-session Scheduler; not an ordinary public Host reachability claim.' }
const started = performance.now()
try {
  const actual = await promisify(execFile)(process.execPath,
    [child, product, store, join(output, 'physical.json')],
    { env, cwd: output, timeout: 22000, maxBuffer: 8 * 1024 * 1024 })
  writeFileSync(join(output, 'stdout.log'), actual.stdout)
  writeFileSync(join(output, 'stderr.log'), actual.stderr)
  result.exit = { code: 0, signal: null }
} catch (error) {
  writeFileSync(join(output, 'stdout.log'), error.stdout ?? '')
  writeFileSync(join(output, 'stderr.log'), error.stderr ?? '')
  result.exit = { code: error.code, signal: error.signal, killed: error.killed, message: error.message }
}
result.elapsedMs = performance.now() - started
result.after = digest()
result.sourceStable = JSON.stringify(result.before) === JSON.stringify(result.after)
writeFileSync(join(output, 'driver-result.json'), JSON.stringify(result, null, 2) + '\n')
console.log(JSON.stringify(result, null, 2))
process.exitCode = result.exit.code === 0 ? 0 : 1
