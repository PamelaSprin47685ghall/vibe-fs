import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

assert.equal(process.version, 'v22.13.0')
const product = resolve(process.argv[2])
const [factCodec, envelopeCodec] = await Promise.all([
  import(pathToFileURL(join(product, 'dist/Persistence/Journal/FactCodecSurface.js'))),
  import(pathToFileURL(join(product, 'dist/Persistence/Journal/CodecSurface.js'))),
])
const cases = [
  ['missing-spec', undefined, false], ['null-spec', null, false], ['array-spec', [], false],
  ['missing-version', { Limit: 3 }, false], ['missing-limit', { Version: 1 }, false],
  ['null-version', { Version: null, Limit: 3 }, false], ['null-limit', { Version: 1, Limit: null }, false],
  ['version-zero', { Version: 0, Limit: 3 }, false], ['version-two', { Version: 2, Limit: 3 }, false],
  ['version-negative', { Version: -1, Limit: 3 }, false], ['version-fraction', { Version: 1.5, Limit: 3 }, false],
  ['version-string', { Version: '1', Limit: 3 }, false],
  ['limit-zero', { Version: 1, Limit: 0 }, false], ['limit-negative', { Version: 1, Limit: -1 }, false],
  ['limit-fraction', { Version: 1, Limit: 1.5 }, false], ['limit-string', { Version: 1, Limit: '3' }, false],
  ['valid-one', { Version: 1, Limit: 1 }, true], ['valid-three', { Version: 1, Limit: 3 }, true],
  ['valid-fifteen', { Version: 1, Limit: 15 }, true],
]
const observations = []
const observed = action => {
  try { return { result: action() } }
  catch (error) { return { thrown: { name: error.name, message: error.message, stack: error.stack } } }
}
for (const [name, spec, wanted] of cases) {
  const eventId = createHash('sha1').update(`codec695-${name}`).digest('hex')
  const failure = { SessionId: ['SessionId', 'codec-session'], LogicalRunId: ['LogicalRunId', 'codec-run'],
    AuthorityRootUserMessageId: ['AuthorityRootUserMessageId', 'codec-root'],
    ProviderRun: ['ProviderRunIdentity', 'codec-provider'], ConsecutiveFailureCount: 1,
    Reason: 'provider_error', BudgetSpec: spec }
  const fact = ['Agent', ['ProviderFailure', ['FailureRecorded', failure]]]
  const payload = { RuntimeId: ['RuntimeId', 'codec-runtime'], LocalSeq: ['LocalSeq', '1'],
    ObservedAt: '2026-10-19T00:00:00.000+00:00', EventId: ['EventId', eventId],
    Stream: ['Session', ['SessionId', 'codec-session']], ProviderRun: ['ProviderRunIdentity', 'codec-provider'], Fact: fact }
  observations.push({ name, wanted, factBytes: JSON.stringify(fact), envelopeBytes: JSON.stringify(payload),
    directFact: observed(() => factCodec.decode(JSON.stringify(fact))),
    envelope: observed(() => envelopeCodec.deserialize(JSON.stringify(payload))),
    event: observed(() => envelopeCodec.decode({ eventId, eventType: 'JournalEnvelope',
      streamId: 'journal/session/codec-session', parents: [], payloadRefs: [], payload })) })
}
const report = { runtime: process.version, executable: process.execPath,
  executableSha256: createHash('sha256').update(readFileSync(process.execPath)).digest('hex'),
  product, cases: observations.length, observations,
  scope: 'Only the corrected direct Fact BudgetSpec validation and matching Envelope/Event codec positive/negative controls. No concurrent ledger/Host reproduction or whole workflow acceptance.' }
writeFileSync(new URL('./result.json', import.meta.url), JSON.stringify(report, null, 2) + '\n')
for (const observation of observations) {
  for (const lane of ['directFact', 'envelope', 'event']) {
    assert.equal(observation[lane].thrown, undefined, `${observation.name}/${lane}: no uncaught exception`)
    assert.equal(observation[lane].result.ok, observation.wanted,
      `${observation.name}/${lane}: ${JSON.stringify(observation[lane])}`)
  }
}
console.log(JSON.stringify({ runtime: process.version, cases: observations.length,
  invalidCases: observations.filter(value => !value.wanted).length,
  validCases: observations.filter(value => value.wanted).length, codecObservations: observations.length * 3, accepted: true }))
