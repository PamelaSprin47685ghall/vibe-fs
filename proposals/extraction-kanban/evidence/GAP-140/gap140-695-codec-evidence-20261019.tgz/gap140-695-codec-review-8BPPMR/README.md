# GAP-140 fixed 695: direct-Fact correction and limited final review

Reviewer: d1_review_git. No shared source was edited. The scope is the corrected BudgetSpec codec branch and a read-only responsibility review. Concurrent ledger/Host probes were not rerun.

## Fixed actual package and runtime

Actual tarball: `/private/tmp/gap140-candidate-695/wanxiangshu-0.9.0.tgz`.

SHA-256: `80d2392e5ea301f984a36d64c9162bbc4948e9bfe11d460d0a3b5ccf831c4418`.

All 2076 regular files in the private product match the actual tarball before and after execution. The product was extracted separately beside the 692 private product, reusing that investigation's complete runtime dependency closure from the prior clean680 install. No active workspace dist/source fallback or new clean npm resolution is claimed. package-verification.json and package-post-verification.json retain equality and exact changed-file mapping.

Runtime: actual official Node v22.13.0 darwin-arm64, executable SHA-256 `5c79f8e198fd2456ea6660aaa6be218f9f44747f2306c7d0f5f97b087b2f2dfc`. The prior official distribution/checksum receipt remains `/private/tmp/cut-r1-node2213-evidence-20261019.tgz` (SHA-256 `440ad94586069ebaf9d8e15a70903182763d68bdcbfe0436c80bed235d5ce5f9`). No newer-runtime emulation was used.

## Actual corrected-branch execution

probe-contract.mjs directly calls the actual FactCodecSurface.decode, canonical Envelope deserialize and EventEnvelope decode. It exercises 14 illegal specs: missing/null/nonobject spec, missing/null fields, unsupported/negative/zero/fractional versions, and zero/negative/fractional limits. Positive controls use persisted limits 1, 3 and 15. Each input is retained in contract-result.json alongside each exact result.

Command:

```sh
/private/tmp/cut-r1-node2213-review.VKeI2I/node-v22.13.0-darwin-arm64/bin/node /private/tmp/gap140-695-codec-review-8BPPMR/probe-contract.mjs /private/tmp/gap140-legacy-word-review-URYCpV/runtime/node_modules/wanxiangshu695
```

The limited contract run exited 0: 17 cases, 51 codec observations, all expected results and no uncaught decoder exception. Illegal Version/Limit evidence is now rejected by direct Fact decode as well as Envelope/Event, closing the specific incomplete branch observed in candidate 692. Valid explicit limits remain accepted. This is a codec proof, not another Journal/Host/cold-workflow execution.

## Preserved review overreach

The first private probe additionally assumed JSON numeric strings must be rejected. It ran 19 cases and saved every result before its assertion failed on Version="1". The analogous Limit="3" also normalized successfully; all three actual codec lanes convert these through the existing Thoth int decoder. The original probe.mjs, result.json and node stderr/exit-1 output are preserved unchanged.

Root explicitly clarified that the frozen typed BudgetSpec contract requires valid decoded integers, not a new restriction on original JSON token kinds. The numeric-string assertion was stronger than that contract and is classified as a review fixture/assumption error, not a new product defect. Thoth Decode.fs.js has the same SHA-256 in actual 680, 692 and 695: `975e012731db81b846c9f1f6af6c4776f2c6eba1862bd417760a7e4226c04a99`. thoth-int-decoder.txt retains the unchanged source branch. The corrected limited matrix omits these two dialect-characterization inputs; it does not overwrite the first failure or claim the decoder changed between the two runs.

## Limited final responsibility and AGENTS review

Relative to actual 692, six product JS files differ: Facts, Projection, Ledger, ProviderFailureFactFold, Envelope and FactCodec. The exact paths are in package-verification.json. The extra Ledger appendNewFailure extraction and FactFold Result.map/applySuccess helper extraction preserve the inspected earlier branch decisions and error mapping; they are not silently treated as byte-identical paths.

BudgetSpec and its single isValid predicate belong in the pure Facts contract with existing Foundation identity dependencies. Both codec paths and Projection reuse that predicate. This does not create another budget owner or pull Host/Journal into the fact contract. Projection keeps the run's exact spec and observed identities, derives exhaustion at the limit and prevents old success from clearing a newer streak. None permits preflight only for a zero-failure state without observed failures. Retry/Evidence read that durable projection; the only production default choice remains the ledger's first unobserved failure with no established spec. The obsolete Surface default-budget argument and context-compression single-default statement were removed in the inspected repair. Old no-budget/Fallback decoding is refused rather than supplied a guessed limit.

The scope is the provider-failure contract, its codecs/fold/writer/retry consumers, projection observation surfaces and affected requirement fixtures. No extra routing authority, Host-stop evidence, resume permission, global lock, compatibility facade or online history migration was added by the inspected 695 change. The root retains the build/requirement/check and progress-report duties; this reviewer ran no dotnet build and made no shared edit. The earlier git diff --check was clean. The root's reported 75-file result includes skips/TODOs and is not relabelled as fully green here.

## Remaining evidence boundaries

Candidate 695 does not repair the independently confirmed pre-existing raw-ledger/callable SyncDelegate concurrent duplicate-fact/send boundary. The old/new attribution receipts remain separate. Fold count one is not proof of one physical fact or one consumer send. Whole-scope cold workflow and final real writer/commit-unknown behavior cannot be inferred from these codec cases.

The root is separately evaluating a narrow success expectedAuthorityRoot change after this candidate. This review neither approves unbuilt later bytes nor treats an unclosed-old-run probe as a proven Host incident. Keep this receipt labelled 695; a later candidate must retain or revalidate the changed proof surface as appropriate. GAP-140 is not marked DONE by this limited receipt. R12-U1 remains deferred and was not investigated.
