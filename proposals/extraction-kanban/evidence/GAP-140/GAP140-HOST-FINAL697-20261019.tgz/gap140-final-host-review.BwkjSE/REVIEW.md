# GAP-140 candidate 697 independent consumer review

Exact package: `/private/tmp/gap140-candidate-697/wanxiangshu-0.9.0.tgz`.
SHA-256: `21a3409fe09a626976189b47349122c2e94b405b941d4536a5ad7e837817346f`.

No shared source or installed package was edited. Installation used the fixed tar and explicit peers, with its own lock. All 2076 product files are byte-identical to the original tar after the experiments (`package-file-verification.json`).

## Package difference and review

Both 692 and 697 contain 2076 product files. Twelve JS files differ; the complete before/after SHA inventory is in `692-697-package-diff.json`. ProviderRecoveryWorkflow, Retry, NodeProcessHost and the bundled library are unchanged. The changes add shared BudgetSpec validation, validation at the physical fact boundary, the associated fold changes, success Root plumbing, and generated signatures. No new alternate retry or commit owner appears.

The success Root boundary is explicit and checked before a write:

- OrdinaryTurnWorkflow passes `turn.AuthorityRootUserMessageId` with the observed provider run.
- Wire passes the Root from the frozen `plan.Profile`, rather than reading a new Root from current projection.
- The ledger reads current state and rejects a different authority Root before `recordSuccessForCurrent` or append. Same-root success dedupe remains in the owned projection.
- The real AgentJournal adapter forwards the new typed signature. Both `.fsi` declarations and the generated call sites agree.

This is a static boundary review, supported by the final package call sites. It does not claim that these private probes execute the complete ordinary cold Workflow or Wire success chain.

The permanent 005/support fixtures were read without editing. They preserve separate real writer and cold-reader processes, native append/fsync/owned-release evidence, exact terminal phase assertions, duplicate failure send deltas, and cleanup in finally. The parent waits under owned tool supervision; the child does not independently reinterpret a timeout. The private-only `/private/tmp/` restriction has been removed. No new actionable defect was found in these fixtures.

## Actual fixed-package experiments

The four writer scenarios and the actual default 12-round chain were each run once on Node and once on Bun: ten producer processes and ten independent cold reader processes, all accepted. Full receipts, actual event bytes, stdout/stderr and exact scripts are retained.

| Scenario | Actual append facts | New Host SendPrompt | Cold failure count |
| --- | --- | --- | --- |
| writer already closed | 0; native target append not called | 0 | 0 |
| throw before native append | 0; product CommitUnknown at PhysicalAppend | 0 | 0 |
| throw after real append, fsync and owned release | 1; product CommitUnknown at StoreRelease | 0 | 1 |
| successful durable admission | 1 | 1 | 1 |

Each refusal is observed again with the same exact identity in the same runtime: no additional append or SendPrompt occurs. The call is already terminal and the handler returns false. This does not prove a still-active handler can safely replay a poisoned ledger.

The actual limit remains the unchanged product default 12. Failures 1 through 11 each cause one real Host-port SendPrompt call; failure 12 causes none. There are 12 FailureRecorded facts and exactly one RetryExhausted fact, with 12 total prompts including the initial request. Independent cold state is count 12 / exhausted true.

All producer runtimes close, cold processes exit, event descriptors are released, and no owned lock remains. Cold readers preserve original file bytes and create no event file for their reader writer identity. Send measurements refer to actual invocation of the controlled Host port, not to an external model-provider network call.

## Remaining boundaries

These checks found no new regression in the reviewed 697 scope. They do not close the parent card's atomic admission/send work or the cold ordinary Workflow prerequisite. A cold journal projection is not Host-stop evidence. The earlier 692 application-concurrency red remains archived separately; it was intentionally not rerun here. R12-U1 was not investigated.

The formatted SyncDelegate completion proves the original injected cause message and the physical phase. It does not expose typed Error identity/code, so those are not claimed as preserved at this consumer boundary. This limitation is recorded in each receipt.

The generation-692 initial Bun fault-binding errors and concurrent red artifacts remain in `GAP140-HOST-WRITER-AND-WORKFLOW-692-20261019.tgz` (SHA-256 `2157fcd474af7da5f5191805611508f66f17fec9e5f81d28ef983fdbd30d1b96`); the final green evidence does not replace them.

## Replay

Install the exact archived tar with the supplied package.json and package-lock.json. In a fresh output copy, run `node run.mjs HOST SCENARIO` for HOST `node` or `bun`, and SCENARIO `closed`, `before-physical`, `after-release`, `valid`, or `limit`. The runners refuse to overwrite existing output. The child consumer source is byte-identical to the final 692 private consumer; only the parent fixed package binding changes.

Only installed dependencies, the duplicate extracted package, and regenerable Bun caches are omitted from the compact evidence archive. `omissions.json` lists their hashes. No event bytes, logs, receipts, package tar, scripts or failure evidence are omitted.
