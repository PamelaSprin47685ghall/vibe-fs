import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import { createHash } from 'node:crypto'
const [host, scenario] = process.argv.slice(2)
const root = path.dirname(fileURLToPath(import.meta.url))
const product = path.join(root, 'node_modules', 'wanxiangshu')
const output = path.join(root, host + '-' + scenario)
if (fs.existsSync(output)) throw new Error('Refuse to overwrite evidence: ' + output)
const home = path.join(output, 'home')
const store = path.join(output, 'store')
fs.mkdirSync(path.join(home, '.config', 'opencode'), { recursive: true })
fs.mkdirSync(store, { recursive: true })
fs.writeFileSync(path.join(home, '.config', 'opencode', 'wanxiangshu.mjs'), `export const routingProtocol = 2
export default function route(role) { return { model: 'provider/' + role + '-model', reasoning: 'none' } }
export const predictorConfiguration = () => ({state:'unconfigured',reason:null})
`)
const env = { ...process.env, HOME: home, USERPROFILE: home }
delete env.NODE_TEST_CONTEXT
delete env.NODE_OPTIONS
delete env.WANXIANGSHU_NO_FATAL_EXIT
const executable = host === 'node' ? process.execPath : host
const run = promisify(execFile)
const hash = file => createHash('sha256').update(fs.readFileSync(file)).digest('hex')
const watched = ['Participant/Provider/Attempt/Fallback/Ledger.js', 'Participant/Provider/Attempt/Fallback/Projection.js',
  'Participant/Provider/Attempt/Fallback/Retry.js', 'Participant/Provider/Attempt/Fallback/Workflow.js',
  'Composition/Durable/AgentJournalPortAdapter.js', 'Persistence/Journal/EventStoreJournalWriter.js']
const digest = () => Object.fromEntries(watched.map(file => [file, hash(path.join(product, 'dist', file))]))
const result = { host, scenario, product, executable, before: digest(), outcomes: [],
  tgz: '/private/tmp/gap140-candidate-697/wanxiangshu-0.9.0.tgz',
  tgzSha256: hash('/private/tmp/gap140-candidate-697/wanxiangshu-0.9.0.tgz') }
async function child(name, args) {
  const started = performance.now()
  try {
    const actual = await run(executable, args, { env, cwd: output, timeout: 30000, maxBuffer: 8 * 1024 * 1024 })
    fs.writeFileSync(path.join(output, name + '.stdout.log'), actual.stdout)
    fs.writeFileSync(path.join(output, name + '.stderr.log'), actual.stderr)
    result.outcomes.push({ name, code: 0, elapsedMs: performance.now() - started })
    return true
  } catch (error) {
    fs.writeFileSync(path.join(output, name + '.stdout.log'), error.stdout ?? '')
    fs.writeFileSync(path.join(output, name + '.stderr.log'), error.stderr ?? '')
    result.outcomes.push({ name, code: error.code, signal: error.signal, killed: error.killed, message: error.message,
      elapsedMs: performance.now() - started })
    return false
  }
}
const receipt = path.join(output, 'physical.json')
const limit = scenario === 'limit'
const physicalArgs = limit ? [product, store, receipt] : [product, store, scenario, receipt]
if (await child('physical', [path.join(root, limit ? 'limit-child.mjs' : 'physical-child.mjs'), ...physicalArgs])) {
  await child('cold', [path.join(root, limit ? 'cold-limit-child.mjs' : 'cold-child.mjs'), product, receipt, path.join(output, 'cold.json')])
}
result.after = digest()
result.sourceStable = JSON.stringify(result.before) === JSON.stringify(result.after)
result.accepted = result.sourceStable && result.outcomes.length === 2 && result.outcomes.every(item => item.code === 0)
fs.writeFileSync(path.join(output, 'result.json'), JSON.stringify(result, null, 2) + '\n')
console.log(JSON.stringify({ host, scenario, accepted: result.accepted, outcomes: result.outcomes }))
if (!result.accepted) process.exitCode = 1
