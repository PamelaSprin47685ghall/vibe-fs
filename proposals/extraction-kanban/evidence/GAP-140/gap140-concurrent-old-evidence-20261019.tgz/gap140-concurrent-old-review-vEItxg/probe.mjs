import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { mkdirSync, readdirSync, readFileSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const [productArg, outputArg] = process.argv.slice(2)
const product = resolve(productArg)
const output = resolve(outputArg)
mkdirSync(output, { recursive: true })
const load = path => import(pathToFileURL(join(product, 'dist', path)))
const [journal, owner] = await Promise.all([
  load('Persistence/Journal/Surface.js'),
  load('Participant/Provider/Attempt/Fallback/ProviderFailureSurface.js'),
])
const observations = []
for (const mode of ['sequential', 'concurrent']) {
  const directory = join(output, mode)
  mkdirSync(directory)
  const opened = await journal.JournalSurface_bootWithWriterId(directory,
    'same-identity-writer', 'same-identity-runtime', process.pid, '2026-10-19T00:00:00Z')
  assert.equal(opened.ok, true, JSON.stringify(opened.error))
  let results
  let snapshot
  try {
    assert.equal((await owner.acceptHumanRoot(opened.journal,
      'same-session', 'same-root', 'engineer')).ok, true)
    const record = () => owner.recordConfirmedFailure(opened.journal,
      owner.budget.defaultBudget, 'same-session', 'same-provider', 'same-reason')
    if (mode === 'concurrent') results = await Promise.all([record(), record()])
    else results = [await record(), await record()]
    snapshot = owner.snapshot(opened.journal, 'same-session')
  } finally { journal.JournalSurface_dispose(opened.journal) }
  const files = readdirSync(join(directory, 'wanxiangshu', 'events'))
    .filter(name => name.endsWith('.ndjson')).map(name => {
      const bytes = readFileSync(join(directory, 'wanxiangshu', 'events', name), 'utf8')
      return { name, bytes, sha256: createHash('sha256').update(bytes).digest('hex') }
    })
  const events = files.flatMap(file => file.bytes.trim().split('\n').filter(Boolean).map(JSON.parse))
  const failureEvents = events.filter(event => event.payload?.Fact?.[1]?.[1]?.[0] === 'FailureRecorded')
  assert.equal(snapshot.failures, 1)
  assert.deepEqual(results, [{ ok: true, outcome: 'RetryAuthorized' }, { ok: true, outcome: 'RetryAuthorized' }])
  assert.equal(failureEvents.length, mode === 'concurrent' ? 2 : 1)
  observations.push({ mode, directory, results, snapshot, failureFacts: failureEvents.length,
    failureEventIds: failureEvents.map(event => event.event_id), files })
}
const report = { runtime: process.version, executable: process.execPath, pid: process.pid, product,
  api: 'Old recordConfirmedFailure(handle, defaultBudget, session, providerRun, reason)',
  observations, scope: 'Actual old ledger plus actual Journal writer. Concurrent duplicate commands can append two identical FailureRecorded facts while the fold count stays one. Sequential control writes one. No Host or Redispatch was invoked or measured, so this is not evidence of double sending.' }
writeFileSync(join(output, 'result.json'), JSON.stringify(report, null, 2) + '\n')
console.log(JSON.stringify(report, null, 2))
