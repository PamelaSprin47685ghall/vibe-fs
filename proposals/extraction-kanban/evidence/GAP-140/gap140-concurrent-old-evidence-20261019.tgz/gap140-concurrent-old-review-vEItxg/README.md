# GAP-140 concurrent ledger attribution: pre-existing on fixed package 680

Reviewer: d1_review_git. No shared source was edited. This is an attribution investigation, not a whole-GAP acceptance test or an implementation of atomic admission.

## Actual old-package control

Actual previously clean-installed package: `/private/tmp/gap159-clean-install-680/node_modules/wanxiangshu`.

Original tarball: `/private/tmp/gap159-candidate-680/wanxiangshu-0.9.0.tgz`, SHA-256 `7d218a541e0a3df334eaa34e1bf7018ca08906062d07e6fed22c68caae886ff6`. All 2076 regular files in the actual installation match that tarball byte-for-byte; package-verification.json preserves this check.

The four relevant Ledger/Projection/Retry/ProviderFailureSurface source files have no diff between the GAP-159 closing commit c385b8fab and the pre-GAP140 baseline 0a7a534182310a6e17bbdadcd120008affa669fc. The retained empty provider-files-680-commit-to-pre-gap140.diff records that narrow relationship. This does not claim all package 680 bytes equal every later baseline byte.

Runtime: actual official Node v22.13.0 darwin-arm64. Executable SHA-256 `5c79f8e198fd2456ea6660aaa6be218f9f44747f2306c7d0f5f97b087b2f2dfc`. Prior official archive/checksum/runtime receipts remain `/private/tmp/cut-r1-node2213-evidence-20261019.tgz`, SHA-256 `440ad94586069ebaf9d8e15a70903182763d68bdcbfe0436c80bed235d5ce5f9`.

Command:

```sh
/private/tmp/cut-r1-node2213-review.VKeI2I/node-v22.13.0-darwin-arm64/bin/node /private/tmp/gap140-concurrent-old-review-vEItxg/probe.mjs /private/tmp/gap159-clean-install-680/node_modules/wanxiangshu /private/tmp/gap140-concurrent-old-review-vEItxg/node-evidence
```

The probe boots the actual Journal, accepts one real Engineer HumanRoot, and calls the old actual recordConfirmedFailure API with its former defaultBudget argument. Both calls use the same session, ProviderRun and reason. It runs one sequential positive control and one Promise.all concurrent counterexample, in separate physical directories.

| Actual old-package scenario | Returned outcomes | Folded count | Physical FailureRecorded facts |
|---|---|---|---|
| Two sequential calls | RetryAuthorized, RetryAuthorized | 1 | 1 |
| Two Promise.all calls | RetryAuthorized, RetryAuthorized | 1 | 2 |

The probe exited 0 because it explicitly checks and preserves these observed old behaviors. It does not label the concurrent result a product pass. Complete canonical NDJSON bytes, SHA-256 values, unique physical event IDs, snapshots and outcomes are in node-evidence/result.json. No private fake journal/append port was substituted.

Root's separate candidate 694 observation is copied unmodified as root-694-observation.json: its actual Journal also records count 1 but two physical FailureRecorded facts and returns two RetryAuthorized outcomes. This reviewer did not rerun candidate 694. The old actual-package comparison establishes that this raw-ledger concurrent-command behavior predates the GAP-140 changes; it must not be attributed to the new persisted spec or whole-run identity retention.

No Host, Retry.Redispatch or physical provider send was invoked or measured here. Two authorized ledger return values and two facts do not by themselves prove two sends. The production ordinary scheduler/session and PromptDispatcher boundaries require their own actual-consumer evidence. Fold idempotence is also not proof that a fact was physically written once. The residual should remain an explicit raw-ledger atomic-admission sub-boundary if not repaired in the current package.

## Existing NoNewWrite and prepare capability

The inspected current source does not expose a domain decision callback that can execute atomically with a no-write result:

- IJournalWriter.Append accepts an already-built Fact; EventStoreJournalWriter.Append allocates a fresh event ID and queues it. RunAcceptedAppend waits for the previous write, then appends that already-chosen fact. The domain read/decision happened earlier in Ledger.
- IEventStore.Append accepts already-built EventEnvelope values. ICanonicalIntegrator.PrepareLive validates those values against its Current; it does not ask Ledger whether to create a fact.
- Store's NoNewWrite is a private physical append classification. It is reached for an empty batch, existing event identity or physical NoAppend; same-failure domain facts currently receive different GUID event IDs, so this path does not deduplicate them.
- Existing append errors distinguish no physical write, unknown commit and release failure. Those distinctions must remain if a dynamic decision contract is added; a no-write domain result is not permission to reinterpret Unknown or resend.

The existing writer owner already has an appropriate same-writer ordering point: after RunAcceptedAppend's do!previous and before building/committing the next business envelope. A future narrow callback contract could let the domain-owned Ledger read the current projection and choose NoWrite with its existing outcome or one append fact. It should reuse that queue rather than create a global mutex, cache or second copy of failure dedupe. It must avoid allocating/publishing a new envelope/revision for a pure duplicate result and preserve writer close/poison/unknown semantics.

That extension is not already implemented. Covering distinct writers/processes would additionally require an explicit fresh-current decision under the appropriate store arbitration boundary; a process-local writer queue alone proves only same-writer atomicity. No new framework or broad cross-process claim is proposed from the present example.

## Limits

This archive establishes old-versus-current attribution and a read-only capability survey. It does not prove a fixed atomic-admission design, whole GAP-140, actual retry/send effects or final FactCodec validation. No further broad test was run, no shared source was modified, and R12-U1 was not investigated.
